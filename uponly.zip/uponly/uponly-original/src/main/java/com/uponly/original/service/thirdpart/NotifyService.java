package com.uponly.original.service.thirdpart;

import com.uponly.original.dto.OriginalOrder;
import com.uponly.original.vo.DistributeBonusesVo;
import com.uponly.original.vo.OriginalOrderVo;
import com.uponly.original.vo.RequestNotifyVo;

import java.util.Map;

public interface NotifyService {


    void validate(RequestNotifyVo requestNotifyVo) throws Exception;

    Map<String, Object> getBalance(RequestNotifyVo requestNotifyVo,Boolean flag) throws Exception;

    Map<String, Object> bettingOrders(OriginalOrderVo originalOrder) throws Exception;

    void distributeBonuses(DistributeBonusesVo distributeBonuses) throws Exception;
}
