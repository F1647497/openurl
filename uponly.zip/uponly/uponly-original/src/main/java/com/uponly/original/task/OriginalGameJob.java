package com.uponly.original.task;


import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.uponly.original.common.constant.ApiConstant;
import com.uponly.original.common.constant.CommonConstant;
import com.uponly.original.dto.OriginalGame;
import com.uponly.original.service.GameService;
import com.uponly.original.util.RestTemplateUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.util.TextUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@Component
@Slf4j
public class OriginalGameJob extends AbstractBaseJob {

    @Autowired
    private RestTemplateUtil restTemplateUtil;

    @Value("${original.api.url}")
    private String baseUrl;

    @Autowired
    private GameService gameService;


    @Scheduled(cron = "10 * * * * ?")
    @Override
    public void execute() {
        pullThridPartGames();
    }

    private void pullThridPartGames() {
        try {
            String apiUrl = String.format(baseUrl + "%s", ApiConstant.GET_GAME_SUFFIX);
            JSONObject result = restTemplateUtil.post(apiUrl, null, new HashMap<>());
            List<OriginalGame> data = this.getData(result);
            data.stream().forEach(d -> gameService.insertPlus(d));
        } catch (Exception ex) {
            log.error("原创游戏同步失败:{}", ex.getMessage());
            ex.printStackTrace();
        }
    }

    private List<OriginalGame> getData(JSONObject result) {
        List<OriginalGame> listOriginlGame = new ArrayList<>();
        if (!ObjectUtils.isEmpty(result) && result.getInteger("code") == CommonConstant.ZERO) {
            JSONArray list = result.getJSONObject("data").getJSONArray("list");
            for (Object obj : list) {
                if (!ObjectUtils.isEmpty(obj)) {
                    JSONObject jsonObject = (JSONObject) obj;
                    String id = TextUtils.isEmpty(jsonObject.getString("id")) ? "" : jsonObject.getString("id");
                    String gameId = TextUtils.isEmpty(jsonObject.getString("gameId")) ? "" : jsonObject.getString("gameId");
                    String name = TextUtils.isEmpty(jsonObject.getString("name")) ? "" : jsonObject.getString("name");
                    String provider = TextUtils.isEmpty(jsonObject.getString("provider")) ? "" : jsonObject.getString("provider");
                    String gameCategory = TextUtils.isEmpty(jsonObject.getString("gameCategory")) ? "" : jsonObject.getString("gameCategory");
                    String gameType = TextUtils.isEmpty(jsonObject.getString("gameType")) ? "" : jsonObject.getString("gameType");
                    String gameIcon = TextUtils.isEmpty(jsonObject.getString("gameIcon")) ? "" : jsonObject.getString("gameIcon");
                    String betLimit = TextUtils.isEmpty(jsonObject.getString("betLimit")) ? "" : jsonObject.getString("betLimit");
                    String typeDescription = TextUtils.isEmpty(jsonObject.getString("typeDescription")) ? "" : jsonObject.getString("typeDescription");
                    String technology = TextUtils.isEmpty(jsonObject.getString("technology")) ? "" : jsonObject.getString("technology");
                    String platform = TextUtils.isEmpty(jsonObject.getString("platform")) ? "" : jsonObject.getString("platform");
                    Integer demoGameAvailable = jsonObject.getBoolean("demoGameAvailable") ? CommonConstant.ONE : CommonConstant.ZERO;
                    Integer realTime = jsonObject.getBoolean("realTime") ? CommonConstant.ONE : CommonConstant.ZERO;
                    String gameUrl = TextUtils.isEmpty(jsonObject.getString("url")) ? "" : jsonObject.getString("url");
                    OriginalGame gameDto = OriginalGame.builder().thridId(id).gameId(gameId)
                            .gameName(name).gameType(gameType).typeDescription(typeDescription).
                            technology(technology).platform(platform).gameUrl(gameUrl).
                            demoGameAvailable(demoGameAvailable).realTime(realTime).
                            provider(provider).gameCategory(gameCategory).gameIcon(gameIcon).
                            betLimit(betLimit).build();
                    listOriginlGame.add(gameDto);
                }
            }
        }
        return listOriginlGame;
    }
}
