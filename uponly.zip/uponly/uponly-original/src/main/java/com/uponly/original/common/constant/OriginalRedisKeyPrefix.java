package com.uponly.original.common.constant;

public interface OriginalRedisKeyPrefix {

    String CASINO_USER_GAME_FAVORITES = "original:user:game:favorites:%s";
    String CASINO_GAME_GAMEID_ENTITY_KEY = "original:game:gameid:entity";

    String userInfoToken = "original:user:tokenInfo:cache:";
    //用户信息缓存
    String USER_INFO = "original:user_info:";

    //游玩id
    String session_id = "original:user:session:id:";

    String casino_banner_cache = "original:banner:cache:";
}
