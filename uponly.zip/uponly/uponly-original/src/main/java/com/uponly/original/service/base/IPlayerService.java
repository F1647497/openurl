package com.uponly.original.service.base;

import com.uponly.original.vo.DistributeBonusesVo;
import com.uponly.original.vo.OriginalOrderVo;
import com.uponly.original.vo.RequestNotifyVo;

import java.util.Map;

public interface IPlayerService {

    Map<String,Object>  getBalance(RequestNotifyVo requestNotifyVo, Boolean flag) throws Exception;

    Map<String,Object> bettingOrders(OriginalOrderVo originalOrder) throws Exception;

    Map<String,Object> distributeBonuses(DistributeBonusesVo distributeBonuses) throws Exception;

    Map<String,Object> cancel(DistributeBonusesVo distributeBonuses) throws Exception;


}
