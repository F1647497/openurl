package com.uponly.original.task;

import cn.hutool.core.thread.ExecutorBuilder;
import cn.hutool.core.thread.ThreadFactoryBuilder;
import com.alibaba.fastjson2.JSON;
import com.alibaba.fastjson2.JSONObject;
//import com.uponly.casino.admin.vo.OrderVO;
//import com.uponly.casino.common.constant.CommonConstant;
//import com.uponly.casino.mapper.OrderMapper;
//import com.uponly.casino.provider.service.UserInfoService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.util.CollectionUtils;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;


@Slf4j
public abstract class AbstractReportJob {

    @Autowired
    protected RedissonClient redissonClient;

//    @Autowired
//    protected UserInfoService userInfoService;
//
//    @Autowired
//    protected OrderMapper orderMapper;

    @Autowired
    protected KafkaTemplate<String, String> kafkaTemplate;


    private static final ExecutorService executor = ExecutorBuilder.create()
            .setCorePoolSize(10)
            .setMaxPoolSize(20)
            .setWorkQueue(new ArrayBlockingQueue<>(100))
            .setThreadFactory(ThreadFactoryBuilder.create().setNamePrefix("kfk-future-").build())
            .build();


    public void execute() {
        try {
            List<Object> dataList = fetchData();
            if (CollectionUtils.isEmpty(dataList)) {
                return;
            }
            for (Object data : dataList) {
                String topic = kafkaTopic();
                String key = kafkaKey(data);
                String kfkData = kafkaData(data);

                if (StringUtils.isBlank(kfkData)) {
                    log.error("【注单上报】上报失败，kafkaData为空，data={}，", data);
                    continue;
                }

                CompletableFuture<SendResult<String, String>> future = kafkaTemplate.send(topic, kfkData); //key
                future.whenCompleteAsync((n, ex) -> {
                    if (ex != null) {
                        log.error("【注单上报】上报失败，data={},exception={}", kfkData, ex.getMessage(), ex);
                    } else {
                        try {
                            updateData(data);
                        } catch (Exception e) {
                            log.error("【注单上报】更新数据状态失败，data={},exception={}", kfkData, e.getMessage(), e);
                        }
                    }
                }, executor);
            }
        } catch (Exception e) {
            log.error("【注单上报】Job发生异常：exception={} ", e.getMessage(), e);
        }
    }

    protected abstract String kafkaTopic();

    protected abstract String kafkaKey(Object data);

    protected abstract String kafkaData(Object data);

    //获取需上报的源数据
    protected abstract List<Object> fetchData();

    //上报成功更新数据库状态
    protected abstract void updateData(Object data);


    protected String buildKafkaMessage(String messageType, JSONObject body) {
        return buildKafkaMessage(messageType, body, System.currentTimeMillis());
    }

    //组装kafka消息体
    protected String buildKafkaMessage(String messageType, JSONObject body, long ts) {
        JSONObject msgJson = new JSONObject();
        msgJson.put("messageType", messageType);
        msgJson.put("messageBody", body);
        msgJson.put("partion", 0);
        msgJson.put("messageId", UUID.randomUUID());
        msgJson.put("ts", ts);
        return msgJson.toJSONString();
    }


    /**
     * 获取单笔注单的有效流水
     *
     * @param betAmount  投注金额
     * @param gameResult 游戏结果
     * @return 有效流水
     */
    public BigDecimal getEffectiveAmount(BigDecimal betAmount, String gameResult) {
        List<JSONObject> betList = JSON.parseArray(gameResult).toList(JSONObject.class);

        return betList.stream()
                .filter(order -> {
                    String result = order.getString("result").toLowerCase();
                    return result.contains("tie") || "push".equals(result);
                }).peek(order -> {
                    log.info("【注单上报】发现tie或push注单，order={},其流水effectiveAmount={}", order, (betAmount.subtract(order.getBigDecimal("payout"))));
                }).map(order -> order.getBigDecimal("payout"))
                .reduce(betAmount, BigDecimal::subtract);
    }

    /**
     * 判断注单的settleAt是否超过指定的时长
     *
     * @return true: 超时 false: 未超时
     */
//    public static boolean isSettleAtTimeout(OrderVO order) {
//        Date settleAt = order.getSettleAt();
//        return System.currentTimeMillis() - settleAt.getTime() > CommonConstant.CASINO_ORDER_HISTORY_TIMEOUT;
//    }


}
