package com.uponly.original.util;


import java.time.Instant;

public class UidUtil {

    /**
     * 我方OrderNo
     *
     * @param userId 用戶Id
     * @return String
     */
    public static String getOrderNo(String userId) {
        return userId+String.format("%03d", (int)(Math.random() * 1000))+ Instant.now().getEpochSecond();
    }

}
