package com.uponly.original.vo;


import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Data
public class RequestNotifyVo implements Serializable {

    private Long uid;

    private String token;

    private String sign;

}
