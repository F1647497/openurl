package com.uponly.original.common.utils;


import com.alibaba.fastjson2.JSON;
import com.alibaba.fastjson2.JSONArray;
import com.alibaba.fastjson2.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.List;

@Slf4j
public class MyJSONUtil {


    public static JSONObject analysis2Data(String jsonStr) {
        log.info("【钱包服务】请求获取用户余额成功，data={}", jsonStr);
        JSONObject jsonObject = JSON.parseObject(jsonStr);
        if (jsonObject.getInteger("code") == 0) {
            return jsonObject.getJSONObject("data");
        } else {
            log.error("【钱包服务】请求用户余额失败，data={}", jsonStr);
        }
        return null;
    }

    public static JSONObject analysis(String jsonStr) {
        log.info("【钱包服务】调用成功，返回 data={}", jsonStr);
        return JSON.parseObject(jsonStr);
    }

    public static JSONObject packageJson(JSONObject data, String msgData) {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("messageType", msgData);
        jsonObject.put("messageBody", data);
        log.info("【钱包/用户】组装请求数据，data={}", jsonObject);
        return jsonObject;
    }

    public static JSONObject packageJson(Object data, String msgData) {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("messageType", msgData);
        jsonObject.put("messageBody", JSON.toJSON(data));
        log.info("【钱包/用户】组装请求数据，data={}", jsonObject);
        return jsonObject;
    }


    public static JSONObject userList(List<Long> data, String msgData) {

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("messageType", msgData);
        jsonObject.put("messageBody", data);
        log.info("packageJson={}", jsonObject);
        return jsonObject;
    }

    public static void main(String[] args) {
        String jsonStr = "{\"data\":[{\"userId\":67685,\"avatar\":\"{\\\"type\\\":\\\"2up\\\",\\\"key\\\":\\\"{\\\\\\\"face\\\\\\\":\\\\\\\"star/i13\\\\\\\",\\\\\\\"background\\\\\\\":{\\\\\\\"f\\\\\\\":[\\\\\\\"#9C14DA\\\\\\\",1],\\\\\\\"t\\\\\\\":[\\\\\\\"#491CAB\\\\\\\",1]}}\\\"}\",\"currency\":\"VND\",\"nickName\":null,\"userName\":\"fafewafe\",\"vip\":0,\"star\":1,\"medal\":null,\"signature\":null,\"location\":5,\"agentId\":\"b410db81-c75e-4c0c-9fcc-cd3cbc5b30ff\",\"tag\":\"\"}],\"code\":0,\"message\":\"success\"}";
        JSONObject jsonObject = JSON.parseObject(jsonStr);
        int code = jsonObject.getInteger("code");
        String message = jsonObject.getString("message");
        JSONArray dataArray = jsonObject.getJSONArray("data");
        System.out.println(dataArray.getJSONObject(0).getLong("userId"));

        JSONObject dataArray2 = (JSONObject) jsonObject.getJSONObject("data").get(0);
        System.out.println(dataArray2);
    }

    public static JSONObject parseUser(String retJson) {
        if (StringUtils.isBlank(retJson)) {
            return null;
        }
        log.info("【用户服务】返回用户数据={}", retJson);
        JSONObject jsonObject = JSON.parseObject(retJson);
        int code = jsonObject.getInteger("code");
        String message = jsonObject.getString("message");
        if (code == 0) {
            JSONArray dataArray = jsonObject.getJSONArray("data");
            return dataArray.getJSONObject(0);
        } else {
            log.error("【用户服务】返回用户数据异常，data={}", retJson);
        }
        return null;
    }


    /**
     * 用户数据：
     * {"data":[{"userId":67685,"avatar":"{\"type\":\"2up\",\"key\":\"{\\\"face\\\":\\\"star/i13\\\",\\\"background\\\":{\\\"f\\\":[\\\"#9C14DA\\\",1],\\\"t\\\":[\\\"#491CAB\\\",1]}}\"}","currency":"VND","nickName":null,"userName":"fafewafe","vip":0,"star":1,"medal":null,"signature":null,"location":5,"agentId":"b410db81-c75e-4c0c-9fcc-cd3cbc5b30ff","tag":""}],"code":0,"message":"success"}
     *
     * @param jsonStr
     * @return
     */
    public static JSONArray analysisList(String jsonStr) {

        log.info("feigeJsonStr={}", jsonStr);
        JSONObject jsonObject = JSON.parseObject(jsonStr);
        if (jsonObject.getInteger("code") == 0) {
            return jsonObject.getJSONArray("data");
        } else {
            log.error("feigeJsonStr={}", jsonStr);
        }

        return null;
    }


    /**
     * 向pp返回json格式的错误信息
     *
     * @param error
     * @param description
     * @return jspn
     */
    public static JSONObject toErrJson(Integer error, String description) {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("error", error);
        jsonObject.put("description", description);
        return jsonObject;
    }

}
