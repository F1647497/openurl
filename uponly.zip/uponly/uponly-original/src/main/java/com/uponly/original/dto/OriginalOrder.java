package com.uponly.original.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Schema(title = "原创小游戏注单")
@Data
public class OriginalOrder {

    @Schema(title = "id")
    private Long id;
    @Schema(title = "注单号")
    private String orderNo;
    @Schema(title = "第三方注单号")
    private String thirdOrderNo;
    @Schema(title = "用户ID")
    private Long userId;
    @Schema(title = "货币类型")
    private String currency;
    @Schema(title = "地区")
    private Integer region;
    @Schema(title = "游戏ID")
    private String gameId;
    @Schema(title = "游戏名字")
    private String gameName;
    @Schema(title = "投注金额")
    private BigDecimal amount;
    @Schema(title = "结算或者取消金额")
    private BigDecimal payout;
    @Schema(title = "倍数")
    private BigDecimal multiplier;
    @Schema(title = "注单状态")
    private Integer status;
    @Schema(title = "消息发送状态")
    private Integer msgState;
    @Schema(title = "投注时间")
    private Date bettingTime;
    @Schema(title = "结算时间")
    private Date settlementTime;
    @Schema(title = "投注类型")
    private Integer betType;
    @Schema(title = "结算牌型")
    private String settleType;
    @Schema(title = "body")
    private String body;
    @Schema(title = "用户名")
    private String userName;
    @Schema(title = "会话ID")
    private String sessionId;
    @Schema(title = "三方id")
    private Integer thirdId;
    @Schema(title = "换算成USD后的Payout金额")
    private BigDecimal usdPayout;
    @Schema(title = "游戏結果")
    private String gameResult;
    @Schema(title = "有效流水")
    private BigDecimal effectiveAmount;
}
