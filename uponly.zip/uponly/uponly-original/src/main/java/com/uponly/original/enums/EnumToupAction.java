package com.uponly.original.enums;

import lombok.Data;
import lombok.Getter;

@Getter
public enum EnumToupAction {

    GET_BALANCE("getbalance"),
    CHANGE_BALANCE("ChangeBalanceFromOriginal");



    private final String action;

    EnumToupAction(String action) {
        this.action = action;
    }

    public static EnumToupAction getEnum(String action) {
        for (EnumToupAction enumToupAction : EnumToupAction.values()) {
            if (enumToupAction.getAction().equals(action)) {
                return enumToupAction;
            }
        }
        return null;
    }
}
