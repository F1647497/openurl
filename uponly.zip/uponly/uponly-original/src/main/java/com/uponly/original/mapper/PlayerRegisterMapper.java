package com.uponly.original.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.uponly.original.dto.PlayerRegister;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface PlayerRegisterMapper extends BaseMapper<PlayerRegister> {
}
