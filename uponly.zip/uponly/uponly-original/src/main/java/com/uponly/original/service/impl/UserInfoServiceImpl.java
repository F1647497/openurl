package com.uponly.original.service.impl;

import com.alibaba.fastjson2.JSONObject;
import com.alibaba.nacos.shaded.com.google.common.collect.Lists;
import com.uponly.original.common.constant.OriginalRedisKeyPrefix;
import com.uponly.original.mapper.UserMapper;
import com.uponly.original.remote.RemoteUserService;
import com.uponly.original.service.UserInfoService;
import com.uponly.original.util.MyJSONUtil;
import com.uponly.original.util.RegionIntegerUtil;
import com.uponly.original.vo.UserInfoVO;
import lombok.extern.slf4j.Slf4j;
import org.redisson.api.RBucket;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.Duration;
import java.util.Date;
import java.util.Objects;
import java.util.Optional;


@Slf4j
@Service
public class UserInfoServiceImpl implements UserInfoService {
    @Autowired
    RedissonClient redissonClient;
    @Autowired
    RemoteUserService remoteUserService;
    @Autowired
    UserMapper userMapper;

    @Override
    public Optional<UserInfoVO> getUser(Long userId) {
        var user = getRawUser(userId);
        if (user.isEmpty()) {
            user = getDBUser(userId);
            if (user.isEmpty()) {
                user = getRemoteUser(userId);
            }
        } else {
            // 检查用户数据的更新时间，如果时间超过一个小时，更新用户数据
            // 由于用户数据的更新频率不高，所以这里设置为1小时, updatedAt, 以防止用户数据被删除, 造成缓存数据不一致
            var userInfo = user.get();
            if (Objects.isNull(userInfo.getUpdatedAt()) || userInfo.getUpdatedAt().getTime() + 3600000 < System.currentTimeMillis()) {
                var remoteUser = getRemoteUser(userId);
                if (remoteUser.isPresent()) {
                    userMapper.update(remoteUser.get());
                    var cache = redissonClient.getBucket(OriginalRedisKeyPrefix.USER_INFO + userId);
                    cache.set(remoteUser.get(), Duration.ofMinutes(60));
                    user = remoteUser;
                }
            }
        }
        return user;
    }

    @Override
    public Optional<UserInfoVO> getUserByName(String userName) {
        var user = getRawUserByName(userName);
        if (user.isEmpty()) {
            user = getDBUser(userName);
        } else {
            // 检查用户数据的更新时间，如果时间超过一个小时，更新用户数据
            // 由于用户数据的更新频率不高，所以这里设置为1小时, updatedAt, 以防止用户数据被删除, 造成缓存数据不一致
            var userInfo = user.get();
            if (Objects.isNull(userInfo.getUpdatedAt()) || userInfo.getUpdatedAt().getTime() + 3600000 < System.currentTimeMillis()) {
                // TODO: 2024/6/12 需要确认是否有通过名字查询的接口
//                var remoteUser = getRemoteUser(userName);
//                if (remoteUser.isPresent()) {
//                    userMapper.update(remoteUser.get());
//                    var cache = redissonClient.getBucket(CasinoRedisKeyPrefix.USER_INFO + userName);
//                    cache.set(remoteUser.get(), Duration.ofMinutes(60));
//                    user = remoteUser;
//                }
            }
        }
        return user;
    }


    private Optional<UserInfoVO> getRawUser(Long userId) {
        // 首先从Redis读用户信息
        RBucket<UserInfoVO> cache = redissonClient.getBucket(OriginalRedisKeyPrefix.USER_INFO + userId);
        var userInfo = cache.get();
        if (userInfo == null) {
            // 如果Redis中没有用户信息，从数据库中读取
            userInfo = userMapper.selectById(userId);
            if (userInfo != null) {
                cache.set(userInfo, Duration.ofMinutes(60));    // 设置缓存时间为1小时
            } else {
                // 如果数据库中也没有用户信息，从远程服务中读取
                var user = getRemoteUser(userId);
                if (user.isPresent()) {
                    // 更新数据库和Redis中的用户信息
                    userInfo = user.get();
                    userMapper.add(userInfo);
                    cache.set(userInfo, Duration.ofMinutes(60));
                }
            }
        }
        return Optional.ofNullable(userInfo);
    }

    private Optional<UserInfoVO> getRawUserByName(String userName) {
        // 首先从Redis读用户信息
        RBucket<UserInfoVO> cache = redissonClient.getBucket(OriginalRedisKeyPrefix.USER_INFO + userName);
        var userInfo = cache.get();
        if (userInfo == null) {
            // 如果Redis中没有用户信息，从数据库中读取
            userInfo = userMapper.selectByName(userName);
            if (userInfo != null) {
                cache.set(userInfo, Duration.ofMinutes(60));    // 设置缓存时间为1小时
            } else {
                // 如果数据库中也没有用户信息，从远程服务中读取
//                var user = getRemoteUser(userName);
//                if (user.isPresent()) {
//                     更新数据库和Redis中的用户信息
//                    userInfo = user.get();
//                    userMapper.add(userInfo);
//                    cache.set(userInfo, Duration.ofMinutes(60));
//                }
            }
        }
        return Optional.ofNullable(userInfo);
    }


    private Optional<UserInfoVO> getDBUser(Long userId) {
        var user = userMapper.selectById(userId);
        return Optional.ofNullable(user);
    }

    private Optional<UserInfoVO> getDBUser(String userName) {
        var user = userMapper.selectByName(userName);
        return Optional.ofNullable(user);
    }

    private Optional<UserInfoVO> getRemoteUser(Long userId) {
        try {
            var userIdList = Lists.newArrayList(userId);
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("userIds", userIdList);
            JSONObject userJsons = MyJSONUtil.packageJson(jsonObject, "getsimpleuserinfos");
            JSONObject userRemote = MyJSONUtil.parseUser(remoteUserService.profile(userJsons));
            if (userRemote != null) {
                var userInfo = new UserInfoVO();
                userInfo.setUserId(userId);
                userInfo.setUserName(userRemote.getString("userName"));
                userInfo.setCurrency(userRemote.getString("currency"));
                userInfo.setNickName(userRemote.getString("nickName"));
                userInfo.setAvatar(userRemote.getString("avatar"));
                userInfo.setVip(userRemote.getInteger("vip"));
                userInfo.setStar(userRemote.getInteger("star"));
                userInfo.setTestTag(userRemote.getString("testTag"));
                userInfo.setAgentId(userRemote.getString("agentId"));
                userInfo.setLocation(RegionIntegerUtil.currencyToArea(userRemote.getString("currency")));
                userInfo.setUpdatedAt(new Date());
                log.info("【用户服务】更新用户数据成功，data={}", userInfo);
                return Optional.of(userInfo);
            }
        } catch (Exception e) {
            log.error("【用户服务】更新{}的用户数据异常，异常信息：{}", userId, e.getMessage(), e);
        }
        return Optional.empty();
    }
}
