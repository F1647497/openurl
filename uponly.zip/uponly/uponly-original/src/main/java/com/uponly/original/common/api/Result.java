package com.uponly.original.common.api;

import lombok.Builder;
import lombok.Data;


@Data
@Builder
public class Result<T> {

    private int code;
    private String message;
    private T data;
//    private long timestamp; //接口请求时间

    protected Result() {
//        this.timestamp = System.currentTimeMillis();
    }

    protected Result(int code, String message, T data) {
        this.code = code;
        this.message = message;
        this.data = data;
//        this.timestamp = System.currentTimeMillis();
    }


    /**
     * 全参数方法
     *
     * @param code    状态码
     * @param message 返回信息
     * @param data    返回数据
     * @return {@link Result <T>}
     */
    private static <T> Result<T> response(int code, String message, T data) {
        return new Result<>(code, message, data);
    }


    /**
     * 全参数方法
     *
     * @param code    状态码
     * @param message 返回信息
     * @param <T>     泛型
     * @return {@link Result <T>}
     */
    private static <T> Result<T> response(int code, String message) {
        Result<T> responseResult = new Result<>();
        responseResult.setCode(code);
        responseResult.setMessage(message);
        return responseResult;
    }


    /**
     * 成功返回（无参）
     */
    public static <T> Result<T> success() {
        return response(ResultCode.SUCCESS.getCode(), ResultCode.SUCCESS.getMessage(), null);
    }

    /**
     * 成功返回（data数据）
     *
     * @param data 获取的数据
     */
    public static <T> Result<T> success(T data) {
        return response(ResultCode.SUCCESS.getCode(), ResultCode.SUCCESS.getMessage(), data);
    }

//    /**
//     * 成功返回（返回信息）
//     *
//     * @param message 数据
//     */
//    public static <T> Result<String> successMsg(String message) {
//        return response(ResultCode.SUCCESS.getCode(), message);
//    }

    /**
     * 成功返回（状态码+返回信息）
     *
     * @param code    状态码
     * @param message 返回信息
     */
    public static <T> Result<T> success(int code, String message) {
        return response(code, message);
    }


    /**
     * 成功返回 （返回信息+数据）
     *
     * @param data    获取的数据
     * @param message 提示信息
     */
    public static <T> Result<T> success(String message, T data) {
        return response(ResultCode.SUCCESS.getCode(), message, data);
    }


    /**
     * 成功返回（状态码+返回信息+数据）
     *
     * @param code    状态码
     * @param message 返回信息
     * @param data    数据
     */
    public static <T> Result<T> success(int code, String message, T data) {
        return response(code, message, data);
    }

    /**
     * 成功返回（枚举参数）
     *
     * @param resultCode 枚举参数
     */
    public static <T> Result<T> success(ResultCode resultCode) {
        return response(resultCode.getCode(), resultCode.getMessage());
    }


    /**
     * 失败返回（无参）
     */
    public static <T> Result<T> fail() {
        return fail(ResultCode.INTERNAL_SERVER_ERROR);
    }

    /**
     * 失败返回（枚举）
     *
     * @param errorCode 错误码
     */
    public static <T> Result<T> fail(IErrorCode errorCode) {
        return response(errorCode.getCode(), errorCode.getMessage());
    }

    /**
     * 失败返回（返回信息）
     *
     * @param message 提示信息
     */
    public static <T> Result<T> fail(String message) {
        return response(ResultCode.INTERNAL_SERVER_ERROR.getCode(), message);
    }

    /**
     * 失败返回（数据）
     *
     * @param data 数据
     */
    public static <T> Result<T> fail(T data) {
        return response(ResultCode.INTERNAL_SERVER_ERROR.getCode(), ResultCode.INTERNAL_SERVER_ERROR.getMessage(), data);
    }

    /**
     * 失败返回（状态码+返回信息）
     *
     * @param code    状态码
     * @param message 提示信息
     */
    public static <T> Result<T> fail(int code, String message) {
        return response(code, message);
    }

    /**
     * 失败返回（返回信息+数据）
     *
     * @param message 提示信息
     * @param data    获取的数据
     */
    public static <T> Result<T> fail(String message, T data) {
        return response(ResultCode.INTERNAL_SERVER_ERROR.getCode(), message, data);
    }

    /**
     * 失败返回（状态码+返回信息+数据）
     *
     * @param code    状态码
     * @param message 提示信息
     * @param data    获取的数据
     */
    public static <T> Result<T> fail(int code, String message, T data) {
        return response(code, message, data);
    }

    /**
     * 参数验证失败返回结果
     */
    public static <T> Result<T> validateFailed() {
        return fail(ResultCode.VALIDATE_FAILED);
    }

    /**
     * 参数验证失败返回结果
     *
     * @param message 提示信息
     */
    public static <T> Result<T> validateFailed(String message) {
        return response(ResultCode.VALIDATE_FAILED.getCode(), message);
    }

    /**
     * 未登录返回结果
     */
    public static <T> Result<T> unauthorized(T data) {
        return response(ResultCode.UNAUTHORIZED.getCode(), ResultCode.UNAUTHORIZED.getMessage(), data);
    }

    /**
     * 未授权返回结果
     */
    public static <T> Result<T> forbidden(T data) {
        return response(ResultCode.FORBIDDEN.getCode(), ResultCode.FORBIDDEN.getMessage(), data);
    }

}
