package com.uponly.original.common.utils;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Map;

@Slf4j
public class CurrencyConverter {


    public static BigDecimal convert(BigDecimal amount, String fromCurrency, String toCurrency, Map<String, BigDecimal> rateMap) {
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            return BigDecimal.ZERO;
        }

        if (StringUtils.isBlank(fromCurrency) || StringUtils.isBlank(toCurrency)) {
            log.error("fromCurrency={} or toCurrency={} is blank", fromCurrency, toCurrency);
            return amount;
        }

        if (fromCurrency.equals(toCurrency)) {
            return amount;
        }

        // 获取起始货币对应的汇率
        BigDecimal fromRate = rateMap.get(fromCurrency);
        // 获取目标货币对应的汇率
        BigDecimal toRate = rateMap.get(toCurrency);

        if (fromRate == null || toRate == null) {
            log.error("fromCurrency={} or toCurrency={} not found in reteMap={}", fromCurrency, toCurrency, rateMap);
            return BigDecimal.ZERO;
        }

        // 计算转换后的金额：先转为通用的USDT，再转为目标货币
        BigDecimal inUSDT = amount.divide(fromRate, 10, RoundingMode.HALF_UP);
        BigDecimal convertedAmount = inUSDT.multiply(toRate).setScale(2, RoundingMode.HALF_UP);
//        log.info("amount={},fromCurrency={},toCurrency={},rates={},convertedAmount={}", amount, fromCurrency, toCurrency, reteMap, convertedAmount);
        return convertedAmount;
    }


}
