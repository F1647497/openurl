package com.uponly.original.common.enums;

import lombok.Getter;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Getter
public enum LanguageEnum {

    EN("en", "Language.en"),
    TH("th", "Language.th"),
    VI("vi", "Language.vi"),
    ID("id", "Language.id"),
    MS("ms", "Language.ms"),
    ZH("zh", "Language.zh");

    private final String id;
    private final String name;

    LanguageEnum(String id, String name) {
        this.id = id;
        this.name = name;
    }


    /**
     * 获取所有的枚举实例
     *
     * @return 包含所有枚举实例的列表
     */
    public static List<LanguageEnum> getAllRecord() {
        return Stream.of(values()).collect(Collectors.toList());
    }
}

