package com.uponly.original.task;

public abstract class AbstractBaseJob {

    public abstract void execute();




}
