package com.uponly.original.service.impl;


import com.alibaba.fastjson2.JSON;
import com.alibaba.fastjson2.JSONObject;
import com.uponly.original.common.constant.CommonConstant;
import com.uponly.original.dto.BalanceDTO;
import com.uponly.original.dto.ChangeBalanceResponse;
import com.uponly.original.enums.EnumToupAction;
import com.uponly.original.service.base.BaseServiceImpl;
import com.uponly.original.util.MyJSONUtil;
import com.uponly.original.vo.DistributeBonusesVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.Optional;

@Service
@Slf4j
public class TwoUPServiceImpl extends BaseServiceImpl {


    @Override
    protected Optional<ChangeBalanceResponse> changeBalance(BalanceDTO changeBalanceDTO) throws Exception {
        log.info("【原创游戏钱包服务】请求更改用户余额，data={}", JSONObject.toJSONString(changeBalanceDTO));
        try {
            var request = MyJSONUtil.packageJson(changeBalanceDTO, EnumToupAction.CHANGE_BALANCE.getAction());
            String jsonRes = walletService.send(request);
            log.info("【changeBalance】原创游戏请求更改用户余额，返回值={}", jsonRes);
            JSONObject jonResponse = JSON.parseObject(jsonRes);
            Integer code = jonResponse.getInteger("code");
            jonResponse = jonResponse.getJSONObject("data");
            if (code.intValue() != CommonConstant.ZERO) {
                log.error("【changeBalance】原创游戏调用钱包服务成功，但更改用户余额失败, 参数={}, 返回值={}", JSONObject.toJSONString(changeBalanceDTO), jsonRes);
                throw new RuntimeException("原创游戏余额更新失败,返回错误code:" + code);
            }
            log.info("【changeBalance】原创游戏请求更改用户余额成功，返回值={}", jsonRes);
            var res = ChangeBalanceResponse.fromJSONObject(jonResponse);
            if (res == null) {
                log.error("【changeBalance】原创游戏更改用户余额失败, 参数={}, 返回值={}", JSONObject.toJSONString(changeBalanceDTO), jsonRes);
                throw new RuntimeException("原创游戏余额更新失败,返回错误code:" + code);
            }
            return Optional.of(res);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("【changeBalance】原创游戏更改余额过程中出现异常, 参数={}, 异常={}", JSONObject.toJSONString(changeBalanceDTO), e.getMessage(), e);
            throw new RuntimeException("原创游戏更改余额异常:" + e.getMessage());
        }
    }

    @Override
    public Map<String, Object> getGameList() throws Exception {
        return null;
    }

    @Override
    public void history() throws Exception {

    }

    @Override
    public Map<String, Object> getGameUrl() throws Exception {
        return null;
    }

    @Override
    public Map<String, Object> cancel(DistributeBonusesVo distributeBonuses) throws Exception {
        return null;
    }
}
