package com.uponly.original.common.constant;

public interface ApiConstant {

    public static final String GET_GAME_SUFFIX = "/integration/getCasinoGames";
    public static final String  GAME_REGISTER_SUFFIX = "/integration/player/account/create";

    public static final String GET_GAME_URL_SUFFIX = "/operator/game/url";


}
