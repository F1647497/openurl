package com.uponly.original.common.enums;

import lombok.Getter;

@Getter
public enum ReportType {

    REBATE("casinoActivityOrder", 0b00001),

    STAKE("stake", 0b00010),

    ACTIVE("active", 0b00100),

    GGR("ggr", 0b01000),

    AMOUNT("amount", 0b10000),

    ;

    private final String type;
    private final int state;

    ReportType(String type, int state) {
        this.type = type;
        this.state = state;
    }

}
