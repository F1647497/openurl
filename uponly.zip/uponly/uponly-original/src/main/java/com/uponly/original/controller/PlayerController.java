package com.uponly.original.controller;


import com.uponly.original.common.api.Result;
import com.uponly.original.service.thirdpart.PlayerService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping(value = "/games")
@Slf4j
@Tag(name = "PlayerController", description = "玩家")
public class PlayerController {

    @Autowired
    private PlayerService playerService;

//    @Operation(summary = "玩家登录")
    @PostMapping(value = "/register")
    public Result<Map<String, Object>> register(@RequestHeader("uid") Long uid) {
        try {
            playerService.register(uid);
        } catch (Exception ex) {
            ex.printStackTrace();
            log.error("玩家三方注册失败:{}", ex.getMessage());
            return Result.fail(ex.getMessage());
        }
        return Result.success();
    }

    @Operation(summary = "获取游戏url")
    @GetMapping(value = "/getGameUrl")
    public Result<Map<String, Object>> getGameUrl(@RequestHeader("gameId") String gameId, @RequestParam("uid") Long uid) {
        Map<String, Object> result = new HashMap<>();
        try {
            result = playerService.getGameUrl(gameId, uid);
        } catch (Exception ex) {
            ex.printStackTrace();
            log.error("获取游戏url失败:{}", ex.getMessage());
            return Result.fail("获取游戏url失败:" + ex.getMessage());
        }
        return Result.success(result);
    }


}
