package com.uponly.original.vo;


import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
public class UserInfoVO implements Serializable {

    private Long userId;

    private Integer userType;

    private String userName;

    private String realName;

    private String nickName;

    private String mobile;

    private String email;

    private String currency;

    private String avatar;

    private String signature;

    private String clientId;

    private String agentId;

    private Integer vip;

    private Integer star;

    private String tag;

    private String language;

    private String privacy;

    private Integer location;

    private Integer odds;

    private String testTag;

    private Date updatedAt;
}
