package com.uponly.original.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import org.apache.ibatis.annotations.ConstructorArgs;

import java.io.Serializable;

@Data
@Builder
public class OriginalGame implements Serializable {

    @Schema(title = "三方id")
    private String thridId;

    @Schema(title = "游戏id")
    private String gameId;

    @Schema(title = "游戏名称")
    private String gameName;

    @Schema(title = "游戏类型")
    private String gameType;

    @Schema(title = "供应商")
    private String provider;

    @Schema(title = "游戏分类")
    private String gameCategory;

    @Schema(title = "游戏图标")
    private String gameIcon;

    @Schema(title = "限额")
    private String betLimit;

    @Schema(title = "游戏类型描述")
    private String typeDescription;

    @Schema(title = "游戏采用的技术,逗号分割")
    private String technology;

    @Schema(title = "游戏平台，逗号分割")
    private String platform;

    @Schema(title = "游戏url")
    private String gameUrl;

    @Schema(title = "是否提供演示版本(0、否，1、是)")
    private Integer demoGameAvailable;

    @Schema(title = "是否即时战略游戏")
    private Integer realTime;


}
