package com.uponly.original.enums;

public enum EnumWalletOperatorType {
    OriginalBet("OriginalBet"),
    OriginalPayout("OriginalPayout"),
    CasinoBetRefund("CasinoBetRefund"),
    CasinoPromotion("CasinoPromotion");

    private final String value;

    EnumWalletOperatorType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public static EnumWalletOperatorType getEnum(String value) {
        for (EnumWalletOperatorType enumWalletOperatorType : EnumWalletOperatorType.values()) {
            if (enumWalletOperatorType.getValue().equals(value)) {
                return enumWalletOperatorType;
            }
        }
        return null;
    }
}
