package com.uponly.original.handler;

import cn.hutool.core.util.StrUtil;
import com.alibaba.nacos.common.model.RestResult;
import com.uponly.original.common.api.Result;
import com.uponly.original.common.utils.AESUtil;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;

@Aspect
@Configuration
@Slf4j
public class AopSignAspect {

    @Pointcut("@annotation(com.uponly.original.tag.VerificationSign)")
    public void excudeService() {
    }

    @Around("excudeService()")
    public Object doAround(ProceedingJoinPoint joinPoint) {
        log.info("开始验证签名");
        try {
            ServletRequestAttributes sra = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            HttpServletRequest request = Objects.requireNonNull(sra).getRequest();
            Map<String, String[]> parameterMap = request.getParameterMap();
            Iterator<Map.Entry<String, String[]>> iterator = parameterMap.entrySet().iterator();
            Map<String, Object> objectObjectHashMap = new HashMap<>();
            while(iterator.hasNext()){
                Map.Entry<String, String[]> next = iterator.next();
                objectObjectHashMap.put(next.getKey(),next.getValue());
            }
            AESUtil.addSecurityParameters(objectObjectHashMap);
            String sign = objectObjectHashMap.get("hash").toString();
            if(!request.getParameter("sign").equals(sign)){
                return Result.fail("签名不正确");
            }
            Object result = joinPoint.proceed();
            return result;
        } catch (Throwable t) {
            return Result.fail("签名校验异常");
        }

    }



}
