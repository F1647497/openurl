package com.uponly.original.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.uponly.original.dto.OriginalOrder;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface OriginalOrderMapper extends BaseMapper<OriginalOrder> {
}
