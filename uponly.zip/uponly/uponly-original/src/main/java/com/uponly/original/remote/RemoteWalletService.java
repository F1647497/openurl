package com.uponly.original.remote;
import com.alibaba.fastjson2.JSONObject;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@FeignClient(name = "app.wallet")
public interface RemoteWalletService {
    @RequestMapping(value = "kh/msg.wallet", method = RequestMethod.POST)
    @ResponseBody
    String send(JSONObject req);
}
