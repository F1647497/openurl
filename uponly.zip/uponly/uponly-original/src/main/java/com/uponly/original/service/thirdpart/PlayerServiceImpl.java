package com.uponly.original.service.thirdpart;


import cn.hutool.core.util.IdUtil;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.uponly.original.common.constant.ApiConstant;
import com.uponly.original.common.constant.CommonConstant;
import com.uponly.original.common.utils.AESUtil;
import com.uponly.original.dto.PlayerRegister;
import com.uponly.original.mapper.PlayerRegisterMapper;
import com.uponly.original.util.RestTemplateUtil;
import lombok.extern.slf4j.Slf4j;
import org.redisson.api.RBucket;
import org.redisson.api.RedissonClient;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Slf4j
public class PlayerServiceImpl extends ServiceImpl<PlayerRegisterMapper, PlayerRegister> implements PlayerService {

    @Autowired
    private RestTemplateUtil restTemplateUtil;

    @Value("${original.api.url}")
    private String baseUrl;

    @Value("${original.api.access-key}")
    private String accessKey;

    @Autowired
    private RedissonClient redissonClient;

    @Autowired
    private PlayerRegisterMapper playerRegisterMapper;


    @Override
    public void register(Long uid) throws Exception {
        PlayerRegister build = PlayerRegister.builder().uid(uid).updateTime(new Date()).build();
        Map<String, Object> selectParam = new HashMap<>();
        selectParam.put("uid", uid);
        List<PlayerRegister> playerRegisters = playerRegisterMapper.selectByMap(selectParam);
        if (!ObjectUtils.isEmpty(playerRegisters) && playerRegisters.size() > 0) {
            PlayerRegister playerRegister = playerRegisters.get(0);
            if (playerRegister.getStatus() == CommonConstant.ZERO) {
                log.info("当前玩家已注册,账号Id为:{}", uid);
                return;
            }
            build.setId(playerRegister.getId());
        } else {
            playerRegisterMapper.insert(build);
        }
        String apiUrl = String.format(baseUrl + "%s", ApiConstant.GAME_REGISTER_SUFFIX);
        Map<String, Object> requestParam = new HashMap<>();
        requestParam.put("accessKey", accessKey);
        requestParam.put("uid", String.valueOf(uid));
        AESUtil.addSecurityParameters(requestParam);
        JSONObject result = restTemplateUtil.post(apiUrl, JSONObject.toJSONString(requestParam), new HashMap<>());
        if (!ObjectUtils.isEmpty(result)) {
            Integer code = result.getInteger("code");
            if (code.intValue() == CommonConstant.ZERO) {
                String thirdPlayerId = result.getJSONObject("data").getString("playerId");
                build.setStatus(CommonConstant.ZERO);
                build.setThirdId(thirdPlayerId);
                build.setMessage("");
                playerRegisterMapper.updateById(build);
                return;
            }
            build.setStatus(CommonConstant.ONE);
            build.setMessage(result.getString("message"));
            playerRegisterMapper.updateById(build);
            throw new RuntimeException("三方注册失败:"+result.getString("message"));
        }
    }

    @Override
    public Map<String, Object> getGameUrl(String gameId, Long uid) throws Exception {
        this.register(uid);
        String apiUrl = String.format(baseUrl + "%s", ApiConstant.GET_GAME_URL_SUFFIX);
        String token = IdUtil.simpleUUID();
        Map<String, Object> requestParam = new HashMap<>();
        requestParam.put("uid", String.valueOf(uid));
        requestParam.put("gameId", gameId);
        requestParam.put("token", token);
        AESUtil.addSecurityParameters(requestParam);
        RBucket<Object> bucket = redissonClient.getBucket(String.format(CommonConstant.PLAY_GAME_TOKEN, String.valueOf(uid)));
        bucket.set(token);
        log.info("token=================:{},uid:{}", token, uid);
        JSONObject result = restTemplateUtil.post(apiUrl, JSONObject.toJSONString(requestParam), new HashMap<>());
        if (result.getInteger("code") == CommonConstant.ZERO) {
            String gameUrl = result.getJSONObject("data").getString("gameUrl");
            Map<String, Object> resultMap = new HashMap<>();
            resultMap.put("gameUrl", gameUrl);
            return resultMap;
        }
        throw new RuntimeException(result.getString("message"));
    }


}
