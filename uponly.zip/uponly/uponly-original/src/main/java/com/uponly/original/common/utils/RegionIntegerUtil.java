package com.uponly.original.common.utils;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@Slf4j
public class RegionIntegerUtil {

    /**
     * 向上取整到最接近的百的整数
     *
     * @param number
     * @return
     */
    public static Integer roundUpToHundreds(Integer number) {
        number = Optional.ofNullable(number).orElse(0);
        // 向上取整到最接近的百的整数
        if (isMultipleOfHundred(number)) {
            return number + 100;
        } else {
            return (int) (Math.ceil(number / 100.0) * 100);
        }
    }


    /**
     * 判断是否为整百数
     *
     * @param number
     * @return
     */
    public static boolean isMultipleOfHundred(Integer number) {
        return number % 100 == 0;
    }


    /**
     * 1 国际 3印尼 4泰国 5越南 7马来西亚
     *
     * @return
     */
    public static List<Integer> initArea() {
        List<Integer> list = Lists.newArrayList();
        list.add(1);
        list.add(3);
        list.add(4);
        list.add(5);
        list.add(7);
        return list;
    }


    /**
     * USDT = 'USDT', //location: 1   国际
     * CNY = 'CNY', //location: 2   中国
     * IDR = 'IDR', //location: 3   印尼
     * THB = 'THB', //location: 4   泰国
     * VND = 'VND', //location: 5   越南盾
     * PHP = 'PHP', //location: 6   菲律宾
     * MYR = 'MYR', //location: 7   马来
     *
     * @return
     */
    public static Integer currencyToArea(String currency) {

        Map<String, Integer> map = Maps.newHashMap();
        map.put("USDT", 1);
        map.put("CNY", 2);
        map.put("IDR", 3);
        map.put("THB", 4);
        map.put("VND", 5);
        map.put("PHP", 6);
        map.put("MYR", 7);
        return map.get(currency);
    }

    /**
     * USDT = 'USDT', //location: 1   国际
     * CNY = 'CNY', //location: 2   中国
     * IDR = 'IDR', //location: 3   印尼
     * THB = 'THB', //location: 4   泰国
     * VND = 'VND', //location: 5   越南盾
     * PHP = 'PHP', //location: 6   菲律宾
     * MYR = 'MYR', //location: 7   马来
     *
     * @return
     */
    public static String AreaToCurrency(Integer area) {

        Map<Integer, String> map = Maps.newHashMap();
        map.put(1, "USDT");
        map.put(2, "CNY");
        map.put(3, "IDR");
        map.put(4, "THB");
        map.put(5, "VND");
        map.put(6, "PHP");
        map.put(7, "MYR");
        return map.get(area);
    }

    /**
     * USDT = 'USDT', //location: 1   国际
     * CNY = 'CNY', //location: 2   中国
     * IDR = 'IDR', //location: 3   印尼
     * THB = 'THB', //location: 4   泰国
     * VND = 'VND', //location: 5   越南盾
     * PHP = 'PHP', //location: 6   菲律宾
     * MYR = 'MYR', //location: 7   马来
     *
     * @return
     */
    public static String lcationIdToRegion(Integer area) {

        Map<Integer, String> map = Maps.newHashMap();
        map.put(1, "Global");
        map.put(3, "Indonesia");
        map.put(4, "Thailand");
        map.put(5, "Vietnam");
        map.put(7, "Malaysia");
        return map.get(area);
    }


}
