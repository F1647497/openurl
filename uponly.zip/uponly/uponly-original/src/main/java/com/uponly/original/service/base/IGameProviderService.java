package com.uponly.original.service.base;

import java.util.Map;

public interface IGameProviderService {

    Map<String, Object> getGameList() throws Exception;

    void history() throws Exception;

    Map<String, Object> getGameUrl() throws Exception;


}
