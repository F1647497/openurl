package com.uponly.original.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.uponly.original.dto.OriginalGame;
import com.uponly.original.vo.OriginalGameVo;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface GameMapper extends BaseMapper<OriginalGame> {

     Integer insertPlus(OriginalGame originalGame);

     List<OriginalGameVo> selectByType();

}
