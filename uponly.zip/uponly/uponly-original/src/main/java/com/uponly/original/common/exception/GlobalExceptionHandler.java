package com.uponly.original.common.exception;

import cn.hutool.core.util.ObjectUtil;
import com.uponly.original.common.api.Result;
import com.uponly.original.common.api.ResultCode;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.NoHandlerFoundException;

/**
 * 全局异常处理器
 * 1. 各层异常必须抛出，不允许吞没异常
 * 2. 不允许直接catch 父类Exception异常，必须明确子类异常
 */
@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {

    /**
     * 请求方式不支持
     */
    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public Result<?> handleHttpRequestMethodNotSupported(Exception e) {
        log.error("请求地址不支持：'{}'", e.getMessage(), e);
        return Result.fail(ResultCode.METHOD_NOT_ALLOWED);
    }

    @ExceptionHandler(MissingRequestHeaderException.class)
    public ResponseEntity<Result<?>> handleMissingRequestHeaderException(MissingRequestHeaderException e) {
        log.error("请求头缺少必需的字段: {}", e.getHeaderName(), e);
        return ResponseEntity.status(e.getStatusCode()).body(Result.fail(e.getStatusCode().value(), "请求头缺少必需的字段: " + e.getHeaderName(), HttpStatus.BAD_REQUEST));
    }

//    @ExceptionHandler(MissingRequestHeaderException.class)
//    public Result<?> handleMissingRequestHeaderException(MissingRequestHeaderException e) {
//        log.error("请求头缺少必需的字段: {}", e.getHeaderName(), e);
//        return CommonResult.fail(ResultCode.VALIDATE_FAILED.getCode(), "请求头缺少必需的字段: " + e.getHeaderName());
//    }

    /**
     * 处理空指针的异常
     */
    @ExceptionHandler(NullPointerException.class)
    public Result<?> nullPointerException(NullPointerException e) {
        log.error("空指针异常 NullPointerException:{} ", e.getMessage());
        return Result.fail(ResultCode.BAD_REQUEST.getCode(), ResultCode.BAD_REQUEST.getMessage());
    }

    /**
     * 数据校验失败异常捕捉
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Result<?> handleBindException(MethodArgumentNotValidException e) {
        FieldError fieldError = e.getBindingResult().getFieldError();
        return Result.fail(ResultCode.VALIDATE_FAILED.getCode(), fieldError.getDefaultMessage());
    }

    /**
     * 数据校验失败异常捕捉
     */
    @ExceptionHandler(BindException.class)
    public Result<?> handleBindException(BindException ex) {
        FieldError fieldError = ex.getBindingResult().getFieldError();
        return Result.fail(ResultCode.VALIDATE_FAILED.getCode(), fieldError.getDefaultMessage());
    }

    /**
     * 参数不合法的异常
     * 可搭配断言使用，如：Assert.notNull(obj, "obj不能为空"); 抛出IllegalArgumentException
     */
    @ExceptionHandler(IllegalArgumentException.class)
    public Result<?> handleIllegalArgumentException(IllegalArgumentException e) {
        return Result.fail(ResultCode.VALIDATE_FAILED.getCode(), e.getMessage());
    }

    /**
     * 处理自定义异常
     *
     * @param e BusinessException
     * @return
     */
    @ExceptionHandler(BusinessException.class)
    public Result<?> businessException(BusinessException e) {
        log.error("业务异常 code={}, BusinessException = {}", e.getCode(), e.getMessage(), e);
        return ObjectUtil.isNotNull(e.getCode()) ? Result.fail(e.getCode(), e.getMessage()) : Result.fail(e.getMessage());
    }


    /**
     * 拦截未知的运行时异常
     */
    @ExceptionHandler(RuntimeException.class)
    public Result<?> handleRuntimeException(RuntimeException e) {
        log.error("请求地址'{}',发生未知异常.", e.getMessage(), e);
        return Result.fail(e.getMessage());
    }


    /**
     * 系统内无此方法处理异常
     * 参考 <a href="https://blog.csdn.net/zhuxiaobo09/article/details/126029105">...</a>
     * <p>
     * 配置中增加如下配置，当一个请求没有找到匹配的处理或访问不存在的静态资源时，抛出异常而不是返回404页
     * <p>
     * spring:
     * mvc:
     * throw-exception-if-no-handler-found: true
     * resources:
     * add-mappings: false
     */
    @ExceptionHandler(NoHandlerFoundException.class)
    public Result<?> noHandlerFoundExceptionHandler(NoHandlerFoundException e) {
        log.error("系统内无此方法处理逻辑异常", e);
        return Result.fail(ResultCode.NOT_FOUND);
    }


    /**
     * 兜底异常捕捉
     */
    @ExceptionHandler(Exception.class)
//    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public Result<?> handleException(Exception e) {
        log.error(e.getMessage());
        return Result.fail("请求错误:-:>" + e);
    }


}
