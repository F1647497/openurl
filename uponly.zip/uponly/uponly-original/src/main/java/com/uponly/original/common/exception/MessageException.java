package com.uponly.original.common.exception;


import com.uponly.original.common.api.ResultCode;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class MessageException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    private long code;

    private String message;

    public MessageException(String message) {
        super(message);
        this.code = ResultCode.INTERNAL_SERVER_ERROR.getCode();
        this.message = message;
    }

    public MessageException(String message, Throwable e) {
        super(message, e);
        this.code = ResultCode.INTERNAL_SERVER_ERROR.getCode();
        this.message = message;
    }


}
