package com.uponly.original.common.constant;

public class TopicConstant {


    public static final String SLOT_CRUD_NOTIFY_ELASTIC_TOPIC = "msg.searchevent";

    public static final String RANK_OPERATION_AFTER_SLOT_BET_ORDER_TOPIC = "slot_live_win_realtime_rank_internal_topic";

    //用户产生赔付
    public static final String SLOT_USER_MADE_RESULT_TOPIC = "slot_user_made_result_topic";

    //用户发生投注
    public static final String CASINO_USER_MADE_BET_TOPIC = "casino_user_made_bet_topic";
    public static final String CASINO_WS_TOPIC = "event.ws";

    public static final String REAL_TIME_RATE = "slot_real_time_rate_topic";

    public static final String LIVE_WINS_REALTIME = "live_wins_realtime";
    public static final String LIVE_WINS_DAILY = "live_wins_daily";
    public static final String LIVE_WINS_WEEKLY = "live_wins_weekly";
    public static final String LIVE_WINS_MONTHLY = "live_wins_monthly";

    //实时大赢排行榜 websocket通知
    public static final String SLOTS_REAL_TIME_LIVE_WINS_RANK = "slot_real_time_live_wins_rank";

}



