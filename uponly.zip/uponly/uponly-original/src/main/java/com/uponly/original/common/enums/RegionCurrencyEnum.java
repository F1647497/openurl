package com.uponly.original.common.enums;

import com.uponly.original.common.constant.exception.BusinessException;
import lombok.Getter;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Getter
public enum RegionCurrencyEnum {
    USDT(1, "USDT", "1", "Global"),
    CNY(2, "CNY", "0", "China"),
    IDR(3, "IDR", "1", "Indonesia"),
    THB(4, "THB", "1", "Thailand"),
    VND(5, "VND", "1", "Vietnam"),
    PHP(6, "PHP", "0", "Philippines"),
    MYR(7, "MYR", "1", "Malaysia");

    private final int locationId;
    private final String currency;
    private final String status;
    private final String shortName;

    RegionCurrencyEnum(int locationId, String currency, String status, String shortName) {
        this.locationId = locationId;
        this.currency = currency;
        this.status = status;
        this.shortName = shortName;
    }

    /**
     * 获取所有的枚举实例
     *
     * @return 包含所有枚举实例的列表
     */
    public static List<RegionCurrencyEnum> getAllRecord() {
        return Stream.of(values()).collect(Collectors.toList());
    }

    // 根据 locationId 获取 currency
    public static String getCurrencyByLocationId(int locationId) {
        return Stream.of(values())
                .filter(enumValue -> enumValue.locationId == locationId)
                .findFirst()
                .map(RegionCurrencyEnum::getCurrency)
                .orElseThrow(() -> new BusinessException("Unknown locationId= " + locationId));
    }
}
