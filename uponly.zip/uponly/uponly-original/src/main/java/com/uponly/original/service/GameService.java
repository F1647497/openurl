package com.uponly.original.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.uponly.original.dto.OriginalGame;
import com.uponly.original.vo.OriginalGameVo;

import java.util.List;

public interface GameService extends IService<OriginalGame> {

   Integer insertPlus(OriginalGame originalGame);


   List<OriginalGameVo> selectByType() throws Exception;
}
