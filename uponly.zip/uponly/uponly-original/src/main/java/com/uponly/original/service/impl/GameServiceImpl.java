package com.uponly.original.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.uponly.original.dto.OriginalGame;
import com.uponly.original.mapper.GameMapper;
import com.uponly.original.service.GameService;
import com.uponly.original.vo.OriginalGameVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GameServiceImpl extends ServiceImpl<GameMapper, OriginalGame> implements GameService {

    @Autowired
    private GameMapper gameMapper;

    @Override
    public Integer insertPlus(OriginalGame originalGame) {
        return gameMapper.insertPlus(originalGame);
    }

    @Override
    public List<OriginalGameVo> selectByType() throws Exception{
        QueryWrapper queryWrapper = new QueryWrapper<OriginalGame>();
        return gameMapper.selectList(queryWrapper);
    }
}
