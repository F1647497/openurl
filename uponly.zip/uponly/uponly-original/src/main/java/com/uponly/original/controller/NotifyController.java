package com.uponly.original.controller;


import com.uponly.original.common.api.Result;
import com.uponly.original.service.thirdpart.NotifyService;
import com.uponly.original.vo.DistributeBonusesVo;
import com.uponly.original.vo.OriginalOrderVo;
import com.uponly.original.vo.RequestNotifyVo;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import java.util.HashMap;
import java.util.Map;

@Tag(name = "NotifyController", description = "三方回调")
@RestController
@RequestMapping("/games")
@Slf4j
public class NotifyController {

    @Autowired
    private NotifyService notifyService;

    @Operation(summary = "用户验证")
    @PostMapping(value = "/validate")
    public Result<Map<String, Object>> validate(@RequestBody RequestNotifyVo requestNotifyVo) {
        try {
            notifyService.validate(requestNotifyVo);
            Map<String, Object> result = new HashMap<>();
            result.put("uid", requestNotifyVo.getUid());
            return Result.success(result);
        } catch (Exception ex) {
            ex.printStackTrace();
            log.error("用户:{},验证失败{}", requestNotifyVo.getUid(), ex.getMessage());
            return Result.fail(ex.getMessage());
        }
    }

    @Operation(summary = "获取余额")
    @PostMapping("/getBalance")
    public Result<Map<String, Object>> getBalance(@RequestBody RequestNotifyVo requestNotifyVo) {
        try {
            Map<String, Object> balance = notifyService.getBalance(requestNotifyVo, true);
            return Result.success(balance);
        } catch (Exception ex) {
            ex.printStackTrace();
            log.error("获取余额失败:{}", ex.getMessage());
            return Result.fail(ex.getMessage());
        }
    }

    @Operation(summary = "下注")
    @PostMapping("/bettingOrders")
    public Result<Map<String, Object>> bettingOrders(@RequestBody OriginalOrderVo originalOrder) {
        try {
            Map<String, Object> result = notifyService.bettingOrders(originalOrder);
            return Result.success(result);
        } catch (Exception ex) {
            ex.printStackTrace();
            log.error("下注失败:{}", ex.getMessage());
            return Result.fail(ex.getMessage());
        }
    }

    @Operation(summary = "派奖")
    @PostMapping("/distributeBonuses")
    public Result<Map<String, Object>> distributeBonuses(@RequestBody DistributeBonusesVo distributeBonuses) {
        try {
            notifyService.distributeBonuses(distributeBonuses);
            return Result.success();
        } catch (Exception ex) {
            ex.printStackTrace();
            log.error("派奖失败:{}", ex.getMessage());
            return Result.fail(ex.getMessage());
        }
    }


}
