package com.uponly.original.common.constant;

import java.lang.management.ManagementFactory;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

public class CommonConstant {

    //当前时间
    public static final Date NOW = Date.from(LocalDateTime.now().atZone(ZoneId.systemDefault()).toInstant());

    public static final String CASINO_LIVE_WIN_REGION_FORMAT = "casino_channel_%s";

    //后台游戏状态新增、更新时，Kafka消息通知，websocket通知H5端，刷新画面。
    public static final String GAME_STATUS_NOTIFY = "game_status_notify";

    //后台游戏状态新增、更新、删除时，Kafka消息通知Elastic Search同步更新。
    public static final String SLOT_INIT_GAME_NOTIFY_ELASTIC_SEARCH = "gameDataInit";

    public static final String SLOT_ADD_GAME_NOTIFY_ELASTIC_SEARCH = "gameDataInsert";
    // 活動A +下注B +GGR
    public static final String CASINO_ORDER_ABG_LIST = "casino_order_ABG_list";
    //有效流水
    public static final String CASINO_ORDER_AMOUNT_LIST = "casino_order_amount_list";
    public static final String CASINO_ORDER_AMOUNT_LIST_FOR_FIX = "casino_order_amount_list_for_fix";
    public static final String CASINO_ORDER_AMOUNT_LIST_FOR_CHECK = "casino_order_amount_list_for_check";
    //返利
    public static final String CASINO_ORDER_REBATE_LIST = "casino_order_rebate_list";
    public static final String CASINO_ORDER_RESULT_LIST = "casino_order_result_list";
    public static final String CASINO_ORDER_RESULT_FAIL_LIST = "casino_order_result_fail_list";

    public static final String SLOT_DELETE_GAME_NOTIFY_ELASTIC_SEARCH = "gameDataDelete";

    //电子游戏大赢家排行榜总榜数量限制
    public static final Integer SLOT_REALTIME_LIVE_WIN_ALL_RANK_LIMIT = 200;

    //电子游戏大赢家排行榜日、周、月数量限制
    public static final Integer SLOT_TOP_20_LIMIT = 20;

    //电子游戏大赢家排行榜地区榜单展示限制
    public static final Integer SLOT_REALTIME_LIVE_WIN_REGION_RANK_LIMIT = 10;


    public static final String CASINO_BETTING_JOB_TOPIC = "event.admin";
    public static final String CASINO_ACTIVITY_TOPIC = "msg.activity";

    public static final String SLOT_MESSAGE_TYPE = "tochannel";

    //H5首页 热门、收藏、NEW、推广、rtp、a~z，z~a接口每页数量。
    public static final int HOME_PAGE_LIMIT = 18;

    public static final String SOCKET_SLOT_MARQUEE = "casino_real_time_live_wins";
    public static final String SOCKET_CASINO_LIVE_WINS_D = "casino_live_wins_daily";
    public static final String SOCKET_CASINO_LIVE_WINS_W = "casnio_live_wins_weekly";
    public static final String SOCKET_CASINO_LIVE_WINS_M = "casino_live_wins_monthly";
    public static final String SOCKET_CASINO_GAME_UPDATE = "casino_game_notify";

    // 游戏更新内部通知
    public static final String PUB_CASINO_UPDATE_GAME = "pub-casino-update-game";
    // live win config变动通知
    public static final String PUB_CASINO_UPDATE_LIVE_WIN = "pub-casino-update-live-win";

    // 启动的时候生成的机器码
    public static final String MACHINE_ID = ManagementFactory.getRuntimeMXBean().getName();

    //注单拉取历史记录的超时时间 单位毫秒
    public static final int CASINO_ORDER_HISTORY_TIMEOUT = 6 * 60 * 1000;


    public static final int ZERO = 0;
    public static final int ONE = 1;

    public static  final String PLAY_GAME_TOKEN ="play_game_token_%s";
}
