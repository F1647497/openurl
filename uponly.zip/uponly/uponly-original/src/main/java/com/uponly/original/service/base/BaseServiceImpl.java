package com.uponly.original.service.base;

import cn.hutool.core.lang.Assert;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.uponly.original.common.constant.CommonConstant;
import com.uponly.original.common.utils.AESUtil;
import com.uponly.original.dto.BalanceDTO;
import com.uponly.original.dto.ChangeBalanceResponse;
import com.uponly.original.dto.GetBalanceDTO;
import com.uponly.original.dto.OriginalOrder;
import com.uponly.original.enums.EnumToupAction;
import com.uponly.original.enums.EnumWalletOperatorType;
import com.uponly.original.mapper.OriginalOrderMapper;
import com.uponly.original.remote.RemoteWalletService;
import com.uponly.original.service.UserInfoService;
import com.uponly.original.util.MyJSONUtil;
import com.uponly.original.util.UidUtil;
import com.uponly.original.vo.DistributeBonusesVo;
import com.uponly.original.vo.OriginalOrderVo;
import com.uponly.original.vo.RequestNotifyVo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Slf4j
public abstract class BaseServiceImpl implements IPlayerService, IGameProviderService {

    @Autowired
    private UserInfoService userInfoService;

    @Autowired
    protected RemoteWalletService walletService;

    @Autowired
    private OriginalOrderMapper originalOrderMapper;

    @Override
    public Map<String, Object> getBalance(RequestNotifyVo requestNotifyVo, Boolean flag) throws Exception {
        if (flag) {
            this.vlidateBalanceParam(requestNotifyVo);
        }
        var userInfo = userInfoService.getUser(requestNotifyVo.getUid());
        if (userInfo.isEmpty()) {
            log.error("【balance】获取用户信息失败,userId={}", requestNotifyVo.getUid());
            throw new RuntimeException("获取用户信息失败");
        }
        try {
            var getBalanceDTO = new GetBalanceDTO(userInfo.get());
            var request = MyJSONUtil.packageJson(getBalanceDTO.toJSONObject(), EnumToupAction.GET_BALANCE.getAction());
            var jsonStr = walletService.send(request);
            var jonResponse = MyJSONUtil.analysis2Data(jsonStr);
            log.info("【balance】获取当前用户余额={}", jonResponse);
            if (jonResponse == null) {
                log.error("【balance】获取当前用户余额失败,参数={}", getBalanceDTO);
                throw new RuntimeException("获取当前用户余额失败");
            }
            Map<String, Object> resultMap = new HashMap<>();
            resultMap.put("currency", userInfo.get().getCurrency());
            resultMap.put("balance", jonResponse.getString("balance"));
            return resultMap;
        } catch (Exception e) {
            e.printStackTrace();
            log.error("【balance】获取当前用户余额失败,userId={},异常={}", requestNotifyVo.getUid(), e.getMessage(), e);
            throw new RuntimeException("获取当前用户余额失败:" + e.getMessage());
        }
    }

    @Override
    public Map<String, Object> bettingOrders(OriginalOrderVo originalOrder) throws Exception {
        RequestNotifyVo requestNotifyVo = new RequestNotifyVo();
        requestNotifyVo.setUid(originalOrder.getUserId());
        Map<String, Object> balanceMap = this.getBalance(requestNotifyVo, false);
        BigDecimal balance = new BigDecimal(String.valueOf(balanceMap.get("balance")));
        if (balance.compareTo(originalOrder.getAmount()) == -1) {
            throw new RuntimeException("余额不足，请充值");
        }
        String orderNo = UidUtil.getOrderNo(String.valueOf(originalOrder.getUserId()));
        OriginalOrder originalOrderEntity = new OriginalOrder();
        BeanUtils.copyProperties(originalOrder, originalOrderEntity);
        originalOrderEntity.setOrderNo(orderNo);
        originalOrderEntity.setStatus(001); //已投注
        originalOrderMapper.insert(originalOrderEntity);

        BalanceDTO changeBalance = new BalanceDTO();
        changeBalance.setUserId(originalOrder.getUserId());
        changeBalance.setOrderNo(orderNo);
        changeBalance.setOperatorType(EnumWalletOperatorType.OriginalBet.getValue());
        changeBalance.setAmount(originalOrder.getAmount());
        changeBalance.setGameId(originalOrder.getGameId());
        changeBalance.setGameName(originalOrder.getGameName());
        changeBalance.setMultiplier(originalOrder.getMultiplier());
        this.changeBalance(changeBalance);
        Map<String, Object> result = new HashMap<>();
        result.put("orderNo", orderNo);
        return result;
    }

    protected abstract Optional<ChangeBalanceResponse> changeBalance(BalanceDTO changeBalanceDTO) throws Exception;


    @Override
    public Map<String, Object> distributeBonuses(DistributeBonusesVo distributeBonuses) throws Exception {

        OriginalOrder originalOrder = new OriginalOrder();
        BeanUtils.copyProperties(distributeBonuses, originalOrder);
        if (StringUtils.isNotBlank(distributeBonuses.getOrderStatus())) {
            originalOrder.setStatus(003);
            originalOrder.setSettlementTime(new Date());
        }
        UpdateWrapper<OriginalOrder> updateWrapper = new UpdateWrapper();
        updateWrapper.eq("order_no", originalOrder.getOrderNo());
        int update = originalOrderMapper.update(originalOrder, updateWrapper);
        if (update > CommonConstant.ZERO) {
            BalanceDTO changeBalance = new BalanceDTO();
            changeBalance.setUserId(distributeBonuses.getUserId());
            changeBalance.setOrderNo(distributeBonuses.getOrderNo());
            changeBalance.setOperatorType(EnumWalletOperatorType.OriginalPayout.getValue());
            changeBalance.setAmount(originalOrder.getPayout());
            changeBalance.setGameId(originalOrder.getGameId());
            changeBalance.setGameName(originalOrder.getGameName());
            changeBalance.setMultiplier(originalOrder.getMultiplier());
            Optional<ChangeBalanceResponse> changeBalanceResponse = this.changeBalance(changeBalance);
            ChangeBalanceResponse changeBalanceResult = changeBalanceResponse.get();
        }
        Map<String, Object> result = new HashMap<>();
//        result.put("orderNo", orderNo);
        return result;
    }

    private void vlidateBalanceParam(RequestNotifyVo requestNotifyVo) {
        Assert.notNull(requestNotifyVo.getUid(), "参数uid不能为空");
        Assert.notNull(requestNotifyVo.getSign(), "参数sign不能为空");
        Map<String, Object> param = new HashMap<>();
        param.put("uid", requestNotifyVo.getUid());
        AESUtil.addSecurityParameters(param);
        if (!requestNotifyVo.getSign().equals(param.get("hash"))) {
            throw new RuntimeException("签名不正确");
        }
    }
}
