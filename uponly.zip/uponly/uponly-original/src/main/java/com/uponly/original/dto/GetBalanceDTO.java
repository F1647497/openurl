package com.uponly.original.dto;

import com.alibaba.fastjson2.JSONObject;
import com.uponly.original.vo.UserInfoVO;
import lombok.Data;

@Data
public class GetBalanceDTO {
    Long userId;
    String currency;

    public GetBalanceDTO(Long userId, String currency) {
        this.userId = userId;
        this.currency = currency;
    }

    public GetBalanceDTO(UserInfoVO userInfo) {
        this.userId = userInfo.getUserId();
        this.currency = userInfo.getCurrency();
    }

    public GetBalanceDTO() {
    }

    public JSONObject toJSONObject() {
        var jsonObject = new JSONObject();
        jsonObject.put("userId", userId);
        jsonObject.put("currency", currency);
        return jsonObject;
    }
}
