package com.uponly.original.dto;

import cn.hutool.core.date.DateTime;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;

import javax.persistence.Table;
import java.util.Date;

@Data
@Builder
@TableName("original_player_register")
public class PlayerRegister {

    @Schema(title = "id")
    private Long id;
    @Schema(title = "uid")
    private Long uid;
    @Schema(title = "状态")
    private Integer status;
    @Schema(title = "消息")
    private String message;
    @Schema(title = "第三方玩家id")
    private String thirdId;
    @Schema(title = "修改时间")
    private Date updateTime;

}
