package com.uponly.original.controller;


import com.uponly.original.common.api.Result;
import com.uponly.original.dto.OriginalGame;
import com.uponly.original.service.GameService;
import com.uponly.original.vo.OriginalGameVo;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@Tag(name = "GamesController", description = "游戏")
@RestController
@RequestMapping("/games")
@Slf4j
public class GamesController {

    @Autowired
    private GameService gameService;

    @Operation(summary = "游戏查询")
    @GetMapping("/list")
    public Result<List> list() {
        try {
            List<OriginalGameVo> list = gameService.selectByType();
            return Result.success(list);
        } catch (Exception ex) {
            ex.printStackTrace();
            log.error("游戏查询失败:{}", ex.getMessage());
            return Result.fail("游戏查询失败");
        }
    }
}
