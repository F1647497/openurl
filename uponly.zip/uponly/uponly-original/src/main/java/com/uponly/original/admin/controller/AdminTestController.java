package com.uponly.original.admin.controller;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping("/admin")
@RestController
public class AdminTestController {

    @GetMapping(value = "/test")
    public Object  test(){

        return "hello word";

    }
}
