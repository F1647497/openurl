package com.uponly.original.mapper;


import com.uponly.original.vo.UserInfoVO;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UserMapper {
    Integer add(UserInfoVO user);
    Integer update(UserInfoVO user);

    UserInfoVO selectById(Long id);
    UserInfoVO selectByName(String userName);
}
