package com.uponly.original.service.thirdpart;

import com.baomidou.mybatisplus.extension.service.IService;
import com.uponly.original.dto.PlayerRegister;

import java.util.Map;

public interface PlayerService extends IService<PlayerRegister> {

    void register(Long uid) throws Exception;

    Map<String, Object> getGameUrl(String gameId, Long uid) throws Exception;
}
