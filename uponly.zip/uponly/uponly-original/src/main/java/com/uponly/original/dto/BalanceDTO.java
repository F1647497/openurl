package com.uponly.original.dto;

import com.alibaba.fastjson2.JSONObject;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class BalanceDTO {
    private Long userId;
    private String orderNo;
    private String operatorType;
    private BigDecimal amount;
    private BigDecimal multiplier;
    private String gameId;
    private String gameName;

    //    private String sessionId;
//    private Long providerId;
//    private String remark;
//    private String transactionId;

    /**
     * CasinoBetFreeze = 'CasinoBetFreeze', //投注冻结成功
     * CasinoPayout = 'CasinoPayout', //投注赔付
     * CasinoBetRefund = 'CasinoBetRefund', //投注退款
     * CasinoPromotion = 'CasinoPromotion', // 大奖
     */

    public BalanceDTO() {
        // 设置默认值
        this.userId = 0L;
        this.orderNo = "";
//        this.transactionId = "";
        this.operatorType = "";
        this.amount = BigDecimal.ZERO;
        this.multiplier = BigDecimal.valueOf(1);
        this.gameId = "";
//        this.sessionId = "";
//        this.providerId = 0L;
        this.gameName = "";
//        this.remark = "";
    }

//    JSONObject toJSONObject() {
//        JSONObject jsonObject = JSONObject.from(this);
//        jsonObject.put("providerId", providerId.toString());
//        return jsonObject;
//    }
}
