#### 1.swagger地址

http://localhost:8080/user-service/swagger-ui/swagger-ui/index.html

上线流程：

数据库相关：
保留表数据：big_wins_config,provider_config
需导入的表：slot_m

其中provider_config表需要把相应环境的参数更改：
provider_account,provider_key,goin_url,
game_api_url,icon_api_url

select game_name_edited,
game_ad_edited
from slot_management;
2个字段的初始值为:

{
"nameId": "en",
"nameI18n": [
{
"id": "en",
"name": "",
"label": "英文"
},
{
"id": "zh",
"name": "",
"label": "中文"
},
{
"id": "th",
"name": "",
"label": "泰文"
},
{
"id": "vi",
"name": "",
"label": "越南文"
},
{
"id": "ms",
"name": "",
"label": "马来文"
},
{
"id": "id",
"name": "",
"label": "印尼文"
}
]
}


