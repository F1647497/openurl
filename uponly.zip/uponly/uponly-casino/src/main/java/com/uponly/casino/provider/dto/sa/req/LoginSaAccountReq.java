package com.uponly.casino.provider.dto.sa.req;

import lombok.Data;
import lombok.experimental.SuperBuilder;

@SuperBuilder
@Data
public class LoginSaAccountReq {

    /**
     * 方法名
     */
    private String method;
    /**
     * 密钥
     */
    private String key;
    /**
     * 当前时间 时间格式：“yyyyMMddHHmmss”
     */
    private String time;
    /**
     * 用户名
     */
    private String userName;
    /**
     * 币种
     */
    private String currencyType;

    public LoginSaAccountReq(){

    }

    public enum MethodEnum {
        loginRequest("LoginRequest"),
        loginRequestForFun("LoginRequestForFun");
        private final String value;
        MethodEnum(String value) {
            this.value = value;
        }
        public String getValue() {
            return value;
        }
    }
}
