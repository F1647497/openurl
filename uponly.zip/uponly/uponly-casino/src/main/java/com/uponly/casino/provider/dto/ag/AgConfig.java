package com.uponly.casino.provider.dto.ag;
import com.alibaba.fastjson2.JSON;
import com.alibaba.fastjson2.JSONObject;
import com.uponly.casino.admin.vo.ProviderVO;
import lombok.Data;

@Data
public class AgConfig {
    private String baseUrl;
    private String cagent;
    private String MD5;
    private String DES;
    private String gameHistoryApiUrl;
    private String backUrl;
    private String getUrl;
    private String productId;

    public AgConfig() {

    }
}
