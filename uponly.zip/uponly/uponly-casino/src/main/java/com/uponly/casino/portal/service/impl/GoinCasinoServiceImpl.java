package com.uponly.casino.portal.service.impl;


import com.alibaba.cloud.commons.lang.StringUtils;
import com.alibaba.fastjson2.JSON;
import com.alibaba.fastjson2.JSONObject;
import com.uponly.casino.admin.vo.GameVO;
import com.uponly.casino.admin.vo.ProviderVO;
import com.uponly.casino.mapper.GameMapper;
import com.uponly.casino.common.constant.CasinoRedisKeyPrefix;
import com.uponly.casino.mapper.ProviderMapper;
import com.uponly.casino.portal.service.GoinCasinoService;
import com.uponly.casino.util.RedissonUtil;
import com.uponly.casino.util.UponlyHttpUtil;
import com.uponly.casino.common.api.ResultCode;
import com.uponly.casino.common.exception.BusinessException;
import com.uponly.casino.common.utils.UponlyKit;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@Service
public class GoinCasinoServiceImpl implements GoinCasinoService {


    @Autowired
    private ProviderMapper providerMapper;

    @Autowired
    private GameMapper gameMapper;

   @Autowired
    private RedissonUtil redissonUtil;


    @Override
    public int getGameStatus(String pgameId) {
        log.info("getGameStatus 已移除 ");
//        GameVO casinoGame = gameMapper.searchOneGame(pgameId);
//        if (casinoGame == null || casinoGame.getStatus() == 0) {
//            return 0;
//        }
//        ProviderVO provider = providerMapper.get(casinoGame.getPid());
//        if (provider == null || provider.getStatus() == 1) {
//            return 0;
//        }
        return 1;
    }

    @Override
    public String goInToCasino(Integer id, String uid, String token, String language, String lobbyUrl, Boolean isTest) throws Exception {
        log.info("goInToCasino 已移除 ");
//        GameVO casinoGame = gameMapper.searchOneGame(uid);
//        if (casinoGame == null || casinoGame.getStatus() == 0) {
//            log.error("用户请求进入游戏,但游戏不存在或者状态未打开!uid: {}, id: {}", uid, id);
//            throw new BusinessException(ResultCode.GAME_CLOSE);
//        }
//        ProviderVO provider = providerMapper.get(casinoGame.getPid());
//        if (provider == null) {
//            log.error("providerConf is null! id: {}", casinoGame.getPid());
//            throw new BusinessException(ResultCode.GAME_CLOSE);
//        }
//
//        Map<String, Object> map = new HashMap<>();
//        if (isTest != null && isTest) {
//            log.info("用户请求试玩！userId={} gameId={}", uid, id);
//            map.put("playMode", "DEMO");
//        }
//        map.put("secureLogin", null);
//        map.put("symbol", casinoGame.getGameId());
//        map.put("language", language);
//        redissonUtil.setStr(CasinoRedisKeyPrefix.userInfoToken + uid, token);   //无法带入token信息存入redis
//        map.put("token", uid);
//        map.put("lobbyUrl", StringUtils.isBlank(lobbyUrl) ? "/" : lobbyUrl);
//
//        String hash = UponlyKit.getSign(map, provider.getPrivateKey(), "", 2);
//        map.put("hash", hash);
//
//        String gameUrl;
//        try {
//            //待修改为evo进入游戏的url
//            String resText = UponlyHttpUtil.doPost("providerConf.getGoinUrl()", map);
//            JSONObject jsonObject = JSON.parseObject(resText);
//            if (!jsonObject.get("error").equals("0")) {
//                throw new BusinessException(ResultCode.GAME_CLOSE);
//            }
//            gameUrl = jsonObject.get("gameURL").toString();
//        } catch (Exception e) {
//            log.error("用户请求进入游戏，但运营商服务不可达！userId={} gameId={} map={}", uid, id, map);
//            throw new BusinessException(ResultCode.GAME_CLOSE);
//        }
//        log.info("用户请求进入游戏！userId={} gameUrl={}", uid, gameUrl);
//        return gameUrl;
        return null;
    }

}
