package com.uponly.casino.mapper;


import com.uponly.casino.admin.dto.AddProviderDTO;
import com.uponly.casino.admin.dto.DeleteProviderDTO;
import com.uponly.casino.admin.dto.SearchProviderDTO;
import com.uponly.casino.admin.dto.UpdateProviderDTO;
import com.uponly.casino.admin.vo.ProviderVO;

import java.util.List;

public interface ProviderMapper {
    Long add(AddProviderDTO addProviderDTO);

    List<ProviderVO> search(SearchProviderDTO provider);

    ProviderVO get(Long pid);

    int delete(DeleteProviderDTO deleteProviderDTO);

    int update(UpdateProviderDTO updateProviderDTO);

    Integer maxSort();

    List<ProviderVO> providers();

    List<ProviderVO> providersWithGameCount();
}
