//package com.uponly.casino.handler;
//
//import com.uponly.casino.admin.dto.UpdateMsgDTO;
//import com.uponly.casino.admin.service.OrderService;
//import com.uponly.casino.admin.vo.RebateMsgVO;
//import com.uponly.casino.common.api.Result;
//import com.uponly.casino.admin.service.GetRedisDataService;
//import com.uponly.casino.mapper.OrderMapper;
//import io.swagger.v3.oas.annotations.Operation;
//import io.swagger.v3.oas.annotations.tags.Tag;
//import lombok.extern.slf4j.Slf4j;
//import org.redisson.api.RList;
//import org.redisson.api.RedissonClient;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.*;
//
//import java.math.BigDecimal;
//import java.util.Date;
//import java.util.List;
//
//@Slf4j
//@RestController
//@RequestMapping("/jobController")
//@Tag(name = "JobController", description = "任务Controller")
//public class JobController {
//
//    @Autowired
//    ActivetJob activetJob;
//
//    @Autowired
//    AmountJob amountJob;
//
//    @Autowired
//    GgrJob ggrJob;
//
//    @Autowired
//    RebateJob rebateJob;
//
//    @Autowired
//    BetMsgJob betMsgJob;
//
//    @Autowired
//    RedissonClient redissonClient;
//
//    @Autowired
//    GetRedisDataService getRedisDataService;
//
//    @Autowired
//    KafkJob kafkJob;
//
//    @Autowired
//    UpdateEffectiveAmountJob updateEffectiveAmountJob;
//
//    @Autowired
//    OrderService orderService;
//
//    @Autowired
//    KafkJobForFix kafkJobForFix;
//
//
//    @ResponseBody
//    @Operation(summary = "删除redis")
//    @PostMapping("/deleteRedisData")
//    public Result<String> deleteRedisData(@RequestParam String key) {
//        redissonClient.getKeys().delete(key);
//        return Result.success("success");
//    }
//
//    @ResponseBody
//    @Operation(summary = "testAllJob")
//    @PostMapping("/testAllJob")
//    public Result<String> testAllJob() {
//        kafkJob.sendAmountMsg();
//        return Result.success("success");
//    }
//
//    @ResponseBody
//    @Operation(summary = "testRebateJob")
//    @PostMapping("/testRebateJob")
//    public Result<String> testRebateJob() {
//        kafkJob.sendRebateMsg();
//        return Result.success("success");
//    }
//
//
//    @ResponseBody
//    @Operation(summary = "调用测试")
//    @PostMapping("/testCall")
//    public Result<String> testCall() {
//       /* //更新有效流水方法
//        List<String> orderListRedis = getRedisDataService.getEvoRedisDataForAmount();
//        System.out.println("orderListRedis = " + orderListRedis);
//        try {
//            updateEffectiveAmountJob.updateEffectiveAmount(orderListRedis);
//        } catch (Exception e) {
//            log.error("updateEffectiveAmountJob 任务失败", e);
//            throw new RuntimeException(e);
//        }*/
//
//
//        kafkJobForFix.sendAmountMsg();
//
//
//       /* UpdateMsgDTO updateMsgDTO = new UpdateMsgDTO();
//
//  //      updateMsgDTO.setMsgNumber(0b0010000);
//        updateMsgDTO.setOrderNo("a0ce9ff1-b4c1-455c-95c8-4a34d194a200");
//
//        orderService.updateMsgState(updateMsgDTO);
//
//
//       updateMsgDTO.setMsgNumber(0b0001000);
//        orderService.updateMsgState(updateMsgDTO);
//*//*
//        updateMsgDTO.setMsgNumber(0b0000100);
//        orderService.updateMsgState(updateMsgDTO);*//*
//
//     *//*   updateMsgDTO.setMsgNumber(0b0000010);
//        orderService.updateMsgState(updateMsgDTO);
//*//*
//        updateMsgDTO.setMsgNumber(0b0000001);
//        orderService.updateMsgState(updateMsgDTO);*/
//
//
//
//
//        return Result.success("success");
//    }
//
//
//}
//
