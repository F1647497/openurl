package com.uponly.casino.provider.dto.ae.req;

import lombok.Data;

import java.util.List;

@Data
public class SettleReq {
    public String action;
    public List<SettleTransaction> txns;
}

