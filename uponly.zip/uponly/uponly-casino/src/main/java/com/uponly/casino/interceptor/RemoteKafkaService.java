package com.uponly.casino.interceptor;

import com.alibaba.fastjson.JSONObject;
import com.uponly.casino.interceptor.kafka.KafkaMessageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;

import java.util.concurrent.CompletableFuture;

@Service
public class RemoteKafkaService {
    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    public CompletableFuture<?> sendKafkaMessage(KafkaMessageHelper.TopicEnum topic, String type, Object data, String channel) {
        return kafkaTemplate.send(topic.getTopic(), KafkaMessageHelper.toJsonString(type, data, channel));
    }

    public CompletableFuture<SendResult<String, String>> send(String topic, String message) {
        return kafkaTemplate.send(topic, message);
    }

    public CompletableFuture<SendResult<String, String>> send(String topic, JSONObject message) {
        return kafkaTemplate.send(topic, message.toJSONString());
    }
}
