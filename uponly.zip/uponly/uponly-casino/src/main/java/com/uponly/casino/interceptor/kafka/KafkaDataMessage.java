package com.uponly.casino.interceptor.kafka;

import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.UUID;

@Data
@Builder
public class KafkaDataMessage<T> {
    private String messageType;
    private MessageBody<T> messageBody;

    @Data
    @Builder
    public static class MessageBody<T> {
        private String channel;
        private Body<T> data;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @SuperBuilder
    public static class Body<T> {
        private String type;
        private T data;
    }

    @Data
    @Builder
    public static class ActivityMessage<T> {
        private String messageType;
        private T messageBody;
        @Builder.Default
        private String messageId = UUID.randomUUID().toString();
        @Builder.Default
        private Long ts = System.currentTimeMillis();
    }
}