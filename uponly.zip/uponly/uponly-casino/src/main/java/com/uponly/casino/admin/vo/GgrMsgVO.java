package com.uponly.casino.admin.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.math.BigDecimal;

@Schema(title = "真人注单消息")
@Data
public class GgrMsgVO {
    private String region;
    private int level;
    private int star;

    private String stakeResult;
    private Boolean isTurnover;
    private String currency;

    private String betId;
    private String tag;
    private String agentId;
    private Long userId;

    private BigDecimal amount;
    private String settleAt;


}