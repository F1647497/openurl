package com.uponly.casino.provider.dto.ae.resp;

import com.alibaba.fastjson2.JSONObject;
import lombok.Data;

@Data
public class SettleResp {
    protected String status;
    protected String desc;

    public SettleResp(String status, String desc) {
        this.status = status;
        this.desc = desc;
    }
    public SettleResp(String status, String desc, boolean success) {
        this.status = status;
        this.desc = desc;
    }

    public SettleResp(){
        super();
    }

    public JSONObject toReturnFail(String status,String desc) {
        this.setStatus(status);
        this.setDesc(desc);
        JSONObject jsonObject =JSONObject.from(this);
        jsonObject.put("status", getStatus());
        jsonObject.put("desc", getDesc());
        return jsonObject;
    }
    public JSONObject toReturnSuccess(String status) {
        this.setStatus(status);
        JSONObject jsonObject =JSONObject.from(this);
        jsonObject.put("status", getStatus());

        return jsonObject;
    }

}
