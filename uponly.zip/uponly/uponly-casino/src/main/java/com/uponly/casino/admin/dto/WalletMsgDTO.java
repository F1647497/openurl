package com.uponly.casino.admin.dto;


import lombok.Data;

import java.math.BigDecimal;


/**
 * 传值到nodejs钱包服务
 */
@Data
public class WalletMsgDTO {

    /**
     * 用户id
     */
    private Long userId;


    /**
     * 订单号
     */
    private String betOrderNumber;


    /**
     * SlotsBetFreeze //电子投注冻结
     * SlotsBetFailedUnfreeze //电子投注失败解冻
     * SlotsBetSuccessful // 电子投注成功扣除
     * SlotsPayout // 电子赔付
     */
    private String operatorType;


    /**
     * 金额
     */
    private BigDecimal betAmount;

    /**
     * 最终赔付金额
     */
    private BigDecimal payout;


    /**
     * 倍数
     */
    private BigDecimal multiplier;


    /**
     * 游戏id
     */
    private Long gameId;


    /**
     * 供应商id
     */
    private Long providerId;


    /**
     * 游戏名称
     */
    private String gameName;


    /**
     * 备注
     */
    private String remark;


    /**
     * transactionId
     */
    private String transactionId;


    private String sessionId;

}
