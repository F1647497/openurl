package com.uponly.casino.provider.dto.ag.req;

import lombok.Data;
import lombok.experimental.SuperBuilder;

@SuperBuilder
@Data
public class CreateAccountReq {
    private String cagent;      // 代理编码。数值=XXX_AGIN，这是一个常数
    private String loginname;   // 游戏账号的登录名。必须少于20个字符，并区分大小写、不可带特殊字符，只允许英文字母、数字、下划线
    private String method; //
    private String actype;       // actype=1 代表真钱账号    actype=0 代表试玩账号
    private String password;     // 游戏账号的密码。必须少于20字符，不支持以下字符: ' , “ , \ , / , > , < , & , # , -- , % , ? , $, 空格, 双节字符(全角字), TAB键, NULL, 换行符(\N)
    private String oddtype; //盘口。设定新玩家可下注的范围 默认值：A   A~I
    private String cur; //账号创建成功后便不能再修改cur

    public static final String DIVIDER = "/\\\\\\\\/";

    public CreateAccountReq() {

    }

    public CreateAccountReq(String cagent, String loginname, String method, String actype, String password, String oddtype, String cur) {
        this.cagent = cagent;
        this.loginname = loginname;
        this.method = method;
        this.actype = actype;
        this.password = password;
        this.oddtype = oddtype;
        this.cur = cur;
    }

    public static enum MethodEnum {
        CHECK_OR_CREATE_GAME_ACCOUNT("lg");
        private final String value;
        MethodEnum(String value) {
            this.value = value;
        }
        public String getValue() {
            return value;
        }
    }
    public static enum OddTypeEnum {
        A("A"),
        B("B"),
        C("C"),
        D("D"),
        E("E"),
        F("F"),
        G("G"),
        H("H"),
        I("I"),;
        private final String value;
        OddTypeEnum(String value) {
            this.value = value;
        }
        public String getValue() {
            return value;
        }
    }

    public String toParam(CreateAccountReq req) {
        StringBuilder builder = new StringBuilder();
        builder.append("cagent=").append(req.getCagent()).append(DIVIDER)
                .append("loginname=").append(req.getLoginname()).append(DIVIDER)
                .append("method=").append(req.getMethod()).append(DIVIDER)
                .append("actype=").append(req.getActype()).append(DIVIDER)
                .append("password=").append(req.getPassword()).append(DIVIDER)
                .append("oddtype=").append(req.getOddtype()).append(DIVIDER)
                .append("cur=").append(req.getCur());
        return builder.toString();
    }
}
