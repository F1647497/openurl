//package com.uponly.casino.handler;
//
//
//import com.alibaba.fastjson.JSONObject;
//import com.uponly.casino.admin.dto.UpdateMsgDTO;
//import com.uponly.casino.admin.vo.ActiveMsgVO;
//import com.uponly.casino.common.utils.RegionIntegerUtil;
//import com.uponly.casino.interceptor.RemoteKafkaService;
//import com.uponly.casino.admin.service.GetRedisDataService;
//import com.uponly.casino.mapper.OrderMapper;
//import com.uponly.casino.provider.service.UserInfoService;
//import com.uponly.casino.provider.vo.UserInfoVO;
//import lombok.extern.slf4j.Slf4j;
//import org.redisson.api.RLock;
//import org.redisson.api.RedissonClient;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.kafka.support.SendResult;
//import org.springframework.stereotype.Service;
//
//import java.math.BigDecimal;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Optional;
//import java.util.UUID;
//import java.util.concurrent.CompletableFuture;
//
//
//@Service
//@Slf4j
//public class ActivetJob extends AbstractReportJob {
//
//
//    @Autowired
//    private RemoteKafkaService remoteKafkaService;
//
//    @Autowired
//    RedissonClient redissonClient;
//
//    @Autowired
//    UserInfoService userInfoService;
//
//    @Autowired
//    GetRedisDataService getRedisDataService;
//
//    @Autowired
//    OrderMapper orderMapper;
//
//    public void sendActiveMsg(List<String> orderListRedis) {
//        RLock lock = redissonClient.getLock("sendActiveMsg");
//        try {
//            // 从redis中获取casino注单列表，然后一次性发送订单数组到kafka
//            lock.lock();
//            List<ActiveMsgVO> activeMsgVOList = this.generateMsg(orderListRedis);
//            for (ActiveMsgVO activeMsgVO : activeMsgVOList) {
//                CompletableFuture<SendResult<String, String>> future = this.sendActiveMsgJob(activeMsgVO);
//                log.info("【sendActiveMsgJob】的发送结果={}", future);
//            }
//        } catch (Exception e) {
//            log.error("sendActiveMsg异常 ", e);
//        } finally {
//            lock.unlock();
//        }
//    }
//
//    public List<ActiveMsgVO> generateMsg(List<String> orderListRedis) {
//        try {
//            List<ActiveMsgVO> activeMsgVOList = new ArrayList<>();
//            for (String orderJsonString : orderListRedis) {
//                JSONObject jsonObject = JSONObject.parseObject(orderJsonString);
//
//                Long userId = jsonObject.getLong("userId");
//                Optional<UserInfoVO> userInfoVO = userInfoService.getUser(userId);
//                UserInfoVO userInfo = userInfoVO.get(); // 获取内部对象
//
//                String region = RegionIntegerUtil.lcationIdToRegion(userInfo.getLocation());
//                int level = userInfo.getVip();
//                int star = userInfo.getStar();
//                String agentId = userInfo.getAgentId();
//
//                BigDecimal amount = jsonObject.getBigDecimal("amount");
//                BigDecimal payout = jsonObject.getBigDecimal("payout");
//                BigDecimal difference = payout.subtract(amount); // 使用 subtract() 方法进行减法操作
//                String stakeResult = difference.compareTo(BigDecimal.ZERO) > 0 ? "win" : difference.compareTo(BigDecimal.ZERO) < 0 ? "lose" : "draw";
//                Boolean isTurnover = difference.compareTo(BigDecimal.ZERO) == 0 ? false : true;
//                String currency = jsonObject.getString("currency");
//                String betId = jsonObject.getString("orderNo");
//                String tagFromUserInfo = jsonObject.getString("tag");
//                String tag = tagFromUserInfo == null ? "real" : "test";
//
//                ActiveMsgVO activeMsgVO = new ActiveMsgVO();
//                activeMsgVO.setUserId(userId);
//                activeMsgVO.setAgentId(agentId);
//                activeMsgVO.setRegion(region);
//                activeMsgVO.setLevel(level);
//                activeMsgVO.setStar(star);
//                activeMsgVO.setStakeResult(stakeResult);
//                activeMsgVO.setIsTurnover(isTurnover);
//                activeMsgVO.setCurrency(currency);
//                activeMsgVO.setAmount(amount);
//                activeMsgVO.setBetId(betId);
//                activeMsgVO.setTag(tag);
//
//                activeMsgVOList.add(activeMsgVO);
//            }
//
//            return activeMsgVOList;
//        } catch (Exception e) {
//            log.error("generateMsg 异常{} ", e.getMessage());
//        }
//        return List.of();
//    }
//
//    public CompletableFuture<SendResult<String, String>> sendActiveMsgJob(ActiveMsgVO activeMsgVO) {
//        try {
//            JSONObject jsonObjectOfBetting = new JSONObject();
//
//            jsonObjectOfBetting.put("gameType", "EVO Casino");
//            jsonObjectOfBetting.put("agentId", activeMsgVO.getAgentId());
//            //active只是统计用户的活跃次数,amount 不用放有效流水
//            jsonObjectOfBetting.put("amount", activeMsgVO.getAmount());
//            jsonObjectOfBetting.put("star", activeMsgVO.getStar());
//            jsonObjectOfBetting.put("level", activeMsgVO.getLevel());
//
//            jsonObjectOfBetting.put("userId", activeMsgVO.getUserId());
//            jsonObjectOfBetting.put("currency", activeMsgVO.getCurrency());
//            jsonObjectOfBetting.put("tag", activeMsgVO.getTag());
//            jsonObjectOfBetting.put("region", activeMsgVO.getRegion());
//
//
//            JSONObject jsonObjectMsgOfBetting = new JSONObject();
//
//            jsonObjectMsgOfBetting.put("messageType", "active");
//            jsonObjectMsgOfBetting.put("messageBody", jsonObjectOfBetting);
//            jsonObjectMsgOfBetting.put("partion", 0);
//            jsonObjectMsgOfBetting.put("messageId", UUID.randomUUID());
//            jsonObjectMsgOfBetting.put("ts", System.currentTimeMillis());
//
//            String msgOfBettingForKafka = jsonObjectMsgOfBetting.toJSONString();
//
//            log.info("【active注单上报】sendActiveMsg.msg={}", msgOfBettingForKafka);
//            CompletableFuture<SendResult<String, String>> future = super.execute(activeMsgVO.getUserId(), msgOfBettingForKafka);
//            //     CompletableFuture<SendResult<String, String>> future = remoteKafkaService.send(CommonConstant.CASINO_BETTING_JOB_TOPIC, msgOfBettingForKafka);
//            //用5个位置 表示发送消息的状态，1表示已发送，0 未发送，
//            // 消息所在位置：AmountMsg：第1位；GgrMsg：第2位；ActiveMsg：第3位；GgrMsg：第4位；BetMsg：第5位；RebateMsg
//
//            UpdateMsgDTO updateMsgDTO = new UpdateMsgDTO();
//            updateMsgDTO.setOrderNo(activeMsgVO.getBetId());
//            updateMsgDTO.setMsgNumber(0b00100);
//
//            if (future != null) {
//                Integer count = orderMapper.updateMsgState(updateMsgDTO);
//                log.info("active更新消息状态数量 = {}", count);
//            }
//
//            return future;
//        } catch (Exception e) {
//            log.error("sendActiveMsgJob 异常{} ", e.getMessage());
//        }
//        return null;
//    }
//
//
//}
