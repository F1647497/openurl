package com.uponly.casino.provider.dto.evo.res;

import lombok.Data;

@Data
public class AuthenticationResponse {
    String url;

    public AuthenticationResponse(String baseUrl, String entry) {
        this.url = baseUrl + entry;
    }
    public AuthenticationResponse(String entry) {
        this.url = entry;
    }
}
