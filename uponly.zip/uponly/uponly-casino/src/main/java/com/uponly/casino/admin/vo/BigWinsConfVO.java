package com.uponly.casino.admin.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;


@Data
public class BigWinsConfVO implements Serializable {

    @Schema(title = "id序号")
    private Long id;

    @Schema(title = "货币类型")
    private String currency;

    @Schema(title = "最小金额")
    private BigDecimal minAmount;

    @Schema(title = "倍数")
    private BigDecimal multiplier;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Schema(title = "创建时间")
    private Date createTime;

    @Schema(title = "创建人")
    private String creator;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Schema(title = "更新时间")
    private Date updateTime;

    @Schema(title = "更新人")
    private String updater;

}