package com.uponly.casino.provider.dto;

import com.uponly.casino.admin.vo.EntryVO;
import com.uponly.casino.admin.vo.GameOriginalVO;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class GameInfoExDTO extends GameInfoDTO {
    @Schema(description = "游戏名称")
    private String gameName;

    @Schema(description = "供应商名字")
    private String providerName;

    @Schema(description = "游戏排序")
    private Integer sort;

    public GameInfoExDTO(GameInfoDTO gameInfoDTO) {
        super(gameInfoDTO);
        this.sort = 0;
        this.setGameName(this.getName());
        if (gameInfoDTO.getInfoType() == GameInfoDTO.EnumInfoType.ENTRY) {
            var orgin = (EntryVO) gameInfoDTO.getOrigin();
            this.setProviderName(orgin.getProviderName());
            this.sort = orgin.getSort();
        } else {
            var origin = (GameOriginalVO) gameInfoDTO.getOrigin();
            this.setProviderName(origin.getGameProvider());
        }
    }
}
