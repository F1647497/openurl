package com.uponly.casino.portal.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;


@Data
@Schema
public class StatisticsVO implements Serializable {


    /**
     * 投注金额
     */
    @Schema(title = "投注次数")
    private int betCount;

    @Schema(title = "平均投注额")
    private BigDecimal averageBetAmount;

    @Schema(title = "最大赔付")
    private BigDecimal maxPayout;

    @Schema(title = "总赔付")
    private BigDecimal totalPayout;



    @Schema(title = "总投注额")
    private BigDecimal totalBetAmount;

    @Schema(title = "获胜次数")
    private int winCount;

    @Schema(title = "平均获胜额")
    private BigDecimal avgWinAmount;

    @Schema(title = "币种")
    private String currency;


}
