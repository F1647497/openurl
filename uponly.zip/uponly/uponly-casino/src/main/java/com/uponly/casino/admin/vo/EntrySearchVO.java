package com.uponly.casino.admin.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class EntrySearchVO {

    @Schema(title = "id")
    private Integer id;

    @Schema(title = "eid")
    private Long eid;

    @Schema(title = "pid")
    private Long pid;

    @Schema(title = "gameId")
    private Long gameId;

    @Schema(title = "ename")
    private String ename;

    @Schema(title = "providerName")
    private String providerName;

    @Schema(title = "regions")
    private String regions;

    @Schema(title = "favoriteCount")
    private int favoriteCount;

    @Schema(title = "gameType")
    private String gameType;

    @Schema(title = "status")
    private Integer status;

    @Schema(title = "icon")
    private String icon;

    @Schema(title = "mainEntry")
    private String mainEntry;

    @Schema(title = "addtion")
    private String addition;

    @Schema(title = "promotion")
    private Integer promotion;

    @Schema(title = "sort")
    private Integer sort;

}
