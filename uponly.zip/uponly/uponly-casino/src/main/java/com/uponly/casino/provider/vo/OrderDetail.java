package com.uponly.casino.provider.vo;

import com.alibaba.fastjson2.JSONObject;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class OrderDetail {

    @Schema(title = "id")
    private Integer id;
    @Schema(title = "第三方注单号")
    private String thirdOrderNo;

    @Schema(title = "用户id")
    private Long userId;

    @Schema(description = "游戏id")
    private String roundId;

    @Schema(title = "游戏名称")
    private String gameName;

    @Schema(title = "投注金额")
    private BigDecimal amount;

    @Schema(title = "赔付金额")
    private BigDecimal payout;

    @Schema(title = "注单状态")
    private Integer status;

    @Schema(title = "投注类型")
    private Integer betType;

    @Schema(title = "结算类型")
    private String settleType;

    @Schema(title = "消息体")
    private String body;

    @Schema(title = "用户名")
    private String userName;

    @Schema(title = "tableId")
    private String tableId;

    @Schema(title = "会话ID") // This is a guess, since `session_id` isn't described in the `OrderVO`.
    private String sessionId;

    @Schema(title = "provider ID") // This is a guess, since `pid` isn't described in the `OrderVO`.
    private Long pid;
}