package com.uponly.casino.portal.controller;


import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.github.pagehelper.PageInfo;
import com.uponly.casino.admin.dto.PageInfoDTO;
import com.uponly.casino.admin.service.*;
import com.uponly.casino.admin.vo.*;
import com.uponly.casino.portal.dto.BaseRequestDTO;
import com.uponly.casino.portal.dto.FavoriteDTO;
import com.uponly.casino.portal.dto.LaunchGameDTO;
import com.uponly.casino.portal.dto.SearchOrderFeDTO;
import com.uponly.casino.portal.service.FavoriteService;
import com.uponly.casino.portal.service.GoinCasinoService;
import com.uponly.casino.portal.service.HeaderService;
import com.uponly.casino.provider.service.GameInfoService;
import com.uponly.casino.provider.service.ProviderManager;
import com.uponly.casino.common.api.Result;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@Slf4j
@Tag(name = "WebApiController", description = "web显示")
@RequestMapping(value = "/portal/games")
public class WebApiController {

    @Autowired
    private GameService gameService;
    @Autowired
    EntranceService entryService;

    @Autowired
    GoinCasinoService goinCasinoService;

    @Autowired
    private HeaderService headerService;

    @Autowired
    ProviderService providerService;

    @Autowired
    ProviderManager providerManager;

    @Autowired
    private GameInfoService gameInfoService;


    @Autowired
    private CasinoBannerService casinoBannerService;

    @Autowired
    private OrderService orderService;

    @Autowired
    private FavoriteService favoriteService;


    @ResponseBody
    @Operation(summary = "查询注单记录")
    @PostMapping("/searchOrderList")
    public Result<Map<String, Object>> searchOrderList(@RequestHeader("Slanguage") String slanguage,
                                                       @RequestParam(value = "betOrderThreeStr", required = true)
                                                       String betOrderStr,
                                                       @RequestBody(required = true)
                                                       SearchOrderFeDTO searchOrderFeDTO) throws JsonProcessingException {
        try {
            // 将逗号分隔的字符串转换为列表
            String[] orderNoArray = betOrderStr.split(",");
            List<String> orderNoList = Arrays.asList(orderNoArray);
            searchOrderFeDTO.setOrderNoList(orderNoList);
            Map<String, Object> orderList = orderService.searchOrderByOrderNoList(searchOrderFeDTO);
            return Result.success(orderList);
        } catch (JsonProcessingException e) {
            log.info("查询注单记录 异常{} ", e.getMessage());
        }
        return null;
    }

    @ResponseBody
    @Operation(summary = "查询注单")
    @PostMapping("/searchOrderFe")
    public Result<Map<String, Object>> searchOrderFe(@RequestBody SearchOrderFeDTO searchOrderFeDTO,
                                                     @RequestHeader("uid") Long uid) throws JsonProcessingException {

        try {
            searchOrderFeDTO.setUserId(uid);
            Map<String, Object> map = orderService.searchOrderFe(searchOrderFeDTO);
            return Result.success(map);
        } catch (JsonProcessingException e) {
            log.error("查询注单 异常{} ", e.getMessage());

        }
        return null;
    }

    @Operation(summary = "获取banner列表")
    @RequestMapping(value = "/banner/list", method = RequestMethod.GET)
    public Result<List<CasinoBanner>> getCommentList(@RequestHeader("Sregion") Integer region,
                                                     @RequestHeader("Slanguage") String language) {
        try {
            List<CasinoBanner> list = casinoBannerService.casinoBannerListFe(region + "-" + language);
            return Result.success(list);
        } catch (Exception e) {
            log.error("获取banner列表 异常{} ", e.getMessage());

        }
        return null;
    }

    @Operation(summary = "查询入口是否被收藏")
    @RequestMapping(value = "/checkIfFavorite", method = RequestMethod.POST)
    @ResponseBody
    public Result<Boolean> checkIfFavorite(@RequestParam Long eid,
                                           @RequestHeader("uid") Long uid) {
        if (uid.equals(0L)) {
            return Result.fail(false);
        }
        try {
            FavoriteDTO favoriteDTO = new FavoriteDTO();
            favoriteDTO.setUserId(uid);
            favoriteDTO.setEid(eid);
            boolean isExist = favoriteService.exists(favoriteDTO);
            return Result.success(isExist);
        } catch (Exception e) {
            log.error("查询入口是否被收藏 异常{} ", e.getMessage());
        }
        return null;
    }


    @Operation(summary = "获取收藏游戏")
    @PostMapping("/favorite")
    public Result<PageInfo<EntryFrontVO>> favorite(@RequestBody BaseRequestDTO favoriteRequestDTO,
                                                   @RequestHeader("Sregion") String sregion,
                                                   @RequestHeader("uid") Long userId,
                                                   @RequestHeader(value = "Slanguage", required = false) String slanguage) {
        try {
            PageInfo<EntryFrontVO> pageInfoList = gameService.favorite(favoriteRequestDTO.getPage(), favoriteRequestDTO.getPageSize(), favoriteRequestDTO.getIds(), sregion, userId, slanguage);
            return Result.success(pageInfoList);
        } catch (Exception e) {
            log.error("获取收藏游戏 异常{} ", e.getMessage());

        }
        return null;
    }

    @Operation(summary = "获取所有游戏列表")
    @PostMapping("/allGameList")
    public Result<PageInfo<EntryFrontVO>> allGameList(@RequestBody BaseRequestDTO allGameRequestDTO,
                                                      @RequestHeader("Sregion") String sregion,
                                                      @RequestHeader("uid") Long userId,
                                                      @RequestHeader(value = "Slanguage", required = false) String slanguage) {
        try {
            PageInfo<EntryFrontVO> pageInfoList = gameService.allGameList(allGameRequestDTO.getPage(), allGameRequestDTO.getPageSize(), allGameRequestDTO.getIds(), sregion, userId, slanguage);
            return Result.success(pageInfoList);
        } catch (Exception e) {
            log.error("获取所有游戏列表 异常{} ", e.getMessage());

        }
        return null;
    }

    @Operation(summary = "获取推广游戏列表")
    @PostMapping("/promotionGameList")
    public Result<PageInfo<EntryFrontVO>> promotionGameList(@RequestBody BaseRequestDTO allGameRequestDTO,
                                                            @RequestHeader("Sregion") String sregion,
                                                            @RequestHeader("uid") Long userId,
                                                            @RequestHeader(value = "Slanguage", required = false) String slanguage) {
        try {
            PageInfo<EntryFrontVO> pageInfoList = gameService.promotionGameList(allGameRequestDTO.getPage(), allGameRequestDTO.getPageSize(), allGameRequestDTO.getIds(), sregion, userId, slanguage);
            return Result.success(pageInfoList);
        } catch (Exception e) {
            log.error("获取推广游戏列表 异常{} ", e.getMessage());

        }
        return null;
    }

    @Operation(summary = "获取分类游戏列表")
    @PostMapping("/gameTypeList")
    public Result<PageInfo<EntryFrontVO>> gameTypeList(@RequestBody BaseRequestDTO allGameRequestDTO,
                                                       @RequestHeader("Sregion") String sregion,
                                                       @RequestHeader("uid") Long userId,
                                                       @RequestHeader(value = "Slanguage", required = false) String slanguage) {
        try {
            PageInfo<EntryFrontVO> pageInfoList = gameService.gameTypeList(allGameRequestDTO.getPage(), allGameRequestDTO.getPageSize(), allGameRequestDTO.getIds(), sregion, userId, slanguage, allGameRequestDTO.getGameType());
            return Result.success(pageInfoList);
        } catch (Exception e) {
            log.error("获取分类游戏列表 异常{} ", e.getMessage());

        }
        return null;
    }

    @Operation(summary = "获取推荐游戏列表")
    @PostMapping("/recommendList")
    public Result<PageInfo<EntryFrontVO>> recommendList(@RequestBody PageInfoDTO pageInfoDTO,
                                                        @RequestHeader("Sregion") String sregion,
                                                        @RequestHeader("uid") Long userId,
                                                        @RequestHeader(value = "Slanguage", required = false) String slanguage) {
        try {

            PageInfo<EntryFrontVO> pageInfoList = gameService.recommendList(pageInfoDTO.getPage(), pageInfoDTO.getPageSize(), sregion, userId, slanguage);
            return Result.success(pageInfoList);
        } catch (Exception e) {
            log.error("获取推荐游戏列表 异常{} ", e.getMessage());

        }
        return null;
    }

    @Operation(summary = "根据eid查询")
    @PostMapping("/searchEntryByEid")
    public Result<EntryFrontVO> searchEntryByEid(@RequestParam Long eid,
                                                 @RequestHeader("Sregion") String sregion,
                                                 @RequestHeader("uid") Long userId,
                                                 @RequestHeader(value = "Slanguage", required = false) String slanguage
    ) {
        try {
            EntryFrontVO entryFrontVO = gameService.searchEntryByEid(eid, sregion, userId, slanguage);
            return Result.success(entryFrontVO);
        } catch (Exception e) {
            log.error("根据eid查询异常", e);
            return Result.fail(1001, "根据eid查询异常");
        }

    }

    @Operation(summary = "根据供应商名称ename查询")
    @PostMapping("/searchEntrance")
    public Result<EntryFrontVO> searchEntrance(
            @RequestParam String requestData,
            @RequestHeader("Sregion") String sregion,
            @RequestHeader("uid") Long uid,
            @RequestHeader(value = "Slanguage", required = false) String slanguage
    ) {
        try {
            EntryFrontVO entryFrontVO = gameService.searchEntranceFe(requestData, sregion, uid, slanguage);
            return Result.success(entryFrontVO);
        } catch (Exception e) {
            log.error("根据requestData查询异常", e);
            return Result.fail(1001, "根据requestData查询异常");
        }

    }


    @Operation(summary = "进入游戏")
    @PostMapping(value = "/getLuaunchURI")
    public Result<?> getLaunchURI(@RequestBody LaunchGameDTO requestDTO,
                                  @RequestHeader("uid") String uid,
                                  @RequestHeader("userInfo") String token,
                                  @RequestHeader("Slanguage") String language) throws Exception {
        try {
            // 获取user-agent
            var bindName = requestDTO.getBindName();
            log.info("用户进入游戏，请求游戏url，game id:{},uid={},token={}", bindName, uid, token);
            if (StringUtils.isBlank(uid) || uid.equals("0") || StringUtils.isBlank(token) || !bindName.contains("-")) {
                log.error("用户进入游戏异常。id={},uid={},token={}", requestDTO.getBindName(), uid, token);
                return Result.validateFailed("请重试，或重新登录。");
            }
            var gameInfo = gameInfoService.getGameInfo(bindName);
            log.info("用户进入游戏  gameInfo : {}",JSONObject.toJSONString(gameInfo));

            if (gameInfo.isEmpty()) {
                log.error("用户进入游戏异常, 获取游戏信息失败。id={},uid={},token={}", bindName, uid, token);
                return Result.fail(1201, "无法获取游戏信息，请稍后再试");
            }
            var pid = gameInfo.get().getPid().toString();
            var instance = providerManager.getInstance(pid);
            if (instance == null) {
                log.error("用户进入游戏异常, 获取游戏实例失败。pid={}, bindName={}", pid, bindName);
                return Result.fail(1201, "无法获取游戏信息，请稍后再试");
            }
            var request = new HashMap<String, Object>();
            request.put("uid", uid);
            request.put("language", language);
            request.put("playMode", requestDTO.getPlayMode());
            request.put("backUrl", requestDTO.getBackUrl());
            request.put("timeoutUrl", requestDTO.getTimeoutUrl());
            request.put("clientIp", "127.0.0.1");
            request.put("bindName", bindName);
            request.put("gameInfo", gameInfo.get());
            return instance.getLaunchURI(request);
        } catch (Exception e) {
            log.error("获取进入游戏url 异常", e);
        }
        return null;
    }

    // 获取所有的Provider
    @Operation(summary = "获取所有的Provider")
    @GetMapping("/providers")
    public Result<PageInfo<BaseProviderVO>> providers() {
        try {
            List<ProviderVO> providers = providerService.providers();
            var pageInfo = new PageInfo<BaseProviderVO>(providers);
            return Result.success(pageInfo);
        } catch (Exception e) {
            log.error("获取所有的Provider异常", e);
            return Result.fail(1001, "无法获取供应商列表，请稍后再试");
        }
    }

    @Operation(summary = "获取evo游戏列表")
    @GetMapping(value = "/getGames")
    public Result<JSONObject> getGames() {
        try {
            JSONObject res = gameService.getGames();
            return Result.success(res);
        } catch (Exception e) {
            log.error("获取evo游戏列表 异常", e);
        }
        return null;
    }

    @Operation(summary = "获取evo游戏列表（已过滤）")
    @GetMapping(value = "/getGamesFiltered")
    public Result<JSONObject> getGamesFiltered() {

//        JSONObject res = gameService.getGamesFiltered();

        return Result.success();
    }

    @Operation(summary = "将三方游戏添加到原始游戏表")
    @PostMapping(value = "/addGamesFromEvo")
    public Result<String> addGamesFromEvo() {
//        JSONObject games = gameService.getGamesFiltered();
//        Set<Map.Entry<String, Object>> entrySet = games.entrySet();
//        GameOriginalVO game = new GameOriginalVO();
//        // 遍历entrySet并获取所有tableId的键和值
//        for (Map.Entry<String, Object> entry : entrySet) {
//            String tableName = entry.getKey(); // 获取tableId
//            JSONObject gameData = (JSONObject) entry.getValue();
//
//            game.setPid(11000L);
//            game.setTableName(tableName);
//            game.setGameName(gameData.getString("name"));
//            game.setGameProvider(gameData.getString("gameProvider"));
//            game.setGameType(gameData.getString("gameType"));
//
//            game.setGameSubtype(gameData.getString("gameSubType"));
//            game.setVirtualTableId(gameData.getString("virtualTableId"));
//            game.setLuckyNumbers(gameData.getString("luckyNumbers"));
//            game.setSitesAssigned(gameData.getString("sitesAssigned"));
//            game.setPlayers(Integer.valueOf(gameData.getString("players")));
//
//            game.setDisplay(gameData.getString("display"));
//            game.setLang(gameData.getString("language"));
//            game.setHistory(gameData.getString("history"));
//            game.setDescriptions(gameData.getString("descriptions"));
//            game.setVideoSnapshot(gameData.getString("videoSnapshot"));
//
//            game.setBetLimits(gameData.getString("betLimits"));
//            game.setDealer(gameData.getString("dealer"));
//            String operationHours = gameData.getString("operationHours");
//            //如果operationHours{"type":"FullTime"}，则设置operationStartTime和operationEndTime为null
//            if (operationHours.equals("{\"type\":\"FullTime\"}")) {
//                game.setOperationStart(new Date());
//                game.setOperationEnd(new Date());
//            }
//
//            game.setOperationHours(gameData.getString("operationHours"));
//            game.setOpen(gameData.getInteger("open"));
//            game.setTableId(gameData.getString("tableId"));
//
//            gameService.addGamesFromEvo(game);
//        }


        return null;
    }

    //热门游戏
    /*    @Operation(summary = "热门游戏")
        @PostMapping("/popular")
        public Result<PageInfo<GameVO>> popular(
                @RequestBody BaseRequestDTO requestDTO,
                @RequestHeader("Sregion") String sregion,
                @RequestHeader("uid") Long userId,
                @RequestHeader(value = "Slanguage", required = false) String slanguage
        ) {
            PageInfo<GameVO> pageInfoList = gameService.popular(
                    requestDTO.getPage(),
                    requestDTO.getIds(),
                    sregion,
                    userId,
                    slanguage
            );
            return Result.success(pageInfoList);
        }*/

    //推广游戏
    /*    @Operation(summary = "推广游戏")
        @PostMapping("/promotion")
        public Result<PageInfo<GameVO>> promotion(
                @RequestBody BaseRequestDTO requestDTO,
                @RequestHeader("Sregion") String sregion,
                @RequestHeader("uid") Long userId,
                @RequestHeader(value = "Slanguage", required = false) String slanguage)
        {
            // 创建一个 PageInfo 对象，并将分页后的数据设置到其中
            PageInfo<GameVO> pageInfo = gameService.promotion(
                    requestDTO.getPage(),
                    requestDTO.getIds(),
                    sregion,
                    userId,
                    slanguage
            );
            return Result.success(pageInfo);
        }*/

    //新游戏
     /*   @Operation(summary = "新游戏")
        @PostMapping("/new")
        public Result<PageInfo<EntryVO>> newGame(@RequestBody BaseRequestDTO requestDTO,
                                                @RequestHeader("Sregion") String sregion,
                                                @RequestHeader("uid") Long userId,
                                                @RequestHeader(value = "Slanguage", required = false) String slanguage) {
            // 创建一个 PageInfo 对象，并将分页后的数据设置到其中
            PageInfo<EntryVO> pageInfo = gameService.newGames(
                    requestDTO.getPage(),
                    requestDTO.getIds(),
                    sregion,
                    userId,
                    slanguage
            );
            System.out.println("newGame pageInfo----------"+pageInfo);
            return Result.success(pageInfo);
        }*/

    // 推荐游戏
        /*@Operation(summary = "推荐游戏")
        @PostMapping("/recommend")
        public Result<PageInfo<GameVO>> recommend(@RequestBody BaseRequestDTO requestDTO,
                                                  @RequestHeader("Sregion") String sregion,
                                                  @RequestHeader("uid") Long userId,
                                                  @RequestHeader(value = "Slanguage", required = false) String slanguage) {
            PageInfo<GameVO> pageInfo = gameService.recommend(
                    requestDTO.getPage(),
                    requestDTO.getIds(),
                    sregion,
                    userId,
                    slanguage
            );
            return Result.success(pageInfo);
        }*/


    //游戏a-z排序
    /*    @Operation(summary = "a-z游戏排序,z-a排序")
    @PostMapping(value = "/sortList")
    public Result<PageInfo<GameVO>> sortList(@RequestBody SortRequestDTO requestDTO,
                                             @RequestHeader("Sregion") String sregion,
                                             @RequestHeader("uid") Long userId,
                                             @RequestHeader(value = "Slanguage", required = false) String slanguage) {
        var sortStr = requestDTO.getAscState() ? "asc" : "desc";
        var pageInfo = gameService.sort(requestDTO.getPage(), requestDTO.getIds(), sregion, userId, slanguage, sortStr);
        return Result.success(pageInfo);
    }*/

}
