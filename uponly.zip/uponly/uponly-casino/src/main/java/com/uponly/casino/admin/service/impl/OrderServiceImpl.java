package com.uponly.casino.admin.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.uponly.casino.admin.dto.SearchOrderDTO;
import com.uponly.casino.admin.dto.UpdateMsgDTO;
import com.uponly.casino.admin.service.GameService;
import com.uponly.casino.admin.service.GetRedisDataService;
import com.uponly.casino.admin.service.OrderService;
import com.uponly.casino.admin.vo.AmountMsgVO;
import com.uponly.casino.admin.vo.OrderVOBe;
import com.uponly.casino.admin.vo.TotalAmountVO;
import com.uponly.casino.common.utils.RegionIntegerUtil;
import com.uponly.casino.mapper.GameOriginalMapper;
import com.uponly.casino.mapper.OrderMapper;
import com.uponly.casino.portal.dto.SearchOrderFeDTO;
import com.uponly.casino.portal.vo.OrderVOFe;
import com.uponly.casino.provider.dto.GameInfoDTO;
import com.uponly.casino.provider.service.GameInfoService;
import com.uponly.casino.provider.vo.UserInfoVO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.SerializationUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.*;


@Slf4j
@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderMapper orderMapper;

    @Autowired
    private GameOriginalMapper gameOriginalMapper;

    @Autowired
    private GameInfoService gameInfoService;

    @Autowired
    GetRedisDataService getRedisDataService;

    @Override
    public PageInfo<OrderVOBe> searchOrder(SearchOrderDTO searchOrderDTO) throws JsonProcessingException {
        // 开始分页
        PageHelper.startPage(searchOrderDTO.getPage(), searchOrderDTO.getPageSize());

        // 查询订单列表
        List<OrderVOBe> orderList = orderMapper.searchOrder(searchOrderDTO);

        // 创建一个新的列表，用于存放包含额外信息的 OrderVOBe 对象
        List<OrderVOBe> newOrderList = new ArrayList<>();

        ObjectMapper objectMapper = new ObjectMapper();

        // 处理查询结果，添加额外信息
        for (OrderVOBe orderVOBe : orderList) {
            //如果是已结算或者已取消的订单，将盈利设置为0
            if(orderVOBe.getStatus() == 1 ||orderVOBe.getStatus() == 2){
                orderVOBe.setProfit(BigDecimal.ZERO);
            }
            String body = orderMapper.selectBodyByOrderNo(orderVOBe.getOrderNo());

            JsonNode rootNode = objectMapper.readTree(body);
            String tableId = rootNode
                    .path("game")
                    .path("details")
                    .path("table")
                    .path("id")
                    .asText();

            OrderVOBe clonedOrderVOBe = SerializationUtils.clone(orderVOBe);

            Optional<GameInfoDTO> GameInfoDTO = gameInfoService.getGameInfoByTableId(tableId);
            if (GameInfoDTO.isPresent()) {
                clonedOrderVOBe.setGameName(GameInfoDTO.get().getName());
            }
            newOrderList.add(clonedOrderVOBe);
        }

        // 确保 PageHelper 知道有多少记录
        Page<OrderVOBe> page = (Page<OrderVOBe>) orderList;

        // 构建 PageInfo
        PageInfo<OrderVOBe> pageInfo = new PageInfo<>(newOrderList);

        // 手动设置总数，以防丢失分页信息
        pageInfo.setTotal(page.getTotal());

        return pageInfo;
    }

    @Override
    public List<TotalAmountVO> searchTotal(SearchOrderDTO searchOrderDTO) throws JsonProcessingException {

        // 查询总额
        List<TotalAmountVO> list = orderMapper.searchTotal(searchOrderDTO);

        return list;
    }



    @Override
    public Map<String, Object> searchOrderFe(SearchOrderFeDTO searchOrderFeDTO) throws JsonProcessingException {
        // 开始分页
        PageHelper.startPage(searchOrderFeDTO.getPage(), searchOrderFeDTO.getPageSize());
        // 执行查询，获取结果集
        List<OrderVOFe> orderList = orderMapper.searchOrderFe(searchOrderFeDTO);

        List<OrderVOFe> newOrderList = new ArrayList<>();

        ObjectMapper objectMapper = new ObjectMapper();

        //用orderList中的orderNo查询orderMapper中的body字段
        for (OrderVOFe orderVOFe : orderList) {
            String body = orderMapper.selectBodyByOrderNo(orderVOFe.getOrderNo());
            // 创建ObjectMapper实例
            // 将JSON字符串解析成JsonNode
            JsonNode rootNode = objectMapper.readTree(body);// 获取tableId
            String tableId = rootNode
                    .path("game")       // 获取 "game" 节点
                    .path("details")    // 获取 "details" 节点
                    .path("table")      // 获取 "table" 节点
                    .path("id")         // 获取 "id" 节点
                    .asText();

            OrderVOFe clonedOrderVOFe = SerializationUtils.clone(orderVOFe);

            Optional<GameInfoDTO> GameInfoDTO = gameInfoService.getGameInfoByTableId(tableId);
            if (GameInfoDTO.isPresent()) {
                clonedOrderVOFe.setGameName(GameInfoDTO.get().getName());
                clonedOrderVOFe.setFullGameName(GameInfoDTO.get().getFullGameName());
                clonedOrderVOFe.setTableIconDisplay(GameInfoDTO.get().getIcon());
            }


            newOrderList.add(clonedOrderVOFe);
        }

        // 创建 PageInfo 对象以包含分页信息
        PageInfo<OrderVOFe> pageInfo = new PageInfo<>(newOrderList);
        Integer settledTotal = orderMapper.countUserBetCount(searchOrderFeDTO.getUserId(), 003);
        Integer unSettledTotal = orderMapper.countUserBetCount(searchOrderFeDTO.getUserId(), 001);
        Integer allTotal = orderMapper.countAllTotal(searchOrderFeDTO.getUserId());
        Map<String, Object> map = new HashMap<>();
        map.put("list", pageInfo.getList());
        map.put("settledTotal", settledTotal);
        map.put("unSettledTotal", unSettledTotal);
        map.put("allTotal", allTotal);

        return map;

    }

    @Override
    public Map<String, Object> searchOrderByOrderNoList(SearchOrderFeDTO searchOrderFeDTO) throws JsonProcessingException {
        // 开始分页
        PageHelper.startPage(searchOrderFeDTO.getPage(), searchOrderFeDTO.getPageSize());
        // 执行查询，获取结果集
        List<OrderVOFe> orderList = orderMapper.searchOrderByOrderNoList(searchOrderFeDTO);

        List<OrderVOFe> newOrderList = new ArrayList<>();

        ObjectMapper objectMapper = new ObjectMapper();

        //用orderList中的orderNo查询orderMapper中的body字段
        for (OrderVOFe orderVOFe : orderList) {
            String body = orderMapper.selectBodyByOrderNo(orderVOFe.getOrderNo());
            // 创建ObjectMapper实例
            // 将JSON字符串解析成JsonNode
            JsonNode rootNode = objectMapper.readTree(body);// 获取tableId
            String tableId = rootNode
                    .path("game")       // 获取 "game" 节点
                    .path("details")    // 获取 "details" 节点
                    .path("table")      // 获取 "table" 节点
                    .path("id")         // 获取 "id" 节点
                    .asText();

            OrderVOFe clonedOrderVOFe = SerializationUtils.clone(orderVOFe);

            Optional<GameInfoDTO> GameInfoDTO = gameInfoService.getGameInfoByTableId(tableId);
            if (GameInfoDTO.isPresent()) {
                clonedOrderVOFe.setGameName(GameInfoDTO.get().getName());
                clonedOrderVOFe.setFullGameName(GameInfoDTO.get().getFullGameName());
                clonedOrderVOFe.setTableIconDisplay(GameInfoDTO.get().getIcon());
            }

            newOrderList.add(clonedOrderVOFe);
        }

        // 创建 PageInfo 对象以包含分页信息
        PageInfo<OrderVOFe> pageInfo = new PageInfo<>(newOrderList);

        Map<String, Object> map = new HashMap<>();
        map.put("list", pageInfo.getList());


        return map;

    }

    @Override
    public Integer updateMsgState(UpdateMsgDTO updateMsgDTO) {

        Integer count = orderMapper.updateMsgState(updateMsgDTO);
        return count;
    }


}

