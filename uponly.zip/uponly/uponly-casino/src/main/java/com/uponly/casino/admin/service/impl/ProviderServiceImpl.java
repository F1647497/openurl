package com.uponly.casino.admin.service.impl;

import com.github.pagehelper.PageInfo;
import com.uponly.casino.admin.dto.AddProviderDTO;
import com.uponly.casino.admin.dto.DeleteProviderDTO;
import com.uponly.casino.admin.dto.SearchProviderDTO;
import com.uponly.casino.admin.dto.UpdateProviderDTO;
import com.uponly.casino.admin.service.ProviderService;
import com.uponly.casino.admin.vo.ProviderVO;
import com.uponly.casino.mapper.ProviderMapper;
import lombok.extern.slf4j.Slf4j;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;


@Slf4j
@Service
public class ProviderServiceImpl implements ProviderService {
    @Autowired
    RedissonClient redissonUtil;
    @Autowired
    private ProviderMapper providerMapper;

    @Override
    public Long add(AddProviderDTO addProviderDTO) {
        providerMapper.add(addProviderDTO);
        Long pid = addProviderDTO.getPid();
        return pid;
    }

    @Override
    public int delete(DeleteProviderDTO deleteProviderDTO) {

        return providerMapper.delete(deleteProviderDTO);
    }

    @Override
    public int update(UpdateProviderDTO updateProviderDTO) {
       int count =  providerMapper.update(updateProviderDTO);
       return count;
    }

    @Override
    public Optional<Integer> maxSort() {
        return Optional.ofNullable(providerMapper.maxSort());
    }

    @Override
    public List<ProviderVO> providers() {
        return providerMapper.providersWithGameCount();
    }


    @Override
    public PageInfo<ProviderVO> search(SearchProviderDTO provider) {
        PageInfo<ProviderVO> pageInfo = new PageInfo<>();
        // 查询符合条件的游戏
        List<ProviderVO> resultList = providerMapper.search(provider);
        // 将查询结果写入PageInfo对象
        pageInfo.setList(resultList);
        pageInfo.setTotal(resultList.size()); // 设置总记录数
        return pageInfo;
    }
}

