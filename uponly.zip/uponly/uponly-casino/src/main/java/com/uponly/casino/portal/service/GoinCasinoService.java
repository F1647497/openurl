package com.uponly.casino.portal.service;


public interface GoinCasinoService {
    int getGameStatus(String pgameId);

    String goInToCasino(Integer id, String uid, String token, String language, String lobbyUrl, Boolean isTest) throws Exception;
}
