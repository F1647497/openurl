package com.uponly.casino.mapper;


import com.uponly.casino.admin.dto.*;
import com.uponly.casino.admin.vo.EntryVO;
import com.uponly.casino.admin.vo.GameTypeVO;
import com.uponly.casino.admin.vo.GameVO;

import java.util.List;
import java.util.Map;

public interface GameMapper {



    GameVO getInfo(Long gameId);
    int add(AddGameDTO game);
    int update(UpdateGameDTO game);

    int addTag(GameTagDTO gameTagDTO);
    int deleteTag(GameTagDTO gameTagDTO);

//    List<GameVO> selectAllCasinoGames();
//    List<GameVO> selectAllCasinoGamesPopular();

//    List<GameVO> searchGame1(SearchGameDTO searchGameDTO);
//    int updateUserCount7d2Game();
//    GameVO searchOneGame(String pgameId);

    Integer maxSort();

    Integer addRegion(GameRegionDTO region);

//    List<GameVO> listPopularGamesByRegion(Map<String, Object> map);
//    List<GameVO> listPromotionGamesByRegion(Map<String, Object> map);
//    List<GameVO> listNewGamesByRegion(Map<String, Object> map);
//    List<EntryVO> listFavoriteGamesByRegion(Map<String, Object> map);
//    List<GameVO> listRecommendGamesByRegion(Map<String, Object> map);


    List<GameRegionDTO> listGameRegions(Long gameId);

    Integer deleteRegion(long id, Integer region);

    List<GameTypeVO> listGameTypeVO(Long pid);

    Integer getPidById(int id);
}
