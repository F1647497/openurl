package com.uponly.casino.admin.dto;


import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.io.Serializable;

@Data
@Schema
public class MyPageParams implements Serializable {


    @Schema(title = "页数", defaultValue = "1")
    private Integer page = 1;

    @Schema(title = "每页大小", defaultValue = "10")
    private Integer pageSize = 10;

}
