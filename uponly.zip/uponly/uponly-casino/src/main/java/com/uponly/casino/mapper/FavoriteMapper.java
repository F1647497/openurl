package com.uponly.casino.mapper;

import com.uponly.casino.portal.dto.FavoriteDTO;
import com.uponly.casino.portal.vo.FavoriteVO;

import java.util.List;


public interface FavoriteMapper {
    List<FavoriteVO> searchUserFavorite(Long userId);

    int add(FavoriteDTO usersFavoriteVo);

    int delete(FavoriteDTO favoriteDTO);

    int exists(FavoriteDTO favoriteDTO);

}
