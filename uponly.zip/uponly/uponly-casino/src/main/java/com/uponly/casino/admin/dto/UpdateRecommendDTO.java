package com.uponly.casino.admin.dto;

import lombok.Data;

@Data
public class UpdateRecommendDTO implements java.io.Serializable {

}
