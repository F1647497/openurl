package com.uponly.casino.provider.service.impl;
import com.uponly.casino.common.api.Result;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Map;

@Slf4j
@Service
public class EvoTestProviderImpl extends BaseProviderImpl {
    public Result<?> getGameList() {
        return Result.success();
    }


    public void history(String orderStr, Integer status) {

    }

    public void history(String str) {

    }

    public Result<?> getLaunchURI(Map<String, Object> body) {
        return Result.success();
    }
}
