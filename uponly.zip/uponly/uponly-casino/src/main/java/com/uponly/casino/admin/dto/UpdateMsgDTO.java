package com.uponly.casino.admin.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.experimental.Accessors;

import java.math.BigDecimal;

@Data
public class UpdateMsgDTO {

    //用5个位置 表示发送消息的状态 0b10000
    // 1表示已发送，0 未发送
    // AmountMsg：第1位；GgrMsg：第2位；ActiveMsg：第3位；GgrMsg：第4位；BetMsg：第5位；RebateMsg
    @Schema(title = "消息数字")
    private Integer msgNumber;

    @Schema(title = "注单号")
    private String orderNo;

    @Schema(title = "有效流水")
    private BigDecimal effectiveAmount;

}
