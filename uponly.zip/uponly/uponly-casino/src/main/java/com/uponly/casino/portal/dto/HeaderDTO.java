package com.uponly.casino.portal.dto;

import lombok.Data;

@Data
public class HeaderDTO {
    private String sregion;
    private Long userId;
    private String slanguage;
    private String token;
}
