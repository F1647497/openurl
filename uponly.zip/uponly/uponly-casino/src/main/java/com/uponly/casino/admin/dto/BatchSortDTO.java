package com.uponly.casino.admin.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.List;

@Data
@Schema(title = "排序DTO")
public class BatchSortDTO implements java.io.Serializable {

    @Schema(title = "需要的排序的eid")
    private List<Long> eids;

    @Schema(title = "需要的更新的sort")
    private List<Integer> sorts;

    @Schema(title = "需要的排序的eid")
    private Long eid;

    @Schema(title = "需要的更新的sort")
    private Integer sort;

}