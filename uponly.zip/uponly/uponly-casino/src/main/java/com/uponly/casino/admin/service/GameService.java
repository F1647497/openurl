package com.uponly.casino.admin.service;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageInfo;
import com.uponly.casino.admin.dto.AddGameDTO;
import com.uponly.casino.admin.dto.SearchGame2DTO;
import com.uponly.casino.admin.dto.UpdateGameDTO;
import com.uponly.casino.admin.vo.*;
import com.uponly.casino.provider.dto.evo.Config;

import java.util.List;

public interface GameService {
/*
    PageInfo<GameVO> popular(Integer page, List<Integer> providerIdList, String sregion, Long uid, String slanguage);
*/

    long add(AddGameDTO addGameDTO);
    int update(UpdateGameDTO game);
   /* PageInfo<GameVO> search(SearchGameDTO searchGameDTO);*/
    PageInfo<GameSearch> search(SearchGame2DTO searchGame2DTO);

   /* PageInfo<EntryVO> newGames(Integer page, List<Integer> providerIdList, String sregion, Long uid, String slanguage);
*/
  /*  PageInfo<EntryVO> promotion(Integer page, List<Integer> providerIdList, String sregion, Long uid, String slanguage);
*/
/*

    PageInfo<GameVO> sort(Integer page, List<Integer> providerIdList, String sregion, Long uid, String slanguage, String sort);
*/


    PageInfo<EntryFrontVO> favorite(Integer page, Integer pageSize,List<Integer> providerIdList, String sregion, Long uid, String slanguage);

    PageInfo<EntryFrontVO> allGameList(Integer page, Integer pageSize,List<Integer> providerIdList, String sregion, Long uid, String slanguage);

    PageInfo<EntryFrontVO> promotionGameList(Integer page, Integer pageSize,List<Integer> providerIdList, String sregion, Long uid, String slanguage);

    PageInfo<EntryFrontVO> gameTypeList(Integer page, Integer pageSize,List<Integer> providerIdList, String sregion, Long uid, String slanguage,String gameType);

    PageInfo<EntryFrontVO> recommendList(Integer page,Integer pageSize,String sregion, Long uid, String slanguage);

    EntryFrontVO searchEntryByEid(Long eid, String sregion, Long uid, String slanguage);


   EntryFrontVO searchEntranceFe(String requestData, String sregion, Long uid, String slanguage);


    JSONObject getGames();

    List<GameTypeVO> getGameTypes(Long pid);
    JSONObject getGamesFiltered(String config);

    int  addGamesFromEvo(GameOriginalVO gameOriginalVO);
    int  addGames(GameOriginalVO gameOriginalVO);

}

