package com.uponly.casino.portal.vo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.uponly.casino.common.utils.LanguageUtil;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;

import java.io.Serializable;
import java.math.BigDecimal;

@Data
public class RecentGamesVO implements Serializable {
    private Integer id;
    private Long userId;
    private String gameName;
    private String gameId;
    @Schema(title = "赔付金额")
    private BigDecimal payout;
    @Schema(title = "赔付金额加总")
    private BigDecimal totalPayout;
    private BigDecimal rtp;
    private String currency;
    private String gameIcon;
    private String provider;

    @JsonIgnore
    private BigDecimal rtpEdited;

    @JsonIgnore
    private String gameIconEdited;

    @JsonIgnore
    @Schema(title = "游戏前置页广告语")
    private String gameAdEdited;

    @Schema(title = "收藏状态")
    private boolean collectState;

    @JsonIgnore
    @Schema(title = "编辑名称")
    private String gameNameEdited;


    // 生成实际的数据
    public void genActual(String langId) {
        genActualGameIcon();
        genActualGameName(langId);
        genActualGameAdEdited(langId);
        genActualRtp();
    }

    // 生成实际的游戏图标
    private String genActualGameIcon() {
        gameIcon = StringUtils.isNotBlank(gameIconEdited) ? gameIconEdited : gameIcon;
        return gameIcon;
    }

    // 生成实际的游戏名称
    private String genActualGameName(String langId) {
        String gameNameByLang = LanguageUtil.getName(gameNameEdited, langId);
        gameName = StringUtils.isNotBlank(gameNameByLang) ? gameNameByLang : gameName;
        return gameName;
    }

    // 生成实际的游戏广告
    private String genActualGameAdEdited(String langId) {
        String gameAdByLang = LanguageUtil.getName(gameAdEdited, langId);
        gameAdEdited = StringUtils.isNotBlank(gameAdByLang) ? gameAdByLang : "";
        return gameAdEdited;
    }

    // 生成实际的游戏rtp
    private BigDecimal genActualRtp() {
        rtp = rtpEdited.compareTo(BigDecimal.ZERO) > 0 ? rtpEdited : rtp;
        return rtp;
    }


}
