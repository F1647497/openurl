package com.uponly.casino.admin.dto;

import com.esotericsoftware.kryo.serializers.FieldSerializer;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.DecimalMin;
import lombok.Data;

import java.util.List;

@Data
@Schema(title = "真人游戏DTO")
public class AddGameDTO implements java.io.Serializable {
    @Schema(title = "地区", requiredMode = Schema.RequiredMode.REQUIRED)
    @FieldSerializer.NotNull()
    private List<Integer> regions;

    @Schema(title = "三方id")
    @FieldSerializer.NotNull()
    private Long pid;

    @Schema(title = "三方gameId", maxLength = 64, requiredMode = Schema.RequiredMode.REQUIRED)
    private String pgameId;

    @Schema(title = "游戏名称", maxLength = 100, requiredMode = Schema.RequiredMode.REQUIRED)
    private String pgameName;

    @Schema(title = "游戏名称编辑", nullable = true, maxLength = 1024)
    private String nameEdit;

    @Schema(title = "游戏图标", requiredMode = Schema.RequiredMode.REQUIRED, maxLength = 255)
    private String pgameIcon;

    @Schema(title = "游戏图标编辑", nullable = true, maxLength = 255)
    private String iconEdit;

    @Schema(title = "游戏类型")
    private String gameType;

    @Schema(title = "游戏状态", requiredMode = Schema.RequiredMode.REQUIRED)
    private int status;

    @Schema(title = "排序", requiredMode = Schema.RequiredMode.REQUIRED)
    @DecimalMin(value = "0")
    private int sort;

    @Schema(title = "标签", nullable = true, maxLength = 100)
    private String tag;

    @Schema(title="是否推广", requiredMode = Schema.RequiredMode.REQUIRED)
    @FieldSerializer.NotNull()
    private Boolean isPromotion;
}