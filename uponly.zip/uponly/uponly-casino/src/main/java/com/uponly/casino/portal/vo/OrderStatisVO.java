package com.uponly.casino.portal.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.util.Date;

@Schema(title = "真人注单实体")
@Data
public class OrderStatisVO {

    @Schema(title = "id")
    private Integer id;

    @Schema(title = "注单号")
    private String orderNo;

    @Schema(title = "第三方注单号")
    private String thirdOrderNo;

    @Schema(title = "用户id")
    private Long userId;

    @Schema(title = "地区id")
    private Integer region;

    @Schema(title = "货币类型")
    private String currency;


    @Schema(description = "游戏id")
    private String roundId;

    @Schema(title = "游戏名称")
    private String gameName;

    @Schema(title = "投注金额")
    private BigDecimal amount;

    @Schema(title = "赔付金额")
    private BigDecimal payout;

    @Schema(title = "利润金额")
    private BigDecimal profit;

    @Schema(title = "倍数")
    private BigDecimal multiplier;

    @Schema(title = "注单状态")
    private Integer status;

    @Schema(title = "投注时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createdAt;

    @Schema(title = "结算时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date settleAt;

    @Schema(title = "投注类型")
    private Integer betType;

    @Schema(title = "结算类型")
    private String settleType;



    @Schema(title = "用户名")
    private String userName;

    @Schema(title = "会话ID")
    private String sessionId;

    @Schema(title = "供应商")
    private String providerName;

}