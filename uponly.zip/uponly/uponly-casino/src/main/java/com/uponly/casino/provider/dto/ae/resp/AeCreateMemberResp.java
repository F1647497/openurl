package com.uponly.casino.provider.dto.ae.resp;

import lombok.Data;


@Data
public class AeCreateMemberResp {
    private String status;
    private String desc;


    public AeCreateMemberResp() {

    }
}
