package com.uponly.casino.admin.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(title="查询推荐DTO")
public class SearchRecommendDTO extends PageInfoDTO  {

    @Schema(title="地区")
    private String region;

    @Schema(title="状态")
    private Integer status;

    //@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")  // 指定日期格式
    @Schema(title="开始时间")
    private String start;

  //  @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")  // 指定日期格式
    @Schema(title="结束时间")
    private String end;

    @Schema(title="供应商名称")
    private String providerName;

    @Schema(title="入口id")
    private long eid;

    @Schema(title="入口名称")
    private String ename;


}