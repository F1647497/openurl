package com.uponly.casino.provider.dto.ae.req;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class SettleTransaction {
    public String platformTxId;
    public String userId;
    public String currency;
    public String platform;
    public String gameType;
    public String gameCode;
    public String gameName;
    public String betType;
    public BigDecimal betAmount;
    public BigDecimal winAmount;
    public BigDecimal turnover;
    public String betTime;
    public String updateTime;
    public String roundId;
    public String txTime;
    public String settleType;
    public String refPlatformTxId;
    @JsonIgnore
    public String gameInfo;
}
