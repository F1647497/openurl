//package com.uponly.casino.handler;
//
//
//import com.alibaba.fastjson2.JSONObject;
//import com.uponly.casino.admin.dto.UpdateMsgDTO;
//import com.uponly.casino.admin.vo.BetMsgVO;
//import com.uponly.casino.common.utils.RegionIntegerUtil;
//import com.uponly.casino.admin.service.GetRedisDataService;
//import com.uponly.casino.mapper.OrderMapper;
//import com.uponly.casino.provider.service.UserInfoService;
//import com.uponly.casino.provider.vo.UserInfoVO;
//import lombok.extern.slf4j.Slf4j;
//import org.redisson.api.RLock;
//import org.redisson.api.RedissonClient;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.kafka.core.KafkaTemplate;
//import org.springframework.kafka.support.SendResult;
//import org.springframework.stereotype.Service;
//
//import java.math.BigDecimal;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Optional;
//import java.util.UUID;
//import java.util.concurrent.CompletableFuture;
//
//
//@Service
//@Slf4j
//public class BetMsgJob extends AbstractReportJob{
//
//
//    @Autowired
//    private KafkaTemplate<String, String> kafkaTemplate;
//
//    @Autowired
//    RedissonClient redissonClient;
//
//    @Autowired
//    UserInfoService userInfoService;
//
//    @Autowired
//    GetRedisDataService getRedisDataService;
//
//    @Autowired
//    OrderMapper orderMapper;
//
//    public void sendBetMsg(List<String> orderListRedis) {
//        RLock lock = redissonClient.getLock("sendBetMsg");
//        try {
//            // 从redis中获取casino注单列表，然后一次性发送订单数组到kafka
//            lock.lock();
//            List<BetMsgVO> betMsgVOList = this.generateMsg(orderListRedis);
//            for (BetMsgVO betMsgVO : betMsgVOList) {
//                CompletableFuture<SendResult<String, String>> future = this.sendBetMsgJob(betMsgVO);
//                log.info("【sendBetMsgJob】的发送结果={}", future);
//            }
//        } catch (Exception e) {
//            log.error("sendBetMsgJob异常 ", e);
//        } finally {
//            lock.unlock();
//        }
//    }
//
//    public List<BetMsgVO> generateMsg(List<String> orderListRedis) {
//        try {
//            List<BetMsgVO> betMsgVOList = new ArrayList<>();
//            for (String orderJsonString : orderListRedis) {
//                com.alibaba.fastjson.JSONObject jsonObject = com.alibaba.fastjson.JSONObject.parseObject(orderJsonString);
//
//                Long userId = jsonObject.getLong("userId");
//                Optional<UserInfoVO> userInfoVO = userInfoService.getUser(userId);
//                UserInfoVO userInfo = userInfoVO.get(); // 获取内部对象
//
//                String region = RegionIntegerUtil.lcationIdToRegion(userInfo.getLocation());
//                int level = userInfo.getVip();
//                int star = userInfo.getStar();
//                String agentId = userInfo.getAgentId();
//
//                BigDecimal amount = jsonObject.getBigDecimal("amount");
//                BigDecimal payout = jsonObject.getBigDecimal("payout");
//                BigDecimal difference = payout.subtract(amount); // 使用 subtract() 方法进行减法操作
//                String stakeResult = difference.compareTo(BigDecimal.ZERO) > 0 ? "win" : difference.compareTo(BigDecimal.ZERO) < 0 ? "lose" : "draw";
//                Boolean isTurnover = difference.compareTo(BigDecimal.ZERO) == 0  ? false : true;
//                String currency = jsonObject.getString("currency");
//                String betId = jsonObject.getString("orderNo");
//                String tagFromUserInfo = jsonObject.getString("tag");
//                String createdAt = jsonObject.getString("createdAt");
//                String tag = tagFromUserInfo == null ? "real" : "test";
//
//                BetMsgVO betMsgVO = new BetMsgVO();
//                betMsgVO.setUserId(userId);
//                betMsgVO.setAgentId(agentId);
//                betMsgVO.setRegion(region);
//                betMsgVO.setLevel(level);
//                betMsgVO.setStar(star);
//                betMsgVO.setStakeResult(stakeResult);
//                betMsgVO.setIsTurnover(isTurnover);
//                betMsgVO.setCurrency(currency);
//                betMsgVO.setAmount(amount);
//                betMsgVO.setBetId(betId);
//                betMsgVO.setTag(tag);
//                betMsgVO.setCreatedAt(createdAt);
//
//                betMsgVOList.add(betMsgVO);
//            }
//
//            //  System.out.println("amountMsgVOList-----" + betMsgVOList);
//            return betMsgVOList;
//        } catch (Exception e) {
//            log.error("generateMsg 异常{} ", e.getMessage());
//
//        }
//        return List.of();
//    }
//
//    public CompletableFuture<SendResult<String, String>> sendBetMsgJob(BetMsgVO betMsgVO) {
//        try {
//            JSONObject jsonObjectOfBetting = new JSONObject();
//            jsonObjectOfBetting.put("agentId", betMsgVO.getAgentId());
//
//            jsonObjectOfBetting.put("userId", betMsgVO.getUserId());
//            jsonObjectOfBetting.put("region", betMsgVO.getRegion());
//
//            jsonObjectOfBetting.put("currency", betMsgVO.getCurrency());
//            jsonObjectOfBetting.put("gameType", "EVO Casino");
//            jsonObjectOfBetting.put("amount", betMsgVO.getAmount());
//
//            jsonObjectOfBetting.put("stakeType", "cash");
//            jsonObjectOfBetting.put("isTurnover",betMsgVO.getIsTurnover());
//            jsonObjectOfBetting.put("stakeResult", betMsgVO.getStakeResult());
//
//            jsonObjectOfBetting.put("betId", betMsgVO.getBetId());
//            jsonObjectOfBetting.put("copiedBetId", "");
//            jsonObjectOfBetting.put("tag", betMsgVO.getTag());
//
//            jsonObjectOfBetting.put("level", betMsgVO.getLevel());
//            jsonObjectOfBetting.put("star", betMsgVO.getStar());
//
//
//            JSONObject jsonObjectMsgOfBetting = new JSONObject();
//
//            jsonObjectMsgOfBetting.put("messageType", "stake");
//            jsonObjectMsgOfBetting.put("messageBody", jsonObjectOfBetting);
//            jsonObjectMsgOfBetting.put("partion", 0);
//            jsonObjectMsgOfBetting.put("messageId", UUID.randomUUID());
//
//            long timestamp = getTimestamp(betMsgVO.getCreatedAt());
//            jsonObjectMsgOfBetting.put("ts", timestamp);
//
//            String msgOfBettingForKafka = jsonObjectMsgOfBetting.toJSONString();
//
//
//            log.info("【BetMsg注单上报】sendBetMsg是={}", msgOfBettingForKafka);
//            CompletableFuture<SendResult<String, String>> future = super.execute(betMsgVO.getUserId(), msgOfBettingForKafka);
//
//     //       CompletableFuture<SendResult<String, String>> future = kafkaTemplate.send(CommonConstant.CASINO_BETTING_JOB_TOPIC, msgOfBettingForKafka);
//        //     CompletableFuture<SendResult<String, String>> future = remoteKafkaService.send(CommonConstant.CASINO_BETTING_JOB_TOPIC, msgOfBettingForKafka);
//            //用5个位置 表示发送消息的状态，1表示已发送，0 未发送，
//            // 消息所在位置：AmountMsg：第1位；GgrMsg：第2位；ActiveMsg：第3位；GgrMsg：第4位；BetMsg：第5位；RebateMsg
//            UpdateMsgDTO updateMsgDTO = new UpdateMsgDTO();
//            updateMsgDTO.setOrderNo(betMsgVO.getBetId());
//            updateMsgDTO.setMsgNumber(0b00010);
//
//
//            if(future != null){
//                Integer count = orderMapper.updateMsgState(updateMsgDTO);
//                log.info("bet更新消息状态数量 = {}", count);
//            }
//
//            System.out.println("future-----" + future);
//            return future;
//        } catch (Exception e) {
//            log.error("sendBetMsgJob 异常{} ", e.getMessage());
//
//        }
//        return null;
//    }
//}