package com.uponly.casino.provider.service;

import com.uponly.casino.common.api.Result;

import java.util.Map;

public interface IGameProviderService {
    Result<?> getGameList();
    void history(String orderStr);
    Result<?> getLaunchURI(Map<String, Object> body);

    void killSession();
    void betLogShot();
}
