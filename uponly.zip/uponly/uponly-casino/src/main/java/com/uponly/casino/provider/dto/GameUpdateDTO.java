package com.uponly.casino.provider.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import static com.uponly.casino.common.constant.CommonConstant.MACHINE_ID;

@Data
public class GameUpdateDTO implements java.io.Serializable {
    @Schema(description = "提供商ID")
    private Long pid;

    @Schema(description = "machineId")
    private String machineId;

    public GameUpdateDTO(Long pid) {
        this.pid = pid;
        this.machineId = MACHINE_ID;
    }
}
