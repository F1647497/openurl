package com.uponly.casino.provider.dto.toup;

import com.alibaba.fastjson2.JSONObject;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class ChangeBalanceResponse {
    private String transactionId;
    private Long userId;
    private String currency;
    private BigDecimal balance;
    private BigDecimal frozenBalance;
//    private BigDecimal freezeAmount;
    private String orderNo;
    private Integer mgs;//如果有錯誤訊息

    public JSONObject toJSONObject() {
        return JSONObject.from(this);
    }

    public static ChangeBalanceResponse fromJSONObject(JSONObject jsonObject) {
        try {
            ChangeBalanceResponse changeBalanceResponse = new ChangeBalanceResponse();
            changeBalanceResponse.setTransactionId(jsonObject.getString("transactionId"));
            changeBalanceResponse.setUserId(jsonObject.getLong("userId"));
            changeBalanceResponse.setCurrency(jsonObject.getString("currency"));
            changeBalanceResponse.setBalance(jsonObject.getBigDecimal("balance"));
            changeBalanceResponse.setFrozenBalance(jsonObject.getBigDecimal("frozenBalance"));

            if (jsonObject.containsKey("orderNo")) {
                changeBalanceResponse.setOrderNo(jsonObject.getString("orderNo"));
            }

            return changeBalanceResponse;
        } catch (Exception e) {
            return null;
        }
    }
}
