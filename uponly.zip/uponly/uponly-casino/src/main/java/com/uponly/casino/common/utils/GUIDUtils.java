package com.uponly.casino.common.utils;

import java.text.SimpleDateFormat;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

public class GUIDUtils {

    /**
     * 20位末尾的数字id
     */
//    private static volatile int Guid = 100;

    /**
     * <获取唯一id>
     *
     * @return 结果
     * @throws
     */
//    public static String getGuid() {
//        GUIDUtils.Guid += 1;
//
//        long now = System.currentTimeMillis();
//        //获取4位年份数字
//        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy");
//        //获取时间戳
//        String time = dateFormat.format(now);
//        String info = now + "";
//        //获取三位随机数
//        //int ran=(int) ((Math.random()*9+1)*100);
//        //要是一段时间内的数据量过大会有重复的情况，所以做以下修改
//        int ran = 0;
//        if (GUIDUtils.Guid > 999) {
//            GUIDUtils.Guid = 100;
//        }
//        ran = GUIDUtils.Guid;
//        return time + info.substring(2) + ran;
//    }

    private static final AtomicLong Guid = new AtomicLong(100);

    public static String getGuid() {
        String ran = String.format("%06d", Guid.getAndIncrement());
        long now = System.currentTimeMillis();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy");
        String time = dateFormat.format(now);
        String info = now + "";
        return time + info.substring(2) + ran;
    }


    public static void main(String[] args) {
        System.out.println(getGuid());
        System.exit(0);

        // 使用多线程模拟请求，验证GUID是否重复
        ExecutorService executorService = Executors.newFixedThreadPool(10);
        ConcurrentHashMap<String, Boolean> map = new ConcurrentHashMap<>();

        for (int i = 0; i < 1000; i++) {
            executorService.execute(() -> {
                String guid = getGuid();
                System.out.println(guid);
                if (map.putIfAbsent(guid, true) != null) {
                    System.out.println("Duplicate GUID: " + guid);
                }
            });
        }

        executorService.shutdown();
        try {
            executorService.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Total GUIDs: " + map.size());
    }


}