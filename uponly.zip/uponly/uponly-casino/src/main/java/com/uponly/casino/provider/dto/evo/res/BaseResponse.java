package com.uponly.casino.provider.dto.evo.res;

import lombok.Data;

@Data
public class BaseResponse {
    protected String status;
    protected String uuid;

    public BaseResponse(String status, String uuid) {
        this.status = status;
        this.uuid = uuid;
    }

    public BaseResponse() {
        this.status = "OK";
        this.uuid = "";
    }
}
