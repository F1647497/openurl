package com.uponly.casino.admin.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(title = "添加游戏入口DTO")
public class AddGameEntranceDTO implements java.io.Serializable {


    @Schema(title = "入口名称")
    private String ename;

    @Schema(title = "三方id")
    private Long gameId;

    @Schema(title = "三方id")
    private Long pid;

    @Schema(title = "入口id")
    private Long eid;

    @Schema(title = "地区")
    private String regions;

    @Schema(title = "mainEntry")
    private String mainEntry;

    @Schema(title = "addition")
    private String addition;

    @Schema(title = "icon")
    private String icon;

    @Schema(title = "icon")
    private String gameType;


    @Schema(title = "promotion")
    private Integer promotion;

    @Schema(title = "sort")
    private Integer sort;

    @Schema(title = "status")
    private Integer status;


}