package com.uponly.casino.common.api;

public class WalletResult<T> {



    private String messageType;
    private T messageBody;


    protected WalletResult(String message, T data) {
        this.messageType = message;
        this.messageBody = data;
    }




    public static <T> WalletResult<T> success(T data, String message) {
        return new WalletResult<T>(message, data);
    }
}
