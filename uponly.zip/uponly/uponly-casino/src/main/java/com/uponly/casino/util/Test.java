package com.uponly.casino.util;

public class Test {

    static int i =0;

    public static void undo() {
        i++;
        undo();
    }

    public static void main(String[] args) {

        try {
            undo();
        } catch (Throwable ex) {
            System.out.println(i+"+++=");
            ex.printStackTrace();
        }

    }
}
