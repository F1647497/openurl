package com.uponly.casino.provider.dto.sa.req;

import cn.hutool.core.date.DateTime;
import lombok.Data;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;

/**
 * sa第三方下注请求对象
 */
@Data
public class PlaceBetReq {

    /**
     * 用户名
     */
    private String username;
    /**
     * 币种
     */
    private String currency;
    /**
     * 投注金额
     */
    private BigDecimal amount;
    /**
     * 交易单号
     */
    private String txnid;
    /**
     * 时间
     */
    private DateTime timestamp;
    /**
     * 用户ip
     */
    private String ip;
    /**
     * 游戏类型
     */
    private String gametype;
    /**
     * 0:桌面版 1:手机版
     */
    private Byte platform;
    /**
     * 桌台编号
     */
    private Integer hostid;
    /**
     * 游戏局号
     */
    private String gameid;
    /**
     * 投注类型数据
     * 类型 - 投注类型
     * 金额 - 投注金额
     */
    private String betdetails;
}
