package com.uponly.casino.job;

import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import com.alibaba.fastjson2.JSONObject;

import com.alibaba.nacos.shaded.com.google.common.collect.Lists;
import com.uponly.casino.admin.dto.UpdateMsgDTO;
import com.uponly.casino.admin.vo.OrderVO;
import com.uponly.casino.common.constant.CommonConstant;
import com.uponly.casino.common.enums.ReportType;
import com.uponly.casino.common.utils.RegionIntegerUtil;
import com.uponly.casino.provider.vo.UserInfoVO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Component
public class AmountJob extends AbstractReportJob {

    protected DateTime startTime;
    protected DateTime endTime;
    protected ReportType reportType;

    private static String startTimeStr;
    private static String endTimeStr;

    public AmountJob() {
        reportType = ReportType.AMOUNT;
    }

    /**
     * 上报要求已结算的数据 流水/有效流水
     */
    @Async("taskScheduler")
    @Scheduled(cron = "0 */1 * * * ?")
    public void execute() {
        startTime = DateUtil.offsetHour(DateUtil.date(), -30);
        endTime = DateUtil.offsetMinute(DateUtil.date(), -5);
        startTimeStr = DateUtil.format(startTime, DatePattern.NORM_DATETIME_MS_PATTERN);
        endTimeStr = DateUtil.format(endTime, DatePattern.NORM_DATETIME_MS_PATTERN);

        super.execute();

    }


    @Override
    protected String kafkaTopic() {
        return CommonConstant.CASINO_BETTING_JOB_TOPIC;
    }

    @Override
    protected String kafkaKey(Object data) {
        if (data instanceof OrderVO order) {
            return String.valueOf(order.getUserId());
        }
        return null;
    }

    @Override
    protected String kafkaData(Object data) {
        if (!(data instanceof OrderVO order)) {
            log.error("【amount注单上报】instanceof错误！data={}", data);
            return null;
        }
        Optional<UserInfoVO> userInfoOp = userInfoService.getUser(order.getUserId());
        if (userInfoOp.isEmpty()) {
            log.error("【amount注单上报】userInfoFeige为空, OrderVO={}", order);
            return null;
        }
        UserInfoVO userInfo = userInfoOp.get();

        //将结算数据推送到报表
        String region = RegionIntegerUtil.lcationIdToRegion(userInfo.getLocation());
        BigDecimal betAmount = order.getAmount();
        BigDecimal payout = order.getPayout();
        BigDecimal profitAmount = payout.subtract(betAmount);

        BigDecimal effBetAmount = getEffectiveAmountV1(order);
//        BigDecimal effBetAmount = Optional.ofNullable(order.getEffectiveAmount()).orElse(BigDecimal.ZERO);
        Boolean isTurnover = effBetAmount.compareTo(BigDecimal.ZERO) != 0;

        JSONObject body = new JSONObject();
        body.put("agentId", userInfo.getAgentId());
        body.put("userId", userInfo.getUserId());
        body.put("currency", userInfo.getCurrency());
        body.put("tag", userInfo.getTestTag());
        body.put("level", userInfo.getVip());
        body.put("star", userInfo.getStar());

        body.put("region", region);
        body.put("betId", order.getOrderNo());
        body.put("gameType", "EVO Casino");
        body.put("amount", betAmount);
        //放入有效流水
        body.put("effectiveAmount", effBetAmount);
        body.put("isTurnover", isTurnover);
        body.put("stakeType", "cash");
        body.put("copiedBetId", null);

        int comparisonResult = profitAmount.compareTo(BigDecimal.ZERO);
        String stakeResult = comparisonResult == 0 ? "draw" : comparisonResult < 0 ? "lose" : "win";
        body.put("stakeResult", stakeResult);

        long ts = order.getSettleAt().getTime();
        String kafkaMsg = super.buildKafkaMessage(reportType.getType(), body, ts);
        log.debug("【amount注单上报】build data success! startTime={},endTime={},kafka.msg={}", startTimeStr, endTimeStr, kafkaMsg);
        return kafkaMsg;
    }

    @Override
    protected ReportType getReportType() {
        return reportType;
    }

    @Override
    protected void finishReporting(Object data) {
        if (data instanceof OrderVO order) {
            super.finishReporting(order.getOrderNo(), reportType);
        }
    }

    @Override
    protected List<Object> fetchData() {
        List<OrderVO> orders = orderMapper.selectOrderByReportState(startTime, endTime, reportType.getState(), 3);
        // 过滤掉gameResult为空的数据，或者settleAt未超时的数据(不为空，或超时才上报)

        List<OrderVO> filteredOrders = orders.stream()
                .filter(order -> (StringUtils.isNotBlank(order.getGameResult()) && !"{}".equals(order.getGameResult())) || isSettleAtTimeout(order))
                .peek(order -> {
                    BigDecimal effBetAmount = getEffectiveAmount(order);
                    order.setEffectiveAmount(effBetAmount);
                })
                .collect(Collectors.toList());

        List<String> originOrderIds = orders.stream().map(OrderVO::getOrderNo).collect(Collectors.toList());
        Set<String> unReportingOrders = super.batchAndMarkUnReportingOrders(originOrderIds, reportType);

        return orders.stream()
                .filter(order -> unReportingOrders.contains(order.getOrderNo()))
                .collect(Collectors.toList());
    }

    @Override
    protected void updateData(Object data) {
        OrderVO order = (OrderVO) data;
        //同时更新有效流水到注单表
        UpdateMsgDTO updateMsgDTO = new UpdateMsgDTO();
        updateMsgDTO.setOrderNo(order.getOrderNo());
        updateMsgDTO.setMsgNumber(reportType.getState());
//        updateMsgDTO.setEffectiveAmount(order.getEffectiveAmount());
        updateMsgDTO.setEffectiveAmount(order.getAmount()); // 有效流水使用投注金额 这个字段变得冗余

        Integer result = orderMapper.updateMsgState(updateMsgDTO);
        if (result > 0) {
            log.info("【amount注单上报】上报成功！startTime={} endTime={} orderId={},effectiveAmount={}",
                    startTimeStr, endTimeStr, order.getId(), order.getEffectiveAmount());
        } else {
            log.error("【amount注单上报】上报失败！startTime={} endTime={} orderId={}", startTimeStr, endTimeStr, order.getId());
        }
    }

    /**
     * 获取有效流水
     *
     * @param order 订单
     * @return 有效流水
     */
    public BigDecimal getEffectiveAmount(OrderVO order) {
        BigDecimal betAmount = order.getAmount();
        String gameResult = order.getGameResult();

        BigDecimal effectBetAmount = BigDecimal.ZERO;
        if (StringUtils.isNotBlank(gameResult) && !"{}".equals(gameResult)) {
            effectBetAmount = super.getEffectiveAmount(order.getAmount(), order.getGameResult());
        } else if (isSettleAtTimeout(order)) {
            effectBetAmount = betAmount;
            log.info("【amount注单上报】settleAt已超时，使用betAmounts作为有效流水, order={}", order);
        }
        log.info("【amount注单上报】获取有效流水成功！order={},有效流水={}", order, effectBetAmount);
        return effectBetAmount;
    }


    /**
     * 获取有效流水第二版
     * 仍然采用注单的投注金额作为有效流水
     *
     * @param order 订单
     * @return 有效流水
     */
    public BigDecimal getEffectiveAmountV1(OrderVO order) {
        return order.getAmount();
    }


}
