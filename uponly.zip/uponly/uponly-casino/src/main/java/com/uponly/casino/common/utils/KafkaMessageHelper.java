package com.uponly.casino.common.utils;

import com.alibaba.fastjson2.JSON;
import com.uponly.casino.common.constant.CommonConstant;
import lombok.Builder;
import lombok.Getter;

import java.util.UUID;

public class KafkaMessageHelper {

    /**
     * @param type    消息类型
     * @param data    消息数据
     * @param channel slots_channel_%s region
     * @return json string
     */
    public static String toJsonString(String type, Object data, String channel) {
        return JSON.toJSONString(KafkaMessage.builder()
                .messageType(CommonConstant.SLOT_MESSAGE_TYPE)
                .messageBody(KafkaMessage.MessageBody.builder()
                        .channel(channel)
                        .data(KafkaMessage.DataBody.builder().type(type).data(data).build())
                        .build())
                .build());
    }

    /**
     * @param dataBody 上报的消息数据
     * @return json string
     */
    public static String toActivityJsonString(String messageType, Object dataBody) {
        ActivityKafkaMessage<Object> message = ActivityKafkaMessage.builder()
                .messageType(messageType)
                .messageBody(dataBody)
                .build();
        System.out.println("message: " + message);
        return JSON.toJSONString(message);
    }


    @Getter
    @Builder
    private static class ActivityKafkaMessage<T> {
        private String messageType;
        private T messageBody;
        @Builder.Default
        private Integer partion = 0;
        @Builder.Default
        private String messageId = UUID.randomUUID().toString();
        @Builder.Default
        private Long ts = System.currentTimeMillis();

    }


}
