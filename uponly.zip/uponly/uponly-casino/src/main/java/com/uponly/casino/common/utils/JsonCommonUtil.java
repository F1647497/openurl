package com.uponly.casino.common.utils;

import com.alibaba.fastjson2.JSON;
import com.alibaba.fastjson2.JSONArray;
import com.alibaba.fastjson2.JSONObject;
import com.alibaba.fastjson2.JSONWriter;

import java.util.List;

/**
 * 共用JSON类，统一避免切换/升级
 */
public class JsonCommonUtil {

    /**
     * 将对象转换为JSON字符串 不忽略null值
     *
     * @param obj 要转换为JSON的对象
     * @return JSON字符串
     */
    public static String toJSONString(Object obj, boolean isIgnoreNull) {
        if (isIgnoreNull) {
            return JSON.toJSONString(obj);
        }
        return JSON.toJSONString(obj, JSONWriter.Feature.WriteMapNullValue, JSONWriter.Feature.WriteNullListAsEmpty);
    }

    private static String toJSONString(Object obj) {
        return JSON.toJSONString(obj);
    }

    /**
     * 将对象转换为byte[]
     *
     * @param obj 要转换为JSON的对象
     * @return byte[]
     */
    public static byte[] toJSONBytes(Object obj) {
        return JSON.toJSONBytes(obj);
    }

    /**
     * 将JSON字符串转换为指定类型的对象
     *
     * @param jsonString JSON字符串
     * @param clazz      目标对象类型的Class
     * @param <T>        目标对象的类型
     * @return 转换后的目标对象
     */
    public static <T> T parseObject(String jsonString, Class<T> clazz) {
        return JSON.parseObject(jsonString, clazz);
    }

    /**
     * 将JSON字符串转换为指定类型的list
     *
     * @param jsonString JSON字符串
     * @param clazz      目标对象类型的Class
     * @param <T>        目标对象的类型
     * @return 转换后的目标对象
     */
    public static <T> List<T> parseArray(String jsonString, Class<T> clazz) {
        return JSON.parseArray(jsonString, clazz);
    }

    /**
     * 将JSON字符串转换为JSONObject对象
     *
     * @param jsonString JSON字符串
     * @return 转换后的JSONObject对象
     */
    public static JSONObject parseJSONObject(String jsonString) {
        return JSON.parseObject(jsonString);
    }

    /**
     * 将JSON字符串转换为JSONArray对象
     *
     * @param jsonString JSON字符串
     * @return 转换后的JSONArray对象
     */
    public static JSONArray parseJSONArray(String jsonString) {
        return JSON.parseArray(jsonString);
    }

    /**
     * 将Java对象转换为JSONObject对象
     *
     * @param obj Java对象
     * @return 转换后的JSONObject对象
     */
    public static JSONObject toJSONObject(Object obj) {
        return (JSONObject) JSON.toJSON(obj);
    }

    /**
     * 将Java对象转换为JSONArray对象
     *
     * @param obj Java对象
     * @return 转换后的JSONArray对象
     */
    public static JSONArray toJSONArray(Object obj) {
        return (JSONArray) JSON.toJSON(obj);
    }

}
