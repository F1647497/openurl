package com.uponly.casino.portal.service.impl;

import com.uponly.casino.portal.dto.HeaderDTO;
import com.uponly.casino.portal.service.HeaderService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class HeaderServiceImpl implements HeaderService{
    public HeaderDTO getHeaderInfo(HttpServletRequest request) {
        var header = new HeaderDTO();
        header.setSregion(request.getHeader("Sregion"));
        header.setUserId(Long.valueOf(request.getHeader("uid")));
        header.setToken(request.getHeader("token"));
        header.setSlanguage(request.getHeader("Slanguage"));
        return header;
    }
}
