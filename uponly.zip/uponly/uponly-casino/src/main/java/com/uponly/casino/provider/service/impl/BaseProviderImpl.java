package com.uponly.casino.provider.service.impl;

import com.alibaba.fastjson2.JSON;
import com.alibaba.fastjson2.JSONObject;
import com.uponly.casino.admin.vo.OrderHistoryVO;
import com.uponly.casino.admin.vo.OrderItemVO;
import com.uponly.casino.admin.vo.OrderVO;
import com.uponly.casino.admin.vo.ProviderVO;
import com.uponly.casino.common.constant.CommonConstant;
import com.uponly.casino.interceptor.RemoteWalletService;
import com.uponly.casino.mapper.OrderItemMapper;
import com.uponly.casino.mapper.OrderMapper;
import com.uponly.casino.provider.dto.RequestDTO;
import com.uponly.casino.provider.dto.toup.BalanceDTO;
import com.uponly.casino.provider.dto.toup.ChangeBalanceResponse;
import com.uponly.casino.provider.dto.toup.GetBalanceDTO;
import com.uponly.casino.provider.dto.toup.GetBalanceResponse;
import com.uponly.casino.provider.enums.EnumBodyType;
import com.uponly.casino.provider.enums.EnumToupAction;
import com.uponly.casino.provider.enums.ag.AgRespCode;
import com.uponly.casino.provider.service.GameInfoService;
import com.uponly.casino.provider.service.IGameProviderService;
import com.uponly.casino.provider.service.IProviderService;
import com.uponly.casino.provider.service.UserInfoService;
import com.uponly.casino.ranking.RollingRankingService;
import com.uponly.casino.util.MyJSONUtil;
import com.uponly.casino.common.api.Result;
import lombok.extern.slf4j.Slf4j;
import org.redisson.api.RBucket;
import org.redisson.api.RList;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Map;
import java.util.Optional;


@Slf4j

public abstract class BaseProviderImpl implements IProviderService, IGameProviderService {
    @Autowired
    protected UserInfoService userInfoService;
    @Autowired
    protected RemoteWalletService walletService;
    @Autowired
    protected RedissonClient redissonClient;

    @Autowired
    protected GameInfoService gameInfoService;

    @Autowired
    protected RollingRankingService rollingRankingService;

    @Autowired
    protected OrderMapper orderMapper;
    @Autowired
    protected OrderItemMapper orderItemMapper;
    public ProviderVO providerVO;

    public static final Duration expiration=Duration.ofMinutes(60);

    public static final String ORDER_KEY_REF = "order:refId:";
    public static final String ORDER_KEY_GAME_ID = "order:gameId:";
    public static final String ORDER_KEY_CANCEL= "order:cancel:";

    public boolean initialize(ProviderVO providerVo) {
        this.providerVO = providerVo;
        return true;
    }

    public EnumBodyType getBodyType() {
        return EnumBodyType.JSON;
    }

    public Object balance(RequestDTO param) {
        return null;
    }

    protected Optional<GetBalanceResponse> getBalance(Long userId) {
        //获取用户信息
        var userInfo = userInfoService.getUser(userId);
        if (userInfo.isEmpty()) {
            log.error("【balance】获取用户信息失败,userId={}", userId);
            return Optional.empty();
        }
        //获取当前用户余额
        try {
            var getBalanceDTO = new GetBalanceDTO(userInfo.get());
            var request = MyJSONUtil.packageJson(getBalanceDTO.toJSONObject(), EnumToupAction.GET_BALANCE.getAction());
            var jsonStr = walletService.send(request);
            var jonResponse = MyJSONUtil.analysis2Data(jsonStr);
            log.info("【balance】获取当前用户余额={}", jonResponse);
            if (jonResponse == null) {
                log.error("【balance】获取当前用户余额失败,参数={}", getBalanceDTO);
                return Optional.empty();
            }

            var response = new GetBalanceResponse();
            response.setCurrency(userInfo.get().getCurrency());
            response.setBalance(new BigDecimal(jonResponse.getString("balance")));
            return Optional.of(response);
        } catch (Exception e) {
            log.error("【balance】获取当前用户余额失败,userId={},异常={}", userId, e.getMessage(), e);
        }
        return Optional.empty();
    }

    public Object check(RequestDTO param) {
        return null;
    }

    // 增加钱
    public Object debit(RequestDTO param) {
        return null;
    }

    // 扣钱
    public Object credit(RequestDTO param) {
//        RLock resultLock = redissonClient.getLock("bet" + creditParams.getBetOrderNumber());
//        JSONObject respJson = new JSONObject();
//        try {
//            if (resultLock.tryLock(5, 10, TimeUnit.SECONDS)) {
////                performCreditTransaction(creditParams, respJson);
//            } else {
//                log.error("【bet】获取锁失败,reference={},map={}", creditParams.getBetOrderNumber(), param.getBody())；
//            }
//        } catch (InterruptedException e) {
//            log.error("【bet】获取锁失败,reference={},map={}", creditParams.getBetOrderNumber(), param.getBody());
//            e.printStackTrace();
//        }
//        finally {
//            // Always ensure the lock is released
//            if (resultLock.isLocked() && resultLock.isHeldByCurrentThread()) {
//                resultLock.unlock();
//            }
//        }
//        // 关闭 Redisson 客户端
//        redissonClient.shutdown();
//        return respJson;
        return null;
    }

    public Object cancel(RequestDTO param) {
        return null;
    }
    public Object promotion(RequestDTO param) {
        return null;
    }

    public void betLogShot() {}
    public void killSession() {}

    public abstract Result<?> getGameList();
    public abstract void history(String orderStr ,Integer status);
    public abstract Result<?> getLaunchURI(Map<String, Object> body);
    @Transactional(rollbackFor = Exception.class)
    public Optional<ChangeBalanceResponse> changeBalance(BalanceDTO changeBalanceDTO) {
        log.info("【钱包服务】请求更改用户余额，data={}", JSONObject.toJSONString(changeBalanceDTO));
        try {
            var request = MyJSONUtil.packageJson(changeBalanceDTO, EnumToupAction.CHANGE_BALANCE.getAction());
            String jsonRes = walletService.send(request);
            log.info("【changeBalance】请求更改用户余额，返回值={}", jsonRes);
            JSONObject jonResponse = JSON.parseObject(jsonRes);
            Integer code =jonResponse.getInteger("code");
            jonResponse= jonResponse.getJSONObject("data");
            if (jonResponse == null) {
                ChangeBalanceResponse res=new ChangeBalanceResponse();
                res.setMgs(code);
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                log.error("【changeBalance】调用钱包服务成功，但更改用户余额失败, 参数={}, 返回值={}", JSONObject.toJSONString(changeBalanceDTO), jsonRes);
                return Optional.of(res);
            }
            log.info("【changeBalance】请求更改用户余额成功，返回值={}", jsonRes);
            var res = ChangeBalanceResponse.fromJSONObject(jonResponse);
            if (res == null) {
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                log.error("【changeBalance】更改用户余额失败, 参数={}, 返回值={}", JSONObject.toJSONString(changeBalanceDTO), jsonRes);
                return Optional.empty();
            }
            return Optional.of(res);
        } catch (Exception e) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            log.error("【changeBalance】更改余额过程中出现异常, 参数={}, 异常={}", JSONObject.toJSONString(changeBalanceDTO), e.getMessage(), e);
        }
        return Optional.empty();
    }
    @Transactional(rollbackFor = Exception.class)
    public void newHistory(BalanceDTO balanceDTO, RequestDTO param) {
        // 插入注单历史记录表
        var orderHistory = new OrderHistoryVO();
        orderHistory.setOrderNo(balanceDTO.getOrderNo());
        orderHistory.setThirdOrderNo(balanceDTO.getTransactionId());
        orderHistory.setStatus(balanceDTO.getOperatorType());
        orderHistory.setUserId(balanceDTO.getUserId().intValue());
        orderHistory.setRoundId(balanceDTO.getGameId());
        orderHistory.setAmount(balanceDTO.getAmount());
        orderHistory.setGameName(balanceDTO.getGameName());
        orderHistory.setOperatorType(balanceDTO.getOperatorType());
        orderHistory.setSessionId(balanceDTO.getSessionId());
        orderHistory.setPid(balanceDTO.getProviderId().intValue());
        String body = new JSONObject(param.getBody()).toJSONString();
        orderHistory.setBody(body);
        var currency = param.getBody().get("currency");
        orderHistory.setCurrency(currency == null ? "" : currency.toString());
        var historyId = orderMapper.addHistory(orderHistory);
        if (historyId == 0) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            log.error("【newHistory】插入注单历史记录表失败,userId={},betOrderNumber={}", balanceDTO.getUserId(), balanceDTO.getOrderNo());
        }
        log.info("【newHistory】插入注单历史记录表成功,userId={},betOrderNumber={}", balanceDTO.getUserId(), balanceDTO.getOrderNo());
    }

    @Transactional(rollbackFor = Exception.class)
    public Integer justNewOrder(BalanceDTO balanceDTO, RequestDTO param) {
        Integer orderId =-1;

        //保存到数据库
        var user = userInfoService.getUser(balanceDTO.getUserId());
        if (user.isEmpty()) {
            log.error("【justNewOrder】获取用户信息失败,userId={},betOrderNumber={}", param.getBody().get("userId"), balanceDTO.getOrderNo());
            return orderId;
        }
        var order = new OrderVO();
        order.setOrderNo(balanceDTO.getOrderNo());
        order.setThirdOrderNo(balanceDTO.getTransactionId());
        order.setStatus(OrderVO.EnumOrderStatus.BET.getCode());
        order.setUserId(balanceDTO.getUserId());
        order.setUserName(user.get().getUserName());
        order.setCurrency(user.get().getCurrency());
        order.setRegion(user.get().getLocation());
        order.setPid(balanceDTO.getProviderId());
        order.setAmount(balanceDTO.getAmount());
        order.setBetType(0);
        order.setMsgState(OrderVO.EnumMsgState.NONE.getCode());
        order.setSessionId(balanceDTO.getSessionId());
        order.setRoundId(balanceDTO.getGameId());
        order.setGameName(balanceDTO.getGameName());
        order.setCreatedAt(new Date());
        order.setBody(new JSONObject(param.getBody()).toJSONString());
        try {
            orderId = orderMapper.add(order);
            if (orderId == 0) {
                log.error("【justNewOrder】保存到数据库失败,userId={},betOrderNumber={}", param.getBody().get("userId"), balanceDTO.getOrderNo());
                return orderId;
            }
        } catch (Exception e) {
            log.error("【justNewOrder】保存到数据库失败", e);
            return orderId;
        }
        log.info("【justNewOrder】保存到数据库成功,userId={},betOrderNumber={}", param.getBody().get("userId"), balanceDTO.getOrderNo());

        // 存Order到redis
        try {
            String orderJson = JSONObject.toJSONString(order);
            String orderKey = ORDER_KEY_REF + balanceDTO.getSessionId();
            String mappingOrderKey = ORDER_KEY_GAME_ID + balanceDTO.getGameId()+":"+balanceDTO.getUserId();
            log.info("【justNewOrder】存Order到redis, key={}, value={}", orderKey, orderJson);
            RBucket<String> bucket = redissonClient.getBucket(orderKey);
            RBucket<String> mappingOrderBucket = redissonClient.getBucket(mappingOrderKey);
            bucket.set(orderJson, expiration);
            mappingOrderBucket.set(orderJson, expiration);
        } catch (Exception e) {
            log.error("【justNewOrder】存Order到redis失败 ", e);
        }

        newHistory(balanceDTO, param);
        return order.getId();
    }

    // 根据balanceDTO的action来判断是加钱还是扣钱，然后调用changeBalance方法，先保存到数据库，再调用钱包服务，最后更新数据库
    @Transactional(rollbackFor = Exception.class)
    public Optional<ChangeBalanceResponse> newOrder(BalanceDTO balanceDTO, RequestDTO param) {
        //保存到数据库
        var user = userInfoService.getUser(balanceDTO.getUserId());
        if (user.isEmpty()) {
            log.error("【newOrder】获取用户信息失败,userId={},betOrderNumber={}", param.getBody().get("userId"), balanceDTO.getOrderNo());
            return Optional.empty();
        }
        var order = new OrderVO();
        order.setOrderNo(balanceDTO.getOrderNo());
        order.setThirdOrderNo(balanceDTO.getTransactionId());
        order.setStatus(OrderVO.EnumOrderStatus.INIT.getCode());
        order.setUserId(balanceDTO.getUserId());
        order.setUserName(user.get().getUserName());
        order.setCurrency(user.get().getCurrency());
        order.setRegion(user.get().getLocation());
        order.setPid(balanceDTO.getProviderId());
        order.setAmount(balanceDTO.getAmount());
        order.setBetType(0);
        order.setMsgState(OrderVO.EnumMsgState.NONE.getCode());
        order.setSessionId(balanceDTO.getSessionId());
        order.setRoundId(balanceDTO.getGameId());
        order.setGameName(balanceDTO.getGameName());
        order.setCreatedAt(new Date());
        order.setBody(new JSONObject(param.getBody()).toJSONString());
        try {
            var orderId = orderMapper.add(order);
            if (orderId == 0) {
                log.error("【newOrder】保存到数据库失败,userId={},betOrderNumber={}", param.getBody().get("userId"), balanceDTO.getOrderNo());
                return Optional.empty();
            }
        } catch (Exception e) {
            log.error("【newOrder】保存到数据库失败", e);
            return Optional.empty();
        }
        log.info("【newOrder】保存到数据库成功,userId={},betOrderNumber={}", param.getBody().get("userId"), balanceDTO.getOrderNo());
        var changeBalanceResponse = changeBalance(balanceDTO);
        if (changeBalanceResponse.isEmpty()) {
            log.error("【newOrder】调用钱包服务失败,userId={},betOrderNumber={}", param.getBody().get("userId"), balanceDTO.getOrderNo());
            return Optional.empty();
        }
        // 存Order到redis
        try {

            String orderJson = JSONObject.toJSONString(order);
            String orderKey = ORDER_KEY_REF + balanceDTO.getSessionId();
            String mappingOrderKey = ORDER_KEY_GAME_ID + balanceDTO.getGameId();
            log.info("【newOrder】存Order到redis, key={}, value={}", orderKey, orderJson);
            RBucket<String> bucket = redissonClient.getBucket(orderKey);
            RBucket<String> mappingOrderBucket = redissonClient.getBucket(mappingOrderKey);
            bucket.set(orderJson, expiration);
            mappingOrderBucket.set(orderJson, expiration);
        } catch (Exception e) {
            log.error("【newOrder】存Order到redis失败 ", e);
        }

        //更新数据库
        var updates = orderMapper.updateStatus(OrderVO.EnumOrderStatus.BET.getCode(), order.getOrderNo());
        if (updates == 0) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            log.error("【bet】更新数据库失败,userId={},betOrderNumber={}", param.getBody().get("userId"), balanceDTO.getOrderNo());
        }
//        var proxy = (BaseProviderImpl)AopContext.currentProxy();
        newHistory(balanceDTO, param);

        return changeBalanceResponse;
    }

    //如果交易行為只有一個請求 各自複寫邏輯
    public Object postTransfer(RequestDTO param) {

        return "";
    }
    public Object betResponse(RequestDTO param) {
        return "";
    }
    @Transactional(rollbackFor = Exception.class)
    public Optional<ChangeBalanceResponse> changeBalance(BalanceDTO balanceDTO, RequestDTO param) {
        //调用钱包服务
        Optional<ChangeBalanceResponse>  changeBalanceResponse =changeBalance(balanceDTO);
        if (changeBalanceResponse.isEmpty()) {
            log.error("【changeBalance】注單合併调用钱包服务失败,userId={},betOrderNumber={}", param.getBody().get("userId"), balanceDTO.getOrderNo());
            return Optional.empty();
        }
        newHistory(balanceDTO, param);
        return changeBalanceResponse;
    }
    //获取游戏id

    public String getGameName(String tableId) {
        var gameInfo = gameInfoService.getGameInfoByTableId(tableId);
        if (gameInfo.isEmpty()) {
            log.error("ag getGameName gameInfo is null");
            return "";
        }
        return gameInfo.get().getName();
    }

    //需要及時發 如果不需要處裡流水 請saveAmountRedis+savePayoutRedis 一起使用
    public void savePayoutRedis(OrderVO order) {
        String dateFormatted = new SimpleDateFormat("yyyyMMdd").format(order.getCreatedAt());
        RList<String> AGBList = redissonClient.getList(CommonConstant.CASINO_ORDER_ABG_LIST + "_" + dateFormatted);
        AGBList.add(JSONObject.toJSONString(order));

        log.info("放入 AGBList 成功 : {}",AGBList.get(AGBList.size()-1));
    }
    //因EVO 需要結果計算流水 所以流水須等拉取結果才能發
    public void saveAmountRedis(OrderVO order) {
        String dateFormatted = new SimpleDateFormat("yyyyMMdd").format(order.getCreatedAt());
        RList<String> amountList = redissonClient.getList(CommonConstant.CASINO_ORDER_AMOUNT_LIST + "_" + dateFormatted);
        amountList.add(JSONObject.toJSONString(order));
        RList<String> rebateList = redissonClient.getList(CommonConstant.CASINO_ORDER_REBATE_LIST + "_" + dateFormatted);
        rebateList.add(JSONObject.toJSONString(order));
        log.info("放入 rebateList 成功 : {}",rebateList.get(rebateList.size()-1));
        log.info("放入 amountList 成功 : {}",amountList.get(amountList.size()-1));
    }
//    public boolean addOrder(Map<String, Object> map, Integer providerId, String betOrder, GameVO game, UserInfoFeige userInfo) {
//        OrderVO order = new OrderVO();
//        order.setOrderNo(betOrder);
//        order.setThirdOrderNo(map.get("reference").toString());
//        order.setStatus(2);
//        order.setUserId(Long.valueOf(map.get("userId").toString()));
//        order.setUserName(userInfo.getUserName());
//        order.setCurrency(userInfo.getCurrency());
//        order.setGameId(Long.valueOf(map.get("gameId").toString()));
//        order.setAmount(Double.parseDouble(String.valueOf(map.get("amount"))));
//        order.setBetType(Integer.parseInt(map.get("roundDetails").toString()));
//
//        //增加推送注单到报表 TODO 移到kafka
//        String region = RegionIntegerUtil.lcationIdToRegion(userInfo.getLocation());
//
//        JSONObject jsonObjectOfBetting = new JSONObject();
//        jsonObjectOfBetting.put("agentId", (userInfo.getAgentId() == null ? "" : userInfo.getAgentId()));
//
//        jsonObjectOfBetting.put("userId", userInfo.getUserId());
//        jsonObjectOfBetting.put("region", region);
//
//        jsonObjectOfBetting.put("currency", userInfo.getCurrency());
//        jsonObjectOfBetting.put("gameType", "EVO Casino");
//        jsonObjectOfBetting.put("amount", new BigDecimal(String.valueOf(map.get("amount"))));
//
//        jsonObjectOfBetting.put("stakeType", "cash");
//        jsonObjectOfBetting.put("isTurnover", true);
//        jsonObjectOfBetting.put("stakeResult", "");
//
//        jsonObjectOfBetting.put("betId", order.getOrderNo());
//        jsonObjectOfBetting.put("copiedBetId", null);
//        jsonObjectOfBetting.put("tag", userInfo.getTestTag());
//
//        jsonObjectOfBetting.put("level", userInfo.getVip());
//        jsonObjectOfBetting.put("star", userInfo.getStar());
//
//
//        JSONObject jsonObjectMsgOfBetting = new JSONObject();
//
//        jsonObjectMsgOfBetting.put("messageType", "stake");
//        jsonObjectMsgOfBetting.put("messageBody", jsonObjectOfBetting);
//        jsonObjectMsgOfBetting.put("partion", 0);
//        jsonObjectMsgOfBetting.put("messageId", UUID.randomUUID());
//        jsonObjectMsgOfBetting.put("ts", System.currentTimeMillis());
//
//        String msgOfBettingForKafka = jsonObjectMsgOfBetting.toJSONString();
//
//        List<Integer> msgState = new ArrayList<>();
//        msgState.add(1);
//        order.setSendMsgState(msgState.toString());
//        JSONArray jsonArray = JSONArray.parseArray(order.getSendMsgState());
//        log.info("【bet】sendBetMsg发送后的send_msg_state是={}", jsonArray);
//
//        //插入投注记录到slot数据库
//        boolean result = betOrderMapper.add(order);
//        if (result) {
//            //用于统计近七日游戏人数 暂时只传用户id和游戏id
//            Pair<Long, String> pair = Pair.of(order.getUserId(), order.getOrderNo());
//            kafkaTemplate.send(TopicConstant.CASINO_USER_MADE_BET_TOPIC, pair.toString());
//            kafkaTemplate.send(CommonConstant.CASINO_BETTING_JOB_TOPIC, msgOfBettingForKafka);
//            log.info("【bet】sendBetMsg.msg={}", msgOfBettingForKafka);
//        }
//        return result;
//    }
}
