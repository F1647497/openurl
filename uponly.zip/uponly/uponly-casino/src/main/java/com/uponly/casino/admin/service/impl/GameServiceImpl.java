package com.uponly.casino.admin.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.uponly.casino.admin.dto.*;
import com.uponly.casino.admin.service.GameService;
import com.uponly.casino.admin.vo.*;
import com.uponly.casino.mapper.EntranceMapper;
import com.uponly.casino.mapper.FavoriteMapper;
import com.uponly.casino.mapper.GameMapper;
import com.uponly.casino.mapper.GameOriginalMapper;
import com.uponly.casino.portal.service.FavoriteService;
import com.uponly.casino.common.utils.ConvertUtils;
import com.uponly.casino.provider.dto.GameInfoDTO;
import com.uponly.casino.provider.dto.evo.Config;
import com.uponly.casino.provider.service.GameInfoService;
import com.uponly.casino.provider.service.ProviderManager;
import lombok.extern.slf4j.Slf4j;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.*;
import java.util.stream.Collectors;

import static com.uponly.casino.common.constant.CommonConstant.PUB_CASINO_UPDATE_LIVE_WIN;


@Slf4j
@Service
public class GameServiceImpl implements GameService {

    @Autowired
    private GameMapper gameMapper;

    @Autowired
    private GameOriginalMapper gameOriginalMapper;

    @Autowired
    private EntranceMapper entranceMapper;

    @Autowired
    private FavoriteService favoriteService;

    @Autowired
    RedissonClient redissonUtil;

    @Autowired
    FavoriteMapper favoriteMapper;

    @Autowired
    GameInfoService gameInfoService;

    @Autowired
    ProviderManager providerManager;
    @Autowired
    private RedissonClient redissonClient;

    @Override
    public PageInfo<EntryFrontVO> favorite(Integer page, Integer pageSize, List<Integer> providerIdList, String sregion, Long uid, String slanguage) {
        String pids = providerIdList.stream()
                .map(Object::toString) // 将Integer转换为String
                .collect(Collectors.joining(","));

        // 获取收藏的游戏ID和热门游戏ID
        Map<String, Object> map = new HashMap<>();
        map.put("pids", pids);
        map.put("region", sregion);
        map.put("uid", uid);

        List<EntryFrontVO> favoriteGamesByRegion = entranceMapper.listFavoriteGamesByRegion(map);
        List<EntryFrontVO> filteredFavoriteGames = new ArrayList<>();

        boolean foundFirstLobby = false; // 标志是否找到第一个满足条件的记录

        for (EntryFrontVO entry : favoriteGamesByRegion) {
            // 检查条件：mainEntry为lobby，gameType非空
            if ("lobby".equals(entry.getMainEntry()) && entry.getGameType() != null && !entry.getGameType().isEmpty()) {
                // 如果已经找到了第一个满足条件的记录，则跳过当前记录
                if (foundFirstLobby) {
                    continue;
                } else {
                    // 添加符合条件的EntryFrontVO到新列表中
                    filteredFavoriteGames.add(entry);
                    // 标记为已找到第一个满足条件的记录
                    foundFirstLobby = true;
                }
            } else {
                // 添加不符合条件的EntryFrontVO到新列表中
                filteredFavoriteGames.add(entry);
            }
        }

        List<EntryFrontVO> resultList = new ArrayList<>();

        // 处理收藏的游戏
        for (EntryFrontVO entryFrontVO : filteredFavoriteGames) {
            entryFrontVO.setIcon(this.getIcon(entryFrontVO));
            entryFrontVO.setFullGameName(this.getFullGameName(entryFrontVO));
            if (entryFrontVO.getCreateAt() != null) {
                entryFrontVO.setFavoriteState(true);
                resultList.add(ConvertUtils.sourceToTarget(entryFrontVO, EntryFrontVO.class));
            } else {
                resultList.add(ConvertUtils.sourceToTarget(entryFrontVO, EntryFrontVO.class));
            }
        }

        return createPageInfo(resultList, page, pageSize);
    }

    @Override
    public PageInfo<EntryFrontVO> gameTypeList(Integer page, Integer pageSize,
                                               List<Integer> providerIdList, String sregion,
                                               Long uid, String slanguage, String gameType) {
        String pids = providerIdList.stream()
                .map(Object::toString) // 将Integer转换为String
                .collect(Collectors.joining(","));

        // 获取收藏的游戏ID和热门游戏ID
        Map<String, Object> map = new HashMap<>();
        map.put("pids", pids);
        map.put("region", sregion);
        map.put("uid", uid);
        map.put("gameType", gameType);

        List<EntryFrontVO> favoriteGamesByRegion = entranceMapper.listEntryGamesByGameType(map);
        List<EntryFrontVO> resultList = new ArrayList<>();

        // 处理收藏的游戏
        for (EntryFrontVO entryFrontVO : favoriteGamesByRegion) {
            entryFrontVO.setIcon(this.getIcon(entryFrontVO));
            ;
            entryFrontVO.setFullGameName(this.getFullGameName(entryFrontVO));

            if (entryFrontVO.getCreateAt() != null) {
                entryFrontVO.setFavoriteState(true);
                resultList.add(ConvertUtils.sourceToTarget(entryFrontVO, EntryFrontVO.class));
            } else {
                resultList.add(ConvertUtils.sourceToTarget(entryFrontVO, EntryFrontVO.class));
            }
        }

        return createPageInfo(resultList, page, pageSize);
    }

    @Override
    public PageInfo<EntryFrontVO> allGameList(Integer page, Integer pageSize, List<Integer> providerIdList, String sregion, Long uid, String slanguage) {
        String pids = providerIdList.stream()
                .map(Object::toString) // 将Integer转换为String
                .collect(Collectors.joining(","));

        // 获取收藏的游戏ID和热门游戏ID
        Map<String, Object> map = new HashMap<>();
        map.put("pids", pids);
        map.put("region", sregion);
        map.put("uid", uid);

        List<EntryFrontVO> favoriteGamesByRegion = entranceMapper.listEntryGamesByAll(map);
        List<EntryFrontVO> resultList = new ArrayList<>();

        // 处理收藏的游戏
        for (EntryFrontVO entryFrontVO : favoriteGamesByRegion) {
            entryFrontVO.setIcon(this.getIcon(entryFrontVO));
            ;
            entryFrontVO.setFullGameName(this.getFullGameName(entryFrontVO));

            if (entryFrontVO.getCreateAt() != null) {
                entryFrontVO.setFavoriteState(true);
                resultList.add(ConvertUtils.sourceToTarget(entryFrontVO, EntryFrontVO.class));
            } else {
                resultList.add(ConvertUtils.sourceToTarget(entryFrontVO, EntryFrontVO.class));
            }
        }

        return createPageInfo(resultList, page, pageSize);
    }

    @Override
    public PageInfo<EntryFrontVO> promotionGameList(Integer page, Integer pageSize, List<Integer> providerIdList, String sregion, Long uid, String slanguage) {
        String pids = providerIdList.stream()
                .map(Object::toString) // 将Integer转换为String
                .collect(Collectors.joining(","));

        // 获取收藏的游戏ID和热门游戏ID
        Map<String, Object> map = new HashMap<>();
        map.put("pids", pids);
        map.put("region", sregion);
        map.put("uid", uid);
        List<EntryFrontVO> favoriteGamesByRegion = entranceMapper.listEntryGamesByPromotion(map);
        List<EntryFrontVO> resultList = new ArrayList<>();

        // 处理收藏的游戏
        for (EntryFrontVO entryFrontVO : favoriteGamesByRegion) {
            entryFrontVO.setIcon(this.getIcon(entryFrontVO));
            ;
            entryFrontVO.setFullGameName(this.getFullGameName(entryFrontVO));

            if (entryFrontVO.getCreateAt() != null) {
                entryFrontVO.setFavoriteState(true);
                resultList.add(ConvertUtils.sourceToTarget(entryFrontVO, EntryFrontVO.class));
            } else {
                resultList.add(ConvertUtils.sourceToTarget(entryFrontVO, EntryFrontVO.class));
            }
        }

        return createPageInfo(resultList, page, pageSize);
    }

    @Override
    public PageInfo<EntryFrontVO> recommendList(Integer page, Integer pageSize, String sregion, Long uid, String slanguage) {
        // 获取收藏的游戏ID和热门游戏ID
        Map<String, Object> map = new HashMap<>();
        map.put("region", sregion);
        map.put("uid", uid);

        List<EntryFrontVO> favoriteGamesByRegion = entranceMapper.listEntryGamesByRecommend(map);
        List<EntryFrontVO> resultList = new ArrayList<>();

        // 处理收藏的游戏
        for (EntryFrontVO entryFrontVO : favoriteGamesByRegion) {
            entryFrontVO.setIcon(this.getIcon(entryFrontVO));

            entryFrontVO.setFullGameName(this.getFullGameName(entryFrontVO));

            if (entryFrontVO.getCreateAt() != null) {
                entryFrontVO.setFavoriteState(true);
                resultList.add(ConvertUtils.sourceToTarget(entryFrontVO, EntryFrontVO.class));
            } else {
                resultList.add(ConvertUtils.sourceToTarget(entryFrontVO, EntryFrontVO.class));
            }
        }

        return createPageInfo(resultList, page, pageSize);
    }

    @Override
    public EntryFrontVO searchEntryByEid(Long eid, String sregion, Long uid, String slanguage) {
        // 获取收藏的游戏ID和热门游戏ID
        Map<String, Object> map = new HashMap<>();
        map.put("eid", eid);
        map.put("region", sregion);
        map.put("uid", uid);

        EntryFrontVO entryFrontVO = entranceMapper.getEntryByEid2(map);

        if (entryFrontVO.getCreateAt() != null) {
            entryFrontVO.setFavoriteState(true);
        }
        return entryFrontVO;
    }


    @Override
    public EntryFrontVO searchEntranceFe(String requestData, String sregion, Long uid, String slanguage) {
        Optional<HashMap<String, Object>> entranceInfo = providerManager.getEntranceInfo(requestData);
        if(entranceInfo.isEmpty()){
            log.error("entranceInfo 找不到");
        }
        String providerName = (String) entranceInfo.get().get("providerName");
        String gameName = (String) entranceInfo.get().get("name");

        Optional<GameInfoDTO> GameInfoDTO = gameInfoService.getGameInfo(requestData);
        if (GameInfoDTO.isPresent()) {
            // 创建Map对象
            Map<String, Object> map = new HashMap<>();
            map.put("providerName", providerName);
            map.put("region", sregion);
            map.put("gameName", gameName);
            map.put("gameType", GameInfoDTO.get().getGameType());
            map.put("uid", uid);

            // 获取入口信息
            EntryFrontVO entryFrontVO = entranceMapper.getEntryByEid3(map);
            System.out.println("entryFrontVO-----" + entryFrontVO);
            // 确保entryFrontVO不为空，避免空指针异常
            if (entryFrontVO != null) {
                // 判断是否收藏
                boolean isFavorited = entryFrontVO.getCreateAt() != null;
                entryFrontVO.setFavoriteState(isFavorited);
            } else {
                // 创建默认的EntryFrontVO对象，以避免空指针问题
                entryFrontVO = new EntryFrontVO();
                entryFrontVO.setFavoriteState(false);
            }

            entryFrontVO.setIcon(GameInfoDTO.get().getIcon());
            //    entryFrontVO.setFullGameName(this.getFullGameName(entryFrontVO));
            entryFrontVO.setFullGameName(GameInfoDTO.get().getFullGameName());

            entryFrontVO.setGameName(GameInfoDTO.get().getName());

            return entryFrontVO;
        } else {
            log.info("GameInfoDTO 找不到");
        }
        return null;
    }


    @Override
    public JSONObject getGames() {
        try {
            // 设置请求 URL
            URL url = new URL("https://tm2up.uat1.evo-test.com/api/lobby/v1/tm2up00000000001/state?gameVertical=live&gameProvider=evolution");
            // 创建 HttpURLConnection 对象
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();

            // 设置请求头
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Authorization", "Basic dG0ydXAwMDAwMDAwMDAwMTp0ZXN0MTIz");

            // 发送请求并获取响应码
            int responseCode = conn.getResponseCode();
            System.out.println("Response Code: " + responseCode);

            // 读取响应内容
            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            // 打印响应内容
         /*   System.out.println("Response Data: " + response.toString());
            System.out.println("--------------------------------------------------------");

*/

//取出response 里面tables 里 的 tableId，name，gameType，gameProvider，gameVertical，language，gameTypeUnified，open，display，sitesAssigned，players，betLimits里面的：THB,VND,IDR,MYR 的值
            JSONObject jsonObject = JSONObject.parseObject(response.toString());
            JSONObject tables = jsonObject.getJSONObject("tables");
            //获取tables 的长度
            //    System.out.println("tables.size()-----------"+tables.size());

            /*//打印tables
            JSONObject table = tables.getJSONObject("DragonTiger00001");
            System.out.println("tableId: " + table.getString("tableId"));
            System.out.println("name: " + table.getString("name"));
            System.out.println("gameType: " + table.getString("gameType"));
            System.out.println("gameProvider: " + table.getString("gameProvider"));
            System.out.println("gameVertical: " + table.getString("gameVertical"));
            System.out.println("language: " + table.getString("language"));
            System.out.println("gameTypeUnified: " + table.getString("gameTypeUnified"));
            System.out.println("open: " + table.getString("open"));
            System.out.println("display: " + table.getString("display"));
            System.out.println("sitesAssigned: " + table.getString("sitesAssigned"));
            System.out.println("players: " + table.getString("players"));
            System.out.println("videoSnapshot: " + table.getString("videoSnapshot"));

            //获取betLimits里面的：THB,VND,IDR,MYR,USD的值
            JSONObject betLimits = table.getJSONObject("betLimits");
            //     System.out.println("betLimits: " + betLimits);
            System.out.println("THB: " + betLimits.getString("THB"));
            System.out.println("VND: " + betLimits.getString("VND"));
            System.out.println("IDR: " + betLimits.getString("IDR"));
            System.out.println("MYR: " + betLimits.getString("MYR"));
            System.out.println("USD: " + betLimits.getString("USD"));*/


            return jsonObject;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<GameTypeVO> getGameTypes(Long pid) {

        return gameMapper.listGameTypeVO(pid);
    }

    @Override
    public JSONObject getGamesFiltered(String configStr) {
        try {
            Config config=JSONObject.parseObject(configStr,Config.class);
            String urlStr = String.format("%s/api/lobby/v1/%s/state?gameVertical=live&gameProvider=evolution", config.getBaseUrl(), config.getMerchantId());

            // 设置请求 URL
            URL url = new URL(urlStr);
            // 创建 HttpURLConnection 对象
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();

            String auth=config.getMerchantId()+":"+config.getExternalLobbyApiToken();
             auth = Base64.getEncoder().encodeToString(auth.getBytes());
            ;
            // 设置请求头
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Authorization", "Basic "+auth);

            // 发送请求并获取响应码
            int responseCode = conn.getResponseCode();
            System.out.println("Response Code: " + responseCode);

            // 读取响应内容
            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            JSONObject jsonObject = JSONObject.parseObject(response.toString());
            JSONObject tables = jsonObject.getJSONObject("tables");

            // 定义一个Map来存储所有的tableId和对应的详细信息
            Map<String, JSONObject> tableIdMap = new HashMap<>();
            // 获取tables中的所有键值对
            Set<Map.Entry<String, Object>> entrySet = tables.entrySet();

            if (entrySet != null) {
                // 遍历entrySet并获取所有tableId的键和值
                for (Map.Entry<String, Object> entry : entrySet) {
                    String tableId = entry.getKey(); // 获取tableId
                    JSONObject tableData = (JSONObject) entry.getValue();
                    //获取tableData的所有数据

                    //对下面字段进行判空处理
                    String gameType = tableData.getString("gameType");
                    String gameSubType = tableData.getString("gameSubType");

                    String name = tableData.getString("name");
                    //获取sitesAssigned，players，gameProvider，display，language，descriptions，videoSnapshot的值
                    com.alibaba.fastjson.JSONArray sitesAssigned = tableData.getJSONArray("sitesAssigned");
                    // 获取 "luckyNumbers" 属性的值
                    com.alibaba.fastjson.JSONArray luckyNumbersArray = tableData.getJSONArray("luckyNumbers");
                    JSONObject luckyNumber = null;
                    if (luckyNumbersArray != null) {
                        for (Object obj : luckyNumbersArray) {
                            luckyNumber = (JSONObject) obj;
                        }
                    }

                    com.alibaba.fastjson.JSONArray history = tableData.getJSONArray("history");

                    // 获取players字段
                    int players = tableData.getIntValue("players");
                    String gameProvider = tableData.getString("gameProvider");
                    String display = tableData.getString("display");
                    String language = tableData.getString("language");
                    JSONObject descriptions = tableData.getJSONObject("descriptions");
                    JSONObject dealer = tableData.getJSONObject("dealer");
                    JSONObject operationHours = tableData.getJSONObject("operationHours");
                    String videoSnapshot = tableData.getString("videoSnapshot");
                    String virtualTableId = tableData.getString("virtualTableId");

                    JSONObject betLimitObj = tableData.getJSONObject("betLimits");
                    JSONObject limitOfTHB = betLimitObj.getJSONObject("THB");
                    JSONObject limitOfVND = betLimitObj.getJSONObject("VND");
                    JSONObject limitOfIDR = betLimitObj.getJSONObject("IDR");
                    JSONObject limitOfMYR = betLimitObj.getJSONObject("MYR");
                    JSONObject limitOfUSD = betLimitObj.getJSONObject("USD");

                    JSONObject myBetLimitObj = new JSONObject();
                    myBetLimitObj.put("THB", limitOfTHB);
                    myBetLimitObj.put("VND", limitOfVND);
                    myBetLimitObj.put("IDR", limitOfIDR);
                    myBetLimitObj.put("MYR", limitOfMYR);
                    myBetLimitObj.put("USD", limitOfUSD);

                    JSONObject myTableData = new JSONObject();
                    myTableData.put("gameType", gameType);
                    myTableData.put("gameSubType", gameSubType);
                    myTableData.put("luckyNumbers", luckyNumber);
                    myTableData.put("history", history);
                    myTableData.put("name", name);
                    myTableData.put("sitesAssigned", sitesAssigned);
                    myTableData.put("players", players);
                    myTableData.put("gameProvider", gameProvider);
                    myTableData.put("display", display);
                    myTableData.put("language", language);
                    myTableData.put("descriptions", descriptions);
                    myTableData.put("videoSnapshot", videoSnapshot);
                    myTableData.put("virtualTableId", virtualTableId);
                    myTableData.put("dealer", dealer);
                    myTableData.put("operationHours", operationHours);
                    myTableData.put("open", tableData.getBooleanValue("open") ? 1 : 0);
                    myTableData.put("tableId", tableId);

                    myTableData.put("betLimits", myBetLimitObj);
                    // 获取对应的详细信息
                    tableIdMap.put(tableId, myTableData); // 将tableId和详细信息存入map中

                }
            }

            //将tableIdMap转换为json字符串
//            String tableIdMapJson = JSONObject.toJSONString(tableIdMap);

            // 创建一个新的 JSONObject
            JSONObject res = new JSONObject();

            // 遍历 tableIdMap，并将每个键值对放入 JSONObject
            for (Map.Entry<String, JSONObject> entry : tableIdMap.entrySet()) {
                res.put(entry.getKey(), entry.getValue());
            }

            //打印myTableData的所有数据
            //       System.out.println("res:---- " + res);

            return res;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    /*@Override
    public PageInfo<GameVO> popular(Integer page, List<Integer> providerIdList, String sregion, Long uid, String slanguage) {
// 将 providerIdList 转换成逗号分隔的字符串
        String pids = providerIdList.stream().map(Object::toString).collect(Collectors.joining(","));


        // 获取用户收藏的游戏ID列表
        List<Long> favoriteGameIds = new ArrayList<>();
        List<FavoriteVO> userFavorites = favoriteMapper.searchUserFavorite(uid);
        for (FavoriteVO userFavorite : userFavorites) {
            Long eid = userFavorite.getEid();
            favoriteGameIds.add(eid);
        }
        // 获取收藏的游戏ID和热门游戏ID
        Map<String, Object> map = new HashMap<>();
        map.put("pids", pids);
        map.put("region", sregion);
        List<GameVO> popularGames = gameMapper.listPopularGamesByRegion(map);
        List<GameVO> resultList = new ArrayList<>();
        // 遍历所有游戏
        for (GameVO casinoGame : popularGames) {
            if (casinoGame != null ) {
                casinoGame.setFavoriteState(favoriteGameIds.contains(casinoGame.getGameId()));
                resultList.add(ConvertUtils.sourceToTarget(casinoGame, GameVO.class));
            }else {
                resultList.add(ConvertUtils.sourceToTarget(casinoGame, GameVO.class));
            }
        }
        // 对结果列表进行排序
        Collections.sort(resultList, popularComparator());
        return createPageInfo(resultList, page);
    }
*/
    @Override
    @Transactional
    public long add(AddGameDTO gameDTO) {
        var gameId = gameMapper.add(gameDTO);
        if (gameId > 0) {
            handleGameTag(gameId, gameDTO.getTag());
            handlePromotionTag(gameId, gameDTO.getIsPromotion());
            handleGameRegions((long) gameId, gameDTO.getRegions());
        }
        return gameId;
    }

    @Override
    public int addGamesFromEvo(GameOriginalVO gameOriginalVO) {

        int count = gameOriginalMapper.addGamesFromEvo(gameOriginalVO);
        return count;
    }

    @Override
    public int addGames(GameOriginalVO gameOriginalVO) {

        int count = gameOriginalMapper.addGamesFromEvo(gameOriginalVO);
        return count;
    }

    @Override
    public int update(UpdateGameDTO gameDTO) {
        int updated = gameMapper.update(gameDTO);
        //获取pid并通知游戏更新
        Integer pid = gameMapper.getPidById(gameDTO.getId());
        gameInfoService.notifyGameUpdate(pid.longValue());
        var topic = redissonClient.getTopic(PUB_CASINO_UPDATE_LIVE_WIN);
        topic.publish("config");
        return updated;
    }
/*
    // 获取游戏地区列表
    private List<Integer> getGameRegions(Long gameId) {
        var regionList = new ArrayList<Integer>();
        List<GameRegionDTO> gameRegionList = gameMapper.listGameRegions(gameId);
        for (GameRegionDTO gameRegion : gameRegionList) {
            regionList.add(gameRegion.getRegion().intValue());
        }
        return regionList;
    }*/

    private void handleGameRegions(Long gameId, List<Integer> regionList) {
        if (regionList != null) {
            // 循环处理地区列表，添加游戏地区关联关系
            for (Integer item : regionList) {
                try {
                    var region = item.longValue();
                    var regionDTO = new GameRegionDTO(gameId, region);
                    var regionId = gameMapper.addRegion(regionDTO);
                    if (regionId > 0) {
                        log.info("添加游戏地区关联关系成功，gameId:{}, regionId:{}", gameId, regionId);
                    } else {
                        log.error("添加游戏地区关联关系失败，gameId:{}, regionId:{}", gameId, regionId);
                    }
                } catch (Exception e) {
                    log.error("添加游戏地区关联关系异常，gameId:{}, regionId:{}", gameId, item, e);
                }
            }
        }
    }

    private void handleGameTag(int gameId, String gameTag) {
        if (gameTag != null) {
            var tag = new GameTagDTO(gameId, 0, gameTag);
            gameMapper.deleteTag(tag);
            if (!gameTag.isEmpty()) {
                gameMapper.addTag(tag);
            }
        }
    }

    private void handlePromotionTag(int gameId, Boolean isPromotion) {
        var tag = new GameTagDTO(gameId, 1, "promotion");
        if (Boolean.TRUE.equals(isPromotion)) {
            gameMapper.addTag(tag);
        } else {
            gameMapper.deleteTag(tag);
        }
    }

    @Override
    public PageInfo<GameSearch> search(SearchGame2DTO searchGame2DTO) {
        // 根据搜索条件查询游戏，如果条件不为NULL，那么包含对应的条件
        PageInfo<GameSearch> pageInfo = PageHelper.startPage(searchGame2DTO.getPage(), searchGame2DTO.getPageSize())
                .doSelectPageInfo(() -> gameOriginalMapper.searchGame(searchGame2DTO));

        return pageInfo;
    }


    private PageInfo<EntryFrontVO> createPageInfo(List<EntryFrontVO> resultList, Integer page, Integer pageSize) {
        PageInfo<EntryFrontVO> newPageInfo = new PageInfo<>();
        newPageInfo.setPageNum(page);
        newPageInfo.setPageSize(pageSize);

        int fromIndex = (page - 1) * pageSize;
        int toIndex = Math.min(page * pageSize, resultList.size());
        newPageInfo.setList(fromIndex > toIndex ? Collections.emptyList() : resultList.subList(fromIndex, toIndex));
        newPageInfo.setTotal(resultList.size());
        return newPageInfo;
    }


    private String getIcon(EntryFrontVO entryFrontVO) {
        Long pid = entryFrontVO.getPid();
        String eid = String.valueOf(entryFrontVO.getEid());
        Optional<GameInfoDTO> gameInfoDTO = gameInfoService.getGameInfo(pid, eid);
        if (gameInfoDTO.isPresent()) {
            if (entryFrontVO.getIcon() != null || entryFrontVO.getIcon() != "") {
                String icon = gameInfoDTO.get().getIcon();
                return icon;
            }
        } else {
            log.info("GameInfoDTO 找不到");
        }
        return null;
    }

    private String getFullGameName(EntryFrontVO entryFrontVO) {
        Long pid = entryFrontVO.getPid();
        String eid = String.valueOf(entryFrontVO.getEid());
        Optional<GameInfoDTO> gameInfoDTO = gameInfoService.getGameInfo(pid, eid);
        if (gameInfoDTO.isPresent()) {
            if (entryFrontVO.getIcon() != null || entryFrontVO.getIcon() != "") {
                String fullGameName = gameInfoDTO.get().getFullGameName();
                return fullGameName;
            }
        } else {
            log.info("GameInfoDTO 找不到");
        }
        return null;
    }
    /* @Override
    public PageInfo<EntryVO> newGames(Integer page, List<Integer> providerIdList, String sregion, Long uid, String slanguage) {
        var map = new HashMap<String, Object>();
        map.put("providerIdList", providerIdList);
        map.put("region", sregion);
        PageInfo<EntryVO> pageInfo = PageHelper.startPage(page, HOME_PAGE_LIMIT)
     //           .setOrderBy("sort asc")
                .doSelectPageInfo(() -> gameMapper.listNewGamesByRegion(map));
    //    System.out.println("pageInfo.getList()------"+pageInfo.getList());
        List<EntryVO> list = dealList(uid, sregion, slanguage, pageInfo.getList());
        PageInfo<EntryVO> newPageInfo = new PageInfo<>(list);
        newPageInfo.setPageNum(pageInfo.getPageNum());
        newPageInfo.setPageSize(pageInfo.getPageSize());
        newPageInfo.setTotal(pageInfo.getTotal());
        return newPageInfo;
    }
*/
  /*  @Override
    public PageInfo<EntryFrontVO> promotion(Integer page, List<Integer> providerIdList, String sregion, Long uid, String slanguage) {
        Map<String, Object> map = new HashMap<>();
        map.put("providerIdList", providerIdList);
        map.put("region", sregion);
        PageInfo<EntryVO> pageInfo = PageHelper.startPage(page, HOME_PAGE_LIMIT)
          //             .setOrderBy("sort asc")
                .doSelectPageInfo(() -> gameMapper.listPromotionGamesByRegion(map));
        //    System.out.println("pageInfo.getList()------"+pageInfo.getList());
        List<EntryFrontVO> list = dealList(uid, sregion, slanguage, pageInfo.getList());
        PageInfo<EntryFrontVO> newPageInfo = new PageInfo<>(list);
        newPageInfo.setPageNum(pageInfo.getPageNum());
        newPageInfo.setPageSize(pageInfo.getPageSize());
        newPageInfo.setTotal(pageInfo.getTotal());
        return newPageInfo;
    }*/
   /* @Override
    public PageInfo<EntryVO> recommend(Integer page, List<Integer> providerIdList, String sregion, Long uid, String slanguage) {
        Map<String, Object> map = new HashMap<>();
        map.put("providerIdList", providerIdList);
        map.put("region", sregion);
        PageInfo<EntryVO> pageInfo = PageHelper.startPage(page, HOME_PAGE_LIMIT)
                //             .setOrderBy("sort asc")
                .doSelectPageInfo(() -> gameMapper.listRecommendGamesByRegion(map));
        //    System.out.println("pageInfo.getList()------"+pageInfo.getList());
        List<EntryVO> list = dealList(uid, sregion, slanguage, pageInfo.getList());
        PageInfo<EntryVO> newPageInfo = new PageInfo<>(list);
        newPageInfo.setPageNum(pageInfo.getPageNum());
        newPageInfo.setPageSize(pageInfo.getPageSize());
        newPageInfo.setTotal(pageInfo.getTotal());
        return newPageInfo;
    }*/
/*
    @Override
    public PageInfo<GameVO> sort(Integer page, List<Integer> providerIdList, String sregion, Long uid, String slanguage, String sort) {
        Map<String, Object> map = new HashMap<>();
        map.put("providerIdList", providerIdList);
        map.put("region", sregion);
        var sortStr = String.format("game_name_en %s", sort);
        PageInfo<GameVO> pageInfo = PageHelper.startPage(page, HOME_PAGE_LIMIT)
                       .setOrderBy(sortStr)
                .doSelectPageInfo(() -> gameMapper.listConditionA2Z(map));
        //    System.out.println("pageInfo.getList()------"+pageInfo.getList());
        List<GameVO> list = dealList(uid, sregion, slanguage, pageInfo.getList());
        PageInfo<GameVO> newPageInfo = new PageInfo<>(list);
        newPageInfo.setPageNum(pageInfo.getPageNum());
        newPageInfo.setPageSize(pageInfo.getPageSize());
        newPageInfo.setTotal(pageInfo.getTotal());
        return newPageInfo;
    }*/

 /*   @Override
    public PageInfo<GameVO> search(SearchGameDTO searchGameDTO) {
        // 根据搜索条件查询游戏，如果条件不为NULL，那么包含对应的条件
        PageInfo<GameVO> pageInfo = PageHelper.startPage(searchGameDTO.getPage(), searchGameDTO.getPageSize())
                .doSelectPageInfo(() -> gameMapper.searchGame1(searchGameDTO));
        return pageInfo;
    }*/



    /*

    private Comparator<GameVO> popularComparator() {
        return new Comparator<GameVO>() {
            @Override
            public int compare(GameVO game1, GameVO game2) {
                // 首先比较userCount7d，降序排列
                int compareByUserCount7d = Integer.compare(game2.getUserCount7d(), game1.getUserCount7d());
                if (compareByUserCount7d != 0) {
                    return compareByUserCount7d;
                }

                // 如果userCount7d相等，再比较gameNameEn，不区分大小写
                return game1.getGameNameEn().compareToIgnoreCase(game2.getGameNameEn());
            }
        };
    }


    private List<EntryFrontVO> dealList(Long uid, String sregion, String slanguage, List<EntryVO> list) {
        List<EntryFrontVO> entryVOList = new ArrayList<>();
        for (EntryFrontVO entryFrontVO : entryVOList) {
            if (entryFrontVO != null) {
         //       slotManagement.genActual(slanguage);
                // 查询游戏是否被收藏了

            //    System.out.println("casinoGame.getGameId()----"+casinoGame.getGameId()+"uid----"+uid);
                FavoriteDTO favoriteDTO = new FavoriteDTO();
                favoriteDTO.setEid(entryFrontVO.getEid());
                favoriteDTO.setUserId(uid);
                boolean isExist = favoriteService.exists(favoriteDTO);
                entryFrontVO.setFavoriteState(isExist);
                entryVOList.add(entryFrontVO);
            }
        }
        return entryVOList;
    }


    // 获取所有游戏数据
    public Map<String, GameVO> getAllGameMap() {
        RMap<String, GameVO> gameMap = redissonUtil.getMap(CasinoRedisKeyPrefix.CASINO_GAME_GAMEID_ENTITY_KEY);
        if (gameMap.isEmpty()) {
            log.info("redis中没有游戏数据，从数据库中加载");
            List<GameVO> allGameList = gameMapper.selectAllCasinoGames();
            log.info("加载到redis的游戏数量:{}", allGameList.size());

            // 将数据库中加载的游戏数据放入Redis Map中
            for (GameVO game : allGameList) {
                gameMap.put(String.valueOf(game.getGameId()), game);
            }
        }
        // 输出Map中的所有键值对
        // System.out.println("readAllMap-----" + gameMap.readAllMap());
        return gameMap.readAllMap();
    }

    public Map<String, GameVO> getAllGameMapPopular() {
        RMap<String, GameVO> gameMap = redissonUtil.getMap(CasinoRedisKeyPrefix.CASINO_GAME_GAMEID_ENTITY_KEY);
        if (gameMap.isEmpty()) {
            log.info("redis中没有游戏数据，从数据库中加载");
            List<GameVO> allGameList = gameMapper.selectAllCasinoGamesPopular();

            System.out.println("allGameList------"+allGameList);
            log.info("加载到redis的游戏数量:{}", allGameList.size());

            // 将数据库中加载的游戏数据放入Redis Map中
            for (GameVO game : allGameList) {
                gameMap.put(String.valueOf(game.getGameId()), game);
            }
        }
        // 输出Map中的所有键值对
        // System.out.println("readAllMap-----" + gameMap.readAllMap());
        return gameMap.readAllMap();
    }

    private boolean isConditionMet(GameVO casinoGame, String searchRegion, List<Integer> searchProvideIds) {
        if (casinoGame == null || casinoGame.getStatus() == 0 || StringUtils.isBlank(casinoGame.getRegion())) {
            return false;
        }
        if (searchProvideIds != null && !searchProvideIds.contains(casinoGame.getPid())) {
            return false;
        }

        // 将游戏地区字符串解析为整数列表
        List<Integer> gameRegionList = new ArrayList<>();
        JSONArray regionArray = JSONArray.parseArray(casinoGame.getRegion());
        for (int i = 0; i < regionArray.size(); i++) {
            gameRegionList.add(regionArray.getInteger(i));
        }

        // 判断游戏地区列表中是否包含搜索地区
        return gameRegionList.contains(Integer.parseInt(searchRegion));
    }

*/
}

