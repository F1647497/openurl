package com.uponly.casino.provider.vo;

import lombok.Data;
import io.swagger.v3.oas.annotations.media.Schema;

@Data
@Schema(title = "CasnioBetActionType 实体")
public class CasnioBetActionType {

    @Schema(title = "id")
    private int id;

    @Schema(title = "名称")
    private String name;
}