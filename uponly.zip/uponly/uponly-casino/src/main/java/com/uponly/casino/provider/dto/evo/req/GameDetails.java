package com.uponly.casino.provider.dto.evo.req;

import lombok.Data;

import java.util.Map;

@Data
public class GameDetails {
    private Table table; // Contains table details for the game

    public GameDetails(Map<String, Object> map) {
        this.table = new Table((Map<String, Object>) map.get("table"));
    }
}
