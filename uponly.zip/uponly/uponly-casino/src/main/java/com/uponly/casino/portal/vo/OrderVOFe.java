package com.uponly.casino.portal.vo;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.util.Date;

@Schema(title = "真人注单实体H5")
@Data
public class OrderVOFe implements java.io.Serializable{

    @JsonInclude(JsonInclude.Include.NON_NULL)// 控制是否包含空值字段
    @Schema(title = "id")
    private Integer id;


    @JsonInclude(JsonInclude.Include.NON_NULL)// 控制是否包含空值字段
    @Schema(title = "注单号")
    private String orderNo;

    @JsonInclude(JsonInclude.Include.NON_NULL)// 控制是否包含空值字段
    @Schema(title = "用户id")
    private Long userId;

    @JsonInclude(JsonInclude.Include.NON_NULL)// 控制是否包含空值字段
    @Schema(title = "货币类型")
    private String currency;

    @JsonInclude(JsonInclude.Include.NON_NULL)// 控制是否包含空值字段
    @Schema(title = "桌台图标")
    private String tableIconDisplay;

    @JsonInclude(JsonInclude.Include.NON_NULL)// 控制是否包含空值字段
    @Schema(title = "游戏名称")
    private String gameName;

    @JsonInclude(JsonInclude.Include.NON_NULL)// 控制是否包含空值字段
    @Schema(title = "H5请求全名")
    private String fullGameName;

    @JsonInclude(JsonInclude.Include.NON_NULL)// 控制是否包含空值字段
    @Schema(title = "投注金额")
    private BigDecimal amount;

    @JsonInclude(JsonInclude.Include.NON_NULL)// 控制是否包含空值字段
    @Schema(title = "总赔付金额")
    private BigDecimal totalPayout;

    @JsonInclude(JsonInclude.Include.NON_NULL)// 控制是否包含空值字段
    @Schema(title = "赔付金额")
    private BigDecimal payout;

    @JsonInclude(JsonInclude.Include.NON_NULL)// 控制是否包含空值字段
    @Schema(title = "注单状态")
    private Integer status;

    @JsonInclude(JsonInclude.Include.NON_NULL)// 控制是否包含空值字段
    @Schema(title = "投注时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createdAt;

    @JsonInclude(JsonInclude.Include.NON_NULL)// 控制是否包含空值字段
    @Schema(title = "结算时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date settleAt;

    @JsonInclude(JsonInclude.Include.NON_NULL)// 控制是否包含空值字段
    @Schema(title = "最近结算时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date maxSettleAt;

    @JsonInclude(JsonInclude.Include.NON_NULL)// 控制是否包含空值字段
    @Schema(title = "供应商")
    private String providerName;

}