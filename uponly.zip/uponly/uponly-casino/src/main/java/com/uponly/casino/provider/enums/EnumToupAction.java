package com.uponly.casino.provider.enums;

import lombok.Getter;

@Getter
public enum EnumToupAction {
    GET_BALANCE("getbalance"),
    CHANGE_BALANCE("ChangeBalanceFromCasino");

    private final String action;

    EnumToupAction(String action) {
        this.action = action;
    }

    public static EnumToupAction getEnum(String action) {
        for (EnumToupAction enumToupAction : EnumToupAction.values()) {
            if (enumToupAction.getAction().equals(action)) {
                return enumToupAction;
            }
        }
        return null;
    }
}
