package com.uponly.casino.provider.dto.ag.req;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class BaseReq {
    private Record data;

    public BaseReq() {

    }
    @Data
    public class Record {
        private String transactionType;

        public Record() {

        }
    }
}
