package com.uponly.casino.admin.controller;


import com.uponly.casino.common.api.Result;
import com.uponly.casino.admin.service.BigWinsConfService;
import com.uponly.casino.admin.vo.BigWinsConfVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@Tag(name = "BigWinsConfController", description = "实时大赢配置相关")
@RequestMapping("/bigWinsConf")
public class BigWinsConfController {

    @Autowired
    private BigWinsConfService bigWinsConfService;

    @Operation(summary = "查询配置列表")
    @RequestMapping(value = "/list", method = RequestMethod.POST)
    @ResponseBody
    public Result<List<BigWinsConfVO>> list() {

        try {
            return Result.success(bigWinsConfService.list(null));
        } catch (Exception e) {
            log.error("查询配置列表 异常{} ", e.getMessage());

        }
        return null;
    }

    /*@Operation(summary = "新增配置")
    @RequestMapping(value = "/save", method = RequestMethod.POST)
    @ResponseBody
    public Result save(@RequestBody BigWinsConfVO entity) {

        return Result.success(bigWinsConfService.save(entity));
    }*/

    @Operation(summary = "修改配置")
    @RequestMapping(value = "/edit", method = RequestMethod.POST)
    @ResponseBody
    public Result edit(@RequestBody BigWinsConfVO entity) {

        try {
            return Result.success(bigWinsConfService.edit(entity));
        } catch (Exception e) {
            log.error("修改配置 异常{} ", e.getMessage());

        }
        return null;
    }

    @Operation(summary = "批量修改配置")
    @RequestMapping(value = "/batchEdit", method = RequestMethod.POST)
    @ResponseBody
    public Result batchEdit(@RequestBody List<BigWinsConfVO> list) {
        try {
            bigWinsConfService.batchEdit(list);
            return Result.success("修改成功", null);
        } catch (Exception e) {
            log.error("批量修改配置 异常{} ", e.getMessage());

        }
        return null;
    }

    /*@Operation(summary = "删除配置")
    @RequestMapping(value = "/delete", method = RequestMethod.POST)
    @ResponseBody
    public Result delete(@RequestBody BigWinsConfVO entity) {
        return Result.success(bigWinsConfService.delete(entity.getId()));
    }*/

}