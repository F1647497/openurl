package com.uponly.casino.provider.dto.evo.res;

import com.alibaba.fastjson2.JSONObject;
import lombok.Data;

@Data
public class SidResponse extends BaseResponse{
    private String sid;

    public SidResponse(String uuid, String status, String sid) {
        super(status, uuid);
        this.sid = sid;
    }

    public SidResponse() {
        super();
    }

    public JSONObject toJSONObject() {
        JSONObject jsonObject =JSONObject.from(this);
        jsonObject.put("uuid", getUuid());
        jsonObject.put("status", getStatus());
        return jsonObject;
    }
}
