package com.uponly.casino.admin.vo;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RebateMsgVO {

    private Long userId;
    private String orderNo;

    @Builder.Default
    private BigDecimal betAmount = BigDecimal.ZERO;
    @Builder.Default
    private BigDecimal winAmount = BigDecimal.ZERO;

    private Date createTime;
    private String batchDate;

    private String exchange;
    private Integer vipLevel;
    private Integer location;
    private String currency;
    private Integer total;

}
