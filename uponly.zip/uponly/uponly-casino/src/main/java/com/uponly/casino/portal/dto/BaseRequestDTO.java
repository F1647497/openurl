package com.uponly.casino.portal.dto;

import com.uponly.casino.admin.dto.PageInfoDTO;
import lombok.Data;

import java.util.List;

@Data
public class BaseRequestDTO  extends PageInfoDTO {

    private List<Integer> ids;

    //baccarat,blackjack,baccarat_sicbo,roulette,dragon_tiger,poker,game_shows
    private String gameType;
}
