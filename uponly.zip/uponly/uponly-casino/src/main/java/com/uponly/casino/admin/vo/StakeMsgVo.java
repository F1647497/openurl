package com.uponly.casino.admin.vo;

import com.uponly.casino.common.utils.RegionIntegerUtil;
import com.uponly.casino.common.utils.RegionUtil;
import com.uponly.casino.common.utils.KafkaMessageHelper;
import com.uponly.casino.provider.vo.UserInfoVO;
import lombok.*;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class StakeMsgVo {

    private String agentId;
    private Long userId;
    private String region;
    private String currency;
    private String gameType;
    private BigDecimal amount;
    @Builder.Default
    private String stakeType = "cash";
    //设置默认值为True
    private boolean isTurnover;
    private String stakeResult;
    private String betId;
    private String copiedBetId;
    private String tag;
    private Integer level;
    private Integer star;


    //创建一个方法，生成一个StakeInfo对象
    public static StakeMsgVo createStakeInfo(UserInfoVO userInfo, String gameType, String betId, BigDecimal amount) {
        String region = RegionIntegerUtil.lcationIdToRegion(userInfo.getLocation());
        return StakeMsgVo.builder()
                .agentId(userInfo.getAgentId())
                .userId(userInfo.getUserId())
                .currency(userInfo.getCurrency())
                .tag(userInfo.getTag())
                .level(userInfo.getVip())
                .star(userInfo.getStar())
                .region(region)
                .gameType(gameType)
                .amount(amount)
                .stakeType("cash")
                .isTurnover(true)
                .stakeResult("")
                .betId(betId)
                .copiedBetId(null)
                .build();
    }

    public static void main(String[] args) {
        StakeMsgVo stakeMsgVo = StakeMsgVo.builder().agentId("1").userId(1L).region("Thailand").currency("THB").gameType("PGS").amount(new BigDecimal(10)).stakeType("cash").isTurnover(true).stakeResult("").betId("202413436011717000943").copiedBetId(null).tag("1").level(0).star(1).build();
        String msg = KafkaMessageHelper.toActivityJsonString("stake", stakeMsgVo);
        System.out.println(msg);
    }
}
