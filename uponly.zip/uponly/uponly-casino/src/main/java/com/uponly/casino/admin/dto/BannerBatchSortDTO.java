package com.uponly.casino.admin.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(title = "广告排序DTO")
public class BannerBatchSortDTO implements java.io.Serializable {


    @Schema(title = "需要的排序的id")
    private Integer id;

    @Schema(title = "需要的更新的sort")
    private Integer sort;

}