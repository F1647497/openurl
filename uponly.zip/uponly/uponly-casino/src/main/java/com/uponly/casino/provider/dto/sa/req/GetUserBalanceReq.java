package com.uponly.casino.provider.dto.sa.req;

import lombok.Data;

@Data
public class GetUserBalanceReq {

    /**
     * 玩家名称
     */
    private String username;
    /**
     * 币种
     */
    private String currency;
}
