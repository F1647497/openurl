package com.uponly.casino.admin.vo;


import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Data
@Schema(title="推荐游戏实体")
public class RecommendGameVO {

    @Schema(title="id")
    private Long id;

    @Schema(title="入口id")
    private long eid;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Schema(title="开始时间")
    private Date start;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Schema(title="结束时间")
    private Date end;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Schema(title="创建时间")
    private Date createTime;



    @Schema(title="供应商名称")
    private String providerName;

    @Schema(title="创建人")
    private String creator;

    @Schema(title="状态")
    private Integer status;

    @Schema(title="排序")
    private int sort;

    @Schema(title="地区")
    private String region;



    @Schema(title="是否有时间限制")
    private int timeLimit;

    @Schema(title="入口名称")
    private String ename;

    @Schema(title="图标")
    private String icon;




}