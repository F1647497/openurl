package com.uponly.casino.provider.dto.evo.req;

import lombok.Data;

import java.util.Map;

@Data
public class SidRequest {
    private String sid;
    private String userId;
    private Channel channel;
    private String uuid;

    @Data
    public static class Channel {
        private String type;
    }

    public SidRequest(String sid, String userId, Channel channel, String uuid) {
        this.sid = sid;
        this.userId = userId;
        this.channel = channel;
        this.uuid = uuid;
    }

    public SidRequest(Map<String, Object> map) {
        this.sid = (String) map.get("sid");
        this.userId = (String) map.get("userId");
        var channelMap = (Map<String, Object>) map.get("channel");
        if (channelMap != null) {
            this.channel = new Channel();
            this.channel.type = (String) channelMap.get("type");
        }
        this.uuid = (String) map.get("uuid");
    }
}

