package com.uponly.casino.provider.dto.ae.resp;

import lombok.Data;


@Data
public class AeLoginAndLaunchGameResp {
    private String status;
    private String url;
    private String[] extension;


    public AeLoginAndLaunchGameResp(String status, String url, String[] extension) {
        this.status = status;
        this.url = url;
        this.extension = extension;
    }
}
