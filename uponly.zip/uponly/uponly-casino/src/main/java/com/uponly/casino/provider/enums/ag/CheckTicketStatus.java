package com.uponly.casino.provider.enums.ag;

import lombok.Getter;


@Getter
public enum CheckTicketStatus {
    CODE_0(0, "等待下注"),
    CODE_1(1, "确认下注成功"),
    CODE_2(2, "收到下注结果，但仍未派彩"),
    CODE_3(3, "错误"),
    CODE_4(4, "传送Post Transfer-BET下注信息 成功，但遊戏平台未操作下注 (请联系客服检查下单情况)"),
    CODE_5(5, "注单取消(Refund)"),
    CODE_6(6, "注单结果传送成功"),
    CODE_7(7, "传送结果失败Send Result error"),
    CODE_10(10, "注单取消失败"),

    ;

    private final Integer code;
    private final String des;


    CheckTicketStatus(Integer code, String des) {
        this.code = code;
        this.des = des;
    }

    public static CheckTicketStatus getEnum(Integer code) {
        for (CheckTicketStatus enums : CheckTicketStatus.values()) {
            if (enums.getCode().equals(code)) {
                return enums;
            }
        }
        return null;
    }

}
