package com.uponly.casino.provider.dto.evo.req;

import lombok.Data;

import java.util.Map;

@Data
public class CreditRequest {
    private String sid;       // Player's session ID
    private String userId;    // Player's ID, assigned by Licensee
    private String currency;  // Currency code (ISO 4217 3-letter code)
    private Game game;        // Contains game details
    private Transaction transaction; // Contains transaction details
    private String uuid;      // Unique request ID

    public CreditRequest(String sid, String userId, String currency, Game game, Transaction transaction, String uuid) {
        this.sid = sid;
        this.userId = userId;
        this.currency = currency;
        this.game = game;
        this.transaction = transaction;
        this.uuid = uuid;
    }

    public CreditRequest(Map<String, Object> map) {
        this.sid = (String) map.get("sid");
        this.userId = (String) map.get("userId");
        this.currency = (String) map.get("currency");
        this.game = new Game((Map<String, Object>) map.get("game"));
        this.transaction = new Transaction((Map<String, Object>) map.get("transaction"));
        this.uuid = (String) map.get("uuid");
    }
}
