package com.uponly.casino.portal.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class LaunchGameDTO implements java.io.Serializable {
    @Schema(description = "入口名字或者游戏名字", requiredMode = Schema.RequiredMode.REQUIRED)
    private String bindName;

    @Schema(description = "play mode", nullable = true)
    private String playMode;

    @Schema(description = "返回地址", nullable = true)
    private String backUrl;

    @Schema(description = "超时返回地址", nullable = true)
    private String timeoutUrl;
}
