package com.uponly.casino.provider.vo.evo;

import lombok.Data;

import java.math.BigDecimal;
import java.util.List;
@Data
public class RNGBaccaratResult {
    private Game data;

    @lombok.Data
    public static class Game {
        private String id;
        private String gameProvider;
        private String startedAt;
        private String settledAt;
        private String status;
        private String gameType;
        private String gameSubType;
        private Table table;
        private Dealer dealer;
        private String currency;
        private List<Participant> participants;
        private Result result;
        private BigDecimal wager;
        private BigDecimal payout;

    }

    public static class Table {
        private String id;
        private String name;

    }

    public static class Dealer {
        private String uid;
        private String name;

    }
    @lombok.Data
    public static class Participant {
        private String casinoId;
        private String playerId;
        private String screenName;
        private String playerGameId;
        private String sessionId;
        private String casinoSessionId;
        private String currency;
        private List<Bet> bets;
        private List<ConfigOverlay> configOverlays;
        private String subType;
        private String playMode;
        private String channel;
        private String os;
        private String device;
        private String skinId;
        private String brandId;
        private String currencyRateVersion;
        private Shoe shoe;

    }
    @lombok.Data
    public static class Bet {
        private String code;
        private BigDecimal stake;
        private BigDecimal payout;
        private String placedOn;
        private String transactionId;
        private String description;

    }

    public static class ConfigOverlay {
        // 屬性定義
    }

    public static class Shoe {
        private String id;
        private String name;

    }
    @lombok.Data
    public static class Result {
        private String outcome;
        private Player player;
        private Player banker;
        private Multipliers multipliers;
        private RedEnvelopePayouts redEnvelopePayouts;

    }

    public static class Player {
        private int score;
        private List<String> cards;

    }

    public static class Multipliers {
        private List<String> cards;
        private List<String> betCodes;

    }

    public static class RedEnvelopePayouts {
        // 屬性定義
    }
}