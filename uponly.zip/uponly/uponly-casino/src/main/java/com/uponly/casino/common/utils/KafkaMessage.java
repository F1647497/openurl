package com.uponly.casino.common.utils;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@Builder
public class KafkaMessage<T> {
    private String messageType;
    private MessageBody<T> messageBody;

    @Data
    @Builder
    public static class MessageBody<T> {
        private String channel;
        private DataBody<T> data;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @SuperBuilder
    public static class DataBody<T> {
        private String type;
        private T data;
    }

}