package com.uponly.casino.provider.dto.toup;

import com.alibaba.fastjson2.JSONObject;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class GetBalanceResponse {
    private String currency;
    private BigDecimal balance;

    public JSONObject toJSONObject() {
        var jsonObject = new JSONObject();
        jsonObject.put("currency", currency);
        jsonObject.put("balance", balance);
        return jsonObject;
    }
}
