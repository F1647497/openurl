package com.uponly.casino.provider.dto.ae.req;

import lombok.Data;

import java.util.List;

@Data
public class CancelBetReq {
    public String action;
    public List<CancelBetTransaction> txns;
}

