package com.uponly.casino.admin.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class UpdateEffectiveAmountDTO {

    @Schema(title = "注单id")
    private String orderNo;

    @Schema(title = "有效流水")
    private BigDecimal effectiveAmount;


}
