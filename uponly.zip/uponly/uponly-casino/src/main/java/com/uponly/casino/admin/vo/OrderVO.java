package com.uponly.casino.admin.vo;

import java.math.BigDecimal;

import com.alibaba.fastjson2.JSONObject;
import com.baomidou.mybatisplus.annotation.TableField;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;
import java.util.HashMap;

@Schema(title = "真人注单实体")
@Data
public class OrderVO {

    @Schema(title = "id")
    private Integer id;

    @Schema(title = "注单号")
    private String orderNo;

    @Schema(title = "第三方注单号")
    private String thirdOrderNo;

    @Schema(title = "地区")
    private Integer region;

    @Schema(title = "用户id")
    private Long userId;

    @Schema(title = "货币类型")
    private String currency;

    @Schema(description = "游戏id") // As 'round_id' may represent a game round ID, there's no direct equivalent in your provided `OrderVO`, so I'm using a generic description.
    private String roundId;

    @Schema(title = "游戏名称")
    private String gameName;

    @Schema(title = "投注金额")
    private BigDecimal amount;

    @Schema(title = "赔付金额")
    private BigDecimal payout;

    @Schema(title = "倍数")
    private BigDecimal multiplier;

    @Schema(title = "换算成usd以后的payout金额")
    private BigDecimal usdPayout;

    @Schema(title = "注单状态 003已结算，002已经取消 001 已投注")
    private Integer status;

    @Schema(title = "消息状态") // As 'msg_state' doesn't have a direct equivalent in `OrderVO`, I'm keeping it generic.
    private Integer msgState;

    @Schema(title = "投注时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createdAt;

    @Schema(title = "结算时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date settleAt;

    @Schema(title = "投注类型")
    private Integer betType;

    @Schema(title = "结算类型")
    private String settleType;

    @Schema(title = "消息体")
    private String body;

    @Schema(title = "用户名")
    private String userName;

    @Schema(title = "tableId")
    private String tableId;

    @Schema(title = "会话ID") // This is a guess, since `session_id` isn't described in the `OrderVO`.
    private String sessionId;

    @Schema(title = "provider ID") // This is a guess, since `pid` isn't described in the `OrderVO`.
    private Long pid;

    @Schema(title = "gameResult") //  Win  Lost  Tie  Bust
    private String gameResult;

    @Schema(title = "gameType")
    private String gameType;

    @Schema(title = "有效投注")
    @TableField(exist = false)
    private BigDecimal effectiveAmount;

    public static enum EnumOrderStatus {
        INIT(0, "初始化"),
        BET(1, "成功"),
        CANCEL(2, "取消"),
        PAYOUT(3, "结算");
        private int code;
        private String desc;

        EnumOrderStatus(int code, String desc) {
            this.code = code;
            this.desc = desc;
        }

        public int getCode() {
            return code;
        }

        public String getDesc() {
            return desc;
        }
    }

    public static enum EnumMsgState {
        NONE(0, "无"),
        BET(1, "投注"),
        AMOUNT(1, "金额"),
        ACTIVITY(2, "活动"),
        GGR(3, "GGR");

        private int code;
        private String desc;

        EnumMsgState(int code, String desc) {
            this.code = code;
            this.desc = desc;
        }

        public int getCode() {
            return code;
        }

        public String getDesc() {
            return desc;
        }
    }

    public HashMap<String, String> toMap() {
        HashMap<String, String> map = new HashMap<>();
        map.put("orderNo", orderNo);
        map.put("thirdOrderNo", thirdOrderNo);
        map.put("userId", String.valueOf(userId));
        map.put("currency", currency);
        map.put("roundId", roundId);
        map.put("gameName", gameName);
        map.put("amount", amount.toString());
        map.put("payout", payout.toString());
        map.put("multiplier", multiplier.toString());
        map.put("status", String.valueOf(status));
        map.put("msgState", String.valueOf(msgState));
        map.put("createdAt", createdAt.toString());
        map.put("settleAt", settleAt.toString());
        map.put("betType", String.valueOf(betType));
        map.put("settleType", settleType);
        map.put("body", body);
        map.put("userName", userName);
        map.put("sessionId", sessionId);
        map.put("pid", String.valueOf(pid));
        map.put("gameResult", gameResult.toString());
        map.put("gameType", gameType);
        return map;
    }

    public JSONObject toJSONObject() {
        return new JSONObject(toMap());
    }
}