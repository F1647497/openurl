package com.uponly.casino.admin.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
public class CasinoBanner implements Serializable {


    private static final long serialVersionUID = 1L;

    /**
     * id
     */
    @Schema(title = "id")
    private Integer id;

    /**
     * 排序
     */
    @Schema(title = "排序")
    private Integer sort;

    /**
     * 广告名称
     */
    @Schema(title = "广告名称")
    private String bannerName;

    /**
     * all app h5(逗号隔开)
     */
    @Schema(title = "all app h5(逗号隔开)")
    private String platformType;

    /**
     * 厂商
     */
    @Schema(title = "厂商")
    private String provider;

    /**
     * 图片地址
     */
    @Schema(title = "图片地址")
    private String pictureUrl;

    /**
     * 开始时间
     */
    @Schema(title = "开始时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date startTime;

    /**
     * 结束时间
     */
    @Schema(title = "结束时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date endTime;

    /**
     * 跳转url
     */
    @Schema(title = "跳转url")
    private String redirectUrl;

    /**
     * 创建人
     */
    @Schema(title = "创建人")
    private String founder;

    /**
     * 备注
     */
    @Schema(title = "备注")
    private String remark;

    /**
     * 0关闭 1开启
     */
    @Schema(title = "0关闭 1开启")
    private int status;

    /**
     * 创建时间
     */
    @Schema(title = "创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;

    /**
     * 修改时间
     */
    @Schema(title = "修改时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date updateTime;


    @Schema(title = "地区  1 3 4 5 7")
    private Integer location;


    @Schema(title = "语言 en,zh,id,vi,th,ms")
    private String locale;


}
