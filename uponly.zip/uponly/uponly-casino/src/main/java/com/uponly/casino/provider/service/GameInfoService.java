package com.uponly.casino.provider.service;

import com.uponly.casino.provider.dto.GameInfoDTO;

import java.util.List;
import java.util.Optional;

public interface GameInfoService {
    Optional<GameInfoDTO> getGameInfo(Long pid, String uniqueName);

    Optional<GameInfoDTO> getGameInfo(String providerUniqueName) ;

    Optional<GameInfoDTO> getGameInfoByTableId(String tableId);

    void notifyGameUpdate(Long pid);

    Optional<List<GameInfoDTO>> getGameInfos(String providerUniqueName);
    Optional<List<GameInfoDTO>> getGameInfos(Long pid, String uniqueName);
}
