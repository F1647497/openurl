package com.uponly.casino.provider.enums;

public enum EnumBodyType {
    JSON("json"),
    FORM("form"),
    XML("xml"),
    URL_ENCODE("url_encode"),
    TEXT("text");

    private String value;

    EnumBodyType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
