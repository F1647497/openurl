package com.uponly.casino.provider.service;

import com.uponly.casino.admin.vo.ProviderVO;
import com.uponly.casino.mapper.ProviderMapper;
import com.uponly.casino.provider.service.impl.BaseProviderImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationContext;
import org.springframework.context.event.EventListener;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.*;

@Slf4j
@Component
public class ProviderManager {
    @Autowired
    private ApplicationContext context;

    @Autowired
    ProviderMapper providerMapper;
    private final HashMap<String, BaseProviderImpl> providerMap = new HashMap<>();
    private final HashMap<Long, ProviderVO> providerIdMap = new HashMap<>();
    private final List<ProviderVO> providerList = new ArrayList<>();

    // This method is called when the application is ready to start.

/*
    这是一个监听器方法，使用了 Spring 的 @EventListener 注解，
    并指定了监听的事件类型为 ApplicationReadyEvent。当应用启动完成后，Spring
    会触发该事件，然后执行这个监听器方法。
   通过 @Order 注解来控制它们的执行顺序。数字越小，优先级越高
    */
    @EventListener(ApplicationReadyEvent.class)
    @Order(1)
    public void onApplicationStartup() {
        try {
            var providers = providerMapper.providers();
            if (providers != null && !providers.isEmpty()) {
            //    log.info("Initializing providers: {}", providers);
                if (initialize(providers)) {
                    log.info("All providers initialized successfully.");
                }
            }
        } catch (Exception e) {
            log.error("Exception occurred during application startup: {}", e.getMessage(), e);
        }
    }

    // This method is used to create an instance of a class and inject dependencies into it.
    private Object createAndInjectDependencies(Class<?> clazz) throws Exception {
        Object instance = clazz.getDeclaredConstructor().newInstance();
        context.getAutowireCapableBeanFactory().autowireBean(instance);
        return instance;
    }

    // This method initializes the providers.
    public boolean initialize(List<ProviderVO> providerVos) {
        for (var providerVo : providerVos) {
            try {
                var name = providerVo.getName();
                var className = String.format("com.uponly.casino.provider.service.impl.%sProviderImpl",
                        Character.toUpperCase(name.charAt(0)) + name.substring(1));
                log.info("Attempting to create class instance for: {}", className);
                Class<?> clazz = Class.forName(className);
                var instance = (BaseProviderImpl) createAndInjectDependencies(clazz);
                instance.initialize(providerVo);
                providerMap.put(name, instance);
                providerMap.put(providerVo.getPid().toString(), instance);
                providerIdMap.put(providerVo.getPid(), providerVo);
                var nameByDash = providerVo.getProviderName().replace(" ", "-");
                providerVo.setNameByDash(nameByDash);
                providerList.add(providerVo);
            } catch (ClassNotFoundException e) {
                log.info("ClassNotFoundException provider [{}]:", providerVo.getName());
            }catch (Exception e) {
                log.error("Failed to initialize provider [{}]: {}", providerVo.getName(), e.getMessage(), e);
            }
        }
        return true;
    }

    public BaseProviderImpl getInstance(String providerIdOrName) {
        return providerMap.get(providerIdOrName);
    }

    // 获取供应商的内容
    public ProviderVO getProvider(Long providerId) {
        return providerIdMap.get(providerId);
    }

    // 获取供应商的内容
    public ProviderVO getProviderByName(String name) {
        return providerMap.get(name).providerVO;
    }
    // 通过供应商名称和游戏名字组成的dash串获取供应商pid，名称，游戏名称
    public Optional<HashMap<String, Object>> getEntranceInfo(String dashName) {
        for (var provider : providerList) {
            if (dashName.startsWith(provider.getNameByDash() + "-")) {
                var providerInfo = new HashMap<String, Object>();
                providerInfo.put("pid", provider.getPid().toString());
                providerInfo.put("providerName", provider.getProviderName());
                var name = dashName.substring(provider.getNameByDash().length() + 1);
                providerInfo.put("name", name.replace("-", " "));
                return Optional.of(providerInfo);
            }
        }
        return Optional.empty();
    }
}
