package com.uponly.casino.mapper;

import cn.hutool.core.date.DateTime;
import com.uponly.casino.admin.dto.SearchOrderDTO;
import com.uponly.casino.admin.dto.UpdateEffectiveAmountDTO;
import com.uponly.casino.admin.dto.UpdateMsgDTO;
import com.uponly.casino.admin.vo.*;
import com.uponly.casino.portal.dto.SearchOrderFeDTO;
import com.uponly.casino.portal.vo.OrderVOFe;
import com.uponly.casino.portal.vo.StatisticsVO;
import org.apache.ibatis.annotations.Param;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public interface OrderMapper {
    Integer add(@Param("order") OrderVO order);


    OrderVO selectByOrderNo(@Param("orderNo") String orderNo);

    OrderVO selectByPidAndThirdOrderNo(@Param("pid") String pid, @Param("thirdOrderNo") String thirdOrderNo);

    Integer updatePayout(@Param("order") OrderVO order);
    Integer updatePayoutAmount(@Param("order") OrderVO order);

    Integer updateStatus(@Param("status") Integer status, @Param("orderNo") String orderNo);

    Integer addHistory(@Param("order") OrderHistoryVO order);

    OrderVO selectByUserIdAndSessionId(@Param("userId") Long userId, @Param("sessionId") String sessionId);

    List<OrderVOBe> searchOrder(SearchOrderDTO searchOrderDTO);

    List<TotalAmountVO> searchTotal(SearchOrderDTO searchOrderDTO);

    List<OrderVOFe> searchOrderFe(SearchOrderFeDTO searchOrderFeDTO);

    List<OrderVOFe> searchOrderByOrderNoList(SearchOrderFeDTO searchOrderFeDTO);

    List<OrderVO> selectLiveBigWins(Double multiplier);

    Integer countUserBetCount(@Param("userId") Long userId, @Param("status") Integer status);

    Integer countAllTotal(@Param("userId") Long userId);

    StatisticsVO statisticsList(Long userId);

    List<OrderVOFe> searchRecentGames(Long userId);

    String selectBodyByOrderNo(@Param("orderNo") String orderNo);

    OrderVO selectByUserIdAndRoundId(@Param("userId") Long userId, @Param("gameId") String gameId);

    /**
     * 查询注单
     * @param userId 用户id
     * @param gameId 游戏id
     * @param thirdOrderNo 第三方流水号
     * @return 注单对象
     */
    OrderVO selectByUserIdAndRoundIdAndThirdOrderNo(@Param("userId") Long userId, @Param("gameId") String gameId,@Param("thirdOrderNo") String thirdOrderNo);

    Integer updateBet(@Param("order") OrderVO order);

    OrderHistoryVO selectHistoryByUserIdAndSessionId(@Param("userId") Long userId, @Param("sessionId") String sessionId, @Param("operatorType") String operatorType);

    // 根据settleAt时间戳查询前30的订单
    List<OrderVO> selectTop30UsdPayout(DateTime settleAt);

    Integer updateBetResult(@Param("order") OrderVO order);

    //更新有效流水
    Integer updateEffectiveAmount(UpdateEffectiveAmountDTO updateEffectiveAmountDTO);

    Integer updateMsgState(UpdateMsgDTO updateMsgDTO);

    List<OrderVO> selectByTime(@Param("startTime") DateTime startTime, @Param("endTime") DateTime endTime);

    List<OrderVO> selectOrderByReportState(@Param("startTime") Date startTime, @Param("endTime") Date endTime, @Param("msgState") int msgState, @Param("state") Integer state);

    @Deprecated
    List<RebateMsgVO> selectRebateSum(Date startTime, Date endTime, int msgState);

    //更新返利状态
    int updateRebateState(@Param("msgState") int msgState,
                          @Param("userId") Long userId,
                          @Param("startTime") Date startTime,
                          @Param("endTime") Date endTime);

}
