package com.uponly.casino.provider.dto.ae.req;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

@Data
public class CancelBetTransaction {
    public String platformTxId;
    public String userId;
    public String platform;
    public String gameType;
    public String gameCode;
    public String roundId;
    @JsonIgnore
    public String gameInfo;
}
