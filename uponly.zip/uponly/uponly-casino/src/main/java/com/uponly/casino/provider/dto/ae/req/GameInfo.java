package com.uponly.casino.provider.dto.ae.req;


import lombok.Data;

@Data
public class GameInfo {
    public String roundStartTime;
    public String streamerId;
    public String tableId;
    public String dealerDomain;
}

