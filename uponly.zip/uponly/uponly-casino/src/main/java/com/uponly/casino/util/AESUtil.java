package com.uponly.casino.util;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;


@Slf4j
public class AESUtil {


    private static final String ALGORITHMSTR = "AES/ECB/PKCS5Padding";


    /**
     *  加密  key 需 16位
     * @param content
     * @param key
     * @return
     */
    public static String encrypt(String content, String key) {
        try {
            //获得密码的字节数组
            byte[] raw = key.getBytes();
            //根据密码生成AES密钥
            SecretKeySpec skey = new SecretKeySpec(raw, "AES");
            //根据指定算法ALGORITHM自成密码器
            Cipher cipher = Cipher.getInstance(ALGORITHMSTR);
            //初始化密码器，第一个参数为加密(ENCRYPT_MODE)或者解密(DECRYPT_MODE)操作，第二个参数为生成的AES密钥 16位
            cipher.init(Cipher.ENCRYPT_MODE, skey);
            //获取加密内容的字节数组(设置为utf-8)不然内容中如果有中文和英文混合中文就会解密为乱码
            byte [] byte_content = content.getBytes("UTF-8");
            //密码器加密数据
            byte [] encode_content = cipher.doFinal(byte_content);
            //将加密后的数据转换为Base64编码的字符串返回
            return Base64.encodeBase64String(encode_content);
        } catch (Exception e) {
            log.error(e.getMessage());
            return null;
        }
    }

    /**
     * 解密 key 需 16位
     * @param content 待解密内容（Base64编码）
     * @param key 密钥（16位）
     * @return 解密后的内容
     */
    public static String decrypt(String content, String key) {
        try {
            // 将密文进行 Base64 解码
            byte[] encode_content = Base64.decodeBase64(content);
            // 获得密码的字节数组
            byte[] raw = key.getBytes();
            // 根据密码生成 AES 密钥
            SecretKeySpec skey = new SecretKeySpec(raw, "AES");
            // 根据指定算法 ALGORITHM 自成密码器
            Cipher cipher = Cipher.getInstance(ALGORITHMSTR);
            // 初始化密码器，第一个参数为解密(DECRYPT_MODE)操作，第二个参数为生成的 AES 密钥 16位
            cipher.init(Cipher.DECRYPT_MODE, skey);
            // 解密数据
            byte[] byte_content = cipher.doFinal(encode_content);
            // 返回解密后的内容
            return new String(byte_content, "UTF-8");
        } catch (Exception e) {
            log.error(e.getMessage());
            return null;
        }
    }

    public static String md5(String str) {
        try {
            // 创建MD5 MessageDigest 实例
            MessageDigest md = MessageDigest.getInstance("MD5");

            // 获取字符串的字节数组
            byte[] messageDigest = md.digest(str.getBytes());

            // 创建一个字符串构建器，用于构建最终的哈希值
            StringBuilder stringBuilder = new StringBuilder();

            // 将每个字节转换成十六进制
            for (byte b : messageDigest) {
                stringBuilder.append(String.format("%02x", b));
            }

            // 返回生成的哈希值
            return stringBuilder.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("MD5 cryptographic algorithm is not available.", e);
        }
    }


    public static void main(String[] args) {
        String s="{\"backUrl\": \"https://2uparena.com\",\"baseUrl\": \"https://2u2p.1up.plus\", \"ecToken\": \"\", \"ua2Token\": \"3a9df1e2703ec6250acb30367c4afb0fa4800f4b\",\"merchantId\": \"tm2up00000000001\",\"owAuthToken\": \"50a049abb7480ed125917df5e9b10a57\", \"rewardGameToken\": \"28d1410a2d17bddb12b36e849e30b8ee97312ab5\",\"gameHistoryApiToken\": \"f1f747698ef682e0327d6adca2fa12fbddf8e628\",\"externalLobbyApiToken\": \"29e08cbc88667bc663ea671d00874f07194ee314\"}";

        String s2=AESUtil.encrypt(s,AESUtil.md5("fc5c1aa94ff44696a4317b21bb695c5f"));
        System.out.println(s2);
        String s3=AESUtil.decrypt(s2,AESUtil.md5("fc5c1aa94ff44696a4317b21bb695c5f"));
        System.out.println(s3);
    }

}
