package com.uponly.casino.common.utils;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.Arrays;
import java.util.List;

/**
 * 把数据库中的region字段的json数据获取并查询是否包含指定的多个地区
 */
public class RegionUtil {

    /**
     * @param sRegion  查询的地区字符串 如：1,2,3
     * @param dbRegion 数据库地区json串 [1,2,3,4,5]
     * @return 数据库地区中是否包含要查询的地区
     * @throws JsonProcessingException
     */
    public static boolean isContainInRegion(String sRegion, String dbRegion) throws JsonProcessingException {
        List<Integer> sRegionList = Arrays.stream(sRegion.split(","))
                .map(Integer::parseInt).toList();
        ObjectMapper objectMapper = new ObjectMapper();
        List<Integer> dbRegionList = objectMapper.readValue(dbRegion, new TypeReference<>() {
        });
        return dbRegionList.stream().anyMatch(sRegionList::contains);
    }

    /**
     * 把"1,2,3"格式的region转为"1|2|3",方便sql使用REGEXP查询
     *
     * @param sRegion old
     * @return
     */
    public static String convert2Condition(String sRegion) {
        sRegion = sRegion.replaceAll("^\\D+|\\D+$", "").replace(",", "|");
        return sRegion;
    }


    public static void main(String[] args) throws JsonProcessingException {
        String sRegion = "";
        String dbRegion = "[1,2,3,4]";
        //System.out.println(isContainInRegion(sRegion, dbRegion));

        System.out.println(convert2Condition(sRegion));
    }

}
