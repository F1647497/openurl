package com.uponly.casino.admin.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Data
public class EntryFrontVO {
    @Schema(title = "providerName")
    private String providerName;

    @Schema(title = "eid")
    private Long eid;

    @Schema(title = "pid")
    private Long pid;

    @Schema(title = "gameId")
    private Long gameId;

    @Schema(title = "gameName")
    private String gameName;

    @Schema(title = "H5请求全名")
    private String fullGameName;

    @Schema(title = "gameType")
    private String gameType;

    @Schema(title = "icon")
    private String icon;

    @Schema(title = "addition")
    private String addition;

    @Schema(title = "mainEntry")
    private String mainEntry;

    @Schema(title = "promotion")
    private Integer promotion;


    @Schema(title = "sort")
    private Integer sort;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Schema(title="收藏游戏创建时间")
    private Date createAt;

    @Schema(title = "status")
    private Integer status;


    @Schema(title="收藏状态")
    private boolean favoriteState;



}
