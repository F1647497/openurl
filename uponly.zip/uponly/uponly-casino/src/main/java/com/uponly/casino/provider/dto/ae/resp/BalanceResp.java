package com.uponly.casino.provider.dto.ae.resp;

import com.alibaba.fastjson2.JSONObject;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class BalanceResp{
    protected String status;
    protected String desc;
    protected BigDecimal balance;
    protected String balanceTs;
    protected String userId;

    public BalanceResp(String status, String desc, BigDecimal balance, String balanceTs, String userId) {
        this.status = status;
        this.desc = desc;
        this.balance = balance;
        this.balanceTs = balanceTs;
        this.userId = userId;
    }
    public BalanceResp(){
        super();
    }

    public JSONObject toReturnFail(String status,String desc) {
        this.status = status;
        this.desc = desc;
        JSONObject jsonObject =JSONObject.from(this);
        jsonObject.put("status", getStatus());
        jsonObject.put("desc", getDesc());
        return jsonObject;
    }

    public JSONObject toReturnSuccess(String status,BigDecimal balance,String balanceTs,String userId) {
        this.status = status;
        this.balance = balance;
        this.balanceTs = balanceTs;
        this.userId = userId;
        JSONObject jsonObject =JSONObject.from(this);
        jsonObject.put("status", getStatus());
        jsonObject.put("balance", getBalance());
        jsonObject.put("balanceTs", getBalanceTs());
        jsonObject.put("userId", getUserId());
        return jsonObject;
    }

}
