package com.uponly.casino.job;

import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson2.JSON;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.uponly.casino.admin.dto.UpdateMsgDTO;
import com.uponly.casino.admin.vo.OrderVO;
import com.uponly.casino.admin.vo.RebateMsgVO;
import com.uponly.casino.common.constant.CommonConstant;
import com.uponly.casino.common.enums.ReportType;
import com.uponly.casino.common.utils.GUIDUtils;
import com.uponly.casino.common.utils.date.DateUtils;
import com.uponly.casino.common.utils.date.LocalDateTimeUtils;
import com.uponly.casino.provider.vo.UserInfoVO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.*;
import java.util.stream.Collectors;


@Slf4j
@Component
public class RebateJob extends AbstractReportJob {

    protected Date startTime;
    protected Date endTime;
    protected ReportType reportType;

    private static String startTimeStr;
    private static String endTimeStr;

    public RebateJob() {
        reportType = ReportType.REBATE;
    }


    /**
     * 返利推送 每日凌晨2点上报前一天数据
     *
     * <p>
     */
    @Async("taskScheduler")
//    @Scheduled(cron = "0 */1 * * * ?") // for test
    @Scheduled(cron = "0 0 2 * * ?") //"0 0 2 * * ?"
    public void sendActiveMsgJob() {
        startTime = DateUtils.of(LocalDateTimeUtils.getYesterday());
        endTime = DateUtils.of(LocalDateTimeUtils.getToday());

        startTimeStr = DateUtil.format(startTime, DatePattern.NORM_DATETIME_MS_PATTERN);
        endTimeStr = DateUtil.format(endTime, DatePattern.NORM_DATETIME_MS_PATTERN);

        super.execute();
    }


    @Override
    protected String kafkaTopic() {
        return CommonConstant.CASINO_ACTIVITY_TOPIC;
    }

    @Override
    protected String kafkaKey(Object data) {
        if (data instanceof RebateMsgVO order) {
            return String.valueOf(order.getUserId());
        }
        return null;
    }

    @Override
    protected String kafkaData(Object data) {
        if (!(data instanceof RebateMsgVO order)) {
            log.error("【Rebate上报】instanceof错误！data={}", data);
            return null;
        }
        if (Objects.isNull(order.getUserId())) {
            log.error("【Rebate上报】userId为空, rebateVO={}", order);
            return null;
        }
        Optional<UserInfoVO> userInfoOp = userInfoService.getUser(order.getUserId());
        if (userInfoOp.isEmpty()) {
            log.error("【Rebate上报】userInfoFeige为空, OrderVO={}", order);
            return null;
        }
        UserInfoVO userInfo = userInfoOp.get();
        order.setExchange(userInfo.getCurrency());
        order.setVipLevel(userInfo.getVip());
        order.setCurrency(userInfo.getCurrency());
        order.setLocation(userInfo.getLocation());

        order.setBatchDate(getBatchDate());

        JSONObject msgJson = new JSONObject();
        msgJson.put("messageType", reportType.getType());
        msgJson.put("messageBody", JSON.toJSON(order));
        String kafkaMsg = msgJson.toJSONString();
        log.info("【Rebate上报】build data success! startTime={},endTime={},kafka.msg={}", startTimeStr, endTimeStr, kafkaMsg);
        return kafkaMsg;
    }

    @Override
    protected ReportType getReportType() {
        return reportType;
    }

    @Override
    protected List<Object> fetchData() {
        List<OrderVO> orders = orderMapper.selectOrderByReportState(startTime, endTime, reportType.getState(), 3);
        log.info("【Rebate上报】fetch data success! startTime={},endTime={},count：{} ", startTimeStr, endTimeStr, orders.size());


        Map<Long, RebateMsgVO> rebateMsgMap = Maps.newHashMap();

        String nowTime = DateUtil.format(DateUtil.date(), "yyyyMMddHHmmss");
        for (OrderVO order : orders) {
            Long userId = order.getUserId();
            //如果rebateMsgMap中不存在该用户则创建，存在则合并数据
            RebateMsgVO rebateMsgVO = rebateMsgMap.getOrDefault(userId, RebateMsgVO.builder().userId(userId).orderNo(userId + "-" + nowTime).build());

            BigDecimal betAmount = order.getAmount();
            BigDecimal payout = order.getPayout();
            String gameResult = order.getGameResult();


            BigDecimal effectBetAmount = getEffectiveAmountV1(order);
            rebateMsgVO.setBetAmount(rebateMsgVO.getBetAmount().add(effectBetAmount));
            rebateMsgVO.setWinAmount(rebateMsgVO.getWinAmount().add(payout));
            rebateMsgMap.put(userId, rebateMsgVO);
        }

        return new ArrayList<>(rebateMsgMap.values());
    }

    @Override
    protected void updateData(Object data) {
        RebateMsgVO order = (RebateMsgVO) data;

        int result = orderMapper.updateRebateState(reportType.getState(), order.getUserId(), startTime, endTime);
        if (result > 0) {
            //        orderMapper.insertRebateRecord(order);
            log.info("【Rebate上报】上报成功！startTime={} endTime={} userId={}", startTimeStr, endTimeStr, order.getUserId());
        } else {
            log.error("【Rebate上报】上报失败！startTime={} endTime={} userId={}", startTimeStr, endTimeStr, order.getUserId());
        }
    }

    @Override
    protected void finishReporting(Object data) {

    }

    /**
     * 获取批次日期
     * 获取字符串格式上报日期batchDate，格式为yyyyMMdd。当前时间是周一时，上报日期为上周一的日期，否则为本周一的日期
     */
    private String getBatchDate() {
        LocalDate now = LocalDate.now();
        LocalDate reportDate = now.getDayOfWeek() == DayOfWeek.MONDAY
                ? now.minusWeeks(1)
                : now.with(TemporalAdjusters.previous(DayOfWeek.MONDAY));

        return reportDate.format(DateTimeFormatter.ofPattern("yyyyMMdd"));
    }

    /**
     * 获取有效流水
     * //当没有内容时，需要辅助时间判断，超时则直接使用betAmount字段
     * //目前先获取列表数据，分别处理有效流水
     * <p>
     * //汇总并计算有效流水
     * //当order的game_result不为空时，直接使用game_result计算有效流水，否则需要判断结算时间settleAt是否超时(自定义的)，超时则采用投注金额作为有效流水
     *
     * @param order 订单
     * @return 有效流水
     * @deprecated 新版本采用getEffectiveAmountV1，直接使用投注金额作为有效流水
     */
    @Deprecated
    public BigDecimal getEffectiveAmount(OrderVO order) {
        BigDecimal betAmount = order.getAmount();
        BigDecimal payout = order.getPayout();
        String gameResult = order.getGameResult();
        // 默认已经在amount上报时入库，此处不再重复计算，如果没有值，再取betAmount
        BigDecimal effectBetAmount = Optional.ofNullable(order.getEffectiveAmount()).orElse(BigDecimal.ZERO);
        if (effectBetAmount.compareTo(BigDecimal.ZERO) <= 0) {
            log.error("【Rebate上报】有效流水为0,尝试重新计算。 order={}", order);

            if (StringUtils.isNotBlank(gameResult) && !"{}".equals(gameResult)) {
                effectBetAmount = super.getEffectiveAmount(betAmount, order.getGameResult());
            } else {
                // 判断settleAt字段是否超时 一天一次发送消息时，默认早已超时，对于此类上报数据，保留其日志
                effectBetAmount = order.getAmount();
                if (!isSettleAtTimeout(order)) {
                    log.error("【Rebate上报】settleAt未超时，但game_result为空，仍使用betAmounts作为有效流水, order={}", order);
                }
            }
        }
        return order.getAmount();
    }

    /**
     * 获取有效流水第二版
     * 仍然采用注单的投注金额作为有效流水
     *
     * @param order 订单
     * @return 有效流水
     */
    private BigDecimal getEffectiveAmountV1(OrderVO order) {
        return order.getAmount();
    }
}
