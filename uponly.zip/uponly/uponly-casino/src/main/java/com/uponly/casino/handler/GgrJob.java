//package com.uponly.casino.handler;
//
//
//import com.alibaba.fastjson.JSONObject;
//import com.uponly.casino.admin.dto.UpdateMsgDTO;
//import com.uponly.casino.admin.vo.GgrMsgVO;
//import com.uponly.casino.common.utils.RegionIntegerUtil;
//import com.uponly.casino.admin.service.GetRedisDataService;
//import com.uponly.casino.mapper.OrderMapper;
//import com.uponly.casino.provider.service.UserInfoService;
//import com.uponly.casino.provider.vo.UserInfoVO;
//import lombok.extern.slf4j.Slf4j;
//import org.redisson.api.RLock;
//import org.redisson.api.RedissonClient;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.kafka.core.KafkaTemplate;
//import org.springframework.kafka.support.SendResult;
//import org.springframework.stereotype.Service;
//
//import java.math.BigDecimal;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Optional;
//import java.util.UUID;
//import java.util.concurrent.CompletableFuture;
//
//
//@Service
//@Slf4j
//public class GgrJob extends AbstractReportJob {
//    @Autowired
//    private KafkaTemplate<String, String> kafkaTemplate;
//
//    @Autowired
//    RedissonClient redissonClient;
//
//    @Autowired
//    UserInfoService userInfoService;
//
//    @Autowired
//    GetRedisDataService getRedisDataService;
//
//    @Autowired
//    OrderMapper orderMapper;
//
//    public void sendGgrMsg(List<String> orderListRedis) {
//        RLock lock = redissonClient.getLock("sendAmountMsg");
//        try {
//            // 从redis中获取casino注单列表，然后一次性发送订单数组到kafka
//            lock.lock();
//            List<GgrMsgVO> ggrMsgVOList = this.generateMsg(orderListRedis);
//            for (GgrMsgVO ggrMsgVO : ggrMsgVOList) {
//                CompletableFuture<SendResult<String, String>> future = this.sendGgrMsgJob(ggrMsgVO);
//                log.info("【sendGgrMsgJob】的发送结果={}", future);
//            }
//        } catch (Exception e) {
//            log.error("sendGgrMsgJob异常 ", e);
//        } finally {
//            lock.unlock();
//        }
//    }
//
//    public List<GgrMsgVO> generateMsg(List<String> orderListRedis) {
//        try {
//            List<GgrMsgVO> ggrMsgVOList = new ArrayList<>();
//            for (String orderJsonString : orderListRedis) {
//                JSONObject jsonObject = JSONObject.parseObject(orderJsonString);
//
//                Long userId = jsonObject.getLong("userId");
//                Optional<UserInfoVO> userInfoVO = userInfoService.getUser(userId);
//                UserInfoVO userInfo = userInfoVO.get(); // 获取内部对象
//
//                String region = RegionIntegerUtil.lcationIdToRegion(userInfo.getLocation());
//                int level = userInfo.getVip();
//                int star = userInfo.getStar();
//                String agentId = userInfo.getAgentId();
//
//                BigDecimal amount = jsonObject.getBigDecimal("amount");
//                BigDecimal payout = jsonObject.getBigDecimal("payout");
//                BigDecimal difference = payout.subtract(amount); // 使用 subtract() 方法进行减法操作
//                String stakeResult = difference.compareTo(BigDecimal.ZERO) > 0 ? "win" : difference.compareTo(BigDecimal.ZERO) < 0 ? "lose" : "draw";
//                String currency = jsonObject.getString("currency");
//                String betId = jsonObject.getString("orderNo");
//                String settleAt = jsonObject.getString("settleAt");
//                String tagFromUserInfo = jsonObject.getString("tag");
//                String tag = tagFromUserInfo == null ? "real" : "test";
//
//                GgrMsgVO ggrMsgVO = new GgrMsgVO();
//                ggrMsgVO.setUserId(userId);
//                ggrMsgVO.setAgentId(agentId);
//                ggrMsgVO.setRegion(region);
//                ggrMsgVO.setLevel(level);
//                ggrMsgVO.setStar(star);
//                ggrMsgVO.setStakeResult(stakeResult);
//                ggrMsgVO.setCurrency(currency);
//                //用于计算毛利，用投注金额减去派彩金额，得到平台的盈亏
//                ggrMsgVO.setAmount(amount.subtract(payout));
//                ggrMsgVO.setBetId(betId);
//                ggrMsgVO.setTag(tag);
//                ggrMsgVO.setSettleAt(settleAt);
//
//                ggrMsgVOList.add(ggrMsgVO);
//            }
//
//            //  System.out.println("amountMsgVOList-----" + ggrMsgVOList);
//            return ggrMsgVOList;
//        } catch (Exception e) {
//            log.error("generateMsg 异常{} ", e.getMessage());
//
//        }
//        return List.of();
//    }
//
//
//    public CompletableFuture<SendResult<String, String>> sendGgrMsgJob(GgrMsgVO ggrMsgVO) {
//        try {
//            JSONObject ggrJson = new JSONObject();
//            ggrJson.put("agentId", ggrMsgVO.getAgentId());
//            ggrJson.put("userId", ggrMsgVO.getUserId());
//            ggrJson.put("region", ggrMsgVO.getRegion());
//
//            ggrJson.put("currency", ggrMsgVO.getCurrency());
//            ggrJson.put("gameType", "EVO Casino");
//            ggrJson.put("amount", ggrMsgVO.getAmount());
//
//            ggrJson.put("stakeType", "cash");
//            ggrJson.put("isTurnover", ggrMsgVO.getIsTurnover());
//            ggrJson.put("stakeResult", ggrMsgVO.getStakeResult());
//
//            ggrJson.put("betId", ggrMsgVO.getBetId());
//            ggrJson.put("copiedBetId", "");
//            ggrJson.put("tag", ggrMsgVO.getTag());
//            ggrJson.put("level", ggrMsgVO.getLevel());
//            ggrJson.put("star", ggrMsgVO.getStar());
//
//            JSONObject jsonObject = new JSONObject();
//            jsonObject.put("messageType", "ggr");
//            jsonObject.put("messageBody", ggrJson);
//            jsonObject.put("partion", 0);
//            jsonObject.put("messageId", UUID.randomUUID());
//
//            long timestamp = getTimestamp(ggrMsgVO.getSettleAt());
//            jsonObject.put("ts", timestamp);
//
//            String msgOfBettingForKafka = jsonObject.toJSONString();
//            log.info("【ggr注单上报】sendGgrMsg.msg={}", msgOfBettingForKafka);
//            CompletableFuture<SendResult<String, String>> future = super.execute(ggrMsgVO.getUserId(), msgOfBettingForKafka);
//            //用5个位置 表示发送消息的状态，1表示已发送，0 未发送，消息所在位置：AmountMsg：第1位；GgrMsg：第2位；ActiveMsg：第3位；GgrMsg：第4位；BetMsg：第5位；RebateMsg
//            UpdateMsgDTO updateMsgDTO = new UpdateMsgDTO();
//            updateMsgDTO.setOrderNo(ggrMsgVO.getBetId());
//            updateMsgDTO.setMsgNumber(0b01000);
//
//            if (future != null) {
//                Integer count = orderMapper.updateMsgState(updateMsgDTO);
//                log.info("ggr更新消息状态数量 = {}", count);
//            }
//
//            //    CompletableFuture<SendResult<String, String>> future = kafkaTemplate.send(CommonConstant.CASINO_BETTING_JOB_TOPIC, msgOfBettingForKafka);
//            System.out.println("future-----" + future);
//            return future;
//        } catch (Exception e) {
//            log.error("sendGgrMsgJob 异常{} ", e.getMessage());
//
//        }
//        return null;
//    }
//
//
//}
