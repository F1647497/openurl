package com.uponly.casino.admin.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(title = "RelEidRegionVO")
public class AddRegionDTO implements java.io.Serializable {

    @Schema(title = "id")
    private Long id;

    @Schema(title = "入口id")
    private Long eid;

    @Schema(title = "地区")
    private int region;


}