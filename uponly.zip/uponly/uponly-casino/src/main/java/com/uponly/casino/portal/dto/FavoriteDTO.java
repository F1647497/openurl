package com.uponly.casino.portal.dto;


import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class FavoriteDTO {
    @Schema(title="ID", hidden = true)
    private Long id;

    @Schema(title="入口ID", nullable = false, requiredMode = Schema.RequiredMode.REQUIRED)
    private Long eid;

    @Schema(title = "用户ID", hidden = true)
    // 可选，不暴露
    private Long userId;

}
