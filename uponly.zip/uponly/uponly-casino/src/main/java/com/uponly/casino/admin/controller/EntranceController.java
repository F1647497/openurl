package com.uponly.casino.admin.controller;

import com.github.pagehelper.PageInfo;
import com.uponly.casino.admin.dto.*;
import com.uponly.casino.admin.service.EntranceService;
import com.uponly.casino.admin.service.GameService;
import com.uponly.casino.admin.vo.EntryVO;
import com.uponly.casino.admin.vo.GameTypeVO;
import com.uponly.casino.common.api.Result;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/gameEntrance")
@Tag(name = "EntranceController", description = "游戏入口管理")
public class EntranceController {

    @Autowired
    private EntranceService entryService;

    @Autowired
    private GameService gameService;

    @ResponseBody
    @Operation(summary = "查询入口名称是否存在")
    @PostMapping("/searchEname")
    public Result<String> searchEname(@RequestParam String providerName, @RequestParam String ename) {

            // 避免使用字符串常量直接比较，改用equals方法比较
            if ("All Games".equals(ename) && "Evolution".equals(providerName)) {
                return Result.success("");
            } else {
                SearchEnameDTO searchEnameDTO = new SearchEnameDTO();
                searchEnameDTO.setEname(ename);
                searchEnameDTO.setProviderName(providerName);
                Integer count = entryService.searchEname(searchEnameDTO);

                System.out.println("count: " + count);
                // 尽早返回，减少嵌套深度
                if (count > 0) {
                    return Result.fail("入口名称已存在");
                } else {
                    return Result.success("");
                }
            }

    }


    @ResponseBody
    @Operation(summary = "查询tableId是否存在")
    @PostMapping("/searchAddition")
    public Result<String> searchAddition(@RequestBody String addition) {

        try {
            Integer count = entryService.searchAddition(addition);
            if (count > 0) {
                return Result.fail("tableId已存在");
            } else
                return Result.success("");
        } catch (Exception e) {
            log.error("查询tableId是否存在 异常{} ", e.getMessage());
        }
        return null;
    }

    @ResponseBody
    @Operation(summary = "查询游戏入口")
    @PostMapping("/searchGameEntrance")
    public Result<PageInfo<EntryVO>> search(@RequestBody SearchGameEntranceDTO searchGameEntranceDTO) {
        try {
            PageInfo<EntryVO> pageInfo = entryService.searchGameEntrance(searchGameEntranceDTO);
            return Result.success(pageInfo);
        } catch (Exception e) {
            log.error("查询游戏入口 异常{} ", e.getMessage());
        }
        return null;
    }

    @ResponseBody
    @Operation(summary = "添加游戏游戏入口")
    @PostMapping("/newGameEntrance")
    public Result<String> newGameEntrance(@RequestBody AddGameEntranceDTO addGameEntranceDTO) {
        try {
            Long eid = entryService.newGameEntrance(addGameEntranceDTO);
            if (eid == 0) {
                return Result.fail("添加游戏入口失败");
            }
            return Result.success("添加游戏入口成功", null);
        } catch (Exception e) {
            log.error("添加游戏游戏入口 异常{} ", e.getMessage());

            return Result.fail("添加游戏入口失败", e.getMessage());
        }
    }

    @ResponseBody
    @Operation(summary = "编辑游戏入口")
    @PostMapping("/editGameEntrance")
    public Result<String> editGameEntrance(@RequestBody EditGameEntranceDTO editGameEntranceDTO) {
        try {
            int result = entryService.editGameEntrance(editGameEntranceDTO);
            if (result == 0) {
                return Result.fail("eid不存在入口表 地区表 推荐表或者已经删除");
            } else {
                return Result.success("编辑游戏入口成功");
            }
        } catch (Exception e) {
            log.error("编辑游戏入口 异常{} ", e.getMessage());
        }
        return null;
    }

    @ResponseBody
    @Operation(summary = "刪除游戏游戏入口")
    @PostMapping("/deleteGameEntrance")
    public Result<String> deleteGameEntrance(@RequestBody DeleteGameEntranceDTO deleteGameEntranceDTO) {
        try {
            int result = entryService.deleteGameEntrance(deleteGameEntranceDTO);
            if (result > 0) {
                return Result.success("删除游戏入口成功");
            }
            return Result.fail("删除游戏入口失败");
        } catch (Exception e) {
            log.error("刪除游戏游戏入口 异常{} ", e.getMessage());
        }
        return null;
    }

    @ResponseBody
    @Operation(summary = "批量排序入口")
    @PostMapping("/batchSortEntrance")
    public Result<String> batchSortEntrance(@RequestBody BatchSortDTO batchSortDTO) {
        try {
            entryService.setGameEntrance(batchSortDTO);
            return Result.success("批量排序成功");
        } catch (Exception e) {
            log.error("批量排序入口 异常{} ", e.getMessage());
        }
        return null;
    }

    @Operation(summary = "获取主入口类型")
    @PostMapping(value = "/getMainEntry")
    public Result<Map<String, String>> getMainEntry() {

        try {
            Map<String, String> gameEntryList = new HashMap<>();
            gameEntryList.put("lobby", "大厅");
            gameEntryList.put("game_lobby", "类型大厅");
            gameEntryList.put("game", "游戏");

            return Result.success(gameEntryList);
        } catch (Exception e) {
            log.error("获取主入口类型 异常{} ", e.getMessage());
        }
        return null;
    }

    @Operation(summary = "获取所有游戏类型")
    @PostMapping(value = "/getGameType")
    public Result<List<GameTypeVO>> getGameType(@RequestParam Long pid) {
        try {
            List<GameTypeVO> gameTypeList = gameService.getGameTypes(pid);
            return Result.success(gameTypeList);
        } catch (Exception e) {
            log.error("获取主入口类型 异常{} ", e.getMessage());
        }
        return null;
    }


   /* @Operation(summary = "获取所有游戏类型")
    @PostMapping(value = "/getAllGameType")
    public Result<List<String>> getAllGameType() {
        JSONObject games = gameService.getGames();

        JSONObject tables = games.getJSONObject("tables");

        Iterator<String> keys = tables.keySet().iterator();
        List<String> gameTypeList = new ArrayList<>();
        while (keys.hasNext()) {
            String key = keys.next();
            JSONObject value = (JSONObject) tables.get(key); // 获取对应的值
            String gameType = (String) value.get("gameType"); // 获取对应的值

            gameTypeList.add(gameType);
             // 打印键和值
      //      System.out.println("gameType: " + gameType);

            // 打印键和值
       //     System.out.println("Key: " + key + ", Value: " + value);
        }
        Set<String> uniqueSet = new LinkedHashSet<>(gameTypeList);
        List<String> uniqueGameTypeList = new ArrayList<>(uniqueSet);

        return Result.success(uniqueGameTypeList);
    }
*/
}

