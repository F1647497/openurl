package com.uponly.casino.provider.dto.ag.res;

import lombok.Data;


@Data
public class Result {
    private String info;



    public Result() {

    }
}
