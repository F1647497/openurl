package com.uponly.casino.admin.dto;

import com.esotericsoftware.kryo.serializers.FieldSerializer;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

@Data
public class RecommendDTO implements java.io.Serializable {
    @Schema(title="id")
    private int id;

    @Schema(title="入口id")
    private Long eid;

    @Schema(title="地区")
    private String region;

    @Schema(title="是否有时间限制")
    @FieldSerializer.NotNull()
    private int timeLimit;

    @Schema(title="排序")
    @FieldSerializer.NotNull()
    private int sort;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Schema(title="开始时间")
    private String start;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Schema(title="结束时间")
    private String end;

    @Schema(title="状态")
    private int status;

    @Schema(title="创建人")
    private String creator;
}
