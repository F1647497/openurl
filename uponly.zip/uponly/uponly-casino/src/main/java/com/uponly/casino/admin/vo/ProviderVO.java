package com.uponly.casino.admin.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.Optional;

import static com.uponly.casino.util.AESUtil.decrypt;
import static com.uponly.casino.util.AESUtil.md5;

@Data
@Schema(title="供应商实体")
public class ProviderVO extends BaseProviderVO {
    private String privateKey;
    private String config;
    // 供应商名称空格用-替换
    private String nameByDash;

    // 获取config中的隐私值
    public Optional<String> getPrivateConfig(ProviderVO providerVo) {
        String privateKey = providerVo.getPrivateKey();
        // 计算privateKey的md5值, 作为AES解密的key
        var keyMd5 = md5(privateKey);
        return Optional.ofNullable(decrypt(providerVo.getConfig(), keyMd5));
    }

}