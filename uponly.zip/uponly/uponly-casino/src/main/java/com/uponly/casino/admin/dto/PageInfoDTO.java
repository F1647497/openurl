package com.uponly.casino.admin.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class PageInfoDTO implements java.io.Serializable {
    @Schema(title="页数")
    private Integer page = 1;

    @Schema(title="每页大小")
    private Integer pageSize = 10;
}
