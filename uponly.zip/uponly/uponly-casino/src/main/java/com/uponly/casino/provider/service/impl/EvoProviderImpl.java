package com.uponly.casino.provider.service.impl;

import cn.hutool.core.util.IdUtil;
import cn.hutool.http.HttpResponse;
import cn.hutool.http.HttpUtil;
import com.alibaba.fastjson2.JSON;
import com.alibaba.fastjson2.JSONArray;
import com.alibaba.fastjson2.JSONObject;
import com.esotericsoftware.minlog.Log;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.uponly.casino.admin.service.GameService;
import com.uponly.casino.admin.vo.*;
import com.uponly.casino.common.constant.CommonConstant;
import com.uponly.casino.mapper.GameOriginalMapper;
import com.uponly.casino.provider.dto.GameInfoDTO;
import com.uponly.casino.provider.dto.RequestDTO;
import com.uponly.casino.provider.dto.evo.Config;
import com.uponly.casino.provider.dto.evo.req.*;
import com.uponly.casino.provider.dto.evo.res.*;
import com.uponly.casino.provider.dto.toup.BalanceDTO;
import com.uponly.casino.provider.dto.toup.ChangeBalanceResponse;
import com.uponly.casino.provider.dto.toup.GetBalanceResponse;
import com.uponly.casino.provider.enums.EVOGameType;
import com.uponly.casino.provider.enums.EVOStatusType;
import com.uponly.casino.provider.enums.EnumWalletOperatorType;
import com.uponly.casino.provider.service.ProviderManager;
import com.uponly.casino.provider.vo.evo.*;
import com.uponly.casino.util.UidUtil;
import com.uponly.casino.common.api.Result;
import com.uponly.casino.common.api.ResultCode;
import com.uponly.casino.common.exception.BusinessException;
import lombok.extern.slf4j.Slf4j;
import org.redisson.api.RBucket;
import org.redisson.api.RList;
import org.redisson.api.RMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.*;

import static com.uponly.casino.common.constant.CommonConstant.CASINO_ORDER_RESULT_LIST;


@Slf4j
@Service
public class EvoProviderImpl extends BaseProviderImpl {

    public static Config config ;
    @Autowired
    private GameService gameService;
    @Autowired
    private GameOriginalMapper gameOriginalMapper;
    @Autowired
    private ProviderManager providerManager;
    public static final String CASINO_SESSION_KEY = "casino:user:session:";

    @Override
    public boolean initialize(ProviderVO providerVo) {
        super.initialize(providerVo);
        if (providerVo.getConfig() == null) {
            log.error("evo config is null");
            return false;
        }
        String configStr=providerVo.getPrivateConfig(providerVo).get();
        Config config=JSONObject.parseObject(configStr,Config.class);
        config.setPrivateKey(providerVo.getPrivateKey());
        EvoProviderImpl.config = config;
        return true;
    }

    public boolean checkUserId(String uid) {
        // 驗證 uid 是否為純數字
        try {
            Long.parseLong(uid);
        } catch (NumberFormatException e) {
            log.error("evo userId is not a numeric value");
            return false;
        }
        return true;
    }

    public boolean validate(String uid, String sid) {
        if (uid == null || sid == null) {
            log.error("evo userId or sid is null");
            return false;
        }
        var sessionKey = CASINO_SESSION_KEY + uid;
        RMap<String, String> map = redissonClient.getMap(sessionKey);
        String jsonValue = map.get("sessionids");
        try {
            JSONObject nested = JSONObject.parseObject(jsonValue);
            if (Objects.isNull(nested) || !nested.containsKey(sid)) {
                log.error("evo {} sid is invalid", sid);
                return false;
            }
        } catch (Exception e) {
            log.error("evo validate error: {}", e.getMessage());
            return false;
        }
        return true;
    }

    @Override
    public JSONObject check(RequestDTO param) {
        log.info("evo check api call {}", JSON.toJSONString(param.getBody()));
        var ret = new CheckUserRequest(param.getBody());
        var response = new CheckResponse();
        response.setUuid(ret.getUuid());
        if(!checkUserId(ret.getUserId())){
            response.setStatus(EVOStatusType.INVALID_PARAMETER.name());
            return response.toJSONObject();
        }
        var check = validate(ret.getUserId(), ret.getSid());
        if (!check) {
            response.setStatus(EVOStatusType.INVALID_SID.name());
        }
        return response.toJSONObject();
    }

    @Override
    public JSONObject balance(RequestDTO param) {
        log.info("evo balance api call {}", JSON.toJSONString(param.getBody()));
        // 把 param的body转换成JSONObject
        var req = new BalanceRequest(param.getBody());
        var res = new BalanceResponse();
        res.setUuid(req.getUuid());
        var userId = req.getUserId();
        if(!checkUserId(userId)){
            res.setStatus(EVOStatusType.INVALID_PARAMETER.name());
            return res.toJSONObject();
        }
        var check = validate(userId, req.getSid());
        if (!check) {
            log.error("evo balance check is false");
            res.setStatus(EVOStatusType.INVALID_PARAMETER.name());
            return res.toJSONObject();
        }
        Long uid = Long.valueOf(userId);
        var balanceResponse = getBalance(uid);
        // 把 balanceResponse转换成JSONObject
        if (balanceResponse.isEmpty()) {
            log.info("evo balanceResponse is null");
            res.setStatus(EVOStatusType.UNKNOWN_ERROR.name());
            return res.toJSONObject();
        }
        var balance = balanceResponse.get().getBalance();
        res.setBalance(balance);
        res.setBonus(BigDecimal.ZERO);
        return res.toJSONObject();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public JSONObject credit(RequestDTO param) {
        log.info("evo 【credit】api call {}", JSON.toJSONString(param.getBody()));
        var ret = new CreditRequest(param.getBody());
        var res = new CreditResponse();
        res.setUuid(ret.getUuid());
        var userId = ret.getUserId();
        if(!checkUserId(ret.getUserId())){
            res.setStatus(EVOStatusType.INVALID_PARAMETER.name());
            return res.toJSONObject();
        }
        var check = validate(userId, ret.getSid());
        if (!check) {
            res.setStatus(EVOStatusType.INVALID_SID.name());
            log.error("evo 【credit】  check is false");
            return res.toJSONObject();
        }
        var changeBalance = new BalanceDTO();
        var transaction = ret.getTransaction();
        var game = ret.getGame();
        changeBalance.setTransactionId(transaction.getId());
        changeBalance.setSessionId(transaction.getRefId());
        changeBalance.setGameId(game.getId());
        changeBalance.setGameName(game.getType());
        changeBalance.setAmount(transaction.getAmount());
        changeBalance.setUserId(Long.valueOf(userId));
        // 从redis中获取存入的Order
        String orderKey = ORDER_KEY_REF + transaction.getRefId();
        RBucket<String> bucket = redissonClient.getBucket(orderKey);
        OrderVO order;
        OrderHistoryVO orderHistory;
        var orderData = (String)bucket.get();
        if (orderData == null) {
            // 根据orderKey没有找到对应的order, 从数据库中查找
            order = orderMapper.selectByUserIdAndRoundId(changeBalance.getUserId(), game.getId());
            if (order == null) {
                //多注合併後 還需去歷史紀錄找
                orderHistory = orderMapper.selectHistoryByUserIdAndSessionId(changeBalance.getUserId(), transaction.getId(),EnumWalletOperatorType.CasinoBetFreeze.getValue());
                if (orderHistory == null) {
                    log.info("evo 【credit】 order is null, cannot find order by userId={}, pid={}, roundId={}", userId, game.getId(), transaction.getRefId());
                    res.setStatus(EVOStatusType.BET_DOES_NOT_EXIST.name());
                    return res.toJSONObject();
                }else {
                    if(!orderHistory.getSessionId().equals(transaction.getRefId())){
                        res.setStatus(EVOStatusType.BET_DOES_NOT_EXIST.name());
                        return res.toJSONObject();
                    }
                    var user = userInfoService.getUser(changeBalance.getUserId());
                    if (user.isEmpty()) {
                        log.error("【newOrder】获取用户信息失败,userId={},betOrderNumber={}", param.getBody().get("userId"), changeBalance.getOrderNo());
                        res.setStatus(EVOStatusType.INVALID_SID.name());
                        return res.toJSONObject();
                    }
                    order= new OrderVO();
                    order.setThirdOrderNo(transaction.getId());
                    order.setOrderNo(orderHistory.getOrderNo());
                    order.setStatus(OrderVO.EnumOrderStatus.BET.getCode());
                    order.setAmount(orderHistory.getAmount());

                    order.setUserId(changeBalance.getUserId());
                    order.setUserName(user.get().getUserName());
                    order.setCurrency(user.get().getCurrency());
                    order.setRegion(user.get().getLocation());
                    order.setPid(changeBalance.getProviderId());

                    order.setMsgState(OrderVO.EnumMsgState.NONE.getCode());
                    order.setSessionId(changeBalance.getSessionId());
                    order.setRoundId(changeBalance.getGameId());
                    order.setGameName(changeBalance.getGameName());
                    order.setCreatedAt(new Date());
                    order.setBody(new JSONObject(param.getBody()).toJSONString());
                }
            }
        } else {
            log.info("evo 【credit】 redis orderData={}", orderData);
            order = JSON.parseObject(orderData, OrderVO.class);
            bucket.expire(expiration);
        }

        //確認狀態是否已經派彩過
        if(order.getStatus().equals(OrderVO.EnumOrderStatus.PAYOUT.getCode()) || order.getStatus().equals(OrderVO.EnumOrderStatus.CANCEL.getCode()) ){
            res.setStatus(EVOStatusType.BET_ALREADY_SETTLED.name());
            return res.toJSONObject();
        }

        //檢查注單refId是否對的上
        if(!order.getSessionId().equals(transaction.getRefId())){
            res.setStatus(EVOStatusType.BET_DOES_NOT_EXIST.name());
            return res.toJSONObject();
        }

        changeBalance.setOrderNo(order.getOrderNo());

        changeBalance.setOperatorType(EnumWalletOperatorType.CasinoPayout.getValue());
        changeBalance.setRemark(game.getDetails().toString());
        newHistory(changeBalance, param);
        var changeResponse = changeBalance(changeBalance);
        if (changeResponse.isEmpty()) {
            res.setStatus(EVOStatusType.INSUFFICIENT_FUNDS.name());
            log.error("evo 【credit】  changeResponse is empty");
            return res.toJSONObject();
        }

        if(changeResponse.get().getMgs()!=null){
            if(changeResponse.get().getMgs().equals(170) || changeResponse.get().getMgs().equals(100)){//重複訂單
                res.setStatus(EVOStatusType.BET_ALREADY_SETTLED.name());
                return res.toJSONObject();
            }
            res.setStatus(EVOStatusType.INSUFFICIENT_FUNDS.name());
            return res.toJSONObject();
        }

        // 更新credit状态
        order.setPayout(transaction.getAmount());
        // add by danny 2024-05-09
        if (transaction.getAmount().compareTo(BigDecimal.ZERO) > 0) {
            var rate = rollingRankingService.getRate(order.getCurrency());
            if (rate.isPresent()) {
                log.info("evo 【credit】 payout={}", order.getPayout());
                log.info("evo 【credit】 rate={}", rate.get());
                var usdPayout = order.getPayout().divide(rate.get(), 6, BigDecimal.ROUND_HALF_UP);
                log.info("evo 【credit】 usdPayout={}", usdPayout);
                order.setUsdPayout(usdPayout);
            }
        }

        order.setStatus(OrderVO.EnumOrderStatus.PAYOUT.getCode());
        order.setSettleAt(new Date());
        order.setPid(providerVO.getPid());
        order.setGameType(game.getType());
        if (orderMapper.updatePayout(order) == 0) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            log.error("evo 【credit】 updatePayout failed");
            res.setStatus(EVOStatusType.UNKNOWN_ERROR.name());
            return res.toJSONObject();
        }
        order.setBody(null);

        if (EVOGameType.getEnumByName(game.getType()) == null) {
            savePayoutRedis(order);
            saveAmountRedis(order);
        } else {
            RList<OrderVO> resultList = redissonClient.getList(CASINO_ORDER_RESULT_LIST);
            resultList.add(order);
            savePayoutRedis(order);
        }


        // 更新排行榜
        order.setBody(new JSONObject(param.getBody()).toJSONString());
        rollingRankingService.processBettingData(order);

        String orderJson = JSONObject.toJSONString(order);
        bucket.set(orderJson, expiration);

        var balance = changeResponse.get().getBalance();
        res.setBalance(balance);
        res.setBonus(BigDecimal.ZERO);
        return res.toJSONObject();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public JSONObject debit(RequestDTO param) {
        log.info("evo 【debit】debit api call {} ", JSON.toJSONString(param.getBody()));
        DebitRequest ret = new DebitRequest(param.getBody());
        DebitResponse res = new DebitResponse();
        res.setUuid(ret.getUuid());
        String userId = ret.getUserId();
        if(!checkUserId(ret.getUserId())){
            res.setStatus(EVOStatusType.INVALID_PARAMETER.name());
            return res.toJSONObject();
        }
        boolean check = validate(userId, ret.getSid());
        if (!check) {
            res.setStatus(EVOStatusType.INVALID_SID.name());
            log.error("evo 【debit】debit check is false");
            return res.toJSONObject();
        }

        BalanceDTO changeBalance = new BalanceDTO();
        Transaction transaction = ret.getTransaction();
        Game game = ret.getGame();

        Optional<GetBalanceResponse> balanceRes = getBalance(Long.parseLong(userId));

        if(transaction.getAmount().compareTo(balanceRes.get().getBalance())>0){
            res.setStatus(EVOStatusType.INSUFFICIENT_FUNDS.name());
            return res.toJSONObject();
        }

        // 單注多次下注 ex 21點  需從GameId 辨認
        String orderKey = ORDER_KEY_GAME_ID + game.getId();
        RBucket<String> bucket = redissonClient.getBucket(orderKey);
        OrderVO order;
        String orderData = bucket.get();
        if (orderData == null) {
            // 根据orderKey没有找到对应的order, 从数据库中查找
            log.info("evo 【debit】 redis order is null");
            order = orderMapper.selectByUserIdAndRoundId(Long.valueOf(userId), game.getId());

        } else {
            order = JSON.parseObject(orderData, OrderVO.class);
            bucket.expire(expiration);
        }

        changeBalance.setSessionId(transaction.getRefId());
        changeBalance.setProviderId(providerVO.getPid());
        changeBalance.setGameId(game.getId());
        GameDetails details = game.getDetails();
        if (details != null) {
            Log.debug("evo 【debit】details={}", details.toString());
            var table = details.getTable();
            if (table != null) {
                String tableId = table.getId();
                String gameName = getGameName(tableId);
                changeBalance.setGameName(gameName);
            }
        }
        changeBalance.setTransactionId(transaction.getId());
        BigDecimal amount = transaction.getAmount();
        // 把 amount转换成负数
        changeBalance.setAmount(amount);
        changeBalance.setUserId(Long.valueOf(userId));
        changeBalance.setOperatorType(EnumWalletOperatorType.CasinoBetFreeze.getValue());
        changeBalance.setRemark(game.getDetails().toString());

        BigDecimal balance;
        if (order != null) {
            if(order.getThirdOrderNo().equals(transaction.getId())){
                res.setStatus(EVOStatusType.BET_ALREADY_EXIST.name());
                return res.toJSONObject();
            }
            // 要把多同一個注單多次投注合併 更新order and redis 的資料
            changeBalance.setOrderNo(order.getOrderNo());
            order.setAmount(amount.add(order.getAmount()));

            //更新注單下注額
            OrderVO updateOrder=new OrderVO();
            updateOrder.setAmount(amount);
            updateOrder.setOrderNo(order.getOrderNo());

            if (orderMapper.updateBet(updateOrder) == 0) {
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                log.error("evo 【credit】 updateBet failed");
                res.setStatus(EVOStatusType.UNKNOWN_ERROR.name());
                return res.toJSONObject();
            }

            Optional<ChangeBalanceResponse> balanceResponse = changeBalance(changeBalance, param);
            if (balanceResponse.isEmpty()) {
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                log.error("evo 【debit】balanceResponse is null");
                res.setStatus(EVOStatusType.INSUFFICIENT_FUNDS.name());
                return res.toJSONObject();
            }

            if(balanceResponse.get().getMgs()!=null){
                if(balanceResponse.get().getMgs().equals(170) || balanceResponse.get().getMgs().equals(100)){//重複訂單
                    res.setStatus(EVOStatusType.BET_ALREADY_EXIST.name());
                    return res.toJSONObject();
                }
                res.setStatus(EVOStatusType.INSUFFICIENT_FUNDS.name());
                return res.toJSONObject();
            }

            try {
                balance=balanceResponse.get().getBalance();
            }catch (Exception e){
                log.error("evo 【debit】balanceResponse is fail {}",balanceResponse.get());
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                res.setStatus(EVOStatusType.UNKNOWN_ERROR.name());
                return res.toJSONObject();
            }
            //多注要存 不然會找不到資料
            order.setSessionId(transaction.getRefId());
            order.setThirdOrderNo(transaction.getId());
            String debitOrderKey = ORDER_KEY_REF + transaction.getRefId();
            RBucket<String> debitBucket = redissonClient.getBucket(debitOrderKey);
            debitBucket.set(JSONObject.toJSONString(order), expiration);
        }else {
            //EVO : This test case is simulate we couldn't received your debit response before the game round close, so we send cancel to you, but somehow the cancel arrive before the debit
            //you need to respond FINAL_ERROR_ACTION_FAILED and do not accept this debit
            RBucket<String> cancelBucket = redissonClient.getBucket(ORDER_KEY_CANCEL + game.getId());
            if(Objects.nonNull(cancelBucket.get())){
                res.setStatus(EVOStatusType.FINAL_ERROR_ACTION_FAILED.name());
                return res.toJSONObject();
            }
            //正常下注行為 新增注單
            changeBalance.setOrderNo(UidUtil.getOrderNo(ret.getUserId()));
            Optional<ChangeBalanceResponse> changeResponse = newOrder(changeBalance, param);
            if (changeResponse.isEmpty()) {
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                log.error("evo 【debit】changeResponse is null");
                res.setStatus(EVOStatusType.INSUFFICIENT_FUNDS.name());
                return res.toJSONObject();
            }
            balance=changeResponse.get().getBalance();
        }

        res.setBalance(balance);
        res.setBonus(BigDecimal.ZERO);
        return res.toJSONObject();
    }

    @Transactional(rollbackFor = Exception.class)
    public JSONObject cancel(RequestDTO param) {
        log.info("evo 【cancel】cancel api call {}", JSON.toJSONString(param.getBody()));
        var ret = new CancelRequest(param.getBody());
        var res = new CancelResponse();
        res.setUuid(ret.getUuid());
        var userId = ret.getUserId();
        if(!checkUserId(ret.getUserId())){
            res.setStatus(EVOStatusType.INVALID_PARAMETER.name());
            return res.toJSONObject();
        }
        var check = validate(userId, ret.getSid());
        if (!check) {
            res.setStatus(EVOStatusType.INVALID_SID.name());
            log.error("evo 【cancel】cancel check is false");
            return res.toJSONObject();
        }
        var changeBalance = new BalanceDTO();
        var transaction = ret.getTransaction();
        var game = ret.getGame();
        changeBalance.setUserId(Long.valueOf(userId));
        changeBalance.setTransactionId(transaction.getId());
        changeBalance.setSessionId(transaction.getRefId());
        changeBalance.setGameId(game.getId());
        changeBalance.setGameName(game.getType());
        // 从redis中获取存入的Order
        String orderKey = ORDER_KEY_REF + transaction.getRefId();
        RBucket<String> bucket = redissonClient.getBucket(orderKey);
        OrderVO order;
        OrderHistoryVO orderHistoryVO ;
        var orderData = (String)bucket.get();
        if (orderData == null) {
            // 根据orderKey没有找到对应的order, 从数据库中查找
            order = orderMapper.selectByUserIdAndSessionId(Long.valueOf(userId), transaction.getRefId());
            if (order == null) {// 都找不到還要再去 歷史紀錄裡找
                orderHistoryVO = orderMapper.selectHistoryByUserIdAndSessionId(Long.valueOf(userId), transaction.getRefId(),EnumWalletOperatorType.CasinoBetFreeze.getValue());
                if(orderHistoryVO==null){
                    log.error("evo 【cancel】order is null, cannot find order by userId={}, pid={}, roundId={}", userId, game.getId(), transaction.getRefId());
                    res.setStatus(EVOStatusType.BET_DOES_NOT_EXIST.name());
                    log.info("evo 【cancel】 特殊情境 : key {}",ORDER_KEY_CANCEL + game.getId());
                    RBucket<String> cancelBucket = redissonClient.getBucket(ORDER_KEY_CANCEL + game.getId());
                    cancelBucket.set(game.getId(),expiration);
                    return res.toJSONObject();
                }else {
                    order=new OrderVO();
                    order.setOrderNo(orderHistoryVO.getOrderNo());
                    order.setStatus(OrderVO.EnumOrderStatus.CANCEL.getCode());
                }
            }
        } else {
            order = JSON.parseObject(orderData, OrderVO.class);
            bucket.expire(expiration);
        }
        //確認狀態是否已經取消過
        if(order.getStatus().equals(OrderVO.EnumOrderStatus.CANCEL.getCode()) || order.getStatus().equals(OrderVO.EnumOrderStatus.PAYOUT.getCode())) {
            res.setStatus(EVOStatusType.BET_ALREADY_SETTLED.name());
            return res.toJSONObject();
        }

        changeBalance.setOrderNo(order.getOrderNo());
        // 金額從注單拿(多注的原因 不然取消會址取消一半) 拿不到再從req拿
//       OrderVO balanceOrder = orderMapper.selectByUserIdAndRoundId(Long.valueOf(userId), game.getId());
        BigDecimal amount = transaction.getAmount();

//        if(balanceOrder!=null){
//            amount=balanceOrder.getAmount();
//        }

        changeBalance.setAmount(amount);
        changeBalance.setOperatorType(EnumWalletOperatorType.CasinoBetRefund.getValue());
        changeBalance.setRemark(game.getDetails().toString());
        newHistory(changeBalance, param);
        var changeResponse = changeBalance(changeBalance);
        if (changeResponse.isEmpty()) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            log.error("evo 【cancel】cancel changeResponse is null");
            res.setStatus(EVOStatusType.INSUFFICIENT_FUNDS.name());
            return res.toJSONObject();
        }

        if(changeResponse.get().getMgs()!=null){
            if(changeResponse.get().getMgs().equals(170) || changeResponse.get().getMgs().equals(100)){//重複訂單
                res.setStatus(EVOStatusType.BET_ALREADY_SETTLED.name());
                return res.toJSONObject();
            }
            res.setStatus(EVOStatusType.INSUFFICIENT_FUNDS.name());
            return res.toJSONObject();
        }
        order.setAmount(amount);
        order.setThirdOrderNo(changeBalance.getTransactionId());
        order.setUserId(changeBalance.getUserId());
        order.setPid(providerVO.getPid());
        order.setSessionId(changeBalance.getSessionId());
        order.setRoundId(changeBalance.getGameId());
        order.setGameName(changeBalance.getGameName());
//        // 更新cancel状态
        order.setPayout(BigDecimal.ZERO);
        order.setStatus(OrderVO.EnumOrderStatus.CANCEL.getCode());
        order.setSettleAt(new Date());
        if (orderMapper.updatePayout(order) == 0) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            log.error("evo 【cancel】cancel updatePayout failed");
            res.setStatus(EVOStatusType.UNKNOWN_ERROR.name());
            return res.toJSONObject();
        }

        String orderJson = JSONObject.toJSONString(order);
        bucket.set(orderJson, expiration);

        BigDecimal balance = changeResponse.get().getBalance();
        res.setBalance(balance);
        res.setBonus(BigDecimal.ZERO);
        return res.toJSONObject();
    }

    @Transactional(rollbackFor = Exception.class)
    public JSONObject promo_payout(RequestDTO param) {
        log.info("evo promotion api call {}", JSON.toJSONString(param.getBody()));
        var ret = new PromotionRequest(param.getBody());
        var res = new PromotionResponse();
        res.setUuid(ret.getUuid());
        var userId = ret.getUserId();
        if(!checkUserId(ret.getUserId())){
            res.setStatus(EVOStatusType.INVALID_PARAMETER.name());
            return res.toJSONObject();
        }
        var check = validate(userId, ret.getSid());
        if (!check) {
            res.setStatus(EVOStatusType.INVALID_SID.name());
            log.error("evo promotion check is false");
            return res.toJSONObject();
        }


        var changeBalance = new BalanceDTO();
        var promoTransaction = ret.getPromoTransaction();
        var game = ret.getGame();

        OrderHistoryVO orderHistoryVO = orderMapper.selectHistoryByUserIdAndSessionId(Long.valueOf(userId), promoTransaction.getId(),EnumWalletOperatorType.CasinoPromotion.getValue());
        if(Objects.nonNull(orderHistoryVO)){
            res.setStatus(EVOStatusType.BET_ALREADY_SETTLED.name());
            return res.toJSONObject();
        }

        changeBalance.setOrderNo(UidUtil.getOrderNo(ret.getUserId()));
        changeBalance.setTransactionId(promoTransaction.getId());
        var amount = BigDecimal.valueOf(promoTransaction.getAmount());
        changeBalance.setAmount(amount);
        changeBalance.setUserId(Long.valueOf(userId));
        changeBalance.setProviderId(providerVO.getPid());
        changeBalance.setSessionId(promoTransaction.getId());
        changeBalance.setOperatorType(EnumWalletOperatorType.CasinoPromotion.getValue());
        if (game != null) {
            changeBalance.setSessionId(game.getId());
            changeBalance.setRemark(game.getDetails().toString());
        } else {
            changeBalance.setRemark(promoTransaction.toString());
        }
        var changeResponse = changeBalance(changeBalance);
        if (changeResponse.isEmpty()) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            res.setStatus(EVOStatusType.INSUFFICIENT_FUNDS.name());
            return res.toJSONObject();
        }

        if(changeResponse.get().getMgs()!=null){
            if(changeResponse.get().getMgs().equals(170) || changeResponse.get().getMgs().equals(100)){//重複訂單
                res.setStatus(EVOStatusType.BET_ALREADY_EXIST.name());
                return res.toJSONObject();
            }
            res.setStatus(EVOStatusType.INSUFFICIENT_FUNDS.name());
            return res.toJSONObject();
        }

        newHistory(changeBalance, param);
        BigDecimal balance = changeResponse.get().getBalance();
        res.setBalance(balance);
        res.setBonus(BigDecimal.ZERO);
        return res.toJSONObject();
    }

    public Result<?> getGameList() {
        List<GameOriginalVO> allGames = gameOriginalMapper.selectAll();
        List<String> idList = allGames.stream()
                .map(GameOriginalVO::getTableId)
                .toList();
        List<String> nameList = allGames.stream()
                .map(GameOriginalVO::getTableName)
                .toList();
        // 定時任務 因線程不同關係 須重拿
        Long pid=providerManager.getProviderByName("evo").getPid();
        com.alibaba.fastjson.JSONObject games = gameService.getGamesFiltered(JSONObject.toJSONString(config));

        Set<Map.Entry<String, Object>> entrySet = games.entrySet();
        GameOriginalVO game = new GameOriginalVO();
        // 遍历entrySet并获取所有tableId的键和值
        for (Map.Entry<String, Object> entry : entrySet) {
            String tableName = entry.getKey(); // 获取tableId
            com.alibaba.fastjson.JSONObject gameData = (com.alibaba.fastjson.JSONObject) entry.getValue();
            //檢查是否有重名
            if(idList.contains(gameData.getString("tableId")) || nameList.contains(gameData.getString("tableName"))){
                continue;
            }
            game.setPid(pid);
            game.setTableName(tableName);
            game.setGameName(gameData.getString("name"));
            game.setGameProvider(gameData.getString("gameProvider"));
            game.setGameType(gameData.getString("gameType"));

            game.setGameSubtype(gameData.getString("gameSubType"));
            game.setVirtualTableId(gameData.getString("virtualTableId"));
            game.setLuckyNumbers(gameData.getString("luckyNumbers"));
            game.setSitesAssigned(gameData.getString("sitesAssigned"));
            game.setPlayers(Integer.valueOf(gameData.getString("players")));

            game.setDisplay(gameData.getString("display"));
            game.setLang(gameData.getString("language"));
            game.setHistory(gameData.getString("history"));
            game.setDescriptions(gameData.getString("descriptions"));
            game.setVideoSnapshot(gameData.getString("videoSnapshot"));

            game.setBetLimits(gameData.getString("betLimits"));
            game.setDealer(gameData.getString("dealer"));
            JSONObject js=JSONObject.parseObject(game.getVideoSnapshot());
            js=JSONObject.parseObject(js.getString("thumbnails"));
            if (js != null) {
                game.setTableIcon(js.getString("M"));
            }else {
                game.setTableIcon("");
            }

            String operationHours = gameData.getString("operationHours");
            //如果operationHours{"type":"FullTime"}，则设置operationStartTime和operationEndTime为null
            if (operationHours.equals("{\"type\":\"FullTime\"}")) {
                game.setOperationStart(new Date());
                game.setOperationEnd(new Date());
                game.setOperationHours("0-24");
            }else {
                game.setOperationHours(gameData.getString("operationHours"));
            }

            game.setOpen(gameData.getInteger("open"));
            game.setTableId(gameData.getString("tableId"));

            gameService.addGamesFromEvo(game);
        }

        return Result.success();
    }

    @Override
    public void history(String orderStr) {

    }

    //    @Async("evoTask") TODO 調整成限流 會請求失敗
    public void history(String orderStr,Integer status) {
        try {
            OrderVO order=JSON.parseObject(orderStr, OrderVO.class);
            String key = config.getMerchantId();
            String secret = config.getGameHistoryApiToken();
            String url= config.getBaseUrl()+"/api/gamehistory/v1/players/"+order.getUserId()+"/games/"+order.getRoundId();
            log.info("evo getGameHistory 请求的url：{}", url);
            HttpResponse response = HttpUtil.createGet(url)
                    .basicAuth(key,secret)
                    .execute();
            log.info("evo getGameHistory 请求的结果：{}", response.body());
            int httpStatus = response.getStatus();
            if (httpStatus != 200) {
                log.info("evo getGameHistory 请求失败！httpStatus={},body={}", httpStatus, response.body());
                throw new BusinessException("Failed to get evo GameHistory , HTTP status: " + httpStatus);
            }
            BaseResult baseResult = JSON.parseObject(response.body(), BaseResult.class);
            EVOGameType gameType = EVOGameType.getEnumByName(baseResult.getData().getGameType()); // 假設你有一個遊戲類型
            List<CalResult> results = new ArrayList<CalResult>();

            switch (gameType) {
                case DT:
                case LT_DT:
                case BAC_BO:
                case FOOTBALL_STUDIO:
                case KDBS:
                case FOOTBALL_STUDIO_DICE:
                    DTResult dtResult = JSONObject.parseObject(response.body(), DTResult.class);
                    dtResultCalculate(dtResult, results, order);
                    break;
                case CASIO_HOLDEM:
                case ULTIMATE_TEXAS_HOLDEM:
                case EXTREME_TEXAS_HOLDEM:
                case THREE_CARD_POKER:
                case TRIPLE_CARD_POKER:
                case CARIBBEAN_STUD_POKER:
                case TEXAS_HOLDEM_BONUS_POKER:
                case SECOND_HAND_CASINO_HOLDEM:
                    DTResult pokerResult = JSONObject.parseObject(response.body(), DTResult.class);
                    pokerResultCalculate(pokerResult, results, order);
                    break;
                case POWER_BJ:
                case SCALA_BJ:
                case FREE_BET_BJ:
                case LIGHTNING_BJ:
                case FUN_FUN_BJ:
                case CLASSIC_BJ:
                    BJNoSeatResult bjNoSeatResult = JSONObject.parseObject(response.body(), BJNoSeatResult.class);
                    noSeatBJResultCalculate(bjNoSeatResult, results, order);
                    break;
                case BACCARAT:
                    BaccaratResult baccaratResult = JSONObject.parseObject(response.body(), BaccaratResult.class);
                    baccaratResultCalculate(baccaratResult, results, order);
                    break;
                case RNG_BACCARAT:
                    RNGBaccaratResult rngBaccaratResult = JSONObject.parseObject(response.body(), RNGBaccaratResult.class);
                    results.addAll(rngBaccaratResultCalculate(rngBaccaratResult));
                    break;
                case RNG_BLACKJACK:
                case BLACKJACK:
                    BJResult bjResult = JSONObject.parseObject(response.body(), BJResult.class);
                    bjResultCalculate(bjResult, results);
                    break;
                default:
                    throw new BusinessException("Failed to get evo GameHistory , HTTP status: " + httpStatus);
            }
            if(!results.isEmpty()){
                order.setGameResult(JSONArray.toJSONString(results));
            }
            log.info("evo getGameHistory gameId : {}  result : {}",order.getRoundId(),order.getGameResult());
            if(status.equals(1)){//正常流程1
                saveAmountRedis(order);
            }else if(status.equals(2)){//修復Amount遺漏數據2
                fixAmountRedis(order);
            }//單純修復order數據傳3
            orderMapper.updateBetResult(order);
        }catch (Exception e){
            e.printStackTrace();
        }
    }


    public static void pokerResultCalculate(DTResult dtResult, List<CalResult> results, OrderVO order) {
        for (DTResult.Participant participant : dtResult.getData().getParticipants()) {
            if (participant.getPlayerId().equals(order.getUserId().toString())) {
                for (DTResult.Bet bet : participant.getBets()) {
                    String result;
                    if (hasFee(bet.getCode())) {
                        result = "fee";
                    } else {
                        if(hasBonus(bet.getCode())){
                            result = bet.getPayout().compareTo(BigDecimal.ZERO) > 0 ? "Win" : "Lose";
                        }else {
                            result = dtResult.getData().getResult().getOutcome();
                            result=result.equals("Player")?"Win":result.equals("Dealer")?"Lose":"Tie";
                        }
                    }
                    if(!result.equals("None")){
                        results.add(CalResult.builder()
                                .result(result)
                                .bet(bet.getStake())
                                .payout(bet.getPayout())
                                .code(bet.getCode())
                                .build());
                    }
                }
            }
        }
    }

    public static void dtResultCalculate(DTResult dtResult, List<CalResult> results, OrderVO order) {
        for (DTResult.Participant participant : dtResult.getData().getParticipants()) {
            if (participant.getPlayerId().equals(order.getUserId().toString())) {
                for (DTResult.Bet bet : participant.getBets()) {
                    String result;
                    if (hasFee(bet.getCode())) {
                        result = "fee";
                    } else {
                        result = dtResult.getData().getResult().getOutcome();
                    }
                    //百家寶 格是一樣 但是返回數據不一樣 做特殊處裡
                    if(dtResult.getData().getGameType().equals(EVOGameType.FOOTBALL_STUDIO.getName()) || dtResult.getData().getGameType().equals(EVOGameType.KDBS.getName())
                    || dtResult.getData().getGameType().equals(EVOGameType.FOOTBALL_STUDIO_DICE.getName())){
                        result=footBall(result);
                    }else {
                        result=bacBo(result);
                    }
                    if(bet.getCode().toLowerCase().contains("tie") && result.toLowerCase().contains("tie")){
                        result="Win";
                    }
                    if (bet.getPayout().compareTo(bet.getStake()) > 0) {
                        result = "Win";
                    } else if (bet.getPayout().compareTo(BigDecimal.ZERO) == 0) {
                        result = "Lose";
                    }

                    if (!result.equals("None")){
                        results.add(CalResult.builder()
                                .result(result)
                                .bet(bet.getStake())
                                .payout(bet.getPayout())
                                .code(bet.getCode())
                                .build());
                    }
                }
            }
        }
    }
    public static String footBall(String result) {
        return result.replace("X", "Tie");
    }
    public static String bacBo(String result) {
        return result.replace("Won", "Win");
    }

    public static void noSeatBJResultCalculate(BJNoSeatResult bjNoSeatResult, List<CalResult> results, OrderVO order) {
        for (BJNoSeatResult.Participant participant : bjNoSeatResult.getData().getParticipants()) {
            if (participant.getPlayerId().equals(order.getUserId().toString())) {
                for (BJNoSeatResult.Bet bet : participant.getBets()) {
                    String result = "";
                    if (bet.getCode().contains("Main")) {
                        result = participant.getHands().getHand1().getOutcome();
                    } else {
                        result = bet.getPayout().compareTo(BigDecimal.ZERO) > 0 ? "Win" : "Lose";
                    }
                    if(!result.equals("None")) {
                        results.add(CalResult.builder()
                                .result(result)
                                .bet(bet.getStake())
                                .payout(bet.getPayout())
                                .code(bet.getCode())
                                .build());
                    }
                }
            }
        }
    }

    public static void baccaratResultCalculate(BaccaratResult baccaratResult, List<CalResult> results, OrderVO order) {
        for (BaccaratResult.Participant participant : baccaratResult.getData().getParticipants()) {
            if (participant.getPlayerId().equals(order.getUserId().toString())) {
                for (BaccaratResult.Bet bet : participant.getBets()) {
                    String result;
                    if (hasFee(bet.getCode())) {
                        result = "fee";
                    } else {
                        if (bet.getCode().contains("Pair") || bet.getCode().contains("Bonus")) {
                            result = bet.getPayout().compareTo(BigDecimal.ZERO) > 0 ? "Win" : "Lose";
                        } else {
                            result = baccaratResult.getData().getResult().getOutcome();
                            if(bet.getCode().toLowerCase().contains("tie") && result.toLowerCase().contains("Tie")){
                                result="Win";
                            }
                            if (bet.getPayout().compareTo(bet.getStake()) > 0) {
                                result = "Win";
                            } else if (bet.getPayout().compareTo(BigDecimal.ZERO) == 0) {
                                result = "Lose";
                            }
                        }
                    }
                    if(!result.equals("None")){
                        results.add(CalResult.builder()
                            .result(result)
                            .bet(bet.getStake())
                            .payout(bet.getPayout())
                            .code(bet.getCode())
                            .build());
                        }
                }
            }
        }
    }

    public static void bjResultCalculate(BJResult bjResult, List<CalResult> results) {
        BJResult.Game data = bjResult.getData();
        for (BJResult.Participant participant : data.getParticipants()) {
            for (BJResult.Bet bet : participant.getBets()) {
                    String code = bet.getCode();
                    int start = code.indexOf("PlaySeat");
                    String resultCode;
                    if (start != -1) {
                        resultCode = code.substring(start + 4, start + 9);
                    } else {
                        int splitSeat = code.indexOf("SplitSeat");
                        if (splitSeat != -1) {
                            resultCode = code.substring(splitSeat + 5, splitSeat + 10);
                        } else {
                            resultCode = code;
                        }
                    }
                    results.add(CalResult.builder()
                            .payout(bet.getPayout())
                            .bet(bet.getStake())
                            .result(resultCode)
                            .code(resultCode)
                            .build());
            }
        }

        for (CalResult result : results) {
            //PerfectPair 213Seat  從payout 算結果
            String code = result.getResult();
            BJResult.Seat seat = getSeatByCode(data.getResult().getSeats(), code);
            if (seat != null) {
                result.setResult(seat.getOutcome());
            } else {
                BJResult.Seat seatSplit = getSeatByCode(data.getResult().getSeats(), code + "Split");//為了分排
                if (seatSplit != null) {
                    result.setResult(seatSplit.getOutcome());
                } else {
                    result.setResult(result.getPayout().compareTo(BigDecimal.ZERO) > 0 ? "Win" : "Lose");
                }
            }
            if(result.getResult().equals("None")){
                results.clear();
                break;
            }
        }
    }

    public static List<CalResult> rngBaccaratResultCalculate(RNGBaccaratResult rngBaccaratResult) {
        List<CalResult> results = new ArrayList<>();
        for (RNGBaccaratResult.Participant participant : rngBaccaratResult.getData().getParticipants()) {
            for (RNGBaccaratResult.Bet bet : participant.getBets()) {
                String result;
                if (hasFee(bet.getCode())) {
                    result = "fee";
                } else {
                    result = rngBaccaratResult.getData().getResult().getOutcome();
                }
                if(!result.equals("None")) {
                    results.add(CalResult.builder()
                            .result(result)
                            .bet(bet.getStake())
                            .payout(bet.getPayout())
                            .build());
                }
            }

        }

        return results;
    }

    private static boolean hasFee(String code) {
        return code != null && (code.contains("Fee") || code.contains("Lightning"));
    }
    private static boolean hasBonus(String code) {
        return code != null && (code.contains("Bonus"));
    }
    // 根据座位代码从 Seats 对象中获取对应的座位对象
    public static BJResult.Seat getSeatByCode(BJResult.Seats seats, String seatCode) {
        try {
            // 构建 getSeatX 方法名，其中 X 是座位编号
            String methodName = "get" + seatCode;
            // 使用反射获取方法对象
            Method method = seats.getClass().getMethod(methodName);
            // 调用方法并返回结果
            return (BJResult.Seat) method.invoke(seats);
        } catch (NoSuchMethodException e) {
            log.info("seatCode : {} getSeatByCode null",seatCode);
            return null;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw new BusinessException("Failed to get evo GameHistory "+e.getMessage());
        }
    }

    public Result<?> getLaunchURI(Map<String, Object> body) {
        // 游戏ID, 桌子ID, 用户ID, 语言, 用户ID
        var userId = (String)body.get("uid");
        var language = (String)body.get("language");
        var gameInfo = (GameInfoDTO)body.get("gameInfo");
        var playMode = (String)body.get("playMode");
        var clientIp = (String)body.get("clientIp");
        var backUrl = (String)body.get("backUrl");
        if (backUrl == null || backUrl.isEmpty()) {
            backUrl = providerVO.getBackUrl();
        }
        var timeoutUrl = (String)body.get("timeoutUrl");
        if (timeoutUrl == null || timeoutUrl.isEmpty()) {
            timeoutUrl = backUrl;
        }
        var request = new AuthenticationRequest();
        var player = request.getPlayer();
        Long uid = Long.valueOf(userId);
        var user = userInfoService.getUser(uid);
        if (user.isEmpty()) {
            return Result.fail(1201, "user is null");
        }
        player.setId(userId);
        var currency = Objects.equals(user.get().getCurrency(), "USDT") ? "USD" :  user.get().getCurrency();
        player.setCurrency(currency);
        player.setNickname(user.get().getNickName());
        player.setUpdate(false);
        player.setLanguage(language);
        var sid = IdUtil.randomUUID();
        // 设置Redis的session
        var sessionKey = CASINO_SESSION_KEY + userId;
        RMap<String, String> map = redissonClient.getMap(sessionKey);
        String jsonValue = map.get("sessionids");
        var objectMapper = new ObjectMapper();
        try {
            jsonValue = jsonValue == null ? "{}" : jsonValue;
            Map<String, Object> nestedMap = objectMapper.readValue(jsonValue, Map.class);
            nestedMap.put(sid, new Date());
            map.put("sessionids", objectMapper.writeValueAsString(nestedMap));
            log.info("evo getGameURI call, add new sid={}", sid);
        } catch (Exception e) {
            log.error("evo getGameURI call error: {}", e.getMessage());
        }

        player.getSession().setId(sid);
        player.getSession().setIp(clientIp);
        var reqConfig = request.getConfig();
        var urls = reqConfig.getUrls();
        urls.setCashier(backUrl+"/wallet/deposit");
        if (gameInfo != null && gameInfo.getMainEntrance() != null) {
            var mainEntry = gameInfo.getMainEntrance();
            var mainMap = Map.of(
                    "lobby", EntryVO.EnumMainEntry.LOBBY,
                    "game_lobby", EntryVO.EnumMainEntry.GAME_LOBBY,
                    "game", EntryVO.EnumMainEntry.GAME,
                    "origin", EntryVO.EnumMainEntry.ORIGIN
            );
            var mainEntryEnum = mainMap.getOrDefault(mainEntry, EntryVO.EnumMainEntry.LOBBY);
            var gameConfig = reqConfig.getGame();
            switch (mainEntryEnum) {
                case LOBBY:
                    reqConfig.setGame(null);
                    break;
                case GAME_LOBBY:
                        gameConfig.setCategory(gameInfo.getGameType());
                    log.info("evo getGameURI call, category={}", gameConfig.getCategory());
                    break;
                case GAME:
                case ORIGIN:
                    var tableId = gameInfo.getTableId();
                    if (tableId != null) {
                        var table = gameConfig.getTable();
                        if (table == null) {
                            table = new Table();
                            gameConfig.setTable(table);
                        }
                        table.setId(tableId);
                    }
                    // 获取游戏原始表的信息
                    break;
            }
            gameConfig.setInterfaceType(AuthenticationRequest.EnumGameInterface.VIEW1.getValue());
            reqConfig.getChannel().setWrapped(true);
            reqConfig.getChannel().setMobile(true);
            urls.setLobby(backUrl);
            urls.setSessionTimeout(timeoutUrl);
        } else {
            reqConfig.setGame(null);
        }

        // 设置游戏模式
        if (playMode != null) {
            var gameConfig = reqConfig.getGame();
            if (gameConfig == null) {
                gameConfig = new AuthenticationRequest.Game();
                reqConfig.setGame(gameConfig);
            }
            var modeMap = Map.of(
                    "fun", AuthenticationRequest.EnumGamePlayMode.PLAY_FOR_FUN,
                    "reward", AuthenticationRequest.EnumGamePlayMode.REWORD_GAMES,
                    "demo", AuthenticationRequest.EnumGamePlayMode.DEMO,
                    "real", AuthenticationRequest.EnumGamePlayMode.REAL_MONEY
            );

            // 获取对应的枚举值，如果playMode不在map中，则默认为REAL_MONEY
            var playModeEnum = modeMap.getOrDefault(playMode, AuthenticationRequest.EnumGamePlayMode.REAL_MONEY);
            gameConfig.setPlayMode(playModeEnum.getValue());
        }

        try {
            var key = config.getMerchantId(); //"tm2up00000000001";
            var secret = config.getUa2Token(); //"test123";
            var baseUrl = config.getBaseUrl(); //"https://tm2up.uat1.evo-test.com";
            var evoGameUrl = String.format("%s/ua/v1/%s/%s", baseUrl, key, secret);
            log.info("evo 请求的url：{}", evoGameUrl);
            var mapBody = request.toMap();
            JSONObject json = JSONObject.from(mapBody);
            log.info("evo 请求的参数：{}", json.toJSONString());
            HttpResponse response = HttpUtil.createPost(evoGameUrl)
                    .body(json.toJSONString())
                    .execute();
            log.info("evo 请求的结果：{}", response.body());
            int httpStatus = response.getStatus();
            if (httpStatus != 200) {
                log.error("evo 请求失败！httpStatus={},body={}", httpStatus, response.body());
                throw new BusinessException("Failed to get evo game URL, HTTP status: " + httpStatus);
            }

            var entryBody = JSONObject.parseObject(response.body());
            var entry = entryBody.getString("entry");
            var entryEmbedded = entryBody.getString("entryEmbedded");
            var resData = new AuthenticationResponse(baseUrl, entry);
            return Result.success(resData);
        } catch (Exception e) {
            throw new BusinessException(ResultCode.GAME_CLOSE.getCode(), e.getMessage());
        }
    }

    public JSONObject sid(RequestDTO param) {
        var ret = new SidRequest(param.getBody());
        var res = new SidResponse();
        res.setUuid(ret.getUuid());
        if(!checkUserId(ret.getUserId())){
            res.setStatus(EVOStatusType.INVALID_PARAMETER.name());
            return res.toJSONObject();
        }
        var check = validate(ret.getUserId(), ret.getSid());
        if (check) {
            log.error("evo sid api check is OK, sid={}", ret.getSid());
            return res.toJSONObject();
        }
        var sid = IdUtil.randomUUID();
        // 设置Redis的session
        var sessionKey = CASINO_SESSION_KEY + ret.getUserId();

        RMap<String, String> map = redissonClient.getMap(sessionKey);
        String jsonValue = map.get("sessionids");
        var objectMapper = new ObjectMapper();
        try {
            jsonValue = jsonValue == null ? "{}" : jsonValue;
            Map<String, Object> nestedMap = objectMapper.readValue(jsonValue, Map.class);
            nestedMap.put(sid, new Date());
            map.put("sessionids", objectMapper.writeValueAsString(nestedMap));
            log.info("evo sid call, add new sid={}", sid);
        } catch (Exception e) {
            log.error("evo sid error: {}", e.getMessage());
            res.setStatus(EVOStatusType.UNKNOWN_ERROR.name());
            return res.toJSONObject();
        }
        res.setSid(sid);
        return res.toJSONObject();
    }


    public void fixAmountRedis(OrderVO order) {
        RList<String> amountList = redissonClient.getList(CommonConstant.CASINO_ORDER_AMOUNT_LIST_FOR_FIX);
        amountList.add(JSONObject.toJSONString(order));
        log.info("放入 amountList 成功 : {}",amountList.get(amountList.size()-1));
    }
}
