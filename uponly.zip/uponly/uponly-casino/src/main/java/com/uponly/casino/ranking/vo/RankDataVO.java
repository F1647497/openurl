package com.uponly.casino.ranking.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class RankDataVO implements java.io.Serializable {
    @Schema(description = "user id")
    Long userId;

    @Schema(description = "user name")
    String userName;

    @Schema(description = "eid")
    Long eid;

    @Schema(description = "betting amount")
    BigDecimal bet;

    @Schema(description = "win amount")
    BigDecimal payout;

    @Schema(description = "icon")
    String icon;

    @Schema(description = "multiplier")
    BigDecimal multiplier;

    @Schema(description = "currency")
    String currency;

    @Schema(description = "game name")
    String gameName;

    @Schema(description = "full game name")
    String fullGameName;

    @Schema(description = "timestamp")
    Long timestamp;

    @Schema(description = "vip")
    Integer vip;

    @Schema(description = "star")
    Integer star;

    @Schema(description = "pid")
    Long pid;

    @Schema(description = "provider name")
    String providerName;

    @Schema(description = "usd payout")
    BigDecimal usdPayout;

    public RankDataVO(RankDataVO rankDataVO) {
        this.userId = rankDataVO.userId;
        this.userName = rankDataVO.userName;
        this.eid = rankDataVO.eid;
        this.bet = rankDataVO.bet;
        this.payout = rankDataVO.payout;
        this.icon = rankDataVO.icon;
        this.multiplier = rankDataVO.multiplier;
        this.currency = rankDataVO.currency;
        this.gameName = rankDataVO.gameName;
        this.setVip(rankDataVO.getVip());
        this.setStar(rankDataVO.getStar());
        this.timestamp = rankDataVO.timestamp;
        this.pid = rankDataVO.pid;
        this.providerName = rankDataVO.providerName;
        this.usdPayout = rankDataVO.usdPayout;
        this.fullGameName = rankDataVO.fullGameName;
    }

    public RankDataVO() {
    }
}
