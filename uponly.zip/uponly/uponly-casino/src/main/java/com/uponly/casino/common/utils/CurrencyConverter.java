package com.uponly.casino.common.utils;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;

@Slf4j
public class CurrencyConverter {


    /**
     * @param fromCurrency 区域
     * @param toCurrency   转换区域
     * @param rateMap      汇率缓存
     * @return 转换值
     */
    public static Function<BigDecimal, BigDecimal> identity(String fromCurrency, String toCurrency, Map<String, BigDecimal> rateMap) {
        return from -> {
            BigDecimal bigDecimal = convert(from, fromCurrency, toCurrency, rateMap);
            if (Objects.nonNull(bigDecimal))
                return bigDecimal.setScale(2, RoundingMode.HALF_UP);
            return null;
        };
    }

    /**
     * 货币转换 TODO 待优化
     *
     * @param amount       转换金额
     * @param fromCurrency 起始货币
     * @param toCurrency   目标货币
     * @param rateMap      汇率Map
     * @return 转换后的金额
     */
    public static BigDecimal convert(BigDecimal amount, String fromCurrency, String toCurrency, Map<String, BigDecimal> rateMap) {
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            return BigDecimal.ZERO;
        }

        if (StringUtils.isBlank(fromCurrency) || StringUtils.isBlank(toCurrency)) {
            log.error("fromCurrency={} or toCurrency={} is blank", fromCurrency, toCurrency);
            return amount;
        }

        if (fromCurrency.equals(toCurrency)) {
            return amount;
        }

        // 获取起始货币对应的汇率
        BigDecimal fromRate = rateMap.get(fromCurrency);
        // 获取目标货币对应的汇率
        BigDecimal toRate = rateMap.get(toCurrency);

        if (fromRate == null || toRate == null) {
            log.error("fromCurrency={} or toCurrency={} not found in reteMap={}", fromCurrency, toCurrency, rateMap);
            return BigDecimal.ZERO;
        }

        // 计算转换后的金额：先转为通用的USDT，再转为目标货币
        BigDecimal inUSDT = amount.divide(fromRate, 10, RoundingMode.HALF_UP);
        BigDecimal convertedAmount = inUSDT.multiply(toRate).setScale(6, RoundingMode.HALF_UP);
        log.debug("amount={},fromCurrency={},toCurrency={},convertedAmount={}", amount, fromCurrency, toCurrency, convertedAmount);
        return convertedAmount;
    }


}
