package com.uponly.casino.provider.vo.evo;

import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;
@Builder
@Data
public class CalResult {
    private String result;//Push Win Lost Tie
    private BigDecimal payout;
    private BigDecimal bet;
    private String code;

}