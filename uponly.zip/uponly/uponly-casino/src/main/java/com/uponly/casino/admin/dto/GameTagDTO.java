package com.uponly.casino.admin.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class GameTagDTO implements java.io.Serializable {
    @Schema(description = "id", hidden = true)
    private Long id;

    public GameTagDTO() {}
    public GameTagDTO(int gameId, int type, String tag) {
        this.gameId = gameId;
        this.type = type;
        this.tag = tag;
    }
    @Schema(description = "游戏ID", requiredMode = Schema.RequiredMode.REQUIRED)
    private int gameId;

    @Schema(description = "类型", defaultValue = "0")
    private int type;

    @Schema(description = "标签")
    private String tag;
}
