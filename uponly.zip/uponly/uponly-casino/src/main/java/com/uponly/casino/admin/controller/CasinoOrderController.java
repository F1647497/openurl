package com.uponly.casino.admin.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.github.pagehelper.PageInfo;
import com.uponly.casino.admin.dto.SearchOrderDTO;
import com.uponly.casino.admin.service.OrderService;
import com.uponly.casino.admin.vo.OrderVOBe;
import com.uponly.casino.admin.vo.TotalAmountVO;
import com.uponly.casino.common.api.Result;
import com.uponly.casino.mapper.OrderItemMapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/casinoOrder")
@Tag(name = "CasinoOrderController", description = "真人注单管理")
public class CasinoOrderController {

    @Autowired
    private OrderService orderService;

    @Autowired
    private OrderItemMapper orderItemMapper;

    @ResponseBody
    @Operation(summary = "后台查询注单")
    @PostMapping("/search")
    public Result<PageInfo<OrderVOBe>> search(@RequestBody SearchOrderDTO searchOrderDTO) throws JsonProcessingException {
        try {
            PageInfo<OrderVOBe> pageInfo = orderService.searchOrder(searchOrderDTO);
            return Result.success(pageInfo);
        } catch (JsonProcessingException e) {
            log.error("后台查询注单 异常{} ", e.getMessage());
        }
        return null;
    }

    @ResponseBody
    @Operation(summary = "后台查询总额")
    @PostMapping("/searchTotal")
    public Result<List<TotalAmountVO>> searchTotal(@RequestBody SearchOrderDTO searchOrderDTO) throws JsonProcessingException {
        try {
            List<TotalAmountVO> list = orderService.searchTotal(searchOrderDTO);
            return Result.success(list);
        } catch (JsonProcessingException e) {
            log.error("后台查询总额 异常{} ", e.getMessage());
        }
        return null;
    }

//    @ResponseBody
//    @Operation(summary = "后台查询注单")
//    @PostMapping("/test")
//    public Result<Integer> test() throws JsonProcessingException {
//        List<OrderItemVO> orderItemList = new ArrayList<OrderItemVO>();
//        OrderItemVO orderItemVO = new OrderItemVO();
//        orderItemVO.setCasinoOrderId(123);
//        orderItemVO.setTransactionId("tx123-1");
//        orderItemVO.setOrderNo("tx123-1");
//        orderItemVO.setRoundId("round-1234");
//        orderItemVO.setUserId(412323L);
//        orderItemVO.setAmount(BigDecimal.valueOf(23.00));
//        orderItemVO.setEffectiveAmount(BigDecimal.valueOf(25.00));
//        orderItemVO.setPayout(BigDecimal.valueOf(24.00));
//        orderItemVO.setBetType("10");
//        orderItemVO.setItemPayload("{}");
//        orderItemVO.setResult(5);
//        orderItemVO.setMultiplier(BigDecimal.valueOf(2.00));
//        orderItemList.add(orderItemVO);
//        OrderItemVO orderItemVO2 = new OrderItemVO();
//        orderItemVO2.setCasinoOrderId(123);
//        orderItemVO2.setTransactionId("tx123-2");
//        orderItemVO2.setOrderNo("tx123-2");
//        orderItemVO2.setRoundId("round-1234");
//        orderItemVO2.setUserId(412323L);
//        orderItemVO2.setAmount(BigDecimal.valueOf(23.00));
//        orderItemVO2.setEffectiveAmount(BigDecimal.valueOf(25.00));
//        orderItemVO2.setPayout(BigDecimal.valueOf(24.00));
//        orderItemVO2.setBetType("10");
//        orderItemVO2.setItemPayload("{}");
//        orderItemVO2.setResult(5);
//        orderItemVO2.setMultiplier(BigDecimal.valueOf(2.00));
//        orderItemList.add(orderItemVO2);
//        Integer size = orderItemMapper.addBatch(orderItemList);
//
//
//        return Result.success(size);
//    }
}

