package com.uponly.casino.provider.dto.evo.req;

import lombok.Data;

import java.util.Map;

@Data
public class Game {
    private String id;          // Unique game round id
    private String type;       // Game type, e.g., "blackjack", "roulette"
    private GameDetails details; // Additional game round details

    public Game(String id, String type, GameDetails details) {
        this.id = id;
        this.type = type;
        this.details = details;
    }

    public Game(Map<String, Object> map) {
        this.id = (String) map.get("id");
        this.type = (String) map.get("type");
        this.details = new GameDetails((Map<String, Object>) map.get("details"));
    }
}
