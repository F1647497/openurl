package com.uponly.casino.mapper;


import com.uponly.casino.admin.dto.RecommendDTO;
import com.uponly.casino.admin.dto.SearchRecommendDTO;
import com.uponly.casino.admin.vo.RecommendGameVO;

import java.util.List;

public interface RecommendMapper {



    int addRecommendGame(RecommendDTO recommendGame);
    List<RecommendGameVO> searchRecommendGame(SearchRecommendDTO searchRecommendDTO);


    Integer maxSort();

    int update(RecommendDTO recommendDTO);

    int deleteRecommend(RecommendDTO recommendDTO);
}
