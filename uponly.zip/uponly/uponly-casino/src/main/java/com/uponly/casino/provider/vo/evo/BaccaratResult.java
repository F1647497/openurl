package com.uponly.casino.provider.vo.evo;

import lombok.Data;
import lombok.Getter;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Data
public class BaccaratResult {
    private String uuid;
    private Date timestamp;
    private GameData data;

    // getters and setters


    @Data
    public class GameData {
        private String id;
        private String gameProvider;
        private Date startedAt;
        private Date settledAt;
        private String status;
        private String gameType;
        private String gameSubType;
        private Table table;
        private Dealer dealer;
        private String currency;
        private List<Participant> participants;
        private BaccaratResultDetails result;
        private BigDecimal wager;
        private BigDecimal payout;

        // getters and setters
    }

    @Data
    public class Table {
        private String id;
        private String name;

        // getters and setters
    }

    @Data
    public class Dealer {
        private String uid;
        private String name;

        // getters and setters
    }

    @Data
    public class Participant {
        private String casinoId;
        private String playerId;
        private String screenName;
        private String playerGameId;
        private String sessionId;
        private String casinoSessionId;
        private String currency;
        private List<Bet> bets;
        private List<Object> configOverlays;
        private String subType;
        private String playMode;
        private String channel;
        private String os;
        private String device;
        private String currencyRateVersion;

        // getters and setters
    }

    @Data
    public class Bet {
        private String code;
        private BigDecimal stake;
        private BigDecimal payout;
        private Date placedOn;
        private String transactionId;
        private String description;

        // getters and setters
    }

    @Data
    public class BaccaratResultDetails {
        private Object redEnvelopePayouts;
        private String sideBetPerfectPair;
        private String sideBetPlayerPair;
        private String sideBetPlayerBonus;
        private String sideBetBankerBonus;
        private Score banker;
        private String outcome;
        private String sideBetEitherPair;
        private String sideBetBankerPair;
        private Score player;

        // getters and setters
    }

    @Data
    public class Score {
        private int score;
        private List<String> cards;

        // getters and setters
    }
}
