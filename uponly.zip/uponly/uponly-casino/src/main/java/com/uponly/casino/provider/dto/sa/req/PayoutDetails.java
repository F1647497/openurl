package com.uponly.casino.provider.dto.sa.req;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class PayoutDetails {

    /**
     * 投注编号
     */
    private Integer betid;
    /**
     * 投注类型
     */
    private Integer bettype;
    /**
     * 投注金额
     */
    private BigDecimal betamount;
    /**
     * 输赢金额
     */
    private BigDecimal resultamount;
    /**
     * 交易编号
     */
    private String txnid;
    /**
     * 投注来源
     */
    private Integer betsource;
    /**
     * 有效投注额
     */
    private BigDecimal rolling;
}
