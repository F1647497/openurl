package com.uponly.casino.provider.dto.ae.resp;

import com.alibaba.fastjson2.JSONObject;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class BetResp {
    protected String status;
    protected String desc;
    protected BigDecimal balance;
    protected String balanceTs;
    protected boolean success;

    public BetResp(String status, String desc, BigDecimal balance, String balanceTs, boolean success) {
        this.status = status;
        this.desc = desc;
        this.balance = balance;
        this.balanceTs = balanceTs;
        this.success = success;
    }
    public BetResp(String status, String desc, boolean success) {
        this.status = status;
        this.desc = desc;
        this.success = success;
    }

    public BetResp(){
        super();
    }

    public JSONObject toReturn() {
        JSONObject jsonObject =JSONObject.from(this);
        if (success){
            jsonObject.put("status", getStatus());
            jsonObject.put("balance", getBalance());
            jsonObject.put("balanceTs", getBalanceTs());
        } else {
            jsonObject.put("status", getStatus());
            jsonObject.put("desc", getDesc());
        }
        return jsonObject;
    }
    public JSONObject toReturnFail(String status,String desc) {
        this.setStatus(status);
        this.setDesc(desc);
        this.setSuccess(false);
        JSONObject jsonObject =JSONObject.from(this);
        jsonObject.put("status", getStatus());
        jsonObject.put("desc", getDesc());

        return jsonObject;
    }
    public JSONObject toReturnSuccess(String status,BigDecimal balance,String balanceTs) {
        this.setStatus(status);
        this.setBalance(balance);
        this.setBalanceTs(balanceTs);
        this.setSuccess(true);
        JSONObject jsonObject =JSONObject.from(this);
        jsonObject.put("status", getStatus());
        jsonObject.put("balance", getBalance());
        jsonObject.put("balanceTs", getBalanceTs());

        return jsonObject;
    }

}
