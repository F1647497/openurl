package com.uponly.casino.provider.dto.toup;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class CreditDTO {
    private Long userId;
    private String orderNo;
    private BigDecimal amount;
    private BigDecimal payout;
    private Long gameId;
    private String thirdOrderNo;
}
