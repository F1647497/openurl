package com.uponly.casino.provider.dto.ae.req;

import com.alibaba.fastjson2.JSONObject;
import lombok.Data;
import lombok.Getter;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Data
public class BetReq {
    public String action;
    public List<BetTransaction> txns;
}

