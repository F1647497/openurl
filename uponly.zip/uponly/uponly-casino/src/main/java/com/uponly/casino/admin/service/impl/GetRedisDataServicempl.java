package com.uponly.casino.admin.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.uponly.casino.common.constant.CommonConstant;
import com.uponly.casino.admin.service.GetRedisDataService;
import lombok.extern.slf4j.Slf4j;
import org.redisson.api.RList;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


@Slf4j
@Service
public class GetRedisDataServicempl implements GetRedisDataService {
    @Autowired
    RedissonClient redissonClient;


    @Override
    @Transactional
    public List<String> getEvoRedisDataForAmount() {
        // 获取当前日期
        LocalDate currentDate = LocalDate.now();
        //去掉currentDate 的横线
        String currentDateStr = currentDate.toString().replace("-", "");
        String key = CommonConstant.CASINO_ORDER_AMOUNT_LIST + "_" + currentDateStr;
        RList<String> orderListRedis = redissonClient.getList(key);
        List<String> orderList = new ArrayList<>();

        Iterator<String> iterator = orderListRedis.iterator();

        while (iterator.hasNext()) {
            String orderJsonString = iterator.next();
            JSONObject jsonObject = JSONObject.parseObject(orderJsonString);
            String status = jsonObject.getString("status");
            if ("3".equals(status)) {
                orderList.add(orderJsonString);
            }
        }
        return orderList;
    }

    @Override
    public List<String> getEvoRedisDataForFix() {

        String key = "casino_order_amount_list_for_fix";
        RList<String> orderListRedis = redissonClient.getList(key);
        List<String> orderList = new ArrayList<>();

        Iterator<String> iterator = orderListRedis.iterator();

        while (iterator.hasNext()) {
            String orderJsonString = iterator.next();
            JSONObject jsonObject = JSONObject.parseObject(orderJsonString);
            String status = jsonObject.getString("status");
            if ("3".equals(status)) {
                orderList.add(orderJsonString);
            }
        }
        return orderList;
    }

    @Override
    @Transactional
    public List<String> getEvoRedisDataForABG() {
        // 获取当前日期
        LocalDate currentDate = LocalDate.now();
        //去掉currentDate 的横线
        String currentDateStr = currentDate.toString().replace("-", "");
        String key = CommonConstant.CASINO_ORDER_ABG_LIST + "_" + currentDateStr;
        RList<String> orderListRedis = redissonClient.getList(key);
        List<String> orderList = new ArrayList<>();

        Iterator<String> iterator = orderListRedis.iterator();

        while (iterator.hasNext()) {
            String orderJsonString = iterator.next();
            JSONObject jsonObject = JSONObject.parseObject(orderJsonString);
            String status = jsonObject.getString("status");
            if ("3".equals(status)) {
                orderList.add(orderJsonString);
            }
        }
        return orderList;
    }


    @Override
    @Transactional
    public List<String> getEvoRedisDataForRebate() {
        // 获取当前日期
        LocalDate currentDate = LocalDate.now();
        LocalDate yesterdayDate = currentDate.minusDays(1);
        //去掉currentDate 的横线
        String yesterdayDateStr = yesterdayDate.toString().replace("-", "");

        //   String currentDateStr = currentDate.toString().replace("-", "");

        String key = CommonConstant.CASINO_ORDER_REBATE_LIST + "_" + yesterdayDateStr;
        RList<String> orderListRedis = redissonClient.getList(key);
        List<String> orderList = new ArrayList<>();

        Iterator<String> iterator = orderListRedis.iterator();

        while (iterator.hasNext()) {
            String orderJsonString = iterator.next();
            JSONObject jsonObject = JSONObject.parseObject(orderJsonString);
            String status = jsonObject.getString("status");
            if ("3".equals(status)) {
                orderList.add(orderJsonString);
            }
        }
        return orderList;
    }

}
