package com.uponly.casino.provider.dto.sa.res;

import lombok.Data;

@Data
public class SaResp {
    private String DisplayName;
    private String Token;
    private String ErrorMsg;
    private Integer ErrorMsgId;


    public SaResp() {

    }
}
