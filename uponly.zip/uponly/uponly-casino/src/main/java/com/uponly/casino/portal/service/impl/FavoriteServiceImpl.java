package com.uponly.casino.portal.service.impl;

import com.uponly.casino.common.constant.CasinoRedisKeyPrefix;
import com.uponly.casino.mapper.FavoriteMapper;
import com.uponly.casino.portal.dto.FavoriteDTO;
import com.uponly.casino.portal.service.FavoriteService;
import lombok.extern.slf4j.Slf4j;
import org.redisson.api.RScoredSortedSet;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by Administrator on 2017/8/16.
 */
@Slf4j
@Service
public class FavoriteServiceImpl implements FavoriteService {
    @Autowired
    FavoriteMapper usersFavoriteMapper;
    @Autowired
    RedissonClient redissonClient;


    @Override
    public boolean exists(FavoriteDTO favoriteDTO) {
        int count = usersFavoriteMapper.exists(favoriteDTO);
        return count > 0;
    }

    @Override
    public Long add(FavoriteDTO favoriteDTO) {
        usersFavoriteMapper.add(favoriteDTO);
        Long resultId = favoriteDTO.getId();
        return resultId;
    }

    @Override
    public int delete(FavoriteDTO favoriteDTO) {
        return usersFavoriteMapper.delete(favoriteDTO);
    }



    @Override
    public List<String> list(Long userId, boolean isNeedSort) {
            RScoredSortedSet<String> set = redissonClient.getScoredSortedSet(String.format(CasinoRedisKeyPrefix.CASINO_USER_GAME_FAVORITES, userId));
            if (set.isEmpty()) {
                usersFavoriteMapper.searchUserFavorite(userId).forEach(userFavorite -> {

                set.add(userFavorite.getCreateAt().getTime(), String.valueOf(userFavorite.getEid()));

                });
            }
        return isNeedSort ? set.valueRangeReversed(0, -1).stream().toList() : set.stream().toList();
    }
}
