package com.uponly.casino.provider.dto;

import com.alibaba.fastjson2.JSONObject;
import com.uponly.casino.admin.vo.EntryVO;
import com.uponly.casino.admin.vo.GameOriginalVO;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

@Slf4j
@Data
public class GameInfoDTO implements java.io.Serializable {
    private static final long baseGameId = 1000000L;
    private EnumInfoType infoType;
    private String uniqueName;
    private String fullGameName;
    private Long id;        //游戏id 或者入口id，大于1000000为游戏
    private Long orginId;   //原始id
    private Long pid;       //provider id
    private String name;    //名称
    private String icon;    //图标
    private String mainEntrance;    //主入口
    private String gameType;    //游戏类型
    private String tableId;    //桌子id
    private Integer status;    //状态
    private Integer version;    //版本 更新时候用
    private Object origin;    //原始数据

    public GameInfoDTO() {
    }

    public GameInfoDTO(GameInfoDTO gameInfoDTO) {
        this.setInfoType(gameInfoDTO.getInfoType());
        this.setId(gameInfoDTO.getId());
        this.setOrginId(gameInfoDTO.getOrginId());
        this.setPid(gameInfoDTO.getPid());
        this.setName(gameInfoDTO.getName());
        this.setUniqueName(gameInfoDTO.getUniqueName());
        this.setIcon(gameInfoDTO.getIcon());
        this.setMainEntrance(gameInfoDTO.getMainEntrance());
        this.setGameType(gameInfoDTO.getGameType());
        this.setTableId(gameInfoDTO.getTableId());
        this.setStatus(gameInfoDTO.getStatus());
        this.setVersion(gameInfoDTO.getVersion());
        this.setOrigin(gameInfoDTO.getOrigin());
        this.fullGameName = gameInfoDTO.getFullGameName();
    }

    public GameInfoDTO(GameOriginalVO originVo) {
        this.setInfoType(EnumInfoType.GAME);
        this.setId(originVo.getId() + baseGameId);
        this.setPid(originVo.getPid());
        this.setOrginId(originVo.getId());
        // 如果有名字编辑，使用编辑后的名字，否则使用原始名字
        var nameEdit = originVo.getTableNameEdit();
        this.name = nameEdit == null || nameEdit.isEmpty() ? originVo.getTableName() : originVo.getTableNameEdit();
        this.setUniqueName(this.name.replace(" ", "-"));
    //    log.info("edit icon: {} : table icon: {}", originVo.getTableIconEdit(), originVo.getTableIcon());
        var iconEdit = originVo.getTableIconEdit();
        this.icon = iconEdit != null && !iconEdit.trim().isEmpty() ? originVo.getTableIconEdit() : originVo.getTableIcon();
    //    log.info("info icon: {}", this.icon);
        this.mainEntrance = EntryVO.EnumMainEntry.ORIGIN.getValue();
        this.gameType = originVo.getGameType();
        this.setTableId(originVo.getTableId());
        this.status = originVo.getOpen();
        this.setVersion(originVo.getVersion());
        this.origin = originVo;
    }

    public GameInfoDTO(EntryVO entryVO) {
        this.setInfoType(EnumInfoType.ENTRY);
        this.setId(entryVO.getEid());
        this.setOrginId(entryVO.getEid());
        this.setPid(entryVO.getPid());
        this.setName(entryVO.getEname());
        this.setUniqueName(this.name.replace(" ", "-"));
        this.setIcon(entryVO.getIcon());
        this.mainEntrance = entryVO.getMainEntry();
        if (this.mainEntrance.equals(EntryVO.EnumMainEntry.GAME.getValue())) {
            var additional = entryVO.getAddition();
            if (StringUtils.isNotEmpty(additional)) {
                var addition = JSONObject.parseObject(additional);
                var tableId = addition.getString("tableId");
                if (tableId != null) {
                    this.tableId = tableId;
                }
            }

        }
        this.gameType = entryVO.getGameType();
        this.status = entryVO.getStatus();
        this.setVersion(entryVO.getVersion());
        this.origin = entryVO;
    }

    public String setFullGameName(String providerName) {
        this.fullGameName = providerName + "-" + this.uniqueName;
        return this.fullGameName;
    }

    public static enum EnumInfoType {
        GAME("game"),
        ENTRY("entry");

        private String value;

        EnumInfoType(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }
    }
}
