package com.uponly.casino.mapper;


import com.uponly.casino.admin.dto.SearchGame2DTO;
import com.uponly.casino.admin.vo.GameOriginalVO;
import com.uponly.casino.admin.vo.GameSearch;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface GameOriginalMapper {
    int addGamesFromEvo(GameOriginalVO gameOriginalVO);
    int addGames(GameOriginalVO gameOriginalVO);
    List<GameSearch> searchGame(SearchGame2DTO searchGame2DTO);

    List<GameOriginalVO> selectAll();
    List<GameOriginalVO> selectAllByPid(Long pid);
    String selectGameNameByTableId(String tableId);
    String selectTableIconByGameName(String gameName);
    String selectTableNameByGameName(String gameName);

    /**
     * 通过指定的桌台id查询桌台数据
     * @param tableIdList 桌台id集合
     * @return 桌台数据集合
     */
    List<GameOriginalVO> selectListByTableId(@Param("tableIdList") List<String> tableIdList);

    /**
     * 批量插入
     * @param tableList 桌台集合
     */
    Integer addGameList(List<GameOriginalVO> tableList);

    /**
     * 批量修改
     * @param tableList 桌台数据
     */
    Integer updateGameBatch(List<GameOriginalVO> tableList);
}
