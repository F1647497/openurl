package com.uponly.casino.admin.controller;


import com.github.pagehelper.PageInfo;
import com.uponly.casino.admin.dto.BannerBatchSortDTO;
import com.uponly.casino.admin.dto.BannerDTO;
import com.uponly.casino.admin.service.CasinoBannerService;
import com.uponly.casino.admin.vo.CasinoBanner;
import com.uponly.casino.common.api.Result;
import com.uponly.casino.common.exception.BusinessException;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@Tag(name = "BannerController", description = "banner相关")
@RequestMapping("/banner")
@Slf4j
public class BannerController {


    @Autowired
    private CasinoBannerService casinoBannerService;


    @Operation(summary = "banner列表")
    @RequestMapping(value = "/list", method = RequestMethod.POST)
    @ResponseBody
    public Result<PageInfo<CasinoBanner>> list(@RequestBody BannerDTO dto) {

        try {
            PageInfo<CasinoBanner> pageInfo = casinoBannerService.casinoBannerList(dto);
            return Result.success(pageInfo);
        } catch (Exception e) {
            log.error("banner列表 异常{} ", e.getMessage());
        }
        return null;
    }


    @Operation(summary = "新增列表")
    @RequestMapping(value = "/save", method = RequestMethod.POST)
    @ResponseBody
    public Result<String> insert(@RequestBody CasinoBanner dto) throws BusinessException {
        try {
            casinoBannerService.insert(dto);
            return Result.success();
        } catch (BusinessException e) {
            log.error("新增列表 异常{} ", e.getMessage());
        }
        return null;
    }

    @Operation(summary = "修改banner")
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    @ResponseBody
    public Result<String> update(@RequestBody CasinoBanner dto) throws BusinessException {
        try {
            casinoBannerService.update(dto);
            return Result.success();
        } catch (BusinessException e) {
            log.error("修改banner 异常{} ", e.getMessage());
        }
        return null;
    }


    @Operation(summary = "删除banner")
    @RequestMapping(value = "/delete/{id}", method = RequestMethod.GET)
    @ResponseBody
    public Result<PageInfo<CasinoBanner>> delete(@PathVariable Long id) {
        try {
            casinoBannerService.delete(id);
            return Result.success();
        } catch (Exception e) {
            log.error("删除banner 异常{} ", e.getMessage());
        }
        return null;
    }


    @Operation(summary = "批量排序")
    @RequestMapping(value = "/batchSort", method = RequestMethod.POST)
    @ResponseBody
    public Result<String> batchSort(@RequestBody List<BannerBatchSortDTO> batch) throws BusinessException {

        try {
            casinoBannerService.batchSort(batch);
            return Result.success();
        } catch (BusinessException e) {
            log.error("批量排序 异常{} ", e.getMessage());
        }
        return null;
    }


    @Operation(summary = "获取最大的排序值")
    @RequestMapping(value = "/getMaxSort", method = RequestMethod.GET)
    @ResponseBody
    public Result<Integer> getMaxSort() {
        try {
            return Result.success(casinoBannerService.maxSort());
        } catch (Exception e) {
            log.error("获取最大的排序值 异常{} ", e.getMessage());
        }
        return null;
    }


   /* @RequestMapping(value = "/banner/forFeign", method = RequestMethod.GET)
    public String forFeignTest() {
        log.info("here is admin, test for feign");
        return "hello, oepn feign";
    }*/
}
