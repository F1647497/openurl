package com.uponly.casino.provider.dto.sa.req;

import cn.hutool.core.date.DateTime;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class PlaceWinReq {

    /**
     * 用户名
     */
    private String username;
    /**
     * 币种
     */
    private String currency;
    /**
     * 投注金额
     */
    private BigDecimal amount;
    /**
     * 有效投注
     */
    private BigDecimal rolling;
    /**
     * 交易编号
     */
    private String txnid;
    /**
     * 时间
     */
    private DateTime timestamp;
    /**
     * 游戏类型
     */
    private String gametype;
    /**
     * 派彩时间
     */
    private DateTime Payouttime;
    /**
     * 桌台编号
     */
    private Integer hostid;
    /**
     * 游戏局号
     */
    private String gameid;
    /**
     * 首次发送︰retry=0
     * 第二次发送︰retry=1
     */
    private Integer retry;
    /**
     * 投注清单 - 详细投注列表
     */
    private String payoutdetails;
}
