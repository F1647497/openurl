package com.uponly.casino.provider.service;

import com.uponly.casino.provider.vo.UserInfoVO;

import java.util.Optional;

public interface UserInfoService {
    Optional<UserInfoVO> getUser(Long userId);

    Optional<UserInfoVO> getUserByName(String userName);
}
