package com.uponly.casino.admin.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.github.pagehelper.PageInfo;
import com.uponly.casino.admin.dto.SearchOrderDTO;
import com.uponly.casino.admin.dto.UpdateMsgDTO;
import com.uponly.casino.admin.vo.OrderVOBe;
import com.uponly.casino.admin.vo.TotalAmountVO;
import com.uponly.casino.portal.dto.SearchOrderFeDTO;
import com.uponly.casino.portal.vo.OrderVOFe;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

public interface OrderService {

  PageInfo<OrderVOBe> searchOrder(SearchOrderDTO searchOrderDTO) throws JsonProcessingException;

  List<TotalAmountVO> searchTotal(SearchOrderDTO searchOrderDTO) throws JsonProcessingException;

  Map<String, Object> searchOrderFe(SearchOrderFeDTO searchOrderFeDTO) throws JsonProcessingException;

  Map<String, Object> searchOrderByOrderNoList(SearchOrderFeDTO searchOrderFeDTO) throws JsonProcessingException;

  Integer updateMsgState(UpdateMsgDTO updateMsgDTO);

}

