package com.uponly.casino.common.api;

import lombok.Data;

/**
 * node.js后台管理-通用返回对象
 *
 */
@Data
public class CommonResultNodeJs<T> {
    private Integer code;
    private String msg;
    private T data;

    protected CommonResultNodeJs() {
    }

    protected CommonResultNodeJs(Integer code, String msg, T data) {
        this.code = code;
        this.msg = msg;
        this.data = data;
    }


}