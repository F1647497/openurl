package com.uponly.casino.mapper;


import com.uponly.casino.admin.dto.BannerDTO;
import com.uponly.casino.admin.vo.CasinoBanner;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface CasinoBannerMapper {

    int insert(CasinoBanner record);


    int insertSelective(CasinoBanner record);

    CasinoBanner selectByPrimaryKey(Long id);


    int updateByPrimaryKeySelective(CasinoBanner record);

    int updateByPrimaryKey(CasinoBanner record);

    int deleteById(Long id);

    List<CasinoBanner> queryBanner(BannerDTO record);

    List<Integer> querySort(@Param("sortList") List<Integer> sortList);

    Integer getMaxSort();

    List<CasinoBanner> refreshCache();

    int updateSort(CasinoBanner record);
}