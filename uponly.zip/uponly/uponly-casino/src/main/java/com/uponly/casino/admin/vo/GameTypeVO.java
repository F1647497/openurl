package com.uponly.casino.admin.vo;


import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(title="游戏类型实体")
public class GameTypeVO {

    @Schema(title="id")
    private Long id;

    @Schema(title="三方id")
    private Long pid;

    @Schema(title="游戏类型")
    private String gameType;

    @Schema(title="展示名称")
    private String displayName;



}