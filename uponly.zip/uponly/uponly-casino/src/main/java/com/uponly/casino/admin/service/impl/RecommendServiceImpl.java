package com.uponly.casino.admin.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.uponly.casino.admin.dto.AddGameEntranceDTO;
import com.uponly.casino.admin.dto.RecommendDTO;
import com.uponly.casino.admin.dto.SearchRecommendDTO;
import com.uponly.casino.admin.service.RecommendService;
import com.uponly.casino.admin.vo.RecommendGameVO;
import com.uponly.casino.mapper.EntranceMapper;
import com.uponly.casino.mapper.RecommendMapper;
import com.uponly.casino.provider.service.GameInfoService;
import lombok.extern.slf4j.Slf4j;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;


@Slf4j
@Service
public class RecommendServiceImpl implements RecommendService {

    @Autowired
    RedissonClient redissonUtil;
    @Autowired
    private RecommendMapper recommendGameMapper;

    @Autowired
    private GameInfoService gameInfoService;

    @Autowired
    private EntranceMapper entranceMapper;

    @Override
    public int add(RecommendDTO recommendDTO) {
        //获取pid并通知游戏更新
        Long pid = entranceMapper.getPidByEid(recommendDTO.getEid());
        gameInfoService.notifyGameUpdate(pid);
        return recommendGameMapper.addRecommendGame(recommendDTO);
    }

    @Override
    public PageInfo<RecommendGameVO> searchRecommendGame(SearchRecommendDTO searchRecommendDTO) {
        Integer page = searchRecommendDTO.getPage();
        Integer pageSize = searchRecommendDTO.getPageSize();

        // 根据搜索条件查询游戏，如果条件不为NULL，那么包含对应的条件
        PageInfo<RecommendGameVO> pageInfo = PageHelper.startPage(page, pageSize)
                .doSelectPageInfo(() -> recommendGameMapper.searchRecommendGame(searchRecommendDTO));



        return pageInfo;
    }

    @Override
    public Optional<Integer> maxSort() {
        return Optional.ofNullable(recommendGameMapper.maxSort());
    }

    @Override
    public int update(RecommendDTO recommendDTO) {
        //获取pid并通知游戏更新
        Long pid = entranceMapper.getPidByEid(recommendDTO.getEid());
        gameInfoService.notifyGameUpdate(pid);

        return recommendGameMapper.update(recommendDTO);
    }

    @Override
    public int delete(RecommendDTO recommendDTO) {
        //获取pid并通知游戏更新
        Long pid = entranceMapper.getPidByEid(recommendDTO.getEid());
        gameInfoService.notifyGameUpdate(pid);
        return recommendGameMapper.deleteRecommend(recommendDTO);
    }

}

