package com.uponly.casino.provider.dto.ag.req;

import lombok.Builder;
import lombok.Data;
@Data
public class ForwardGameReq extends CreateAccountReq {
    private String sid;      // sid=(cagent+序列)，唯一值，序列为13~16位数。 *每次调用登入游戏都必须变更sid值
    private String dm;   // dm 代表返回的网站域名 *如无须跳转，请设置为dm=NO_RETURN
    private String lang; // 语系
    private String gameType;  // gameType=0 代表登入大厅
    private String mh5;     // mh5=n 代表电脑网页版 mh5=y 代表移动网页版 如不添加此参数，将自适应装置跳转

    public ForwardGameReq() {

    }
    public ForwardGameReq(String sid, String dm, String lang, String gameType, String mh5) {
        this.sid = sid;
        this.dm = dm;
        this.lang = lang;
        this.gameType = gameType;
        this.mh5 = mh5;

    }

}
