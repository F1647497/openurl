package com.uponly.casino.ranking.service.impl;

import cn.hutool.core.date.DateTime;
import com.alibaba.fastjson2.JSONObject;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.uponly.casino.admin.vo.OrderVO;
import com.uponly.casino.admin.vo.ProviderVO;
import com.uponly.casino.common.utils.ConvertUtils;
import com.uponly.casino.common.utils.CurrencyConverter;
import com.uponly.casino.interceptor.RemoteKafkaService;
import com.uponly.casino.interceptor.kafka.KafkaMessageHelper;
import com.uponly.casino.mapper.BigWinsConfMapper;
import com.uponly.casino.mapper.OrderMapper;
import com.uponly.casino.mapper.ProviderMapper;
import com.uponly.casino.provider.dto.GameInfoDTO;
import com.uponly.casino.provider.service.GameInfoService;
import com.uponly.casino.provider.service.UserInfoService;
import com.uponly.casino.ranking.RollingRankingService;
import com.uponly.casino.ranking.dto.LiveWinDTO;
import com.uponly.casino.admin.vo.BigWinsConfVO;
import com.uponly.casino.ranking.vo.RankDataVO;
import com.uponly.casino.util.RegionIntegerUtil;
import com.uponly.casino.common.constant.RedisKeyPrefixConst;
import lombok.extern.slf4j.Slf4j;
import org.redisson.api.RMap;
import org.redisson.api.RScoredSortedSet;
import org.redisson.api.RedissonClient;
import org.redisson.client.protocol.ScoredEntry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.core.annotation.Order;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.*;

import static com.uponly.casino.common.constant.CommonConstant.*;

@Slf4j
@Service
public class RollingRankingImpl implements RollingRankingService {
    @Autowired
    private RedissonClient redissonClient; // Redisson客户端

    @Autowired
    private OrderMapper orderMapper;

    @Autowired
    private GameInfoService gameInfoService;

    @Autowired
    private UserInfoService userInfoService;

    @Autowired
    private ProviderMapper providerMapper;

    @Autowired
    private BigWinsConfMapper bigwinsConfMapper;

    @Autowired
    private RemoteKafkaService remoteKafkaService;

    private static HashMap<String, List<RankDataVO>> rankingMap = new HashMap<>();
    private static List<Integer> locationList;
    private static final Map<String, BigDecimal> rateMap = new HashMap<>();
    private static final Map<Long, ProviderVO> providerVOMap = new HashMap<>();
    private static final Map<String, BigWinsConfVO> bigwinsConfMap = new HashMap<>();
    // 假设的时间窗口长度，以秒为单位
    private static final long ONE_DAY_IN_SECONDS = 24 * 3600;
    private static final long SEVEN_DAYS_IN_SECONDS = 7 * ONE_DAY_IN_SECONDS;
    private static final long THIRTY_DAYS_IN_SECONDS = 30 * ONE_DAY_IN_SECONDS;

    private static final int MAX_RANKING_BUFFER_SIZE = 30;
    private static final int MAX_RANKING_SIZE = 20;
    private static final int MAX_BIG_WINS_SIZE = 10;
    private static Boolean initialized = false;

    // This method is called when the application is ready to start.
    @EventListener(ApplicationReadyEvent.class)
    @Order(3)
    public void onApplicationStartup() {
        updateBigWinsConf();

        if (!initialized) {
            initialize();
            initialized = true;
        }

        // 订阅redis的更新排行榜事件
        var topic = redissonClient.getTopic(PUB_CASINO_UPDATE_LIVE_WIN);
        topic.addListener(String.class, (channel, event) -> {
            try {
                log.info("Received redis message: {} from channel: {}", event, channel);
                if (event.equals("config")) {
                    updateBigWinsConf();
                } else {
                    loadLiveWins(LiveWinDTO.LiveType.fromValue(event));
                }
            } catch (NumberFormatException e) {
                log.error("Failed to parse message as long: {}", event, e);
            }
        });
    }

    // live wins config 变动通知
    public void notifyLiveWinConfigUpdate() {
        var topic = redissonClient.getTopic(PUB_CASINO_UPDATE_LIVE_WIN);
        topic.publish("config");
    }

    // live wins 变动通知
    public void notifyRefreshLiveWin(LiveWinDTO.LiveType type) {
        var topic = redissonClient.getTopic(PUB_CASINO_UPDATE_LIVE_WIN);
        topic.publish(type.getValue());
    }

    public void initialize() {
        // 初始化供应商信息
        var allProviders = providerMapper.providers();
        for (var provider : allProviders) {
            providerVOMap.put(provider.getPid(), provider);
        }
        // 初始化地区列表
        locationList = RegionIntegerUtil.initArea();
        // 初始化实时汇率
        updateRateMap();

        // 初始化排行榜
        loadLiveWins(LiveWinDTO.LiveType.DAILY);
        loadLiveWins(LiveWinDTO.LiveType.WEEKLY);
        loadLiveWins(LiveWinDTO.LiveType.MONTHLY);

        // 初始化大赢排行榜
        loadLiveWins(LiveWinDTO.LiveType.BIG_WINS);
    }

    private void loadLiveWins(LiveWinDTO.LiveType type) {
        log.info("Loading live wins: {}", type);
        if (type == LiveWinDTO.LiveType.BIG_WINS) {
            var rankingBigWins = getRankingKey(LiveWinDTO.LiveType.BIG_WINS, 0L);
            // 从Redis中获取大赢排行榜
            var bigWinList = new ArrayList<RankDataVO>();
            var bigWinSortList = redissonClient.getScoredSortedSet(rankingBigWins);
            if (!bigWinSortList.isEmpty()) {
                // 如果Redis中的数据存在，直接从Redis中加载排行榜数据
                for (var entry : bigWinSortList.entryRange(0, -1)) {
                    try {
                        var rankData = JSONObject.parseObject((String) entry.getValue(), RankDataVO.class);
                        if (rankData.getFullGameName() == null
                                || rankData.getFullGameName().isEmpty()
                                || rankData.getIcon() == null
                                || rankData.getIcon().isEmpty()) {
                            var gameInfo = gameInfoService.getGameInfo(rankData.getEid().toString());
                            if (gameInfo.isPresent()) {
                                rankData.setFullGameName(gameInfo.get().getFullGameName());
                                rankData.setIcon(gameInfo.get().getIcon());
                            }
                        }
                        bigWinList.add(rankData);
                    }catch (Exception e){
                        log.error("loadLiveWins fail :{} ,err: ",JSONObject.parseObject((String) entry.getValue(), RankDataVO.class),e);
                    }
                }
            } else {
                // 如果redis中的数据不存在，从数据库加载排行榜数据
                var bigWins = orderMapper.selectLiveBigWins(0.3);
                for (var win : bigWins) {
                    var rankData = getRankDataVO(win);
                    bigWinList.add(rankData);
                }
            }
            bigWinList.sort(Comparator.comparing(RankDataVO::getTimestamp).reversed());
            rankingMap.put(getRankingKey(LiveWinDTO.LiveType.BIG_WINS, 0L), bigWinList);
            return;
        }
        rankingMap.put(type.getValue(), getRankingData(type));
    }

    private void updateBigWinsConf() {
        var bigwinsConfList = bigwinsConfMapper.selectAll();
        for (var conf : bigwinsConfList) {
            // 如果Map中已经存在该配置，更新配置
            String lowerCurrency = conf.getCurrency().toLowerCase();
            String upperCurrency = conf.getCurrency().toUpperCase();
            // 如果Map中不存在该配置，添加配置，否则更新配置
            bigwinsConfMap.putIfAbsent(lowerCurrency, conf);
            // 如果Map中不存在大写货币配置，添加大写货币配置，否则更新大写货币配置
            bigwinsConfMap.putIfAbsent(upperCurrency, conf);
        }
    }

    // 获取currency对应的汇率
    public Optional<BigDecimal> getRate(String currency) {
        return Optional.ofNullable(rateMap.get(currency));
    }

    private Optional<GameInfoDTO> getGameInfoFromBody(String body) {
        var objectMapper = new ObjectMapper();
        try {
            JsonNode rootNode = objectMapper.readTree(body);
            String tableId = rootNode
                    .path("game")       // 获取 "game" 节点
                    .path("details")    // 获取 "details" 节点
                    .path("table")      // 获取 "table" 节点
                    .path("id")         // 获取 "id" 节点
                    .asText();
            return gameInfoService.getGameInfoByTableId(tableId);
        } catch (Exception e) {
            log.error("Error parsing game details: {}", e.getMessage());
        }
        return Optional.empty();
    }

    private RankDataVO getRankDataVO(OrderVO win) {
        log.info("RankDataVO, body: {}", win.getBody());
        var rankData = new RankDataVO();
        String body = win.getBody();
        if (win.getGameName() == null) {
            if (body != null) {
                var gameInfo = getGameInfoFromBody(body);
                setRankDataGameInfo(gameInfo, rankData);
            }
        } else {
            log.info("gameName: {}", win.getGameName());
            var gameInfo = gameInfoService.getGameInfo(win.getPid(), win.getGameName().replace(" ", "-"));
            if (gameInfo.isEmpty()) {
                if (body != null) {
                    gameInfo = getGameInfoFromBody(body);
                }
            }
            setRankDataGameInfo(gameInfo, rankData);
        }
        var userInfo = userInfoService.getUser(win.getUserId());
        if (userInfo.isPresent()) {
            log.info("userInfo: {}", userInfo.get());
            var nickName = userInfo.get().getNickName();
            // 如果nickName为空或者是空字符串，将其设置为userName
            var name = nickName == null || nickName.isEmpty() ? userInfo.get().getUserName() : nickName;
            log.info("name: {}", name);
            rankData.setUserName(name);
            rankData.setVip(userInfo.get().getVip());
            rankData.setStar(userInfo.get().getStar());
        }
        rankData.setUserId(win.getUserId());
        rankData.setBet(win.getAmount());
        rankData.setCurrency(win.getCurrency());
        rankData.setPayout(win.getPayout());
        rankData.setUsdPayout(win.getUsdPayout());
        var pid = win.getPid();
        rankData.setPid(pid);
        rankData.setProviderName(providerVOMap.get(pid).getProviderName());
        var multiplier = win.getPayout().divide(win.getAmount(), 6, RoundingMode.HALF_UP);
        rankData.setMultiplier(multiplier);
        rankData.setTimestamp(win.getSettleAt().getTime());
        return rankData;
    }

    private static void setRankDataGameInfo(Optional<GameInfoDTO> gameInfo, RankDataVO rankData) {
        if (gameInfo.isPresent()) {
            rankData.setGameName(gameInfo.get().getName());
            rankData.setEid(gameInfo.get().getId());
            rankData.setIcon(gameInfo.get().getIcon());
            rankData.setFullGameName(gameInfo.get().getFullGameName());
        }
    }

    // 获取实时大赢排行榜, location为地区ID
    public List<RankDataVO> getLiveBigWins(Integer location) {
        var retList = new ArrayList<RankDataVO>();
        var bigWinKey = getRankingKey(LiveWinDTO.LiveType.BIG_WINS, 0L);
        var bigWinList = rankingMap.get(bigWinKey);
        // 遍历listWins，返回根据location的currency计算后的数据的新列表
        if (bigWinList != null) {
            String currency = RegionIntegerUtil.AreaToCurrency(location);
            var rate = rateMap.get(currency);
            for (var win : bigWinList) {
//                var newWin = getRankDataVO(win, currency, rate);
                RankDataVO newWin = getRankDataVOV2(win, currency, rateMap);
                retList.add(newWin);
            }
        }
        System.out.println("retListsize-------" + retList.size());
        return retList;
    }

    //原始数据保存了现成的usd_payout，然后还需要转bet为对应地区的汇率

    /**
     * 获取对应地区的排行榜数据
     *
     * @param origin   原始数据
     * @param currency 地区对应的货币
     * @param rateMap  汇率
     * @return 转换后的数据
     */
    private static RankDataVO getRankDataVOV2(RankDataVO origin, String currency, Map<String, BigDecimal> rateMap) {
        var rankVo = new RankDataVO(origin);
        if (currency.equals(origin.getCurrency())) {
            return rankVo;
        }
        //把原始数据的投注和赔付都转成对应地区的汇率
        BigDecimal regionBet = CurrencyConverter.convert(origin.getBet(), origin.getCurrency(), currency, rateMap);
        BigDecimal regionPayout = CurrencyConverter.convert(origin.getPayout(), origin.getCurrency(), currency, rateMap);
        rankVo.setBet(regionBet);
        rankVo.setPayout(regionPayout);

        rankVo.setCurrency(currency);
        log.info("使用usdtPayout计算的赔付:{},直接汇率转换的赔付:{},直接汇率转换的投注：{}", origin.getUsdPayout().multiply(rateMap.get(currency)), regionPayout, regionBet);
        return rankVo;
    }

    private static RankDataVO getRankDataVO(RankDataVO origin, String currency, BigDecimal rate) {
        var rankVo = new RankDataVO(origin);
        if (currency.equals(origin.getCurrency())) {
            return rankVo;
        }
        rankVo.setCurrency(currency);
        if (currency.equals("USDT") || currency.equals("USD")) {
//            rankVo.setBet(origin.getBet().divide(rate, 6, RoundingMode.HALF_UP));
            rankVo.setPayout(origin.getUsdPayout());
            return rankVo;
        }
        rankVo.setBet(origin.getBet());
        rankVo.setPayout(origin.getUsdPayout().multiply(rate));
        return rankVo;
    }

    public List<RankDataVO> getLiveWins(LiveWinDTO liveType) {
        // 从Redis获取排行榜
        var location = liveType.getLocation();
        var realType = LiveWinDTO.LiveType.fromValue(liveType.getLiveType());
        var retList = new ArrayList<RankDataVO>();
        if (realType == null) {
            log.error("Invalid liveType: {}", liveType.getLiveType());
            return retList;
        }
        var rankingList = rankingMap.get(realType.getValue());
        if (rankingList != null) {
            var currency = RegionIntegerUtil.AreaToCurrency(location);
            var rate = rateMap.get(currency);
            for (var item : rankingList) {
                retList.add(getRankDataVO(item, currency, rate));
            }
            // 按照payout降序排序
            retList.sort(Comparator.comparing(RankDataVO::getPayout).reversed());
            if (retList.size() > MAX_RANKING_SIZE) {
                // 如果排行榜的长度大于MAX_RANKING_SIZE，截取前MAX_RANKING_SIZE个元素
                return retList.subList(0, MAX_RANKING_SIZE);
            }
        }
        return retList;
    }

    private String getRankingKey(LiveWinDTO.LiveType type, Long location) {
        String rankingKey = switch (type) {
            case DAILY -> "ranking:24hours:";
            case WEEKLY -> "ranking:7days:";
            case MONTHLY -> "ranking:30days:";
            case BIG_WINS -> "ranking:bigwins:";
        };
        return rankingKey + location;
    }

    // 获取排行榜数据, type为排行榜类型
    private List<RankDataVO> getRankingData(LiveWinDTO.LiveType type) {
        var rankingData = new ArrayList<RankDataVO>();
        // 获取当前时间戳，单位为秒
        long ts = Instant.now().getEpochSecond();
        switch (type) {
            case DAILY -> {
                ts -= ONE_DAY_IN_SECONDS;
            }
            case WEEKLY -> {
                // ts - 7天的秒数
                ts -= SEVEN_DAYS_IN_SECONDS;
            }
            case MONTHLY -> {
                ts -= THIRTY_DAYS_IN_SECONDS;
            }
        }
        var rankingKey = getRankingKey(type, 0L);
        // 首先从Redis中获取排行列表，如果排行不存在，那么从数据库直接读取
        var rankingSet = redissonClient.getScoredSortedSet(rankingKey);
        if (!rankingSet.isEmpty()) {
            // 从Redis中获取排行榜的所有数据
            var entries = rankingSet.entryRange(0, -1);
            for (var entry : entries) {
                try {
                    var rankData = JSONObject.parseObject((String) entry.getValue(), RankDataVO.class);
                    if (rankData.getUsdPayout() == null) {
                        var usdRate = getRate(rankData.getCurrency());
                        if (usdRate.isEmpty()) {
                            continue;
                        }
                        var usdPayout = rankData.getPayout().divide(usdRate.get(), 6, RoundingMode.HALF_UP);
                        rankData.setUsdPayout(usdPayout);
                    }
                    //   log.info("rankData Stamp: {}, ts: {}", rankData.getTimestamp(), ts);
                    if (rankData.getTimestamp() / 1000L < ts) {
                        // 如果数据的时间戳小于ts，删除数据
                        rankingSet.remove(entry.getValue());
                    } else {
                        if (rankData.getFullGameName() == null || rankData.getFullGameName().isEmpty()) {
                            var gameInfo = gameInfoService.getGameInfo(rankData.getEid().toString());
                            if (gameInfo.isPresent()) {
                                rankData.setFullGameName(gameInfo.get().getFullGameName());
                                rankData.setIcon(gameInfo.get().getIcon());
                            }
                        }
                        rankingData.add(rankData);
                    }
                }catch (Exception e){
                    log.error("getRankingData fail {}, err: ",JSONObject.parseObject((String) entry.getValue(), RankDataVO.class),e);
                }

            }
        }
        if (rankingSet.isEmpty()) {
            var settleAt = new DateTime(ts * 1000L);
            var wins = orderMapper.selectTop30UsdPayout(settleAt);
            for (var win : wins) {
                var rankData = getRankDataVO(win);
                rankingData.add(rankData);
                var jsonData = JSONObject.toJSONString(rankData);
                if (rankData.getUsdPayout() == null) {
                    var usdRate = getRate(rankData.getCurrency());
                    if (usdRate.isEmpty()) {
                        continue;
                    }
                    var usdPayout = rankData.getPayout().divide(usdRate.get(), 6, RoundingMode.HALF_UP);
                    rankData.setUsdPayout(usdPayout);
                }
                var score = rankData.getUsdPayout().doubleValue();
                rankingSet.add(score, jsonData);
            }
        }
        // 按照usdPayout降序排序
        rankingData.sort(Comparator.comparing(RankDataVO::getUsdPayout).reversed());
        return rankingData;
    }

    //    @Async
    public void processBettingData(OrderVO data) {
        double payout = data.getPayout().doubleValue();
        double bet = data.getAmount().doubleValue();
        double multiplier = payout / bet;
        String currency = data.getCurrency();
        var bigwinsConf = bigwinsConfMap.get(currency);
        if (bigwinsConf != null) {
            if (multiplier < bigwinsConf.getMultiplier().doubleValue()) {
                log.info("Multiplier is less than the threshold, skipping");
                return;
            }
            if (bigwinsConf.getMinAmount().doubleValue() > bet) {
                log.info("Bet amount is less than the threshold, skipping");
                return;
            }
        } else {
            if (multiplier <= 0) {
                log.info("Multiplier is less than or equal to 0, skipping");
                return;
            }
        }

        // 更新各个排行榜
        var rankData = getRankDataVO(data);

        // 更新日、周和月排行榜
        checkAddLiveWin(LiveWinDTO.LiveType.DAILY, rankData);
        checkAddLiveWin(LiveWinDTO.LiveType.WEEKLY, rankData);
        checkAddLiveWin(LiveWinDTO.LiveType.MONTHLY, rankData);

        // 更新大赢排行榜
        var bigWinKey = getRankingKey(LiveWinDTO.LiveType.BIG_WINS, 0L);
        var bigWinList = rankingMap.get(bigWinKey);
        bigWinList.add(0, rankData);
        if (bigWinList.size() > MAX_BIG_WINS_SIZE) {
            bigWinList.remove(bigWinList.size() - 1);
        }
        rankingMap.put(bigWinKey, bigWinList);

        // 更新Redis中的大赢排行榜
        var bigWinSet = redissonClient.getScoredSortedSet(bigWinKey);
        String jsonData = JSONObject.toJSONString(rankData);
        bigWinSet.add(rankData.getTimestamp(), jsonData);
        if (bigWinSet.size() > MAX_BIG_WINS_SIZE) {
            bigWinSet.pollFirst();
        }

        // 发送消息到Kafka, 新数据都要针对每个地区发送一次
        for (Integer region : locationList) {
            var regionCurrency = RegionIntegerUtil.AreaToCurrency(region);
            var regionRate = rateMap.get(RegionIntegerUtil.AreaToCurrency(region));
            //旧版本
//            RankDataVO rankDataVO = getRankDataVO(rankData, regionCurrency, regionRate);
            //新版本增加了投注
            RankDataVO rankDataVO = getRankDataVOV2(rankData, regionCurrency, rateMap);
            marquee(rankDataVO, region.longValue());
        }

        notifyRefreshLiveWin(LiveWinDTO.LiveType.BIG_WINS);
    }

    // 发送跑马灯/LiveBigWin消息到Kafka
    private void marquee(RankDataVO rankDataVO, Long location) {
        try {
            log.info("跑马灯 msg:");
            //通过kafka主动推送ws到前端
            //把以下数据包装和推送到kafka的代码包装成独立的方法，并把type和data放到函数中
            String channel = CASINO_LIVE_WIN_REGION_FORMAT.formatted(location);
            log.info("channel:{}", channel);
            String msg = KafkaMessageHelper.toJsonString(SOCKET_SLOT_MARQUEE, rankDataVO, channel);
            log.info("【实时大赢排行榜】刷新实时大赢排行榜-kafka-推送:{}", msg);
            remoteKafkaService.send(KafkaMessageHelper.TopicEnum.EVENT_WS_TOPIC.getTopic(), msg);
            log.info("【实时大赢排行榜】刷新实时大赢排行榜-kafka-推送成功");
        } catch (Exception e) {
            log.error("send marquee msg异常 {} ", e.getMessage());
        }
    }

    // 通知客户端排行榜更新
    private void notifyClientUpdateLiveWin(LiveWinDTO.LiveType type, Integer location) {
        log.info("notifyClientUpdateLiveWin: {}", type.getValue());
        // 获取排行榜数据
        var rankingList = getLiveWins(new LiveWinDTO(type.getValue(), location));
        log.info("rankingList size: {}", rankingList.size());
        // 发送消息到Kafka
        try {
            log.info("Live win update msg: {}", type.getValue());
            //通过kafka主动推送ws到前端
            //把以下数据包装和推送到kafka的代码包装成独立的方法，并把type和data放到函数中
            String channel = CASINO_LIVE_WIN_REGION_FORMAT.formatted(location);
            log.info("live win channel:{}", channel);
            var rankType = SOCKET_CASINO_LIVE_WINS_D;
            switch (type) {
                case DAILY -> rankType = SOCKET_CASINO_LIVE_WINS_D;
                case WEEKLY -> rankType = SOCKET_CASINO_LIVE_WINS_W;
                case MONTHLY -> rankType = SOCKET_CASINO_LIVE_WINS_M;
            }
            log.info("rankType:{}", rankType);
            String msg = KafkaMessageHelper.toJsonString(rankType, rankingList, channel);
            log.info("【大赢排行榜】刷新大赢排行榜-kafka-推送:{}", msg);
            remoteKafkaService.send(KafkaMessageHelper.TopicEnum.EVENT_WS_TOPIC.getTopic(), msg);
            log.info("【大赢排行榜】刷新大赢排行榜-kafka-推送成功");
        } catch (Exception e) {
            log.error("send update live win msg 异常 {} ", e.getMessage());
        }
    }

    private void checkAddLiveWin(LiveWinDTO.LiveType type, RankDataVO rankData) {
        log.info("checkAddLiveWin: {}", type.getValue());
        String jsonData = JSONObject.toJSONString(rankData);
        var score = rankData.getUsdPayout().doubleValue();
        var rankingKey = getRankingKey(type, 0L);
        var rankingSet = redissonClient.getScoredSortedSet(rankingKey);

        // 如果score比map对应的list中的最后一个元素小，直接返回
        var rankingList = rankingMap.computeIfAbsent(type.getValue(), k -> new ArrayList<>());
        if (rankingList.isEmpty() || rankingList.size() < MAX_RANKING_BUFFER_SIZE) {
            rankingList.add(rankData);
            rankingList.sort(Comparator.comparing(RankDataVO::getUsdPayout).reversed());
            rankingSet.add(score, jsonData);
            // 查找刚插入的数据在排行榜中的位置
            if (rankingList.indexOf(rankData) < MAX_RANKING_SIZE) {
                log.info("notifyClientUpdateLiveWin: {}", type.getValue());
                for (Integer location : locationList) {
                    notifyClientUpdateLiveWin(type, location);
                }
            }
            return;
        }

        if (score <= rankingList.get(rankingList.size() - 1).getUsdPayout().doubleValue()) {
            return;
        }
        // 按照score降序排序插入数据到list中
        var notifyClient = false;
        for (int i = 0; i < rankingList.size(); i++) {
            if (score > rankingList.get(i).getUsdPayout().doubleValue()) {
                rankingList.add(i, rankData);
                if (i < MAX_RANKING_SIZE) {
                    log.info("notifyClientUpdateLiveWin: {}", type.getValue());
                    notifyClient = true;
                }
                if (rankingList.size() > MAX_RANKING_SIZE) {
                    rankingList.remove(rankingList.size() - 1);
                }
                break;
            }
        }
        // 使用当前时间戳更新排行榜
        rankingSet.add(score, jsonData);
        // 如果排行榜的长度大于MAX_RANKING_BUFFER_SIZE
        if (rankingSet.size() > MAX_RANKING_BUFFER_SIZE) {
            // 删除排行榜中的数据最小的元素
            rankingSet.pollFirst();
        }

        log.info("notifyClient: {}", notifyClient);
        // 如果notifyClient为true，发送消息到Kafka
        if (notifyClient) {
            log.info("notifyClientUpdateLiveWin: {}", type.getValue());
            for (Integer location : locationList) {
                notifyClientUpdateLiveWin(type, location);
            }
        }
    }

    // 定期清理过时的数据，应该设置为定时任务
    private void cleanup(LiveWinDTO.LiveType type, long maxAgeInSeconds) {
        var ts = Instant.now().getEpochSecond() - maxAgeInSeconds;
        var rankingKey = getRankingKey(type, 0L);
        var lockKey = rankingKey + ":lock";
        var keyLock = redissonClient.getLock(lockKey); // 获取排行榜的锁
        if (keyLock.tryLock()) {
            try {
                // 锁定排行榜
                RScoredSortedSet<String> ranking = redissonClient.getScoredSortedSet(rankingKey);
                // 获取排行榜的所有数据
                Collection<ScoredEntry<String>> entries = ranking.entryRange(0, -1);
                // 遍历排行榜，删除过时的数据
                boolean needRefresh = false;
                boolean needNotifyClient = false;
                for (ScoredEntry<String> entry : entries) {
                    var rankData = JSONObject.parseObject(entry.getValue(), RankDataVO.class);
                    if (rankData.getTimestamp() / 1000L < ts) {
                        ranking.remove(entry.getValue());
                        needRefresh = true;
                        // 检测删除的数据是否在排行榜中，如果在，删除
                        var rankingList = rankingMap.get(type.getValue());
                        for (int i = 0; i < rankingList.size(); i++) {
                            if (rankingList.get(i).getTimestamp() == rankData.getTimestamp()) {
                                rankingList.remove(i);
                                if (i < MAX_RANKING_SIZE) {
                                    needNotifyClient = true;
                                }
                                break;
                            }
                        }
                    }
                }

                // 更新排行榜
                if (needRefresh) {
                    // 通知其它pod更新排行榜
                    notifyRefreshLiveWin(type);
                    // 通知客户端更新排行榜
                    if (needNotifyClient) {
                        for (Integer location : locationList) {
                            notifyClientUpdateLiveWin(type, location);
                        }
                    }
                }
            } finally {
                if (keyLock.isLocked() && keyLock.isHeldByCurrentThread()) {
                    keyLock.unlock();
                }
            }
        }
    }

    @Async
    @Scheduled(fixedRate = 60000 * 10) // 每10分钟执行一次
    public void cleanupRankings() {
        log.info("Cleaning up rankings {}", Instant.now());
        cleanup(LiveWinDTO.LiveType.DAILY, ONE_DAY_IN_SECONDS);
        cleanup(LiveWinDTO.LiveType.WEEKLY, SEVEN_DAYS_IN_SECONDS);
        cleanup(LiveWinDTO.LiveType.MONTHLY, THIRTY_DAYS_IN_SECONDS);
        log.info("Cleaning up rankings done {}", Instant.now());
    }

    @Async
    @Scheduled(fixedRate = 60000 * 5) // 每5分钟执行一次
    public void updateRateMap() {
        // 更新汇率
        log.info("Updating exchange rate {}", Instant.now());
        RMap<String, BigDecimal> newRateMap = redissonClient.getMap(RedisKeyPrefixConst.exchangeRate);
        if (!newRateMap.isEmpty()) {
            rateMap.putAll(newRateMap);
            rateMap.put("USD", BigDecimal.ONE); // 美元汇率为1
            log.info("Exchange rate updated: {}", rateMap);
        }
    }
}
