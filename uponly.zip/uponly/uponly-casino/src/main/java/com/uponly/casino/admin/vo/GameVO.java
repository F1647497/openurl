package com.uponly.casino.admin.vo;


import com.uponly.casino.common.utils.LanguageUtil;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Data
@Schema(title="真人游戏实体")
public class GameVO {

    @Schema(title="id")
    private Long gameId;

    @Schema(title="地区")
    private String region;

    @Schema(title="三方id")
    private Long pid;

    @Schema(title="三方game id")
    private String pgameId;

    @Schema(title="游戏名称")
    private String pgameName;

    @Schema(title="游戏名称编辑")
    private String nameEdit;

    @Schema(title="游戏图标")
    private String pgameIcon;

    @Schema(title="游戏图标编辑")
    private String iconEdit;

    @Schema(title="最低投注")
    private String minBet;

    @Schema(title="最高投注")
    private String maxBet;

    @Schema(title="游戏类型")
    private int gameType;

    @Schema(title="游戏状态")
    private int status;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Schema(title="创建时间")
    private Date createTime;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Schema(title="更新时间")
    private Date updateTime;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Schema(title="收藏游戏创建时间")
    private Date createAt;

    @Schema(title="排序")
    private int sort;

    @Schema(title="标签")
    private String tag;

    @Schema(title="收藏状态")
    private boolean favoriteState;

    @Schema(title = "近7日游戏人数")
    private int userCount7d;

    @Schema(title = "最终的英文名，仅用于按名字排序")
    private String gameNameEn;

    @Schema(title = "最终的英文名，仅用于按名字排序")
    private int userFavoriteCount;

    @Schema(title = "供应商名称")
    private String name;

    public void genActual(String langId) {
        genActualGameIcon();
        genActualGameName(langId);

    }

    // 生成实际的游戏图标
    public String genActualGameIcon() {
        pgameIcon = StringUtils.isNotBlank(iconEdit) ? iconEdit : pgameIcon;
        return pgameIcon;
    }

    // 生成实际的游戏名称
    public String genActualGameName(String langId) {
        String gameNameByLang = LanguageUtil.getName(nameEdit, langId);
        pgameName = StringUtils.isNotBlank(gameNameByLang) ? gameNameByLang : pgameName;
        return pgameName;
    }

}