package com.uponly.casino.provider.dto.evo.res;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class DebitResponse extends BalanceResponse {
    public DebitResponse(String uuid, String status, BigDecimal balance, BigDecimal bonus) {
        super(uuid, status, balance, bonus);
    }

    public DebitResponse() {
        super();
    }
}
