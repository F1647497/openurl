package com.uponly.casino.provider.dto.ae.req;

import lombok.Data;
import lombok.experimental.SuperBuilder;

@SuperBuilder
@Data
public class LoginReq {
    private String cert;
    private String agentId;
    private String userId;
    private String isMobileLogin;
    private String externalURL;
    private String platform="SEXYBCRT";
    private String gameType="LIVE";
    private String gameForbidden;
    private String language;
    private String betLimit = "";
    private String autoBetMode="1";
    private String currency;


    public LoginReq() {

    }

    public LoginReq(String cert, String agentId, String userId, String isMobileLogin, String externalURL, String platform, String gameType, String gameForbidden, String language, String betLimit, String autoBetMode, String currency) {
        this.cert = cert;
        this.agentId = agentId;
        this.userId = userId;
        this.isMobileLogin = isMobileLogin;
        this.externalURL = externalURL;
        this.platform = platform;
        this.gameType = gameType;
        this.gameForbidden = gameForbidden;
        this.language = language;
        this.betLimit = betLimit;
        this.autoBetMode = autoBetMode;
        this.currency = currency;
    }
}
