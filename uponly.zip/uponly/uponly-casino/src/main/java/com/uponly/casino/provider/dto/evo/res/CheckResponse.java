package com.uponly.casino.provider.dto.evo.res;

import com.alibaba.fastjson2.JSONObject;
import lombok.Data;

@Data
public class CheckResponse extends BaseResponse{
    private String sid;

    public CheckResponse() {
        super();
    }

    public JSONObject toJSONObject() {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("status", status);
        jsonObject.put("uuid", uuid);
        if (sid != null) {
            jsonObject.put("sid", sid);
        }
        return jsonObject;
    }
}
