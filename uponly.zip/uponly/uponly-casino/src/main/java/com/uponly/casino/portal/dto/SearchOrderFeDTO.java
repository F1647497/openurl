package com.uponly.casino.portal.dto;

import com.uponly.casino.admin.dto.PageInfoDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.List;

@Data
public class SearchOrderFeDTO extends PageInfoDTO {

    @Schema(title = "用户id")
    private Long userId;

    private List<Integer> pids;


    @Schema(title = "注单状态")
    private Integer status;

    @Schema(title = "游戏名称")
    private String gameName;

    @Schema(title = "游戏名称")
    private List<String> orderNoList;



}
