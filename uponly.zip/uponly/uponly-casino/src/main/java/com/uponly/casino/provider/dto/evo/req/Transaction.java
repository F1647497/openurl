package com.uponly.casino.provider.dto.evo.req;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Map;

@Data
public class Transaction {
    private String id;       // Unique transaction identifier
    private String refId;    // Reference identifier for transaction
    private BigDecimal amount;   // Amount of transaction, rounded to 6 decimal places

    public Transaction(String id, String refId, BigDecimal amount) {
        this.id = id;
        this.refId = refId;
        this.amount = amount;
    }

    public Transaction(Map<String, Object> map) {
        this.id = (String) map.get("id");
        this.refId = (String) map.get("refId");
        this.amount = BigDecimal.valueOf(Double.parseDouble(map.get("amount").toString()));
    }
}
