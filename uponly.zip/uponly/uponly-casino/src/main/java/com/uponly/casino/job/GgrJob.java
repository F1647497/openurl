package com.uponly.casino.job;

import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import com.alibaba.fastjson2.JSONObject;
import com.uponly.casino.admin.dto.UpdateMsgDTO;
import com.uponly.casino.admin.vo.OrderVO;
import com.uponly.casino.common.constant.CommonConstant;
import com.uponly.casino.common.enums.ReportType;
import com.uponly.casino.common.utils.RegionIntegerUtil;
import com.uponly.casino.provider.vo.UserInfoVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Component
public class GgrJob extends AbstractReportJob {

    protected DateTime startTime;
    protected DateTime endTime;
    protected ReportType reportType;

    private static String startTimeStr;
    private static String endTimeStr;

    public GgrJob() {
        reportType = ReportType.GGR;
    }

    /**
     * 毛利上报 上报要求已结算的数据
     */
    @Async("taskScheduler")
    @Scheduled(cron = "0 */1 * * * ?")
    public void execute() {
        startTime = DateUtil.offsetHour(DateUtil.date(), -30);
        endTime = DateUtil.offsetMinute(DateUtil.date(), -5);
        startTimeStr = DateUtil.format(startTime, DatePattern.NORM_DATETIME_MS_PATTERN);
        endTimeStr = DateUtil.format(endTime, DatePattern.NORM_DATETIME_MS_PATTERN);

        super.execute();

    }


    @Override
    protected String kafkaTopic() {
        return CommonConstant.CASINO_BETTING_JOB_TOPIC;
    }

    
    @Override
    protected String kafkaKey(Object data) {
        if (data instanceof OrderVO order) {
            return String.valueOf(order.getUserId());
        }
        return null;
    }

    @Override
    protected ReportType getReportType() {
        return reportType;
    }

    @Override
    protected void finishReporting(Object data) {
        if (data instanceof OrderVO order) {
            super.finishReporting(order.getOrderNo(), reportType);
        }
    }

    @Override
    protected String kafkaData(Object data) {
        if (!(data instanceof OrderVO order)) {
            log.error("【ggr注单上报】instanceof错误！data={}", data);
            return null;
        }
        Optional<UserInfoVO> userInfoOp = userInfoService.getUser(order.getUserId());
        if (userInfoOp.isEmpty()) {
            log.error("【ggr注单上报】userInfoFeige为空, OrderVO={}", order);
            return null;
        }
        UserInfoVO userInfo = userInfoOp.get();

        //将结算数据推送到报表
        String region = RegionIntegerUtil.lcationIdToRegion(userInfo.getLocation());
        //获取注单对应的供应商枚举
        log.info("【ggr注单上报】orderReportType={}", "EVO Casino");

        BigDecimal betAmount = order.getAmount();
        BigDecimal payout = order.getPayout();
        BigDecimal profitAmount = payout.subtract(betAmount);

        JSONObject body = new JSONObject();
        body.put("agentId", userInfo.getAgentId());
        body.put("userId", userInfo.getUserId());
        body.put("currency", userInfo.getCurrency());
        body.put("tag", userInfo.getTestTag());
        body.put("level", userInfo.getVip());
        body.put("star", userInfo.getStar());
        body.put("region", region);

        body.put("amount", profitAmount.negate()); // //用于计算毛利，用投注金额减去派彩金额
        body.put("betId", order.getOrderNo());
        body.put("gameType", "EVO Casino");

        body.put("copiedBetId", null);
        body.put("isTurnover", true);
        body.put("stakeType", "cash");

        int comparisonResult = profitAmount.compareTo(BigDecimal.ZERO);
        String stakeResult = comparisonResult == 0 ? "draw" : comparisonResult < 0 ? "lose" : "win";
        body.put("stakeResult", stakeResult);


        long ts = order.getSettleAt().getTime();
        String kafkaMsg = super.buildKafkaMessage(reportType.getType(), body, ts);
        log.debug("【ggr注单上报】build data success! startTime={},endTime={},kafka.msg={}", startTimeStr, endTimeStr, kafkaMsg);
        return kafkaMsg;
    }


    @Override
    protected List<Object> fetchData() {
        List<OrderVO> orders = orderMapper.selectOrderByReportState(startTime, endTime, reportType.getState(), 3);
        log.info("【ggr注单上报】fetch data success! startTime={},endTime={},count：{} ", startTimeStr, endTimeStr, orders.size());
//        return Collections.unmodifiableList(orders);
        List<String> originOrderIds = orders.stream().map(OrderVO::getOrderNo).collect(Collectors.toList());
        Set<String> unReportingOrders = super.batchAndMarkUnReportingOrders(originOrderIds, reportType);

        return orders.stream()
                .filter(order -> unReportingOrders.contains(order.getOrderNo()))
                .collect(Collectors.toList());
    }


    @Override
    protected void updateData(Object data) {
        OrderVO order = (OrderVO) data;

        UpdateMsgDTO updateMsgDTO = new UpdateMsgDTO();
        updateMsgDTO.setOrderNo(order.getOrderNo());
        updateMsgDTO.setMsgNumber(reportType.getState());
        Integer result = orderMapper.updateMsgState(updateMsgDTO);
        if (result > 0) {
            log.info("【ggr注单上报】上报成功！startTime={} endTime={} orderId={}", startTimeStr, endTimeStr, order.getId());
        } else {
            log.error("【ggr注单上报】上报失败！startTime={} endTime={} orderId={}", startTimeStr, endTimeStr, order.getId());
        }
    }

}
