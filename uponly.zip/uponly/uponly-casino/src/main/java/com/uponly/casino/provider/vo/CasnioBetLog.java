package com.uponly.casino.provider.vo;

import lombok.Data;
import io.swagger.v3.oas.annotations.media.Schema;
import java.sql.Timestamp;
import java.math.BigDecimal;

@Data
@Schema(title = "CasnioBetLog")
public class CasnioBetLog {

    @Schema(title = "id")
    private int id;

    @Schema(title = "会员ID")
    private int memberId;

    @Schema(title = "品牌ID")
    private int brandId;

    @Schema(title = "游戏种类ID")
    private int gameKindId;

    @Schema(title = "货币")
    private String currency;

    @Schema(title = "投注金额")
    private BigDecimal betAmount;

    @Schema(title = "有效投注金额")
    private BigDecimal effectiveAmount;

    @Schema(title = "净赢金额")
    private BigDecimal netWin;

    @Schema(title = "投注时间")
    private BigDecimal betTime;

    @Schema(title = "结算时间")
    private Timestamp settleTime;

    @Schema(title = "设备类型")
    private int deviceType;

    @Schema(title = "状态")
    private int status;

    @Schema(title = "订单号")
    private String orderNumber;

    @Schema(title = "最后修改时间")
    private Timestamp lastModifyTime;
}