package com.uponly.casino.portal.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.uponly.casino.mapper.GameOriginalMapper;
import com.uponly.casino.mapper.OrderMapper;
import com.uponly.casino.portal.service.CasinoBetOrderService;
import com.uponly.casino.portal.vo.OrderVOFe;
import com.uponly.casino.portal.vo.StatisticsVO;
import com.uponly.casino.provider.dto.GameInfoDTO;
import com.uponly.casino.provider.service.GameInfoService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.SerializationUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


@Slf4j
@Service
public class CasinoBetOrderServiceImpl implements CasinoBetOrderService {

    @Autowired
    private OrderMapper orderMapper;

    @Autowired
    private GameOriginalMapper gameOriginalMapper;

    @Autowired
    private GameInfoService gameInfoService;


    @Override
    public StatisticsVO statisticsList(Long userId, Integer region, String language) {
        StatisticsVO result = orderMapper.statisticsList(userId);
        if (ObjectUtils.isNotEmpty(result.getTotalPayout()) && result.getWinCount() > 0) {
            result.setAvgWinAmount(result.getTotalPayout().divide(new BigDecimal(result.getWinCount()), 6, RoundingMode.HALF_UP));
        }
        return result;
    }

    @Override
    public List<OrderVOFe> searchRecentGames(Long userId) throws JsonProcessingException {
        List<OrderVOFe> list = orderMapper.searchRecentGames(userId);

        List<OrderVOFe> newOrderList = new ArrayList<>();

        for (OrderVOFe orderVOFe : list) {

            OrderVOFe clonedOrderVOFe = SerializationUtils.clone(orderVOFe);

            String providerName = clonedOrderVOFe.getProviderName();
            String gameName = clonedOrderVOFe.getGameName();

            if (gameName != null && providerName != null) {
                String gameNameWithDash = gameName.replace(" ", "-");
                String ProviderNameWithDash = providerName.replace(" ", "-");

                String uniqueName = ProviderNameWithDash + "-" + gameNameWithDash;
                Optional<GameInfoDTO> GameInfoDTO = gameInfoService.getGameInfo(uniqueName);
                if (GameInfoDTO.isPresent()) {
                    clonedOrderVOFe.setGameName(GameInfoDTO.get().getName());
                    clonedOrderVOFe.setFullGameName(GameInfoDTO.get().getFullGameName());
                    clonedOrderVOFe.setTableIconDisplay(GameInfoDTO.get().getIcon());
                }
            }

            newOrderList.add(clonedOrderVOFe);
        }


        return newOrderList;
    }


}
