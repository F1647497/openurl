package com.uponly.casino.portal.controller;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.uponly.casino.portal.service.CasinoBetOrderService;
import com.uponly.casino.portal.vo.OrderVOFe;
import com.uponly.casino.portal.vo.StatisticsVO;
import com.uponly.casino.common.api.Result;
import com.uponly.casino.provider.service.UserInfoService;
import com.uponly.casino.ranking.RollingRankingService;
import com.uponly.casino.util.RegionIntegerUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.math.RoundingMode;
import java.util.List;
import java.math.BigDecimal;


@RestController
@Tag(name = "StatisticsController", description = "前台游戏统计")
@RequestMapping("/portal/statistics")
@Slf4j
public class StatisticsController {

    @Autowired
    CasinoBetOrderService  casinoBetOrderService;

    @Autowired
    private UserInfoService userInfoService;

    @Autowired
    protected RollingRankingService rollingRankingService;


    @Operation(summary = "查询个人统计数据")
    @RequestMapping(value = "/list", method = RequestMethod.POST)
    @ResponseBody
    public Result<StatisticsVO> statisticsList(@RequestHeader("Slanguage") String slanguage,
                                               @RequestParam("uid") Long uid,
                                               @RequestHeader("Sregion") Integer region) {
        if (uid == null) {
            return Result.fail("查询的用户ID不能为空");
        }

        try {
            // 获取uid对应的用户的信息
            var userInfo = userInfoService.getUser(uid);
            if (userInfo.isEmpty()) {
                return Result.fail("用户不存在");
            }

            var result = casinoBetOrderService.statisticsList(uid, region, slanguage);
            if (result == null) {
                return Result.fail("查询个人统计数据失败");
            }
            // 下面要针对 region 获取对应的currency
            var regionCurrency = RegionIntegerUtil.AreaToCurrency(region);
            // 对result的每条数据进行处理
//            var currency = userInfo.get().getCurrency();
//            if (currency.equals(regionCurrency)) {
//                return Result.success(result);
//            }
            // 下面对结果集中的数据进行处理
            // 获取用户的currency对应的汇率
            var rate = rollingRankingService.getRate(result.getCurrency());
            var rateRegion = rollingRankingService.getRate(regionCurrency);
            if (rateRegion.isEmpty()) {
                return Result.fail("请求地区获取汇率失败");
            }
            // 对result中的每个数据进行处理
            var averageBetAmount = result.getAverageBetAmount();
            if (averageBetAmount != null) {
                averageBetAmount = averageBetAmount.divide(rate.get(), 6, RoundingMode.HALF_UP).multiply(rateRegion.get()).setScale(2,BigDecimal.ROUND_HALF_UP);
                result.setAverageBetAmount(averageBetAmount);
            }
            var maxBetAmount = result.getMaxPayout();
            if (maxBetAmount != null) {
                maxBetAmount = maxBetAmount.divide(rate.get(), 6, RoundingMode.HALF_UP).multiply(rateRegion.get()).setScale(2,BigDecimal.ROUND_HALF_UP);
                result.setMaxPayout(maxBetAmount);
            }
            var totalBetAmount = result.getTotalPayout();
            if (totalBetAmount != null) {
                totalBetAmount = totalBetAmount.divide(rate.get(), 6, RoundingMode.HALF_UP).multiply(rateRegion.get()).setScale(2,BigDecimal.ROUND_HALF_UP);
                result.setTotalPayout(totalBetAmount);
            }
            var avgWinAmount = result.getAvgWinAmount();
            if (avgWinAmount != null) {
                avgWinAmount = avgWinAmount.divide(rate.get(), 6, RoundingMode.HALF_UP).multiply(rateRegion.get()).setScale(2,BigDecimal.ROUND_HALF_UP);
                result.setAvgWinAmount(avgWinAmount);
            }
            var totalPayAmount = result.getTotalBetAmount();
            if(totalPayAmount !=null){
                totalPayAmount = totalPayAmount.divide(rate.get(), 6, RoundingMode.HALF_UP).multiply(rateRegion.get()).setScale(2,BigDecimal.ROUND_HALF_UP);
                result.setTotalBetAmount(totalPayAmount);
            }

            return Result.success(result);
        } catch (Exception e) {
            log.error("查询个人统计数据 失败", e);
        }
        return null;
    }


    @Operation(summary = "查询最近游戏")
    @RequestMapping(value = "/searchRecentGames", method = RequestMethod.POST)
    @ResponseBody
    public Result<List<OrderVOFe>> searchRecentGames(@RequestParam("uid") Long uid,
                                                       @RequestHeader("Sregion") Integer region,
                                                       @RequestHeader("Slanguage") String slanguage) throws JsonProcessingException {


        try {
            var result = casinoBetOrderService.searchRecentGames(uid);
            if (result == null) {
                return Result.fail("查询最近游戏失败");
            }

            // 下面要针对 region 获取对应的currency
            var regionCurrency = RegionIntegerUtil.AreaToCurrency(region);
            // 获取用户的currency对应的汇率
            var rateRegion = rollingRankingService.getRate(regionCurrency);
            if (rateRegion.isEmpty()) {
                return Result.fail("获取汇率失败");
            }
// 对result中的每个数据进行处理
            BigDecimal rate = null;
            for (var order : result) {
                if (rate == null) {
                    var currency = order.getCurrency();
                    var rateOpt = rollingRankingService.getRate(currency);
                    if (rateOpt.isEmpty()) {
                        return Result.fail("获取汇率失败");
                    }
                    rate = rateOpt.get();
                }
                var amount = order.getTotalPayout();
                if (amount == null) {
                    continue;
                }
                amount = amount.divide(rate, 6, RoundingMode.HALF_UP).multiply(rateRegion.get());
                order.setTotalPayout(amount);
            }
            return Result.success(result);
        } catch (JsonProcessingException e) {
            log.error("查询最近游戏 失败", e);
        }
        return null;
    }

}
