package com.uponly.casino.admin.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class UpdateGameDTO {
    @Schema(title = "id")
    private int id;

    @Schema(title = "游戏名称编辑", nullable = true, maxLength = 1024)
    private String tableNameEdit;

    @Schema(title = "游戏图标", requiredMode = Schema.RequiredMode.REQUIRED, maxLength = 255)
    private String tableIconEdit;


}
