package com.uponly.casino.portal.service;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.uponly.casino.portal.vo.OrderVOFe;
import com.uponly.casino.portal.vo.StatisticsVO;

import java.util.List;

public interface CasinoBetOrderService {

    StatisticsVO statisticsList(Long userId, Integer region, String language);

    List<OrderVOFe> searchRecentGames(Long userId) throws JsonProcessingException;

}