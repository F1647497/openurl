package com.uponly.casino.provider.enums;

/***
 * 0 Success   :Indicates operation completed successfully
 * 1 Retryable Error :Failed adapter operation could be retried after getting such error
 * 2 Fatal Error
 * 3 Final error   Non-retryable error, but subsequent requests might reuse same session
 * ***/
public enum EVOStatusType {
    OK(0),
    TEMPORARY_ERROR(1),
    INVALID_TOKEN_ID(2),
    INVALID_SID(3),
    ACCOUNT_LOCKED(3),
    FATAL_ERROR_CLOSE_USER_SESSION(3),
    UNKNOWN_ERROR(4),
    INVALID_PARAMETER(4),
    BET_DOES_NOT_EXIST(4),
    BET_ALREADY_EXIST(0),
    BET_ALREADY_SETTLED(0),
    INSUFFICIENT_FUNDS(4),
    INSUFFICIENT_FUNDS_TIPS(4),
    FINAL_ERROR_ACTION_FAILED(4),
    GEOLOCATION_FAIL(4),
    BONUS_LIMIT_EXCEEDED(4),

    ;

    private final Integer type;

    EVOStatusType(Integer type) {
        this.type = type;
    }

    public Integer getType() {
        return type;
    }

    public static EVOStatusType getEnum(Integer type) {
        for (EVOStatusType enumToupAction : EVOStatusType.values()) {
            if (enumToupAction.getType().equals(type)) {
                return enumToupAction;
            }
        }
        return null;
    }
}
