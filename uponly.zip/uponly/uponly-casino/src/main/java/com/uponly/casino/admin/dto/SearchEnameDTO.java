package com.uponly.casino.admin.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class SearchEnameDTO {


    @Schema(description = "ename", nullable = true)
    private String ename;

    @Schema(description = "三方名称", nullable = true)
    private String providerName;

}
