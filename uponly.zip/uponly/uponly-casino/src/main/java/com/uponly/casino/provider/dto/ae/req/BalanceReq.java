package com.uponly.casino.provider.dto.ae.req;

import com.alibaba.fastjson2.JSONObject;
import com.uponly.casino.provider.dto.evo.req.Game;
import lombok.Data;

import java.util.Map;

@Data
public class BalanceReq {
    private String action;
    private String userId;

    public BalanceReq(Map<String, Object> body) {
        this.action = (String) body.get("action");
        this.userId = (String) body.get("userId");
    }
    public BalanceReq(JSONObject body) {
        this.action = (String) body.get("action");
        this.userId = (String) body.get("userId");
    }
}
