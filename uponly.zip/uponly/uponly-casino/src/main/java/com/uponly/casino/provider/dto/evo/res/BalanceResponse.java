package com.uponly.casino.provider.dto.evo.res;

import com.alibaba.fastjson2.JSONObject;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class BalanceResponse extends BaseResponse{
    protected BigDecimal balance; // Player's current balance
    protected BigDecimal bonus; // Player's bonus balance

    public BalanceResponse(String uuid, String status, BigDecimal balance, BigDecimal bonus) {
        super(status, uuid);
        this.balance = balance;
        this.bonus = bonus;
    }

    public BalanceResponse() {
        super();
    }

    public JSONObject toJSONObject() {
        JSONObject jsonObject =JSONObject.from(this);
        jsonObject.put("uuid", getUuid());
        jsonObject.put("status", getStatus());
        return jsonObject;
    }
}
