package com.uponly.casino.job;

import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import com.alibaba.fastjson2.JSONObject;

import com.uponly.casino.admin.dto.UpdateMsgDTO;
import com.uponly.casino.admin.vo.OrderVO;
import com.uponly.casino.admin.vo.StakeMsgVo;
import com.uponly.casino.common.constant.CommonConstant;
import com.uponly.casino.common.enums.ReportType;
import com.uponly.casino.provider.vo.UserInfoVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;


@Slf4j
@Component
public class StakeJob extends AbstractReportJob {

    protected DateTime startTime;
    protected DateTime endTime;
    protected ReportType reportType;

    private static String startTimeStr;
    private static String endTimeStr;

    public StakeJob() {
        reportType = ReportType.STAKE;
    }

    /**
     * 投注上报 统计人数主要 未有金额
     */
    @Async("taskScheduler")
    @Scheduled(cron = "0 */1 * * * ?")
    public void sendActiveMsgJob() {
        startTime = DateUtil.offsetHour(DateUtil.date(), -3);
        endTime = DateUtil.offsetMinute(DateUtil.date(), -5);
        startTimeStr = DateUtil.format(startTime, DatePattern.NORM_DATETIME_MS_PATTERN);
        endTimeStr = DateUtil.format(endTime, DatePattern.NORM_DATETIME_MS_PATTERN);

        super.execute();
    }


    @Override
    protected String kafkaTopic() {
        return CommonConstant.CASINO_BETTING_JOB_TOPIC;
    }

    @Override
    protected String kafkaKey(Object data) {
        if (data instanceof OrderVO order) {
            return String.valueOf(order.getUserId());
        }
        return null;
    }

    @Override
    protected ReportType getReportType() {
        return reportType;
    }

    @Override
    protected void finishReporting(Object data) {
        if (data instanceof OrderVO order) {
            super.finishReporting(order.getOrderNo(), reportType);
        }
    }

    @Override
    protected String kafkaData(Object data) {
        if (!(data instanceof OrderVO order)) {
            log.error("【stake注单上报】instanceof错误！data={}", data);
            return null;
        }
        Optional<UserInfoVO> userInfoOp = userInfoService.getUser(order.getUserId());
        if (userInfoOp.isEmpty()) {
            log.error("【stake注单上报】userInfoFeige为空, OrderVO={}", order);
            return null;
        }
        UserInfoVO userInfo = userInfoOp.get();

        //获取注单对应的供应商枚举
        String providerType = "EVO Casino";
        StakeMsgVo stakeInfo = StakeMsgVo.createStakeInfo(userInfo, providerType, order.getOrderNo(), order.getAmount());
        long ts = order.getCreatedAt().getTime();
        String kafkaMsg = super.buildKafkaMessage(reportType.getType(), JSONObject.from(stakeInfo), ts);
        log.debug("【stake注单上报】build data success! startTime={},endTime={},kafka.msg={}", startTimeStr, endTimeStr, kafkaMsg);
        return kafkaMsg;
    }

    @Override
    protected List<Object> fetchData() {
        List<OrderVO> orders = orderMapper.selectOrderByReportState(startTime, endTime, reportType.getState(), null);
        log.info("【stake注单上报】fetch data success! startTime={},endTime={},count：{} ", startTimeStr, endTimeStr, orders.size());
//        return Collections.unmodifiableList(orders);
        List<String> originOrderIds = orders.stream().map(OrderVO::getOrderNo).collect(Collectors.toList());
        Set<String> unReportingOrders = super.batchAndMarkUnReportingOrders(originOrderIds, reportType);

        return orders.stream()
                .filter(order -> unReportingOrders.contains(order.getOrderNo()))
                .collect(Collectors.toList());
    }

    @Override
    protected void updateData(Object data) {
        OrderVO order = (OrderVO) data;

        UpdateMsgDTO updateMsgDTO = new UpdateMsgDTO();
        updateMsgDTO.setOrderNo(order.getOrderNo());
        updateMsgDTO.setMsgNumber(reportType.getState());

        Integer result = orderMapper.updateMsgState(updateMsgDTO);
        if (result > 0) {
            log.info("【stake注单上报】上报成功！startTime={} endTime={} orderId={}", startTimeStr, endTimeStr, order.getId());
        } else {
            log.error("【stake注单上报】上报失败！startTime={} endTime={} orderId={}", startTimeStr, endTimeStr, order.getId());
        }
    }
}
