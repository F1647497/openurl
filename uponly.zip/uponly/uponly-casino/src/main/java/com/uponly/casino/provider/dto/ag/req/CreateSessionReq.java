package com.uponly.casino.provider.dto.ag.req;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class CreateSessionReq {
    @JsonProperty("productid")
    private String productId;      // 代理编码
    private String username;// 游戏账号的登录名
    @JsonProperty("session_token")
    private String sessionToken; //验证编码，会发送到及储存在遊戏平台的数据库，最高为64 码。只能使用英文字母、數字和’-‘
    private String credit;       //账户余额，必须为非负数。

    public CreateSessionReq() {

    }

    public CreateSessionReq(String productId, String username, String sessionToken, String credit) {
        this.productId = productId;
        this.username = username;
        this.sessionToken = sessionToken;
        this.credit = credit;

    }


}
