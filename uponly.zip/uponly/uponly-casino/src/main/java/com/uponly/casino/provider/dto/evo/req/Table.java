package com.uponly.casino.provider.dto.evo.req;

import lombok.Data;

import java.util.Map;

@Data
public class Table {
    private String id;  // Table identifier
    private String vid; // Unique virtual table identifier, can be null

    public Table(String id, String vid) {
        this.id = id;
        this.vid = vid;
    }

    public Table(Map<String, Object> map) {
        this.id = (String) map.get("id");
        this.vid = (String) map.get("vid");
    }

    public Table() {
    }
}
