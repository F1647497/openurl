package com.uponly.casino.portal.service;

import com.uponly.casino.portal.dto.HeaderDTO;
import jakarta.servlet.http.HttpServletRequest;

public interface HeaderService {
    HeaderDTO getHeaderInfo(HttpServletRequest request);
}
