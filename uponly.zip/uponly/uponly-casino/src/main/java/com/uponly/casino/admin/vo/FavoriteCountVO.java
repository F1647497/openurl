package com.uponly.casino.admin.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class FavoriteCountVO implements java.io.Serializable {
    @Schema(title="eid")
    private Long eid;

    @Schema(title="收藏数")
    private int favoriteCount;


}
