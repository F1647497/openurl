package com.uponly.casino.portal.service;

import com.uponly.casino.portal.dto.FavoriteDTO;
import com.uponly.casino.portal.vo.FavoriteVO;

import java.util.List;

/**
 * Created by Administrator on 2018/4/19.
 */
public interface FavoriteService {

    boolean exists(FavoriteDTO favoriteDTO);

    Long add(FavoriteDTO usersFavorite);

    int delete(FavoriteDTO favoriteDTO);


    List<String> list(Long userId, boolean isNeedSort);

}
