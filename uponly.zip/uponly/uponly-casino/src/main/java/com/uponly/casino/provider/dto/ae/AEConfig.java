package com.uponly.casino.provider.dto.ae;
import com.alibaba.fastjson2.JSON;
import com.uponly.casino.admin.vo.ProviderVO;
import lombok.Data;

@Data
public class AEConfig {
    private String baseUrl;
    private String cert;
    private String agentId;
    private String betLimit;
    private String prefix;
    private String currency;
    private String backUrl;

    public AEConfig(ProviderVO providerVo) {
        String config = providerVo.getConfig();
        AEConfig aeConfig = JSON.parseObject(config, AEConfig.class);
        this.setBaseUrl(aeConfig.getBaseUrl());
        this.setBetLimit(aeConfig.getBetLimit());
        this.setCert(aeConfig.getCert());
        this.setPrefix(aeConfig.getPrefix());
        this.setCurrency(aeConfig.getCurrency());
        this.setAgentId(aeConfig.getAgentId());
        this.setBackUrl(aeConfig.getBackUrl());
    }
    public AEConfig() {

    }
}
