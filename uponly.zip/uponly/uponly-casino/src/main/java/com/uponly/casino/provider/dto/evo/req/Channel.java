package com.uponly.casino.provider.dto.evo.req;

import lombok.Data;

import java.util.Map;

@Data
public class Channel {
    private String type; // Player's device type (M for mobile, P for anything else)

    public Channel(String type) {
        this.type = type;
    }

    public Channel(Map<String, Object> map) {
        this.type = (String) map.get("type");
    }
}
