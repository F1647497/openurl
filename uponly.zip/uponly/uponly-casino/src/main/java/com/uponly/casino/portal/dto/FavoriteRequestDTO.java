package com.uponly.casino.portal.dto;

import lombok.Data;

@Data
public class FavoriteRequestDTO extends BaseRequestDTO {
}
