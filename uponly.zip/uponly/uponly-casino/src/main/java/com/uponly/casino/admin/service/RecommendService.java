package com.uponly.casino.admin.service;

import com.github.pagehelper.PageInfo;
import com.uponly.casino.admin.dto.RecommendDTO;
import com.uponly.casino.admin.dto.SearchRecommendDTO;
import com.uponly.casino.admin.vo.RecommendGameVO;

import java.util.Optional;

public interface RecommendService {

    int add(RecommendDTO recommendGame);

    PageInfo<RecommendGameVO> searchRecommendGame(SearchRecommendDTO searchRecommendDTO);

    Optional<Integer> maxSort();

    int update(RecommendDTO recommendDTO);

    int delete(RecommendDTO recommendDTO);
}

