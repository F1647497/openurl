package com.uponly.casino.ranking.controller;

import com.uponly.casino.ranking.RollingRankingService;
import com.uponly.casino.ranking.dto.LiveWinDTO;
import com.uponly.casino.common.api.Result;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@Slf4j
@Tag(name = "RollingRankingController", description = "排行榜接口")
@RequestMapping(value = "/ranking")
public class RollingRankingController {
    @Autowired
    private RollingRankingService rollingRankingService;

    @RequestMapping(value = "/liveWins", method = RequestMethod.POST)
    @ResponseBody
    public Result<?> handleLiveWins(@RequestBody LiveWinDTO body,
                                                    @RequestHeader("Sregion") String sregion) {
        try {
            log.info("Received request: {}", body);
            body.setLocation(Integer.valueOf(sregion));

            var result = rollingRankingService.getLiveWins(body);
            return Result.success(result);
        } catch (Exception e) {
            log.error("Exception occurred: {}", e.getMessage());
            return Result.fail("Invalid request");
        }
    }

    @RequestMapping(value = "/livebigwins", method = RequestMethod.GET)
    @ResponseBody
    public Result<?> handleLiveBigWins(@RequestHeader("Sregion") String sregion) {
        Integer location = Integer.valueOf(sregion);
        try {
            var result = rollingRankingService.getLiveBigWins(location);
            return Result.success(result);
        } catch (Exception e) {
            log.error("Exception occurred: {}", e.getMessage());
            return Result.fail("Invalid request");
        }
    }
}
