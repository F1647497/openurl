package com.uponly.casino.admin.service;

import com.github.pagehelper.PageInfo;
import com.uponly.casino.admin.dto.AddProviderDTO;
import com.uponly.casino.admin.dto.DeleteProviderDTO;
import com.uponly.casino.admin.dto.SearchProviderDTO;
import com.uponly.casino.admin.dto.UpdateProviderDTO;
import com.uponly.casino.admin.vo.ProviderVO;

import java.util.List;
import java.util.Optional;

public interface ProviderService {
    Long add(AddProviderDTO addProviderDTO);

    PageInfo<ProviderVO> search(SearchProviderDTO provider);

    int delete(DeleteProviderDTO deleteProviderDTO);

    int update(UpdateProviderDTO provider);

    Optional<Integer> maxSort();

    List<ProviderVO> providers();
}

