package com.uponly.casino.provider.dto.evo;
import com.alibaba.fastjson2.JSONObject;
import com.uponly.casino.admin.vo.ProviderVO;
import com.uponly.casino.provider.dto.ag.AgConfig;
import com.uponly.casino.util.AESUtil;
import lombok.Data;

import java.util.Map;

@Data
public class Config {
    private String baseUrl;
    private String privateKey;
    private String merchantId;
    private String ua2Token;
    private String ecToken;
    private String gameHistoryApiToken;
    private String externalLobbyApiToken;
    private String rewardGameToken;
    private String owAuthToken;
    private String backUrl;

    public Config(ProviderVO providerVo) {
        String configStr= providerVo.getPrivateConfig(providerVo).get();
        Config config = JSONObject.parseObject(configStr,Config.class);
        this.baseUrl=config.getBaseUrl();
        this.privateKey=config.getPrivateKey();
        this.merchantId=config.getMerchantId();
        this.ua2Token=config.getUa2Token();
        this.ecToken=config.getEcToken();
        this.gameHistoryApiToken=config.getGameHistoryApiToken();
        this.externalLobbyApiToken=config.getExternalLobbyApiToken();
        this.rewardGameToken=config.getRewardGameToken();
        this.owAuthToken=config.getOwAuthToken();
        this.backUrl=config.getBackUrl();
    }
    public Config() {

    }
}
