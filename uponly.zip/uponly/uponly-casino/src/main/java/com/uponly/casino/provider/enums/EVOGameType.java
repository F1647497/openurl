package com.uponly.casino.provider.enums;


public enum EVOGameType {
    BACCARAT("baccarat","baccarat"),
    RNG_BACCARAT("baccarat","rng-baccarat"),

    BLACKJACK("blackjack","blackjack"),
    POWER_BJ("blackjack","powerscalableblackjack"),
    SCALA_BJ("blackjack","scalableblackjack"),
    FREE_BET_BJ("blackjack","freebet"),
    LIGHTNING_BJ("blackjack","lightningscalablebj"),
    FUN_FUN_BJ("blackjack","funfun21scalablebj"),
    CLASSIC_BJ("blackjack","classicfreebet"),
    RNG_BLACKJACK("blackjack","rng-blackjack"),

    DT("dragonTiger","dragontiger"),
    LT_DT("dragonTiger","dragontiger"),

    BAC_BO("baccarat","bacbo"),//百家寶

    FOOTBALL_STUDIO("game_shows","topcard"),
    KDBS("game_shows","topcard"),//TC_X
    FOOTBALL_STUDIO_DICE("game_shows","topdice"),///TD_X

    CASIO_HOLDEM("poker","holdem"),
    ULTIMATE_TEXAS_HOLDEM("poker","uth"),
    EXTREME_TEXAS_HOLDEM("poker","eth"),
    THREE_CARD_POKER("poker","tcp"),
    TRIPLE_CARD_POKER("poker","trp"),
    CARIBBEAN_STUD_POKER("poker","csp"),
    TEXAS_HOLDEM_BONUS_POKER("poker","thb"),
    SECOND_HAND_CASINO_HOLDEM("poker","dhp"),


    ;

    private final String type;
    private final String name;

    EVOGameType(String type, String name) {
        this.type = type;
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public static EVOGameType getEnumByName(String name) {
        for (EVOGameType gameEnum : EVOGameType.values()) {
            if (gameEnum.getName().equals(name)) {
                return gameEnum;
            }
        }
        return null;
    }

    public String getName() {
        return name;
    }
}
