package com.uponly.casino.provider.controller;

import cn.hutool.json.XML;
import com.alibaba.fastjson2.JSONObject;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.uponly.casino.provider.dto.RequestDTO;
import com.uponly.casino.provider.service.ProviderManager;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URLDecoder;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

@RestController
@Slf4j
@Tag(name = "ProviderController", description = "三方回调接口")
@RequestMapping(value = "/notify")
public class NotifyController {
    @Autowired
    ProviderManager providerManager;
    @Autowired
    ObjectMapper objectMapper;
    @PostMapping(value = "/{provider}/{methodName}", consumes = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_FORM_URLENCODED_VALUE,MediaType.TEXT_PLAIN_VALUE ,  MediaType.TEXT_XML_VALUE})
    @Transactional(rollbackFor = Exception.class)
    public ResponseEntity<?> handleNotification(@RequestParam Map<String, Object> params,
                                                @RequestHeader Map<String, Object> headers,
                                                @RequestBody String body,
                                                @PathVariable String provider,
                                                @PathVariable String methodName) {
        try {
            log.info("provider -----"+provider+" methodName-----"+methodName);

            var instance = providerManager.getInstance(provider);
            if (instance == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Provider not found");
            }
            System.out.println(instance.getBodyType());
            var requestDTO = new RequestDTO(methodName, params, headers);
            switch (instance.getBodyType()) {
                case JSON:
                case FORM:
                    requestDTO.setBody(parseJsonToMap(body));
                    break;
                case XML:
                    requestDTO.setBody(parseXmlToMap(body));
                    break;
                case TEXT:
                    requestDTO.setBody(parseTextToMap(body));
                    break;
            }
            //
            // 验证方法是否允许被调用
            Method method = Arrays.stream(instance.getClass().getDeclaredMethods())
                    .filter(m -> m.getName().equals(methodName) && m.getParameterCount() == 1 && m.getParameterTypes()[0].equals(RequestDTO.class))
                    .findFirst()
                    .orElseThrow(() -> new NoSuchMethodException("Method not allowed or does not exist"));

            // 调用方法
            Object result = method.invoke(instance, requestDTO);
            log.info("provider:{} ,methodName : {}, result:{}",provider,methodName,result);
            return ResponseEntity.ok(result);
        } catch (InvocationTargetException ite) {
            log.error("err: ",ite);
            Throwable targetException = ite.getTargetException();
            log.error("Error executing method: {}", targetException.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error processing request");
        } catch (Exception e) {
            log.error("err: ",e);
            log.error("Exception occurred: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid request");
        }
    }

    private Map<String, Object> parseTextToMap(String body) {
        HashMap<String, Object> bodyMap = new HashMap<>();
        bodyMap.put("param",body);
        return bodyMap;
    }

    @PostMapping(value = "/{provider}", consumes = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_FORM_URLENCODED_VALUE })
    @Transactional(rollbackFor = Exception.class)
    public ResponseEntity<?> handleNotificationWithoutMethod(@RequestParam Map<String, Object> params,
                                                             @RequestHeader Map<String, Object> headers,
                                                             @RequestBody String body,
                                                             @PathVariable String provider) {
        try {
            log.info("provider -----"+provider + "body-----"+body);

            var instance = providerManager.getInstance(provider);
            if (instance == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Provider not found");
            }
            String methodName = "";
            var requestDTO = new RequestDTO(methodName, params, headers);
            switch (instance.getBodyType()) {
                case JSON:
                case FORM:
                    requestDTO.setBody(parseJsonToMap(body));
                    break;
                case URL_ENCODE:
                    requestDTO.setBody(parseUrlToMap(body));
                    break;
                case XML:
                    requestDTO.setBody(parseXmlToMap(body));
                    break;
            }
            //特别处理当第三方不能使用path variable 区分方法
            switch (provider){
                case "ae":
                    Object message  = requestDTO.getBody().get("message");
                    JSONObject jsonObject = JSONObject.parseObject( URLDecoder.decode(String.valueOf(message), "UTF-8"));
                    methodName = String.valueOf(jsonObject.get("action"));
                    requestDTO.setMethod(methodName);
            }

            String finalMethodName = methodName;
            Method method = Arrays.stream(instance.getClass().getDeclaredMethods())
                    .filter(m -> m.getName().equals(finalMethodName) && m.getParameterCount() == 1 && m.getParameterTypes()[0].equals(RequestDTO.class))
                    .findFirst()
                    .orElseThrow(() -> new NoSuchMethodException("Method not allowed or does not exist"));

            // 调用方法
            Object result = method.invoke(instance, requestDTO);
            log.info("provider:{} ,methodName : {}, result:{}",provider,methodName,result);
            return ResponseEntity.ok(result);
        } catch (InvocationTargetException ite) {
            log.error("err: ",ite);
            Throwable targetException = ite.getTargetException();
            log.error("Error executing method: {}", targetException.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error processing request");
        } catch (Exception e) {
            log.error("err: ",e);
            log.error("Exception occurred: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid request");
        }
    }
    private Map<String, Object> parseXmlToMap(String xml) throws Exception {
        cn.hutool.json.JSONObject js=XML.toJSONObject(xml);
        return convertJSONObjectToMap(js);
    }

    private Map<String, Object> convertJSONObjectToMap(cn.hutool.json.JSONObject jsonObject) {
        Map<String, Object> resultMap = new HashMap<>();
        for (String key : jsonObject.keySet()) {
            Object value = jsonObject.get(key);
            if (value instanceof JSONObject) {
                resultMap.put(key, convertJSONObjectToMap((cn.hutool.json.JSONObject) value));
            } else {
                resultMap.put(key, value);
            }
        }
        return resultMap;
    }
    private Map<String, Object> parseJsonToMap(String json) throws IOException {
        // 使用 ObjectMapper 解析 JSON 字符串，并转换为 Map
        return objectMapper.readValue(json, Map.class);
    }
    private Map<String, Object> parseUrlToMap(String json) throws IOException {
        // 使用 ObjectMapper 解析 JSON 字符串，并转换为 Map
        return extractParams(json);
    }

    private static Map<String, Object> extractParams(String decodedString) {
        Map<String, Object> params = new HashMap<>();
        String[] pairs = decodedString.split("&");
        for (String pair : pairs) {
            String[] keyValue = pair.split("=", 2); // Split into key and value, limit to 2 parts
            if (keyValue.length == 2) {
                params.put(keyValue[0], keyValue[1]);
            } else {
                params.put(keyValue[0], ""); // Handle case where there is no value
            }
        }
        return params;
    }
}
