package com.uponly.casino.admin.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class SearchGame2DTO extends PageInfoDTO {
    @Schema(description = "供应商名称", nullable = true)
    private String providerName;


    @Schema(description = "荷官id", nullable = true)
    private String dealerId;

    @Schema(description = "荷官姓名", nullable = true)
    private String dealerName;

    @Schema(description = "游戏类型", nullable = true)
    private String gameType;

    @Schema(description = "桌台id", nullable = true)
    private String tableId;

    @Schema(description = "桌台名称", nullable = true)
    private String tableName;

    @Schema(description = "营业状态", nullable = true)
    private Integer open;


}
