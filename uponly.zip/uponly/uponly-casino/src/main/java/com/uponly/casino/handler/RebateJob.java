//package com.uponly.casino.handler;
//
//
//import com.alibaba.fastjson.JSONObject;
//import com.uponly.casino.admin.dto.UpdateMsgDTO;
//import com.uponly.casino.admin.vo.RebateMsgVO;
//import com.uponly.casino.common.utils.GUIDUtils;
//import com.uponly.casino.admin.service.GetRedisDataService;
//import com.uponly.casino.job.AbstractReportJob;
//import com.uponly.casino.mapper.OrderMapper;
//import com.uponly.casino.provider.service.UserInfoService;
//import com.uponly.casino.provider.vo.UserInfoVO;
//import lombok.extern.slf4j.Slf4j;
//import org.redisson.api.RLock;
//import org.redisson.api.RedissonClient;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.kafka.core.KafkaTemplate;
//import org.springframework.kafka.support.SendResult;
//import org.springframework.stereotype.Service;
//
//import java.math.BigDecimal;
//import java.time.LocalDate;
//import java.util.*;
//import java.util.concurrent.CompletableFuture;
//
//
//@Service
//@Slf4j
//public class RebateJob extends AbstractReportJob {
//    @Autowired
//    private KafkaTemplate<String, String> kafkaTemplate;
//
//    @Autowired
//    RedissonClient redissonClient;
//
//    @Autowired
//    UserInfoService userInfoService;
//
//    @Autowired
//    GetRedisDataService getRedisDataService;
//
//    @Autowired
//    OrderMapper orderMapper;
//
//
//    public void sendRebateMsg(List<String> orderListRedis) {
//        RLock lock = redissonClient.getLock("sendRebateMsg");
//        try {
//            // 从redis中获取casino注单列表，然后一次性发送订单数组到kafka
//            lock.lock();
//            List<RebateMsgVO> rebateMsgVOList = this.generateMsg(orderListRedis);
//            for (RebateMsgVO rebateMsgVO : rebateMsgVOList) {
//                CompletableFuture<SendResult<String, String>> future = this.sendRebateMsgJob(rebateMsgVO);
//                log.info("【sendRebateMsgJob】的发送结果={}", future);
//            }
//        } catch (Exception e) {
//            log.error("sendRebateMsg异常 ", e);
//        } finally {
//            lock.unlock();
//        }
//    }
//
//    public List<RebateMsgVO> generateMsg(List<String> orderListRedis) {
//        Map<Long, RebateMsgVO> rebateMsgMap = new HashMap<>();
//        try {
//            for (String orderJsonString : orderListRedis) {
//                JSONObject jsonObject = JSONObject.parseObject(orderJsonString);
//
//                Long userId = jsonObject.getLong("userId");
//                RebateMsgVO rebateMsgVO = rebateMsgMap.getOrDefault(userId, new RebateMsgVO());
//
//                Optional<UserInfoVO> userInfoVO = userInfoService.getUser(userId);
//                userInfoVO.ifPresent(userInfo -> {
//                    int level = userInfo.getVip();
//                    BigDecimal amount = jsonObject.getBigDecimal("amount");
//                    BigDecimal payout = jsonObject.getBigDecimal("payout");
//                    String currency = jsonObject.getString("currency");
//                    String orderNo = jsonObject.getString("orderNo");
//
//
//                    rebateMsgVO.setOrderNo(orderNo);
//                    rebateMsgVO.setUserId(userId);
//
//                    String gameResult = jsonObject.getString("gameResult");
//                    BigDecimal effectiveBet = super.getEffectiveAmount(amount, gameResult);
//
//                    rebateMsgVO.setBetAmount(rebateMsgVO.getBetAmount().add(effectiveBet));
//                    rebateMsgVO.setWinAmount(rebateMsgVO.getWinAmount().add(amount.subtract(payout)));
//                    rebateMsgVO.setExchange(currency);
//                    rebateMsgVO.setVipLevel(level);
//                    rebateMsgVO.setLocation(userInfo.getLocation());
//                    rebateMsgVO.setAgentId(userInfo.getAgentId());
//                    rebateMsgVO.setCurrency(currency);
//
//                    //     CompletableFuture<SendResult<String, String>> future = remoteKafkaService.send(CommonConstant.CASINO_BETTING_JOB_TOPIC, msgOfBettingForKafka);
//                    //用5个位置 表示发送消息的状态，1表示已发送，0 未发送，
//                    // 消息所在位置：AmountMsg：第1位；GgrMsg：第2位；ActiveMsg：第3位；GgrMsg：第4位；BetMsg：第5位；RebateMsg
//                    UpdateMsgDTO updateMsgDTO = new UpdateMsgDTO();
//                    updateMsgDTO.setOrderNo(orderNo);
//                    updateMsgDTO.setMsgNumber(0b00001);
//
//                    log.info("rebate更新消息状态参数 = {}", updateMsgDTO);
//                    Integer count = orderMapper.updateMsgState(updateMsgDTO);
//                    log.info("rebate更新消息状态数量 = {}", count);
//
//
//                    rebateMsgMap.put(userId, rebateMsgVO);
//                });
//            }
//        } catch (Exception e) {
//            log.error("generateMsg 异常{} ", e.getMessage());
//        }
//
//        return new ArrayList<>(rebateMsgMap.values());
//    }
//
//    public CompletableFuture<SendResult<String, String>> sendRebateMsgJob(RebateMsgVO rebateMsgVO) {
//        try {
//            rebateMsgVO.setOrderNo(rebateMsgVO.getOrderNo());
//            rebateMsgVO.setUserId(rebateMsgVO.getUserId());
//            rebateMsgVO.setBetAmount(rebateMsgVO.getBetAmount());
//            rebateMsgVO.setWinAmount(rebateMsgVO.getWinAmount());
//            rebateMsgVO.setCreateTime(new Date());
//
//            rebateMsgVO.setExchange(rebateMsgVO.getExchange());
//            rebateMsgVO.setVipLevel(rebateMsgVO.getVipLevel());
//            rebateMsgVO.setLocation(rebateMsgVO.getLocation());
//            rebateMsgVO.setAgentId(rebateMsgVO.getAgentId());
//            rebateMsgVO.setCurrency(rebateMsgVO.getCurrency());
//            rebateMsgVO.setBatchDate(this.getBatchDate(LocalDate.now()));
//
//            rebateMsgVO.setType("");
//
//            JSONObject jsonObject = new JSONObject();
//            jsonObject.put("messageType", "casinoActivityOrder");
//            jsonObject.put("messageBody", rebateMsgVO);
//            String msgOfRebate = jsonObject.toJSONString();
//            log.info("【Rebate 注单上报】 RebateMsg={}", msgOfRebate);
//            //      CompletableFuture<SendResult<String, String>> future = kafkaTemplate.send(CommonConstant.CASINO_ACTIVITY_TOPIC, msgOfRebate);
//            CompletableFuture<SendResult<String, String>> future = super.executeRebate(rebateMsgVO.getUserId(), msgOfRebate);
//
//
//            System.out.println("future-----" + future);
//            return future;
//        } catch (Exception e) {
//            log.error("sendRebateMsgJob 异常{} ", e.getMessage());
//
//        }
//        return null;
//    }
//
//    private String getBatchDate(LocalDate date) {
//        // 如果今天是周一，返回上周一的日期
//        if (date.getDayOfWeek().getValue() == 1) {
//            return date.minusDays(7).toString().replace("-", "");
//        } else if (date.getDayOfWeek().getValue() > 1 && date.getDayOfWeek().getValue() <= 7) {
//            // 如果今天是周二到周日，返回本周一的日期
//            return date.minusDays(date.getDayOfWeek().getValue() - 1).toString().replace("-", "");
//        }
//        return "";
//    }
//
//
//}