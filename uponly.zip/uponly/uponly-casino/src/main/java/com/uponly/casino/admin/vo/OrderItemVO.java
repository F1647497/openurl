package com.uponly.casino.admin.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.Getter;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.util.Date;

@Schema(title = "真人子注单实体")
@Data
public class OrderItemVO {

    @Schema(title = "id")
    private Integer id;

    @Schema(title = "主表ID")
    private Integer casinoOrderId;

    @Schema(title = "第三方注单号")
    private String orderNo;

    @Schema(title = "第三方交易ID")
    private String transactionId;

    @Schema(title = "注单回合ID")
    private String roundId;

    @Schema(title = "用户id")
    private Long userId;

    @Schema(title = "投注金额")
    private BigDecimal amount;

    @Schema(title = "有效投注金额")
    private BigDecimal effectiveAmount;

    @Schema(title = "结算或者取消金额")
    private BigDecimal payout;

    @Schema(title = "换算成USD后的Payout金额")
    private BigDecimal usdPayout;

    @Schema(title = "注单状态")
    private Integer result;

    @Schema(title = "投注类型")
    private String betType;

    @Schema(title = "子注单详情")
    private String itemPayload;

    @Schema(title = "倍数")
    private BigDecimal multiplier;

    @Schema(title = "投注时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createdAt;

    @Schema(title = "结算时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date settleAt;


    @Getter
    public static enum EnumOrderItemResult{
        PENDING(0, "初始化","Pending"),
        WIN(1, "赢局","Win"),
        LOSE(2, "输局","Lose"),
        DRAW(3, "合局","Tie"),
        CANCEL(4, "取消","Cancel");
        private Integer code;
        private String calName;
        private String desc;

        EnumOrderItemResult(Integer code, String desc, String calName) {
            this.code = code;
            this.desc = desc;
            this.calName = calName;
        }

        public static EnumOrderItemResult getEnumByCalName(String calName) {
            for (EnumOrderItemResult enumToupAction : EnumOrderItemResult.values()) {
                if (enumToupAction.getCalName().equals(calName)) {
                    return enumToupAction;
                }
            }
            return null;
        }
        public static EnumOrderItemResult getEnumByName(String name) {
            for (EnumOrderItemResult enumToupAction : EnumOrderItemResult.values()) {
                if (enumToupAction.name().equals(name)) {
                    return enumToupAction;
                }
            }
            return null;
        }
        public static EnumOrderItemResult getEnumByCode(Integer code) {
            for (EnumOrderItemResult enumToupAction : EnumOrderItemResult.values()) {
                if (enumToupAction.getCode().equals(code)) {
                    return enumToupAction;
                }
            }
            return null;
        }
    }
}