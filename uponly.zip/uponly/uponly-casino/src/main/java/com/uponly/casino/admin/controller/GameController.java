package com.uponly.casino.admin.controller;

import com.github.pagehelper.PageInfo;
import com.uponly.casino.admin.dto.SearchGame2DTO;
import com.uponly.casino.admin.dto.UpdateGameDTO;
import com.uponly.casino.admin.service.GameService;
import com.uponly.casino.admin.vo.GameOriginalVO;
import com.uponly.casino.admin.vo.GameSearch;
import com.uponly.casino.common.api.Result;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/game")
@Tag(name = "GameController", description = "游戏管理")
public class GameController {

    @Autowired
    private GameService gameService;

    @ResponseBody
    @Operation(summary = "添加游戏")
    @PostMapping("/add")
    public Result<String> add(@RequestBody GameOriginalVO gameOriginalVO) {
        try {
            var gameId = gameService.addGames(gameOriginalVO);
            if (gameId == 0) {
                return Result.fail("添加游戏失败");
            }
            return Result.success("添加游戏成功", null);
        } catch (Exception e) {
            return Result.fail("添加游戏失败", e.getMessage());
        }
    }

    @ResponseBody
    @Operation(summary = "查询游戏")
    @PostMapping("/search")
    public Result<PageInfo<GameSearch>> search(@RequestBody SearchGame2DTO searchGame2DTO) {
        PageInfo<GameSearch> pageInfo = gameService.search(searchGame2DTO);
        return Result.success(pageInfo);
    }

    @Operation(summary = "更新游戏")
    @PostMapping("/update")
    public Result<String> update(@RequestBody UpdateGameDTO updateGameDTO) {
        try {
            int updated = gameService.update(updateGameDTO);
            if (updated == 0) {
                return Result.fail("更新游戏失败");
            }
            return Result.success("更新游戏成功", null);
        } catch (Exception e) {
            e.printStackTrace();
            return Result.fail("更新游戏失败", e.getMessage());
        }
    }

 /*   @ResponseBody
    @Operation(summary = "添加游戏")
    @PostMapping("/add")
    public Result<String> add(@RequestBody AddGameDTO addGameDTO) {
        try {
            var gameId = gameService.add(addGameDTO);
            if (gameId == 0) {
                return Result.fail("添加游戏失败");
            }
            return Result.success("添加游戏成功", null);
        } catch (Exception e) {
            return Result.fail("添加游戏失败", e.getMessage());
        }
    }*/

    // 更新游戏
   /* @ResponseBody
    @Operation(summary = "更新游戏")
    @PostMapping("/update")
    public Result<String> update(@RequestBody UpdateGameDTO updateGameDTO) {
        try {
            int updated = gameService.update(updateGameDTO);
            if (updated == 0) {
                return Result.fail("更新游戏失败");
            }
            return Result.success("更新游戏成功", null);
        } catch (Exception e) {
            return Result.fail("更新游戏失败", e.getMessage());
        }
    }*/

    //根据页码 和 每页要展示的数据来生成所有数据页面
   /* @ResponseBody
    @Operation(summary = "查询游戏")
    @PostMapping("/search")
    public Result<PageInfo<GameVO>> search(@RequestBody SearchGameDTO searchGameDTO) {
        PageInfo<GameVO> pageInfo = gameService.search(searchGameDTO);
        return Result.success(pageInfo);
    }*/

    // 获取最大排序值的后续100可以整除的值
   /* @ResponseBody
    @Operation(summary = "获取最大排序值")
    @GetMapping("/maxSort")
    public Result<Integer> maxSort() {
        Optional<Integer> maxSort = gameService.maxSort();
        return Result.success(maxSort.orElse(0));
    }*/
}

