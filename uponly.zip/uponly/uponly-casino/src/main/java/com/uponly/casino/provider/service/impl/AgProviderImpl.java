package com.uponly.casino.provider.service.impl;

import cn.hutool.core.util.IdUtil;
import cn.hutool.http.HttpResponse;
import cn.hutool.http.HttpUtil;
import cn.hutool.json.XML;
import com.alibaba.fastjson2.JSON;
import com.alibaba.fastjson2.JSONArray;
import com.alibaba.fastjson2.JSONObject;
import com.alibaba.nacos.shaded.com.google.gson.Gson;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.reflect.TypeToken;
import com.uponly.casino.admin.service.GameService;
import com.uponly.casino.admin.vo.*;
import com.uponly.casino.common.api.Result;
import com.uponly.casino.common.api.ResultCode;
import com.uponly.casino.common.exception.BusinessException;
import com.uponly.casino.mapper.GameOriginalMapper;
import com.uponly.casino.provider.dto.GameInfoDTO;
import com.uponly.casino.provider.dto.RequestDTO;
import com.uponly.casino.provider.dto.ag.AgConfig;
import com.uponly.casino.provider.dto.ag.req.*;
import com.uponly.casino.provider.dto.ag.res.AgResp;
import com.uponly.casino.provider.dto.evo.req.Table;
import com.uponly.casino.provider.dto.evo.res.*;
import com.uponly.casino.provider.dto.toup.BalanceDTO;
import com.uponly.casino.provider.dto.toup.ChangeBalanceResponse;
import com.uponly.casino.provider.dto.toup.GetBalanceResponse;
import com.uponly.casino.provider.enums.EnumBodyType;
import com.uponly.casino.provider.enums.ag.AgCallbackCode;
import com.uponly.casino.provider.enums.ag.AgLanguageCode;
import com.uponly.casino.provider.enums.ag.AgRespCode;
import com.uponly.casino.provider.enums.EnumWalletOperatorType;
import com.uponly.casino.provider.service.ProviderManager;
import com.uponly.casino.provider.vo.UserInfoVO;
import com.uponly.casino.provider.vo.evo.CalResult;
import com.uponly.casino.util.DESUtil;
import com.uponly.casino.util.UidUtil;
import lombok.extern.slf4j.Slf4j;
import org.redisson.api.RBucket;
import org.redisson.api.RMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.StringReader;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Type;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

import static com.uponly.casino.common.constant.CommonConstant.CASINO_ORDER_RESULT_LIST;
import static com.uponly.casino.provider.dto.ag.req.CreateAccountReq.DIVIDER;


@Slf4j
@Service
public class AgProviderImpl extends BaseProviderImpl {
    protected AgConfig agConfig;
    @Autowired
    private GameService gameService;
    @Autowired
    private GameOriginalMapper gameOriginalMapper;
    @Autowired
    private ProviderManager providerManager;
    public static final String ACTYPE_1="1";//代表真钱账号
    public static final String ACTYPE_0="0";//代表试玩账号

    @Override
    public boolean initialize(ProviderVO providerVo) {
        //TODO 要補上加解密
        super.initialize(providerVo);
        AgConfig agConfig = JSON.parseObject(providerVo.getConfig(), AgConfig.class);

        if (agConfig == null) {
            log.error("ag config is null");
            return false;
        }
        this.agConfig= agConfig;

        return true;
    }
    public boolean checkUserId(String uid) {
        // 驗證 uid 是否為純數字
        try {
            Long.parseLong(uid);
        } catch (NumberFormatException e) {
            log.error("ag userId is not a numeric value");
            return false;
        }
        return true;
    }
    @Transactional(rollbackFor = Exception.class)
    public Object postTransfer(RequestDTO param) {

        JSONObject data = JSONObject.from(param.getBody().get("Data"));
        JSONObject record = JSONObject.from(data.get("Record"));
        AgCallbackCode codeEnum = AgCallbackCode.getEnum(record.get("transactionType").toString());
        if(codeEnum==null){
            log.error("ag postTransfer api call {}", param.getBody());
            return XMLStr(AgRespCode.INVALID_DATA.getCode(), BigDecimal.ZERO);
        }
        log.info("ag {} api call {}",codeEnum.name(), param.getBody());

        param.setBody(record);

        return switch (codeEnum) {
            case BET -> debit(param);
            case REFUND -> cancel(param);
            case LOSE, DRAW, WIN -> credit(param);
            default -> XMLStr(AgRespCode.INVALID_DATA.getCode(), BigDecimal.ZERO);
        };
    }
    public EnumBodyType getBodyType() {
        return EnumBodyType.XML;
    }

    public boolean validate(String uid, String sid) {
        if (uid == null || sid == null) {
            log.error("ag userId or sid is null");
            return false;
        }
        var sessionKey = "casino_user_session_" + uid;
        RMap<String, String> map = redissonClient.getMap(sessionKey);
        String jsonValue = map.get("sessionids");
        try {
            JSONObject nested = JSONObject.parseObject(jsonValue);
            if (Objects.isNull(nested) || !nested.containsKey(sid)) {
                log.error("ag {} sid is invalid", sid);
                return false;
            }
        } catch (Exception e) {
            log.error("ag validate error: {}", e.getMessage());
            return false;
        }
        return true;
    }

    @Override
    public JSONObject check(RequestDTO param) {
        return null;
    }

    @Override
    public JSONObject balance(RequestDTO param) {
        return null;
    }

    public String XMLStr(String status, BigDecimal balance) {
        // 构建 XML 字符串
        StringBuilder xmlBuilder = new StringBuilder();
        xmlBuilder.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
        xmlBuilder.append("<TransferResponse>");
        xmlBuilder.append("<ResponseCode>").append(status).append("</ResponseCode>");
        xmlBuilder.append("<Balance>").append(balance).append("</Balance>");
        xmlBuilder.append("</TransferResponse>");

        // 输出 XML 字符串
        return xmlBuilder.toString();
    }


    @Override
    @Transactional(rollbackFor = Exception.class)
    public Object credit(RequestDTO param) {
        String req=JSON.toJSONString(param.getBody());
        String resStatus="OK";
        PayoutReq payoutReq = JSONObject.parseObject(req,PayoutReq.class);
        String transactionId=payoutReq.getTransactionID();
        List<String> list =new ArrayList<>();
        if(transactionId.contains(",")){
            Gson gson = new Gson();
            Type listType = new TypeToken<List<String>>() {}.getType();
            list = gson.fromJson(transactionId, listType);
            transactionId=list.get(0);
        }

        String userId = getUserId(payoutReq.getPlayname());
        BigDecimal balance= getBalance(Long.valueOf(userId)).get().getBalance();

        if(!checkUserId(userId)){
            log.error("ag 【credit】 checkUserId Fail ");
            resStatus="";
            return XMLStr(resStatus,balance);
        }


        var check = validate(userId, payoutReq.getSessionToken());
        if (!check) {
            resStatus="";
            log.error("ag 【credit】  check is false");
            return XMLStr(resStatus,balance);
        }
        BigDecimal payoutAmount=payoutReq.getNetAmount().add(payoutReq.getValidBetAmount());
        BalanceDTO changeBalance = new BalanceDTO();

        changeBalance.setTransactionId(transactionId+2);
        changeBalance.setSessionId(transactionId);
        changeBalance.setGameId(payoutReq.getGameCode());
        changeBalance.setGameName(payoutReq.getGametype());
        changeBalance.setAmount(payoutAmount);
        changeBalance.setUserId(Long.valueOf(userId));
        // 从redis中获取存入的Order
        String orderKey = ORDER_KEY_GAME_ID + payoutReq.getGameCode()+":"+userId;
        RBucket<String> bucket = redissonClient.getBucket(orderKey);
        OrderVO order;
        OrderHistoryVO orderHistory;
        var orderData = (String)bucket.get();
        if (orderData == null) {
            // 根据orderKey没有找到对应的order, 从数据库中查找
            order = orderMapper.selectByUserIdAndRoundId(changeBalance.getUserId(), payoutReq.getGameCode());
            if (order == null) {
                //多注合併後 還需去歷史紀錄找
                orderHistory = orderMapper.selectHistoryByUserIdAndSessionId(changeBalance.getUserId(), transactionId,EnumWalletOperatorType.CasinoBetFreeze.getValue());
                if (orderHistory == null) {
                    log.error("ag 【credit】 order is null, cannot find order by userId={},roundId={} sessionId={}", userId, payoutReq.getGameCode(), payoutReq.getBillNo());
                    resStatus=" orderHistory Fail";
                    return XMLStr(resStatus,balance);
                }else {
                    if(!orderHistory.getSessionId().equals(transactionId)){
                        resStatus="TransactionID fail";
                        return XMLStr(resStatus,balance);
                    }
                    var user = userInfoService.getUser(changeBalance.getUserId());
                    if (user.isEmpty()) {
                        log.error("【newOrder】获取用户信息失败,userId={},betOrderNumber={}", param.getBody().get("userId"), changeBalance.getOrderNo());
                        resStatus=AgRespCode.INVALID_SESSION.getCode();
                        return XMLStr(resStatus,balance);
                    }
                    order= new OrderVO();
                    order.setThirdOrderNo(transactionId);
                    order.setOrderNo(orderHistory.getOrderNo());
                    order.setStatus(OrderVO.EnumOrderStatus.BET.getCode());
                    order.setAmount(orderHistory.getAmount());

                    order.setUserId(changeBalance.getUserId());
                    order.setUserName(user.get().getUserName());
                    order.setCurrency(user.get().getCurrency());
                    order.setRegion(user.get().getLocation());
                    order.setPid(changeBalance.getProviderId());

                    order.setMsgState(OrderVO.EnumMsgState.NONE.getCode());
                    order.setSessionId(changeBalance.getSessionId());
                    order.setRoundId(changeBalance.getGameId());
                    order.setGameName(changeBalance.getGameName());
                    order.setCreatedAt(new Date());
                    order.setBody(new JSONObject(param.getBody()).toJSONString());
                }
            }
        } else {
            log.info("ag 【credit】 redis orderData={}", orderData);
            order = JSON.parseObject(orderData, OrderVO.class);
            bucket.expire(expiration);
        }

        //確認狀態是否已經派彩過
        if(order.getStatus().equals(OrderVO.EnumOrderStatus.PAYOUT.getCode()) || order.getStatus().equals(OrderVO.EnumOrderStatus.CANCEL.getCode()) ){
            log.error("ag 【credit】 already payout Fail ");
            resStatus=AgRespCode.INVALID_TRANSACTION.getCode();
            return XMLStr(resStatus,balance);
        }

//        //檢查注單refId是否對的上
//        if(!order.getSessionId().equals(transactionId)){
//            log.error("ag 【credit】 already payout Fail ");
//            resStatus=AgRespCode.INVALID_TRANSACTION.getCode();
//            return XMLStr(resStatus,balance);
//        }

        changeBalance.setOrderNo(order.getOrderNo());

        changeBalance.setOperatorType(EnumWalletOperatorType.CasinoPayout.getValue());
        changeBalance.setRemark("");
        if(!payoutReq.getFinish()){
            changeBalance.setIsFinish(false);
        }
        newHistory(changeBalance, param);
        var changeResponse = changeBalance(changeBalance);
        if (changeResponse.isEmpty()) {
            log.error("ag 【credit】  changeResponse is empty");
            resStatus=AgRespCode.ERROR.getCode();
            return XMLStr(resStatus,balance);
        }

        if(changeResponse.get().getMgs()!=null){
            if(changeResponse.get().getMgs().equals(170) || changeResponse.get().getMgs().equals(100)){//重複訂單
                log.error("ag 【credit】 changeResponse Fail ");
                resStatus=AgRespCode.INVALID_TRANSACTION.getCode();
                return XMLStr(resStatus,balance);
            }
            log.error("ag 【credit】 changeResponse Fail 2");
            resStatus=AgRespCode.ERROR.getCode();
            return XMLStr(resStatus,balance);
        }

        // 更新credit状态
        order.setPayout(payoutAmount);

        // add by danny 2024-05-09
        if (payoutAmount.compareTo(BigDecimal.ZERO) > 0) {
            var usdAmount = rollingRankingService.getRate(order.getCurrency());
            BigDecimal bigDecimal = usdAmount.get();
            order.setUsdPayout(bigDecimal.multiply(payoutAmount));
        }
        updateOrderItem(payoutAmount,payoutReq,transactionId,order.getUsdPayout());
        if(payoutReq.getFinish()){
            order.setStatus(OrderVO.EnumOrderStatus.PAYOUT.getCode());
            order.setSettleAt(new Date());
            order.setPid(providerVO.getPid());
            order.setGameType(payoutReq.getGametype());
            if (orderMapper.updatePayout(order) == 0) {
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                log.error("ag 【credit】 updatePayout failed");
                resStatus=AgRespCode.ERROR.getCode();
                return XMLStr(resStatus,balance);
            }
            List<OrderItemVO> orderItemVOList=orderItemMapper.selectByCasinoOrderId(order.getId());

            List<CalResult> results = orderItemVOList.stream()
                    .map(e -> CalResult.builder()
                            .result(OrderItemVO.EnumOrderItemResult.getEnumByCode(e.getResult()).getCalName())
                            .bet(e.getAmount())
                            .code(e.getBetType())
                            .payout(e.getPayout())
                            .build())
                    .collect(Collectors.toList());

            order.setGameResult(JSONArray.toJSONString(results));

            orderMapper.updateBetResult(order);
            order.setBody(null);

            savePayoutRedis(order);
            saveAmountRedis(order);


            // 更新排行榜
            order.setBody(new JSONObject(param.getBody()).toJSONString());
            rollingRankingService.processBettingData(order);
        }else {
            if (orderMapper.updatePayoutAmount(order) == 0) {
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                log.error("ag 【credit】 updatePayoutAmount failed");
                resStatus=AgRespCode.ERROR.getCode();
                return XMLStr(resStatus,balance);
            }
        }


        String orderJson = JSONObject.toJSONString(order);
        bucket.set(orderJson, expiration);
//        checkOrdersStatus(payoutReq.getBillNo());

        return XMLStr(resStatus,balance);
    }

    private String getUserId(String playName) {
        return playName.replace(agConfig.getProductId(), "");
    }
    @Override
    @Transactional(rollbackFor = Exception.class)
    public Object debit(RequestDTO param) {

        String req=JSON.toJSONString(param.getBody());
        String resStatus="OK";
        BetReq betReq = JSONObject.parseObject(req,BetReq.class);
        String transactionId=betReq.getTransactionID();

        Long userId = Long.valueOf(getUserId(betReq.getPlayname()));
        BigDecimal balance= getBalance(userId).get().getBalance();

        if(!checkUserId(userId.toString())){
            log.error("ag 【debit】 checkUserId Fail");
            resStatus=AgRespCode.INVALID_USER.getCode();
            return XMLStr(resStatus,balance);
        }

        var check = validate(userId.toString(), betReq.getSessionToken());
        if (!check) {
            resStatus=AgRespCode.INVALID_USER.getCode();
            log.error("ag 【debit】  check is false");
            return XMLStr(resStatus,balance);
        }

        BalanceDTO changeBalance = new BalanceDTO();

        Optional<GetBalanceResponse> balanceRes = getBalance(userId);

        if(betReq.getValue().compareTo(balanceRes.get().getBalance())>0){
            log.error("ag 【debit】 INSUFFICIENT_FUNDS ");
            resStatus=AgRespCode.INSUFFICIENT_FUNDS.getCode();
            return XMLStr(resStatus,balance);
        }

        // 單注多次下注 ex 21點  需從GameId 辨認
        String orderKey = ORDER_KEY_GAME_ID + betReq.getGameCode()+":"+userId;
        RBucket<String> bucket = redissonClient.getBucket(orderKey);
        OrderVO order;
        String orderData = bucket.get();
        if (orderData == null) {
            // 根据orderKey没有找到对应的order, 从数据库中查找
            log.error("ag 【debit】 redis order is null");
            order = orderMapper.selectByUserIdAndRoundId(Long.valueOf(userId), betReq.getGameCode());

        } else {
            order = JSON.parseObject(orderData, OrderVO.class);
            bucket.expire(expiration);
        }

        changeBalance.setSessionId(transactionId);
        changeBalance.setProviderId(providerVO.getPid());
        changeBalance.setGameId(betReq.getGameCode());

        String tableId = betReq.getTableCode();
        if (tableId != null) {
            String gameName = getGameName(tableId);
            changeBalance.setGameName(gameName);
        }
        changeBalance.setTransactionId(transactionId+1);
        BigDecimal amount = betReq.getValue();
        // 把 amount转换成负数
        changeBalance.setAmount(amount);
        changeBalance.setUserId(Long.valueOf(userId));
        changeBalance.setOperatorType(EnumWalletOperatorType.CasinoBetFreeze.getValue());
        changeBalance.setRemark(betReq.getPlaytype());

//        BigDecimal balance = BigDecimal.ZERO;
        if (order != null) {
            // 要把多同一個注單多次投注合併 更新order and redis 的資料
            changeBalance.setOrderNo(order.getOrderNo());

            //更新注單下注額
            OrderVO updateOrder=new OrderVO();
            updateOrder.setAmount(amount);
            updateOrder.setOrderNo(order.getOrderNo());

            if (orderMapper.updateBet(updateOrder) == 0) {
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                log.error("ag 【debit】 updateBet failed");
                resStatus=AgRespCode.INVALID_TRANSACTION.getCode();
                return XMLStr(resStatus,balance);
            }
            if(orderItemMapper.selectByCasinoOrderIdAndBetType(order.getId(),Integer.parseInt(betReq.getPlaytype())).isEmpty()){
                insertOrderItem(order.getId(),amount,betReq,userId);
            }else {
                updateOrderItemBet(order.getId(),amount,betReq.getPlaytype());
            }

            Optional<ChangeBalanceResponse> balanceResponse = changeBalance(changeBalance, param);
            if (balanceResponse.isEmpty()) {
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                log.error("ag 【debit】balanceResponse is null");
                resStatus=AgRespCode.ERROR.getCode();
                return XMLStr(resStatus,balance);
            }

            if(balanceResponse.get().getMgs()!=null){
                if(balanceResponse.get().getMgs().equals(170)){//重複訂單
                    resStatus=AgRespCode.INVALID_TRANSACTION.getCode();
                    return XMLStr(resStatus,balance);
                }
                resStatus=AgRespCode.ERROR.getCode();
                return XMLStr(resStatus,balance);
            }

            balance=balanceResponse.get().getBalance();

            //多注要存 不然會找不到資料
            order.setSessionId(transactionId);
            order.setThirdOrderNo(transactionId);
            String debitOrderKey = ORDER_KEY_REF + transactionId;
            RBucket<String> debitBucket = redissonClient.getBucket(debitOrderKey);
            debitBucket.set(JSONObject.toJSONString(order), expiration);
        }else {
            //ag : This test case is simulate we couldn't received your debit response before the game round close, so we send cancel to you, but somehow the cancel arrive before the debit
            //you need to respond FINAL_ERROR_ACTION_FAILED and do not accept this debit
            RBucket<String> cancelBucket = redissonClient.getBucket(ORDER_KEY_CANCEL + betReq.getGameCode()+":"+userId);
            if(Objects.nonNull(cancelBucket.get())){
                log.info(" ag debit FINAL_ERROR_ACTION_FAILED");
                resStatus=AgRespCode.INVALID_DATA.getCode();
                return XMLStr(resStatus,balance);
            }
            //正常下注行為 新增注單
            changeBalance.setOrderNo(UidUtil.getOrderNo(userId.toString()));
            Integer orderId=justNewOrder(changeBalance, param);

            insertOrderItem(orderId,amount,betReq,userId);

            Optional<ChangeBalanceResponse> balanceResponse = changeBalance(changeBalance, param);
            if (balanceResponse.isEmpty()) {
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                log.error("ag 【debit】balanceResponse is null");
                resStatus=AgRespCode.ERROR.getCode();
                return XMLStr(resStatus,balance);
            }

            if(balanceResponse.get().getMgs()!=null){
                if(balanceResponse.get().getMgs().equals(170)){//重複訂單
                    resStatus=AgRespCode.INVALID_TRANSACTION.getCode();
                    return XMLStr(resStatus,balance);
                }
                resStatus=AgRespCode.ERROR.getCode();
                return XMLStr(resStatus,balance);
            }

//            Optional<ChangeBalanceResponse> changeResponse = newOrder(changeBalance, param);
//            if (changeResponse.isEmpty()) {
//                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
//                log.error("ag 【debit】changeResponse is null");
//                resStatus=AgRespCode.ERROR.getCode();
////                res.setStatus(EVOStatusType.INSUFFICIENT_FUNDS.name());
//                return XMLStr(resStatus,balance);
//            }
            balance=balanceResponse.get().getBalance();
        }
//        checkTicketStatus(transactionId);
        return XMLStr(resStatus,balance);
    }

    @Transactional(rollbackFor = Exception.class)
    public Object cancel(RequestDTO param) {
        String req=JSON.toJSONString(param.getBody());
        String resStatus="OK";
        BetReq betReq = JSONObject.parseObject(req,BetReq.class);
        String transactionId=betReq.getTransactionID()+1;
        Long userId = Long.valueOf(getUserId(betReq.getPlayname()));
        BigDecimal balance= getBalance(userId).get().getBalance();


        if(!checkUserId(userId.toString())){
            log.error("ag 【cancel】 checkUserId Fail");
            resStatus=AgRespCode.INVALID_USER.getCode();
            return XMLStr(resStatus,balance);
        }
        var check = validate(userId.toString(), betReq.getSessionToken());
        if (!check) {
            resStatus=AgRespCode.INVALID_USER.getCode();
            log.error("ag 【cancel】  check is false");
            return XMLStr(resStatus,balance);
        }
        var changeBalance = new BalanceDTO();
        changeBalance.setUserId(Long.valueOf(userId));
        changeBalance.setTransactionId(transactionId);
        changeBalance.setSessionId(transactionId);
        changeBalance.setGameId(betReq.getGameCode());
        String tableId = betReq.getTableCode();
        if (tableId != null) {
            String gameName = getGameName(tableId);
            changeBalance.setGameName(gameName);
        }
        // 从redis中获取存入的Order
        String orderKey = ORDER_KEY_REF + transactionId;
        RBucket<String> bucket = redissonClient.getBucket(orderKey);
        OrderVO order;
        OrderHistoryVO orderHistoryVO ;
        var orderData = (String)bucket.get();
        if (orderData == null) {
            // 根据orderKey没有找到对应的order, 从数据库中查找
            order = orderMapper.selectByUserIdAndSessionId(Long.valueOf(userId), transactionId);
            if (order == null) {// 都找不到還要再去 歷史紀錄裡找
                orderHistoryVO = orderMapper.selectHistoryByUserIdAndSessionId(Long.valueOf(userId), transactionId,EnumWalletOperatorType.CasinoBetFreeze.getValue());
                if(orderHistoryVO==null){
                    log.error("ag 【cancel】order is null, cannot find order by userId={} roundId={},transactionId ={}", userId, betReq.getGameCode(), transactionId);
                    log.info("ag 【cancel】 特殊情境 : key {}",ORDER_KEY_CANCEL + betReq.getGameCode()+":"+userId);
                    RBucket<String> cancelBucket = redissonClient.getBucket(ORDER_KEY_CANCEL + betReq.getGameCode()+":"+userId);
                    cancelBucket.set(betReq.getGameCode(),expiration);
                    resStatus=AgRespCode.INVALID_TRANSACTION.getCode();
                    return XMLStr(resStatus,balance);
                }else {
                    order=new OrderVO();
                    order.setOrderNo(orderHistoryVO.getOrderNo());
                    order.setStatus(OrderVO.EnumOrderStatus.BET.getCode());
                }
            }
        } else {
            order = JSON.parseObject(orderData, OrderVO.class);
            bucket.expire(expiration);
        }
//        //確認狀態是否已經取消過
//        if(order.getStatus().equals(OrderVO.EnumOrderStatus.CANCEL.getCode()) || order.getStatus().equals(OrderVO.EnumOrderStatus.PAYOUT.getCode())) {
//            res.setStatus(EVOStatusType.BET_ALREADY_SETTLED.name());
//            return res.toJSONObject();
//        }

        changeBalance.setOrderNo(order.getOrderNo());
        BigDecimal amount = betReq.getValue();
        changeBalance.setAmount(amount);
        changeBalance.setOperatorType(EnumWalletOperatorType.CasinoBetRefund.getValue());
        changeBalance.setRemark("");
        newHistory(changeBalance, param);
        var changeResponse = changeBalance(changeBalance);
        if (changeResponse.isEmpty()) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            log.error("ag 【cancel】cancel changeResponse is null");
            resStatus=AgRespCode.ERROR.getCode();
            return XMLStr(resStatus,balance);
        }

        if(changeResponse.get().getMgs()!=null){
            if(changeResponse.get().getMgs().equals(170)){//重複訂單
                resStatus=AgRespCode.INVALID_TRANSACTION.getCode();
                return XMLStr(resStatus,balance);
            }
            resStatus=AgRespCode.ERROR.getCode();
            return XMLStr(resStatus,balance);
        }

        order.setThirdOrderNo(changeBalance.getTransactionId());
        order.setUserId(changeBalance.getUserId());
        order.setPid(providerVO.getPid());
        order.setSessionId(changeBalance.getSessionId());
        order.setRoundId(changeBalance.getGameId());
        order.setGameName(changeBalance.getGameName());
//        // 更新cancel状态
        order.setPayout(BigDecimal.ZERO);
        order.setStatus(OrderVO.EnumOrderStatus.CANCEL.getCode());
        order.setSettleAt(new Date());
        if (orderMapper.updatePayout(order) == 0) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            log.error("ag 【cancel】cancel updatePayout failed");
            resStatus=AgRespCode.ERROR.getCode();
            return XMLStr(resStatus,balance);
        }

        String orderJson = JSONObject.toJSONString(order);
        bucket.set(orderJson, expiration);

        return XMLStr(resStatus,balance);
    }
    public void updateOrderItemBet(Integer casinoId, BigDecimal amount,String betType) {
        OrderItemVO orderItemVO = new OrderItemVO();
        orderItemVO.setAmount(amount);
        orderItemVO.setCasinoOrderId(casinoId);
        orderItemVO.setBetType(betType);
        orderItemMapper.updateByCasinoOrderIdAndBetType(orderItemVO);
    }
    public void insertOrderItem(Integer casinoId, BigDecimal amount, BetReq betReq, Long userId) {
        OrderItemVO orderItemVO = new OrderItemVO();
        orderItemVO.setAmount(amount);
        orderItemVO.setCasinoOrderId(casinoId);
        orderItemVO.setCreatedAt(new Date());
        orderItemVO.setOrderNo(betReq.getTransactionID());
        orderItemVO.setBetType(betReq.getPlaytype());
        orderItemVO.setRoundId(betReq.getGameCode());
        orderItemVO.setTransactionId(betReq.getTransactionID());
        orderItemVO.setUserId(userId);
        orderItemMapper.add(orderItemVO);
    }
    public void updateOrderItem(BigDecimal amount, PayoutReq payoutReq,String transactionId,BigDecimal usdPayout) {
        OrderItemVO orderItemVO = new OrderItemVO();
        orderItemVO.setSettleAt(new Date());
        orderItemVO.setPayout(amount);
        orderItemVO.setTransactionId(transactionId);
        orderItemVO.setResult(OrderItemVO.EnumOrderItemResult.getEnumByName(payoutReq.getTransactionType()).getCode());
        orderItemVO.setUsdPayout(Objects.nonNull(usdPayout)?BigDecimal.ZERO:usdPayout);
        orderItemVO.setSettleAt(new Date());
        orderItemMapper.updateByTransactionId(orderItemVO);
    }
    @Transactional(rollbackFor = Exception.class)
    public Object promo_payout(RequestDTO param) {
        return null;
    }

    public Object betResponse(RequestDTO param) {
        JSONObject data = JSONObject.from(param.getBody().get("Data"));
        String record = (String) data.get("playname");
        String userId = getUserId(record);
        BigDecimal balance= getBalance(Long.valueOf(userId)).get().getBalance();
        return XMLStr(AgRespCode.OK_.getCode(), balance);
    }

    public Result<?> getGameList() {


        return Result.success();
    }


    public void history(String orderStr, Integer status) {

    }

    public void history(String str) {
    }

    public Result<?> getLaunchURI(Map<String, Object> body) {
        // 游戏ID, 桌子ID, 用户ID, 语言, 用户ID
        String userId = (String)body.get("uid");
        String language = (String)body.get("language");
        GameInfoDTO gameInfo = (GameInfoDTO)body.get("gameInfo");
        String playMode = (String)body.get("playMode");
        String backUrl = (String)body.get("backUrl");

        Long uid = Long.valueOf(userId);
        Optional<UserInfoVO> user = userInfoService.getUser(uid);
        if (user.isEmpty()) {
            return Result.fail(1201, "user is null");
        }
        String currency = Objects.equals(user.get().getCurrency(), "USDT") ? "USD" :  user.get().getCurrency();
        String cagent = agConfig.getCagent();
        String productId = agConfig.getProductId();
        String actype=ACTYPE_1;
        if (playMode != null) {
            Map<String,String> modeMap = Map.of(
                    "fun", ACTYPE_0,
                    "reward", ACTYPE_1,
                    "demo", ACTYPE_0,
                    "real", ACTYPE_1
            );
            // 获取对应的枚举值，如果playMode不在map中，则默认为REAL_MONEY
            actype= modeMap.getOrDefault(playMode, ACTYPE_1);
        }
        //進遊戲前要先確認是否創建帳號
        cn.hutool.json.JSONObject resp=checkOrCreateGameAccount(currency,cagent,userId,actype);

        if (resp == null) {
            throw new BusinessException(1201, "AG创建帐号失败");
        }
        AgResp checkResp = JSON.parseObject(JSON.toJSONString(resp),AgResp.class);
        if(!checkResp.getResult().getInfo().equals("0")){
            throw new BusinessException(1201, checkResp.getMsg());
        }

        //創建session
        String sid = IdUtil.randomUUID();
        BigDecimal balance=getBalance(uid).orElseThrow().getBalance();
        CreateSessionReq createSessionReq = new CreateSessionReq();
        createSessionReq.setSessionToken(sid);
        createSessionReq.setCredit(balance.toString());
        createSessionReq.setUsername(userId);
        createSessionReq.setProductId(productId);
        JSONObject sessionJs= JSONObject.from(createSession(createSessionReq));
        sessionJs= JSONObject.parseObject(sessionJs.get("PlayerTicketResponse").toString());
        if(!sessionJs.get("ResponseCode").equals("OK")){
            throw new BusinessException(1201, Objects.requireNonNull(AgRespCode.getEnum(sessionJs.get("ResponseCode").toString())).getDes());
        }

        // 设置Redis的session
        String sessionKey = "casino_user_session_" + userId;
        RMap<String, String> map = redissonClient.getMap(sessionKey);
        String jsonValue = map.get("sessionids");
        var objectMapper = new ObjectMapper();
        try {
            jsonValue = jsonValue == null ? "{}" : jsonValue;
            Map<String, Object> nestedMap = objectMapper.readValue(jsonValue, Map.class);
            nestedMap.put(sid, new Date());
            map.put("sessionids", objectMapper.writeValueAsString(nestedMap));
            log.info("ag getGameURI call, add new sid={}", sid);
        } catch (Exception e) {
            log.error("ag getGameURI call error: {}", e.getMessage());
        }

        try {
            String gameUrl=forwardGame(currency,cagent,userId,actype,sid,language,backUrl,gameInfo);
            var resData = new AuthenticationResponse(gameUrl);
            return Result.success(resData);
        } catch (Exception e) {
            throw new BusinessException(ResultCode.GAME_CLOSE.getCode(), e.getMessage());
        }
    }

//    public static void main(String[] args){
//        String req="{\"sessionToken\":\"7f1424d4-008a-4ea1-816f-6eb13c2b0a5d\",\"currency\":\"USD\",\"netAmount\":-10,\"validBetAmount\":10,\"playname\":\"LX468131\",\"agentCode\":\"LX4\",\"settletime\":\"06/25/2024 04:37:08\",\"billNo\":240625041591189,\"transactionID\":[\"025114062504364600829\",\"025114062504365200830\"],\"gametype\":\"BAC\",\"gameCode\":\"GN008246250AB\",\"transactionType\":\"LOSE\",\"transactionCode\":\"BCP\",\"ticketStatus\":\"Lose\",\"gameResult\":\"P;H5;C7;S4:B;D7;H10\",\"finish\":true}";
//
//        PayoutReq payoutReq = JSONObject.parseObject(req,PayoutReq.class);
//        System.out.println(payoutReq);
//        System.out.println(payoutReq.getTransactionID());
//       String[] s =payoutReq.getTransactionID().replace("\"","").split(",");
//        for (int i = 0; i < s.length; i++) {
//            System.out.println(s[i]);
//        }
//    }
public static void main(String[] args) {
//    String str = "[\"025114062504364600829\",\"025114062504365200830\"]";
    String str = "025114062504364600829";

    Gson gson = new Gson();
    Type listType = new TypeToken<List<String>>() {}.getType();
    List<String> list = gson.fromJson(str, listType);

    System.out.println(list);
}
    public cn.hutool.json.JSONObject checkOrCreateGameAccount(String currency, String cagent, String userId, String actype) {
        CreateAccountReq req = new CreateAccountReq();
        req.setCur(currency);
        req.setMethod(CreateAccountReq.MethodEnum.CHECK_OR_CREATE_GAME_ACCOUNT.getValue());
        req.setCagent(cagent);
        req.setOddtype(CreateAccountReq.OddTypeEnum.A.getValue());
        req.setLoginname(userId);
        req.setPassword(userId);
        req.setActype(actype);

        String baseUrl = agConfig.getBaseUrl();
        String des = agConfig.getDES();
        String md5 = agConfig.getMD5();
        String param = "";
        String key = "";
        try {
            param = toParam(req);
        } catch (IllegalAccessException e) {
            log.error("lg 出錯 : {}", req, e);
        }

        try {
            param = DESUtil.encrypt(param, des);
        } catch (Exception e) {
            log.error("lg 加密 出錯 : {}", param, e);
        }
        key = DESUtil.MD5(param, md5);

        String agGameUrl = String.format("%s/doBusiness.do?params=%s&key=%s", baseUrl, param, key);

        log.info("ag 请求的url：{}", agGameUrl);
        HttpResponse response = HttpUtil.createPost(agGameUrl)
                .execute();
        log.info("ag 请求的结果：{}", response.body());
        int httpStatus = response.getStatus();
        if (httpStatus != 200) {
            log.error("ag 请求失败！httpStatus={},body={}", httpStatus, response.body());
            throw new BusinessException("Failed to get ag game URL, HTTP status: " + httpStatus);
        }
        return XML.toJSONObject(response.body());
    }
    public String forwardGame(String currency,String cagent,String userId,String actype,String sid,String language,String backUrl,GameInfoDTO gameInfo) {
        language= AgLanguageCode.getEnum(language).getAgCode();
        //進入遊戲
        ForwardGameReq req=new ForwardGameReq();
        req.setCagent(cagent);
        req.setLoginname(userId);
        req.setPassword(userId);
        req.setActype(actype);
        req.setSid(sid);
        req.setLang(language);
        req.setOddtype(CreateAccountReq.OddTypeEnum.A.getValue());
        req.setCur(currency);

        String gameType="0";//總大廳
        if (gameInfo != null && gameInfo.getMainEntrance() != null) {
            var tableId = gameInfo.getTableId();
            if (tableId != null) {
                req.setGameType(tableId);
            }else {
                req.setGameType(Objects.nonNull(gameInfo.getGameType())?gameInfo.getGameType():gameType);
            }
            if (backUrl != null) {
                req.setDm(backUrl);
            } else {
                req.setDm(providerVO.getBackUrl());
            }
        }
        log.info("AG forwardGame req:{}",req);
        String baseUrl = agConfig.getGameHistoryApiUrl();
        String des = agConfig.getDES();
        String md5 = agConfig.getMD5();
        String param = "";
        String key = "";
        try {
            param = toParam(req);
        } catch (IllegalAccessException e) {
            log.error("lg forwardGame 出錯 : {}", req, e);
        }

        try {
            param = DESUtil.encrypt(param, des);
        } catch (Exception e) {
            log.error("lg forwardGame 加密 出錯 : {}", param, e);
        }
        key = DESUtil.MD5(param, md5);

        String agGameUrl = String.format("%s/forwardGame.do?params=%s&key=%s", baseUrl, param, key);

        log.info("ag forwardGame 请求的url：{}", agGameUrl);
        HttpResponse response = HttpUtil.createPost(agGameUrl)
                .execute();
        log.info("ag forwardGame 请求的结果：{}", response.body());
        int httpStatus = response.getStatus();
        if (httpStatus != 200) {
            log.error("ag forwardGame 请求失败！httpStatus={},body={}", httpStatus, response.body());
            throw new BusinessException("Failed to get ag game URL, HTTP status: " + httpStatus);
        }
        return agGameUrl;
    }
    public cn.hutool.json.JSONObject createSession(CreateSessionReq req) {
        String getUrl = agConfig.getGetUrl();
        String productid = req.getProductId();
        String username = req.getUsername();
        String session_token = req.getSessionToken();
        String credit = req.getCredit();

        String url = String.format("%s/player-tickets.ucs?productid=%s&username=%s&session_token=%s&credit=%s", getUrl, productid, username, session_token, credit);

        log.info("ag CreateSession 请求的url：{}", url);
        HttpResponse response = HttpUtil.createGet(url)
                .execute();
        log.info("ag CreateSession 请求的结果：{}", response.body());
        int httpStatus = response.getStatus();
        if (httpStatus != 200) {
            log.error("ag CreateSession 请求失败！httpStatus={},body={}", httpStatus, response.body());
            throw new BusinessException("Failed to get CreateSession , HTTP status: " + httpStatus);
        }
        return XML.toJSONObject(response.body());
    }

    public cn.hutool.json.JSONObject checkTicketStatus(String transactionID) {
        String getUrl = agConfig.getGetUrl();

        String url = String.format("%s/CheckTicketStatus.ucs?transactionID=%s", getUrl, transactionID);

        log.info("ag checkTicketStatus 请求的url：{}", url);
        HttpResponse response = HttpUtil.createGet(url)
                .execute();
        log.info("ag checkTicketStatus 请求的结果：{}", response.body());
        int httpStatus = response.getStatus();
        if (httpStatus != 200) {
            log.error("ag checkTicketStatus 请求失败！httpStatus={},body={}", httpStatus, response.body());
            throw new BusinessException("Failed to get checkTicketStatus , HTTP status: " + httpStatus);
        }
        return XML.toJSONObject(response.body());
    }

    public cn.hutool.json.JSONObject checkOrdersStatus(String billNo) {
        String getUrl = agConfig.getGetUrl();
        String url = String.format("%s/CheckOrdersStatus.ucs?billNo=%s", getUrl,billNo );

        log.info("ag checkOrdersStatus 请求的url：{}", url);
        HttpResponse response = HttpUtil.createGet(url)
                .execute();
        log.info("ag checkOrdersStatus 请求的结果：{}", response.body());
        int httpStatus = response.getStatus();
        if (httpStatus != 200) {
            log.error("ag checkOrdersStatus 请求失败！httpStatus={},body={}", httpStatus, response.body());
            throw new BusinessException("Failed to get checkOrdersStatus , HTTP status: " + httpStatus);
        }
        return XML.toJSONObject(response.body());
    }

    public static JSONObject parseXMLResponse(String xmlResponse) {
        try {
            // 创建 DocumentBuilderFactory 和 DocumentBuilder 实例
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();

            // 将 XML 响应字符串转换为 InputSource 对象
            InputSource inputSource = new InputSource(new StringReader(xmlResponse));

            // 使用 DocumentBuilder 解析 XML 响应并得到 Document 对象
            Document document = builder.parse(inputSource);
            // 获取根元素 <Data>
            Element rootElement = document.getDocumentElement();
            JSONObject json=new JSONObject();
            // 获取所有子元素 <Record>
            NodeList recordNodes = rootElement.getElementsByTagName("Record");
            for (int i = 0; i < recordNodes.getLength(); i++) {
                Element recordElement = (Element) recordNodes.item(i);
                // 获取 <Record> 元素下的所有子元素
                NodeList childNodes = recordElement.getChildNodes();
                for (int j = 0; j < childNodes.getLength(); j++) {
                    if (childNodes.item(j).getNodeType() == org.w3c.dom.Node.ELEMENT_NODE) {
                        Element childElement = (Element) childNodes.item(j);
                        String key = childElement.getTagName();
                        String value = childElement.getTextContent();
                        json.put(key,value);
                    }
                }
            }
            return json;
        } catch (Exception e) {
            log.error("Failed to parse XML response", e);
            // 在解析失败时，你可以返回 null 或者抛出异常，视情况而定
            return null;
        }
    }

    public String toParam(CreateAccountReq req) throws IllegalAccessException {
        StringBuilder builder = new StringBuilder();
        Class<?> clazz = req.getClass();
        while (clazz != null) {
            Field[] fields = clazz.getDeclaredFields();
            for (Field field : fields) {
                field.setAccessible(true);
                Object value = field.get(req);
                if (value != null) {
                    String name = field.getName();
                    if (!name.equals("DIVIDER")) {
                        builder.append(name).append("=").append(value).append(DIVIDER);
                    }
                }
            }
            clazz = clazz.getSuperclass(); // 获取父类
        }
        // 移除末尾的分隔符
        if (!builder.isEmpty()) {
            builder.delete(builder.length() - DIVIDER.length(), builder.length());
        }
        return builder.toString();
    }

}
