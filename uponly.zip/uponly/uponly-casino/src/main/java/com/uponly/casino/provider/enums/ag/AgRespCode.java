package com.uponly.casino.provider.enums.ag;

import lombok.Getter;


public enum AgRespCode {
    OK_0("0","建立成功遊戏session开始启动",200),
    INVALID_PARAMETER("1000","缺少必要的参数",200),
    INVALID_STATUS("1016","玩家账户是禁用状态的",200),
    INVALID_USER("2002","该玩家账户是不存在的",200),
    NOT_SINGLE_WALLET("2003","该产品编码不支持单一钱包功能(通常是因為环境设定还未完成)",200),
    UNKNOWN_ERROR("9999","发送请求后, 服务器出现错误",200),

    OK_("OK","调用成功，交易已被接受及进入",200),
    INVALID_DATA("INVALID_DATA","请求无效",400),
    INCORRECT_SESSION_TYPE("INCORRECT_SESSION_TYPE","请求不正确，回传错误游戏session",403),
    INVALID_SESSION("INVALID_SESSION","此游戏session不是现行使用的",404),
    INVALID_TRANSACTION("INVALID_TRANSACTION","此交易不被接纳",404),
    INSUFFICIENT_FUNDS("INSUFFICIENT_FUNDS","玩家没有足够的额度应付在此次交易",409),
    INSUFFICIENT_CLEARED_FUNDS("INSUFFICIENT_CLEARED_FUNDS","玩家有足够的额度，但额度被禁用",409),
    ERROR("ERROR","错误，服务器错误而无法回传此次请求，并会触发讯息重发机制",500),



    ;

    @Getter
    private final String code;
    @Getter
    private final String des;
    @Getter
    private final Integer httpCode;

    AgRespCode(String code, String des, Integer httpCode) {
        this.code = code;
        this.des = des;
        this.httpCode = httpCode;
    }

    public static AgRespCode getEnum(String type) {
        for (AgRespCode enumToupAction : AgRespCode.values()) {
            if (enumToupAction.getCode().equals(type)) {
                return enumToupAction;
            }
        }
        return null;
    }

}
