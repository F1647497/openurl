/*
 * Copyright (c) 2021-2031, 河北计全科技有限公司 (https://www.jeequan.com & jeequan@126.com).
 * <p>
 * Licensed under the GNU LESSER GENERAL PUBLIC LICENSE 3.0;
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * http://www.gnu.org/licenses/lgpl.html
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.uponly.casino.common.utils;

import com.google.gson.Gson;
import lombok.extern.slf4j.Slf4j;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URLEncoder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;

@Slf4j
public class UponlyKit {


    private static String encodingCharset = "UTF-8";
    private static Gson gson = new Gson();
    /**
     * <p><b>Description: </b>计算签名摘要
     *
     * @param map     参数Map
     * @param key     厂商秘钥
     * @param montage 拼接字符
     * @return
     */
    public static String getSign(Map<String, Object> map, String key, String montage, Integer caseType) {
        ArrayList<String> list = new ArrayList<String>();
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            if (null != entry.getValue() && !"".equals(entry.getValue())) {
                list.add(entry.getKey() + "=" + entry.getValue() + "&");
            }
        }
        int size = list.size();
        String[] arrayToSort = list.toArray(new String[size]);
        Arrays.sort(arrayToSort, String.CASE_INSENSITIVE_ORDER);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < size; i++) {
            sb.append(arrayToSort[i]);
        }

        String result = sb.toString();
        result = result.substring(0, result.length() - 1);
        result += montage + key;
        log.debug("【验签】signStr:{}", result);

        if (caseType == 1) {
            result = md5(result, encodingCharset).toUpperCase();
        } else {
            result = md5(result, encodingCharset).toLowerCase();
        }
        log.debug("【验签】sign:{}", result);
        return result;
    }


    /**
     * <p><b>Description: </b>MD5
     * <p>2018年9月30日 上午11:33:19
     *
     * @param value
     * @param charset
     * @return
     */
    public static String md5(String value, String charset) {
        MessageDigest md = null;
        try {
            byte[] data = value.getBytes(charset);
            md = MessageDigest.getInstance("MD5");
            byte[] digestData = md.digest(data);
            return toHex(digestData);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String toHex(byte input[]) {
        if (input == null) {
            return null;
        }
        StringBuffer output = new StringBuffer(input.length * 2);
        for (int i = 0; i < input.length; i++) {
            int current = input[i] & 0xff;
            if (current < 16) {
                output.append("0");
            }
            output.append(Integer.toString(current, 16));
        }

        return output.toString();
    }

    /**
     * map 转换为  url参数
     **/
    public static String genUrlParams(Map<String, Object> paraMap) {
        if (paraMap == null || paraMap.isEmpty()) {
            return "";
        }
        StringBuffer urlParam = new StringBuffer();
        Set<String> keySet = paraMap.keySet();
        int i = 0;
        for (String key : keySet) {
            urlParam.append(key).append("=").append(paraMap.get(key) == null ? "" : doEncode(paraMap.get(key).toString()));
            if (++i == keySet.size()) {
                break;
            }
            urlParam.append("&");
        }
        return urlParam.toString();
    }

    static String doEncode(String str) {
        if (str.contains("+")) {
            return URLEncoder.encode(str);
        }
        return str;
    }
    // 设定上限（不包括该上限）
    public static Integer getRandomIngerUnderTarget(int upperBound){
        // 创建 Random 对象
        Random random = new Random();

        // 生成介于 0 和 max 之间的随机整数
        return random.nextInt(upperBound);
    }
    // 设定范围的下限和上限（包括上限）
    public static BigDecimal getRandomIngerBetweenLowBoundWithUpBound(BigDecimal min, BigDecimal max){

        // 计算范围
        BigDecimal range = max.subtract(min);

        // 创建一个随机小数，范围在 0 和 1 之间
        BigDecimal randomFactor = new BigDecimal(Math.random());

        // 计算随机数
        BigDecimal randomNumber = randomFactor.multiply(range).add(min);
        // 保留两位小数
        randomNumber = randomNumber.setScale(2, RoundingMode.HALF_UP);
        return randomNumber;
    }
    public static <T> String toJSON(T object){
        return gson.toJson(object);
    }
    public static <T> T  fromJson(String json, Class<T> targetClazz){
        return gson.fromJson(json, targetClazz);
    }


}
