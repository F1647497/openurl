package com.uponly.casino.admin.dto;

import cn.hutool.core.date.DateTime;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Data
public class SearchOrderDTO extends PageInfoDTO {
    @Schema(title = "注单号")
    private String orderNo;

    @Schema(title = "第三方注单号")
    private String thirdOrderNo;

    @Schema(title = "用户id")
    private Long userId;

    @Schema(title = "用户名")
    private String userName;

    @Schema(description = "游戏id") // As 'round_id' may represent a game round ID, there's no direct equivalent in your provided `OrderVO`, so I'm using a generic description.
    private String roundId;

    @Schema(title = "游戏名称")
    private String gameName;

    @Schema(title = "地区")
    private List<Integer> regions;

    @Schema(title = "注单状态")
    private Integer status;

    @Schema(title = "供应商ID") // This is a guess, since `pid` isn't described in the `OrderVO`.
    private Integer pid;

    @Schema(title = "供应商名称") // This is a guess, since `pid` isn't described in the `OrderVO`.
    private String providerName;

    @Schema(title = "投注时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")  // 指定日期格式
    private Date createdAt;

    @Schema(title = "投注开始时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")  // 指定日期格式
    private DateTime betTimeStart;

    @Schema(title = "投注结束时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private DateTime betTimeEnd;

    @Schema(title = "结算类型")
    private String settleType;

    @Schema(title = "结算时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date settleAt;

    @Schema(title = "结算开始时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private DateTime settleStart;

    @Schema(title = "结算结束时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private DateTime settleEnd;

    @Schema(title = "投注判断符号")
    private String methodOfAmount;

    @Schema(title = "投注金额")
    private BigDecimal amount;

    @Schema(title = "赔付判断符号")
    private String methodOfPayout;

    @Schema(title = "赔付金额")
    private BigDecimal payout;

}
