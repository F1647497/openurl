package com.uponly.casino.provider.enums.sa;

import lombok.Getter;

@Getter
public enum SaGameType {

    BAC("bac","百家乐"),
    DTX("dtx","龙虎"),
    SICBO("sicbo","骰宝"),
    ROT("rot","轮盘"),
    POKDENG("pokdeng","博丁"),
    ANDARBAHAR("andarbahar","安达巴哈"),
    TEENPATTI("teenpatti2020","印度炸金花"),
    BLACKJACK("blackjack","黑杰克"),
    XOCDIA("xocdia","色碟"),
    ;


    private final String codeName;
    private final String des;

    SaGameType(String codeName, String des) {
        this.codeName = codeName;
        this.des = des;
    }

    public static SaGameType getEnum(String codeName) {
        for (SaGameType enums : SaGameType.values()) {
            if (enums.getCodeName().equals(codeName)) {
                return enums;
            }
        }
        return null;
    }
}
