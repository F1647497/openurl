package com.uponly.casino.ranking;

import com.uponly.casino.admin.vo.OrderVO;
import com.uponly.casino.ranking.dto.LiveWinDTO;
import com.uponly.casino.ranking.vo.RankDataVO;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

public interface RollingRankingService {
    void processBettingData(OrderVO data);
    List<RankDataVO> getLiveWins(LiveWinDTO liveType);
    List<RankDataVO> getLiveBigWins(Integer location);
    Optional<BigDecimal> getRate(String currency);
    void updateRateMap();
    void cleanupRankings();
    void onApplicationStartup();
}
