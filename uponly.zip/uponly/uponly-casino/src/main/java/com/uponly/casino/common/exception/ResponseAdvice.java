package com.uponly.casino.common.exception;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.uponly.casino.common.api.Result;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.MethodParameter;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;


/**
 * 拦截controller返回值，封装成CommonResult后统一返回
 * <p>
 * RestControllerAdvice  <p>
 * 全局异常处理
 * 全局数据绑定
 * 全局数据预处理
 */
@Slf4j
@RestControllerAdvice
public class ResponseAdvice implements ResponseBodyAdvice<Object> {

    @Autowired
    private ObjectMapper objectMapper;

    /**
     * 对所有的响应都进行处理，应用该ExceptionHandler
     */
    @Override
    public boolean supports(MethodParameter returnType, Class<? extends HttpMessageConverter<?>> converterType) {
        if (returnType.getGenericParameterType().equals(Result.class)) {
            return false;
        }
        // 对类或者方法上面注解了@RestController 或者 @ResponseBody 的方法统一处理
//        return AnnotatedElementUtils.hasAnnotation(returnType.getContainingClass(), RestController.class) ||
//                returnType.hasMethodAnnotation(ResponseBody.class);
        return true;
    }

    /**
     * 在响应体写入之前被调用，修改响应体
     */
    @SneakyThrows //用于writeValueAsString
    @Override
    public Object beforeBodyWrite(Object body, MethodParameter returnType, MediaType selectedContentType, Class<? extends HttpMessageConverter<?>> selectedConverterType, ServerHttpRequest request, ServerHttpResponse response) {

        //如果响应结果是JSON数据类型
        if (selectedContentType.equalsTypeAndSubtype(MediaType.APPLICATION_JSON)) {
            if (body instanceof Result) {
                //为HTTP响应结果设置状态码，即把业务状态码转换成HTTP状态码，覆盖掉默认的200状态码
//                response.setStatusCode(HttpStatus.valueOf(((CommonResult) body).getCode()));
                return body;
            }
            //对String类型特别包装，转成json响应给前端
            if (returnType.getGenericParameterType().equals(String.class)) {
                return objectMapper.writeValueAsString(Result.success(body));
            }
        }
//        return Result.success(body);
        return body;
    }
}