package com.uponly.casino.admin.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class SearchProviderDTO extends PageInfoDTO {
    @Schema(description = "地区", nullable = true)
    private String region;

    @Schema(description = "供应商名称", nullable = true)
    private String providerName;

    @Schema(description = "供应商前端展示名称", nullable = true)
    private String portalDisplayName;

    @Schema(title="状态", nullable = true)
    private Integer status;

    @Schema(title="是否上线", nullable = true)
    private Integer isComming;
}
