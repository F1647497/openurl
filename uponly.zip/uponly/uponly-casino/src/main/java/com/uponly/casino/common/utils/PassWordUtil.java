package com.uponly.casino.common.utils;


import com.uponly.casino.common.utils.sm4.SM4Utils;

public class PassWordUtil {



	//对称秘钥加密(ECB)
	public static String SM4EncForECB(String key,String text) {
		SM4Utils sm4 = new SM4Utils();
		sm4.secretKey = key;
		sm4.hexString = true;
		return sm4.encryptData_ECB(text);
	}


	//对称秘钥解密(ECB)
	public static String SM4DecForECB(String key,String text) {
		SM4Utils sm4 = new SM4Utils();
		sm4.secretKey = key;
		sm4.hexString = true;
		return  sm4.decryptData_ECB(text);
	}


}
