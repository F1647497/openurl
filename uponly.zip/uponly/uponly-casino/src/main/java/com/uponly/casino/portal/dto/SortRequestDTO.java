package com.uponly.casino.portal.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class SortRequestDTO extends BaseRequestDTO {
    @Schema(description = "排序字段", nullable = true)
    Boolean ascState = true;
}
