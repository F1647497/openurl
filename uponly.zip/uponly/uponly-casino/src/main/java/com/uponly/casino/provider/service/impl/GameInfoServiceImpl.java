package com.uponly.casino.provider.service.impl;

import com.alibaba.fastjson2.JSON;
import com.uponly.casino.admin.vo.ProviderVO;
import com.uponly.casino.interceptor.RemoteKafkaService;
import com.uponly.casino.interceptor.kafka.KafkaMessageHelper;
import com.uponly.casino.mapper.EntranceMapper;
import com.uponly.casino.mapper.GameOriginalMapper;
import com.uponly.casino.mapper.ProviderMapper;
import com.uponly.casino.provider.dto.GameInfoDTO;
import com.uponly.casino.provider.dto.GameInfoExDTO;
import com.uponly.casino.provider.dto.GameUpdateDTO;
import com.uponly.casino.provider.service.GameInfoService;
import com.uponly.casino.util.RegionIntegerUtil;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;

import java.util.*;

import static com.uponly.casino.common.constant.CommonConstant.*;

@Slf4j
@Service
public class GameInfoServiceImpl implements GameInfoService {
    @Autowired
    protected GameOriginalMapper originalMapper;
    @Autowired
    protected EntranceMapper entranceMapper;
    @Autowired
    protected ProviderMapper providerMapper;
    @Autowired
    protected RedissonClient redissonClient;
    @Autowired
    private RemoteKafkaService remoteKafkaService;

    private static List<Integer> locationList;
    protected Map<Long, Map<String, List<GameInfoDTO>>> map = new HashMap<>();
    protected Map<String, List<GameInfoDTO>> mapGameInfo = new HashMap<>();
    protected Map<Long, List<GameInfoDTO>> mapGameInfoList = new HashMap<>();
    protected Map<String, GameInfoDTO> mapGameInfoByTableId = new HashMap<>();

    // This method is called when the application is ready to start.
    @EventListener(ApplicationReadyEvent.class)
    @Order(2)
    public void onApplicationStartup() {
        locationList = RegionIntegerUtil.initArea();

        // 获取所有供应商信息
        var mapProviders = providers();

        // Initialize the map
        log.info("GameInfoServiceImpl onApplicationStartup");
        var allGames = originalMapper.selectAll();
        var tableMap = new HashMap<String, GameInfoDTO>();
        // 转换所有数据到GameInfoDTO，放入map中
        for (var game : allGames) {
            var gameInfo = new GameInfoDTO(game);
            tableMap.put(gameInfo.getTableId(), gameInfo);
            newGameInfoItem(gameInfo, mapProviders);
        }

        var allEntrances = entranceMapper.selectAllEntrance();
        for (var entrance : allEntrances) {
            var gameInfo = new GameInfoDTO(entrance);
            // 如果是游戏，并且没有图标，那么获取对应的游戏的图标
            checkEntryIcon(gameInfo, tableMap);
            newGameInfoItem(gameInfo, mapProviders);
        }

        // 订阅redis的更新游戏事件
        var topic = redissonClient.getTopic(PUB_CASINO_UPDATE_GAME);
        topic.addListener(GameUpdateDTO.class, (channel, message) -> {
            try {
                var isUpdater = message.getMachineId().equals(MACHINE_ID);
                log.info("is updater: {}", isUpdater);
                onGameUpdate(message.getPid(), isUpdater);
                log.info("Received message: {} from channel: {}", message, channel);
            } catch (NumberFormatException e) {
                log.error("Failed to parse message : {}", message, e);
            }
        });
    }

    private static void checkEntryIcon(GameInfoDTO gameInfo, HashMap<String, GameInfoDTO> tableMap) {
        if (gameInfo.getIcon() == null || gameInfo.getIcon().isEmpty()) {
            var originGame = tableMap.get(gameInfo.getTableId());
            if (originGame != null) {
                gameInfo.setIcon(originGame.getIcon());
            }
        }
    }

    public void notifyGameUpdate(Long pid) {
        var topic = redissonClient.getTopic(PUB_CASINO_UPDATE_GAME);
        if (topic == null) {
            log.error("topic is null");
            return;
        }
        topic.publish(new GameUpdateDTO(pid));
    }

    // 通过kafka通知客户端游戏更新
    private void notifyClientGameUpdate(List<GameInfoExDTO> gameItemList, String action) {
        log.info("enter Notify Client Game Update {}", action);
        for (Integer location : locationList) {
            try {
                log.info("游戏 更新 msg:");
                //通过kafka主动推送ws到前端
                var data = new HashMap<String, Object>();
                data.put("action", action);
                data.put("data", gameItemList);
                //把以下数据包装和推送到kafka的代码包装成独立的方法，并把type和data放到函数中
                String channel = CASINO_LIVE_WIN_REGION_FORMAT.formatted(location);
                log.info("channel:{}", channel);
                String msg = KafkaMessageHelper.toJsonString(SOCKET_CASINO_GAME_UPDATE, data, channel);
                log.info("【游戏更新】kafka-推送:{}", msg);
                remoteKafkaService.send(KafkaMessageHelper.TopicEnum.EVENT_WS_TOPIC.getTopic(), msg);
                log.info("【游戏更新】kafka-推送成功");
            } catch (Exception e) {
                log.error("send game update msg异常 {} ", e.getMessage());
            }
        }
    }

    // 需要根据pid来更新游戏信息，需要实现这个方法
    private void onGameUpdate(Long pid, boolean isUpdater) {
        var allGames = originalMapper.selectAllByPid(pid);
        var allEntrances = entranceMapper.selectAllEntranceByPid(pid);
        var mapProviders = providers();
        var provider = mapProviders.get(pid).getProviderName();
        var dashProviderName = provider.replace(" ", "-");

        var originList = mapGameInfoList.computeIfAbsent(pid, k -> new ArrayList<>());
        var newList = new ArrayList<GameInfoDTO>();
        var tableMap = new HashMap<String, GameInfoDTO>();
        // 对比新旧数据，找出新增的数据，找出删除的数据
        var newMap = new HashMap<Long, GameInfoDTO>();
        for (var game : allGames) {
            var gameInfo = new GameInfoDTO(game);
            newList.add(gameInfo);
            tableMap.put(gameInfo.getTableId(), gameInfo);
            newMap.put(gameInfo.getId(), gameInfo);
        }
        for (var entrance : allEntrances) {
            var gameInfo = new GameInfoDTO(entrance);
            // 如果是游戏，并且没有图标，那么获取对应的游戏的图标
            checkEntryIcon(gameInfo, tableMap);
            newList.add(gameInfo);
            newMap.put(gameInfo.getId(), gameInfo);
        }
        var gameMap = map.get(pid);
        var deleteNotifyList = new ArrayList<GameInfoExDTO>();
        for (var item : originList) {
            if (!newMap.containsKey(item.getId())) {
                // 删除的数据
                gameMap.remove(item.getId().toString());
                // 因为uniqueName里面包含的数组可能是多条，所以只能删除当前id对应的数据
                var list = gameMap.get(item.getUniqueName());
                if (list != null) {
                    //遍历list，找到对应的数据，然后删除
                    for (var gameInfo : list) {
                        if (gameInfo.getId().equals(item.getId())) {
                            list.remove(gameInfo);
                            break;
                        }
                    }
                    // 如果list为空，则删除对应的key
                    if (list.isEmpty()) {
                        gameMap.remove(item.getUniqueName());
                    }
                }

                var providerUniqueName = item.setFullGameName(dashProviderName);
                mapGameInfo.remove(item.getId().toString());
                // mapGameInfo.remove(providerUniqueName);
                // 同名的游戏可能有多个，所以只删除当前id对应的数据
                var listGameInfo = mapGameInfo.get(providerUniqueName);
                if (listGameInfo != null) {
                    for (var gameInfo : listGameInfo) {
                        if (gameInfo.getId().equals(item.getId())) {
                            listGameInfo.remove(gameInfo);
                            break;
                        }
                    }
                    if (listGameInfo.isEmpty()) {
                        mapGameInfo.remove(providerUniqueName);
                    }
                }

                mapGameInfoList.get(pid).remove(item);
                if (item.getTableId() != null) {
                    var tableGame = mapGameInfoByTableId.get(item.getTableId());
                    if (tableGame != null && tableGame.getId().equals(item.getId())) {
                        mapGameInfoByTableId.remove(item.getTableId());
                    }
                }
                deleteNotifyList.add(new GameInfoExDTO(item));
                log.debug("Item with id {} added to deleteNotifyList", item.getId());
            } else {
                log.info("Item with id {} exists in newMap", item.getId());
            }
        }
        var newNotifyList = new ArrayList<GameInfoExDTO>();
        var updateNotifyList = new ArrayList<GameInfoExDTO>();
        // 添加新的数据
        for (var gameInfo : newList) {
            // 检查是否已经存在
            var item = gameMap.get(gameInfo.getId().toString());
            // 如果不存在则添加, 如果存在则更新
            if (item == null) {
                newGameInfoItem(gameInfo, mapProviders);
                newNotifyList.add(new GameInfoExDTO(gameInfo));
            } else {
                // 如果版本不一致则更新
                var itemData = item.get(0);
                if (!itemData.getVersion().equals(gameInfo.getVersion())) {
                    gameMap.put(gameInfo.getId().toString(), List.of(gameInfo));
                    var uniqueName = gameInfo.getUniqueName();
                    if (uniqueName.equals(itemData.getUniqueName())) {
                        var providerUniqueName = gameInfo.setFullGameName(dashProviderName);
                        // 替换原来的数据
                        var list = gameMap.get(uniqueName);
                        list.remove(itemData);
                        list.add(gameInfo);
                        // 更新mapGameInfo
                        var listGameInfo = mapGameInfo.get(providerUniqueName);
                        listGameInfo.remove(itemData);
                        listGameInfo.add(gameInfo);
//                        mapGameInfo.put(providerUniqueName, gameInfo);
                        mapGameInfo.put(gameInfo.getId().toString(), List.of(gameInfo));
                    } else {
                        // 如果uniqueName不一致则删除旧的，添加新的
                        var oldUniqueName = itemData.getUniqueName();
                        var list = gameMap.get(oldUniqueName);
                        list.remove(itemData);
                        if (list.isEmpty()) {
                            gameMap.remove(oldUniqueName);
                        }

                        mapGameInfo.put(gameInfo.getId().toString(), List.of(gameInfo));
                        list = gameMap.computeIfAbsent(uniqueName, k -> new ArrayList<>());
                        list.add(gameInfo);
                        list.sort(Comparator.comparing(GameInfoDTO::getId));

                        // 删除旧的
                        var fullGameName = itemData.setFullGameName(dashProviderName);
                        var listGameInfo = mapGameInfo.get(fullGameName);
                        listGameInfo.remove(itemData);
                        if (listGameInfo.isEmpty()) {
                            mapGameInfo.remove(fullGameName);
                        }

                        var providerUniqueName = gameInfo.setFullGameName(dashProviderName);
                        listGameInfo = mapGameInfo.computeIfAbsent(providerUniqueName, k -> new ArrayList<>());
                        listGameInfo.add(gameInfo);
                        listGameInfo.sort(Comparator.comparing(GameInfoDTO::getId));
                    }
                    originList.remove(itemData);
                    originList.add(gameInfo);
                    // 更新tableId的映射
                    if (itemData.getTableId() != null) {
                        var tableGame = mapGameInfoByTableId.get(itemData.getTableId());
                        if (tableGame != null && tableGame.getId().equals(itemData.getId())) {
                            mapGameInfoByTableId.remove(itemData.getTableId());
                        }
                    }
                    if (gameInfo.getTableId() != null) {
                        mapGameInfoByTableId.put(gameInfo.getTableId(), gameInfo);
                    }
                    updateNotifyList.add(new GameInfoExDTO(gameInfo));
                }
            }
        }
        // 如果是更新者则通知客户端
        if (!isUpdater) {
            return;
        }
        // 通知客户端
        if (!newNotifyList.isEmpty()) {
            log.info("newNotifyList:{}", newNotifyList.size());
            notifyClientGameUpdate(newNotifyList, "add");
        }
        if (!deleteNotifyList.isEmpty()) {
            log.info("deleteNotifyList:{}", deleteNotifyList.size());
            notifyClientGameUpdate(deleteNotifyList, "delete");
        }
        if (!updateNotifyList.isEmpty()) {
            log.info("updateNotifyList:{}", updateNotifyList.size());
            notifyClientGameUpdate(updateNotifyList, "update");
        }
    }

    private HashMap<Long, ProviderVO> providers() {
        var allProviders = providerMapper.providers();
        HashMap<Long, ProviderVO> mapProviders = new HashMap<>();
        for (var provider : allProviders) {
            mapProviders.put(provider.getPid(), provider);
        }
        return mapProviders;
    }

    private void newGameInfoItem(GameInfoDTO gameInfo, HashMap<Long, ProviderVO> mapProviders) {
        try {
            var uniqueId = gameInfo.getId().toString();
            var uniqueName = gameInfo.getUniqueName();
            var pid = gameInfo.getPid();
            // 从map中获取对应的pid的map，如果没有则创建一个新的map
            var pidMap = map.computeIfAbsent(pid, k -> new HashMap<>());
            // 将gameInfo放入pidMap中, key为uniqueName, value为gameInfo
            // 如果已经存在列表，则添加到列表中
            var list = pidMap.computeIfAbsent(uniqueName, k -> new ArrayList<>());
            list.add(gameInfo);
            // 入口会排在游戏前面，所以这里需要重新排序
            list.sort(Comparator.comparing(GameInfoDTO::getId));
            // 将gameInfo放入map中, key为pid, value为gameInfo
            pidMap.put(uniqueId, List.of(gameInfo));
            // 将gameInfo放入mapGameInfo中, key为provider-uniqueName, value为gameInfo
            var provider = mapProviders.get(pid).getProviderName();
            // 设置全名，用于前端启动游戏
            var providerUniqueName = gameInfo.setFullGameName(provider.replace(" ", "-"));
            // 如果已经存在列表，则添加到列表中
            var listGameInfo = mapGameInfo.computeIfAbsent(providerUniqueName, k -> new ArrayList<>());
            listGameInfo.add(gameInfo);
            // 入口会排在游戏前面，所以这里需要重新排序
            listGameInfo.sort(Comparator.comparing(GameInfoDTO::getId));
            mapGameInfo.put(uniqueId, List.of(gameInfo));

            // 将gameInfo放入mapGameInfoList中, key为pid, value为gameInfo, 如果没有则创建一个新的list
            var gameInfoList = mapGameInfoList.computeIfAbsent(pid, k -> new ArrayList<>());
            gameInfoList.add(gameInfo);

            // 将gameInfo放入mapGameInfoByTableId中, key为tableId, value为gameInfo
            if (gameInfo.getTableId() != null) {
                mapGameInfoByTableId.put(gameInfo.getTableId(), gameInfo);
            }
        } catch (Exception e) {
            log.error("GameInfoServiceImpl onApplicationStartup error", e);
        }
    }

    @Override
    public Optional<GameInfoDTO> getGameInfo(Long pid, String uniqueName) {
        var pidMap = map.get(pid);
        if (pidMap == null) {
            return Optional.empty();
        }
        var gameInfoList = pidMap.get(uniqueName);
        if (gameInfoList == null) {
            return Optional.empty();
        }
        return Optional.ofNullable(gameInfoList.get(0));
    }

    @Override
    public Optional<GameInfoDTO> getGameInfo(String providerUniqueName) {
        var gameInfoList = mapGameInfo.get(providerUniqueName);
        if (gameInfoList == null) {
            return Optional.empty();
        }
        return Optional.ofNullable(gameInfoList.get(0));
    }

    @Override
    public Optional<List<GameInfoDTO>> getGameInfos(String providerUniqueName) {
        return Optional.ofNullable(mapGameInfo.get(providerUniqueName));
    }

    @Override
    public Optional<List<GameInfoDTO>> getGameInfos(Long pid, String uniqueName) {
        var pidMap = map.get(pid);
        if (pidMap == null) {
            return Optional.empty();
        }
        return Optional.ofNullable(pidMap.get(uniqueName));

    }

    @Override
    public Optional<GameInfoDTO> getGameInfoByTableId(String tableId) {
        return Optional.ofNullable(mapGameInfoByTableId.get(tableId));
    }
}
