package com.uponly.casino.admin.vo;


import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Data
@Schema(title="三方游戏实体")
public class GameOriginalVO {
    @Schema(title="id")
    private Long id;

    @Schema(title="供应商id")
    private Long pid;

    @Schema(title="游戏名称")
    private String gameName;

    @Schema(title="供应商名称")
    private String gameProvider;

    @Schema(title="桌号名称")
    private String tableName;

    @Schema(title="桌号名称")
    private String tableNameEdit;

    @Schema(title="桌号图标")
    private String tableIcon;

    @Schema(title="桌号图标编辑")
    private String tableIconEdit;

    @Schema(title="游戏类型")
    private String gameType;


    @Schema(title="游戏子类型")
    private String gameSubtype;

    @Schema(title="虚拟桌号")
    private String virtualTableId;

    @Schema(title="幸运号码")
    private String luckyNumbers;

    @Schema(title="桌号皮肤分配")
    private String sitesAssigned;

    @Schema(title="进入游戏玩家数量")
    private Integer players;

    @Schema(title="展示终端")
    private String display;

    @Schema(title="语言")
    private String lang;

    @Schema(title="历史赢家")
    private String history;

    @Schema(title="描述")
    private String descriptions;

    @Schema(title="视频截图")
    private String videoSnapshot;

    @Schema(title="投注限制")
    private String betLimits;

    @Schema(title="荷官")
    private String dealer;

    @Schema(title="营业时间")
    private String operationHours;

    @Schema(title="是否开放")
    private Integer open;

    @Schema(title="桌号Id")
    private String tableId;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Schema(title="更新时间")
    private Date operationStart;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Schema(title="更新时间")
    private Date operationEnd;

    @Schema(title="版本号")
    private Integer version;
}