package com.uponly.casino.mapper;

import com.uponly.casino.admin.vo.OrderItemVO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface OrderItemMapper {
    Integer add(@Param("orderItem") OrderItemVO orderItem);
    Integer addBatch(@Param("orderItemList") List<OrderItemVO> orderItemList);
    OrderItemVO selectByOrderNo(@Param("orderNo") String orderNo);
    Integer updateByTransactionId(@Param("orderItem") OrderItemVO orderItem);
    Integer updateByOrderNo(@Param("orderItem") OrderItemVO orderItem);
    List<OrderItemVO> selectByCasinoOrderId(@Param("casinoOrderId") Integer casinoOrderId);
    List<OrderItemVO> selectByTransactionIds(@Param("transactionIds") List<String> transactionIds);
    Integer updateByCasinoOrderIdAndBetType(@Param("orderItem") OrderItemVO orderItem);
    List<OrderItemVO> selectByCasinoOrderIdAndBetType(@Param("casinoOrderId") Integer casinoOrderId,@Param("betType") Integer betType);

    Integer addAll(@Param("orderItemList") List<OrderItemVO> orderItemVOS);

}
