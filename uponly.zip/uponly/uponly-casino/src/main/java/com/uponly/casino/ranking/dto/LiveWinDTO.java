package com.uponly.casino.ranking.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class LiveWinDTO implements java.io.Serializable {
    @Schema(description = "livewin type")
    String liveType;

    @Schema(description = "地区", hidden = true)
    Integer location;

    public LiveWinDTO() {}

    public LiveWinDTO(String liveType, Integer location) {
        this.liveType = liveType;
        this.location = location;
    }

    public enum LiveType {
        DAILY("daily"),
        WEEKLY("weekly"),
        MONTHLY("monthly"),
        BIG_WINS("big_wins");

        private final String value;

        LiveType(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }

        public static LiveType fromValue(String value) {
            for (LiveType liveType : LiveType.values()) {
                if (liveType.value.equals(value)) {
                    return liveType;
                }
            }
            return null;
        }
    }
}
