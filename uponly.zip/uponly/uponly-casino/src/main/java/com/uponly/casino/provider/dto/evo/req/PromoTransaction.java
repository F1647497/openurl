package com.uponly.casino.provider.dto.evo.req;

import lombok.Data;

import java.util.List;
import java.util.Map;
import java.util.Objects;

@Data
public class PromoTransaction {
    private String type;                       // Type of promo transaction
    private Origin origin;                     // Origination details
    private String id;                         // Unique identifier of the transaction
    private double amount;                     // Amount of the transaction
    private String voucherId;                  // Voucher ID for free rounds or reward games
    private Integer remainingRounds;           // Remaining free rounds count
    private List<Jackpot> jackpots;            // List of jackpots information
    private Double playableBalance;            // Remaining playable balance
    private String bonusConfigId;              // ID of the bonus config that caused the reward
    private String rewardId;                   // ID of the reward paid out

    public PromoTransaction(String type, Origin origin, String id, double amount, String voucherId, Integer remainingRounds, List<Jackpot> jackpots, Double playableBalance, String bonusConfigId, String rewardId) {
        this.type = type;
        this.origin = origin;
        this.id = id;
        this.amount = amount;
        this.voucherId = voucherId;
        this.remainingRounds = remainingRounds;
        this.jackpots = jackpots;
        this.playableBalance = playableBalance;
        this.bonusConfigId = bonusConfigId;
        this.rewardId = rewardId;
    }

    public PromoTransaction(Map<String, Object> map) {
        this.type = (String) map.get("type");
        this.origin = Objects.isNull(map.get("origin"))?null:new Origin((Map<String, Object>) map.get("origin"));
        this.id = (String) map.get("id");
        this.amount = (double) map.get("amount");
        this.voucherId = (String) map.get("voucherId");
        this.remainingRounds = (Integer) map.get("remainingRounds");
        this.jackpots = (List<Jackpot>) map.get("jackpots");
        this.playableBalance = (Double) map.get("playableBalance");
        this.bonusConfigId = (String) map.get("bonusConfigId");
        this.rewardId = (String) map.get("rewardId");
    }

    @Data
    public static class Origin {
        private String type;

        public Origin(String type) {
            this.type = type;
        }

        public Origin(Map<String, Object> map) {
            this.type = (String) map.get("type");
        }
    }

    @Data
    public static class Jackpot {
        private String id;                     // ID of the winning jackpot
        private double winAmount;              // Win amount of the jackpot

        public Jackpot(String id, double winAmount) {
            this.id = id;
            this.winAmount = winAmount;
        }

        public Jackpot(Map<String, Object> map) {
            this.id = (String) map.get("id");
            this.winAmount = (double) map.get("winAmount");
        }
    }
}
