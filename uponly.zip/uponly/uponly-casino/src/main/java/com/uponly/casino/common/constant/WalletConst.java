package com.uponly.casino.common.constant;

public interface WalletConst {

    String CasinoBetFreeze = "SlotsBetFreeze";  //电子投注冻结

    String CasinoBetFailedUnfreeze = "SlotsBetFailedUnfreeze";//电子投注失败解冻

    String CasinoBetSuccessful = "SlotsBetSuccessful";// 电子投注成功扣除

    String CasinoPayout = "SlotsPayout";// 电子赔付


    String CasinoBetRefund = "SlotsBetRefund";  //退款


    String CasinoSettled = "SlotsSettled"; //结算

    String CasinoBetWin = "SlotsBetWin"; //中奖 TODO

}
