package com.uponly.casino.interceptor;
import com.github.pagehelper.PageInfo;
import com.uponly.casino.admin.dto.SearchOrderDTO;
import com.uponly.casino.admin.vo.OrderVOBe;
import com.uponly.casino.common.api.Result;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


@FeignClient(name = "casino-service") // 指定服务名称和路径
public interface CasinoOrderClient {

    @PostMapping("/casinoOrder/search") // 这里使用远程服务的路径
    Result<PageInfo<OrderVOBe>> search(@RequestBody SearchOrderDTO searchOrderDTO);
}


