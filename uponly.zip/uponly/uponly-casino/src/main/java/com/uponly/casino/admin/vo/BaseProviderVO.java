package com.uponly.casino.admin.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Data
public class BaseProviderVO implements java.io.Serializable {
    @Schema(title="pid")
    private Long pid;

    @Schema(title="排序")
    private int sort;

    @Schema(title="地区")
    private String region;

    @Schema(title="供应商名称")
    private String name;

    @Schema(title="供应商名称")
    private String providerName;

    @Schema(title="供应商名称")
    private String portalDisplayName;

    @Schema(title="供应商图标")
    private String providerIcon;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Schema(title="创建时间")
    private Date createTime;

    @Schema(title="创建人")
    private String creator;

    @Schema(title="状态")
    private int status;

    @Schema(title="回调地址")
    private String backUrl;

    @Schema(title="游戏数量")
    private int entranceCount;

    @Schema(title="游戏数量")
    private int isComming;

    @Schema(title="config")
    private String config;
}
