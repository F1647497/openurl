package com.uponly.casino.common.exception;

import com.uponly.casino.common.api.Result;
import com.uponly.casino.common.api.ResultCode;
import feign.FeignException;
import feign.codec.DecodeException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@Slf4j
@RestControllerAdvice
@Order(Ordered.HIGHEST_PRECEDENCE)
@ResponseStatus(code = HttpStatus.INTERNAL_SERVER_ERROR)
@RequiredArgsConstructor
public class FeignExceptionHandler {
    /**
     * 拦截 FeignException 异常，Jackson 处理失败等情况会进入
     */
    @ExceptionHandler(FeignException.class)
    public Result<?> handleFeignException(FeignException e) {
        log.error("FeignException: ", e);
        return Result.fail(ResultCode.INTERNAL_SERVER_ERROR.getCode(), e.getMessage());
    }

    /**
     * 拦截DecodeException异常，decoder中抛出的自定义全局异常会进入此处
     */
    @ExceptionHandler(DecodeException.class)
    public Result<?> handleDecodeException(DecodeException e) {
        Throwable cause = e.getCause();
        if (cause instanceof BusinessException businessException) {
            // 上游符合全局响应包装约定的再次抛出即可
            return Result.fail(businessException.getCode(), businessException.getMessage());
        }
        log.error("DecodeException: ", e);
        return Result.fail(ResultCode.INTERNAL_SERVER_ERROR.getCode(), e.getMessage());
    }
}