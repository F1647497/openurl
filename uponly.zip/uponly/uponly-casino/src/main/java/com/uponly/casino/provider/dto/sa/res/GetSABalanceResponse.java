package com.uponly.casino.provider.dto.sa.res;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class GetSABalanceResponse {
    private String userName;
    private String currency;
    private BigDecimal amount;
    private Integer error;

}
