package com.uponly.casino.provider.vo.evo;

import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

@Data
public class BaseResult {
    private Game data;

    @Data
    public static class Game {
        private String gameType;
    }


}