package com.uponly.casino.provider.service;

import com.uponly.casino.provider.dto.RequestDTO;
import com.uponly.casino.provider.enums.EnumBodyType;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;

public interface IProviderService {
    Object check(RequestDTO param);
    Object balance(RequestDTO param);
    Object debit(RequestDTO param);
    @Transactional(rollbackFor = Exception.class)
    Object credit(RequestDTO param);
    Object cancel(RequestDTO param);
    Object promotion(RequestDTO param);
    // 获取Body类型
    EnumBodyType getBodyType();
}
