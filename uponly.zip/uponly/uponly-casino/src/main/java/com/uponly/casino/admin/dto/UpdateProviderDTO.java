package com.uponly.casino.admin.dto;

import com.esotericsoftware.kryo.serializers.FieldSerializer;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class UpdateProviderDTO extends ProviderDTO {
    @Schema(title = "pid", required = true)
    @FieldSerializer.NotNull()
    private Long pid;
}
