package com.uponly.casino.provider.dto.ag.res;

import lombok.Data;


@Data
public class AgResp {
    private Result result;
    private String msg;


    public AgResp() {

    }
}
