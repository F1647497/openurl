package com.uponly.casino.admin.service;

import java.util.List;

public interface GetRedisDataService {


    List<String> getEvoRedisDataForAmount();
    List<String> getEvoRedisDataForFix();
    List<String> getEvoRedisDataForABG();
    List<String> getEvoRedisDataForRebate();
}
