package com.uponly.casino.mapper;

import com.uponly.casino.provider.vo.UserInfoVO;

public interface UserMapper {
    Integer add(UserInfoVO user);
    Integer update(UserInfoVO user);

    UserInfoVO selectById(Long id);
    UserInfoVO selectByName(String userName);
}
