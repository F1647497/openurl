package com.uponly.casino.admin.vo;
import java.math.BigDecimal;
import lombok.Data;

@Data
public class OrderHistoryVO {
    private Long id;
    private Integer pid;
    private String orderNo;
    private String thirdOrderNo;
    private String sessionId;
    private String roundId;
    private Integer userId;
    private String operatorType;
    private BigDecimal amount;
    private String gameName;
    private String status;
    private String body;
    private String currency;
}
