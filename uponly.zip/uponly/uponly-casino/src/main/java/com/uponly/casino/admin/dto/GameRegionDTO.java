package com.uponly.casino.admin.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class GameRegionDTO implements java.io.Serializable {
    public GameRegionDTO(Long gameId, Long region) {
        this.gameId = gameId;
        this.region = region;
    }

    @Schema(description = "id", hidden = true)
    private Long id;

    @Schema(description = "游戏id", requiredMode = Schema.RequiredMode.REQUIRED)
    private Long gameId;

    @Schema(description = "地区", requiredMode = Schema.RequiredMode.REQUIRED)
    private Long region;
}
