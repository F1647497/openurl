package com.uponly.casino.provider.vo;

import lombok.Data;
import io.swagger.v3.oas.annotations.media.Schema;

import java.math.BigDecimal;
import java.sql.Timestamp;

@Data
@Schema(title = "CasnioBetLogAction")
public class CasnioBetLogAction {

    @Schema(title = "id")
    private int id;

    @Schema(title = "CasnioBetId")
    private int casnioBetId;

    @Schema(title = "行动类型ID")
    private int actionTypeId;

    @Schema(title = "金额")
    private BigDecimal amount;

    @Schema(title = "添加时间")
    private Timestamp addTime;
}
