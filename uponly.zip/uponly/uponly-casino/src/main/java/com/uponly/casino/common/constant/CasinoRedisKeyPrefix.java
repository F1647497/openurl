package com.uponly.casino.common.constant;

public interface CasinoRedisKeyPrefix {

  String CASINO_USER_GAME_FAVORITES = "casino:user:game:favorites:%s";
  String CASINO_GAME_GAMEID_ENTITY_KEY = "casino:game:gameid:entity";

  String userInfoToken = "casino:user:tokenInfo:cache:";
  //用户信息缓存
  String USER_INFO = "casino:user_info:cache:";

  //游玩id
  String session_id = "casino:user:session:id:";

  String casino_banner_cache = "casino:banner:cache:";

}
