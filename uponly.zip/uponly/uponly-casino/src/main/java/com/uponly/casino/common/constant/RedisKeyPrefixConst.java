package com.uponly.casino.common.constant;


public interface RedisKeyPrefixConst {
    String slot_banner_cache = "slot:banner:cache:";
    String RANK_OPERATION_AFTER_SLOT_BET_ORDER = "slot:betOrder:rank";

    String userInfoToken = "slot:user:tokenInfo:cache:";

    String SLOT_LIVEWIN_FALLBACK_RECORD_FORMAT = "slot:livewin:fallback:record:%s";

    String SLOT_BIGWIN_FALLBACK_RECORD_FORMAT = "slot:bigwin:fallback:record:%s";
    String SLOT_GAMEID_REGIONIDLIST_KEY = "slot:gameid:regionidlist";

    String SLOT_LIVEWIN_REALTIME_RANK_LIST_BY_TIEMSTAMP_FORMAT = "slot:livewin:realtime:ranklist:region:%s";
    String SLOT_LIVEWIN_REALTIME_RANK_LIST_BY_TIEMSTAMP_KEY = "%s:%s:%s:%s";
    String SLOT_LIVEWIN_REALTIME_RANK_LIST_BY_TIEMSTAMP_MAP = "slot:livewin:realtime:ranklist:region:map:%s";
    String SLOT_BIGWIN_REALTIME_RANK_LIST_FORMAT = "slot:bigwin:realtime:ranklist:%s";
    String SLOT_BIGWIN_REALTIME_SAVE_LIST_FORMAT = "slot:bigwin:realtime:savelist:%s";
    String SLOT_LIVEWIN_REALTIME_RANK_EXPIRE_KEY_FORMAT = "slot:livewin:realtime:ranklist:expire:%s";

    //大胜排行榜 Live Big Wins/实时大赢。
    // Game数据发生变化时需要通知redis实时修改，
    // 目前需要推送的点有：
    // 后台修改slot表数据，slot的近7日游戏人数发生改变。
    String BINWIN_RANK = "slot:bigwin:rank";

    //直播排行榜(5秒)
    String LIVEWIN_5S = "slot:livewin:rank:5s";

    // gameId:userId:userName:uuid
    String BIG_WIN_SORT_KEY = "big_win_sort_key:%s:%s:%s:%s";

    String TOP_3_LIST = "slot:game:set:user:rank:";

    String TOP_20_LIST = "slot:top20:%s_%s";

    //用户当前游戏返奖总额 slot:game:user:sum:userId:gameId
    String USER_ORDER_PAYOUT_TOTAL = "slot:game:user:sum:%s_%s";

    //用户信息缓存
    String USER_INFO = "slot:game:user:info:cache:";


    //汇率缓存
    String exchangeRate = "slot:exchange:rate:";

    //热门游戏缓存
    String hotGameCache = "slot:hot:game:cache:";

    //新游戏
    String newGameCache = "slot:new:game:cache:";

    //rtp游戏
    String rtpGameCache = "slot:game:sort:rtp:cache:";

    String bigWinCache = "slot:bigwin:rank:cache";

    String bigWinGameTopOne = "slot:bigWin:rank:top:one:cache:";

    //跑马灯金额下限
    String slotMarqueeCurrency = "slot:marquee:currency:cache:";


    //跑马灯地区金额最高列表
    String slotMarqueeRegionTop = "slot:marquee:region:top:cache:";

    //游玩id
    String session_id = "slot:user:session:id:";

    //用户游戏收藏，按收藏时间倒序 slot:user:game:favorites:userId
    String SLOT_USER_GAME_FAVORITE = "slot:user:game:favorite:%s";

    String SLOT_GAME_ID_ENTITY_KEY = "slot:game:id:entity";

    //游戏的近七日用户人数
    String SLOT_GAME_ID_COUNT_7D = "slot:game:id:count:7d";

    //游戏的热门排行 全局性质的排行榜，不区分地区
    String SLOT_GAME_RANK_POPULAR_KEY = "slot:game:rank:popular";

    //保存交易进度状态 transactionId---->state
    String SLOT_GAME_TRANSACTION_PROGRESS_STATE = "slot:order:txid:state:";

    //保存相同父注单的子注单的总金额，以实现一次性推送 父注单id--->sum(payout)
    String SLOT_GAME_BET_PAYOUT_SUM = "slot:order:betId:sum:%s_%s";

    //注单是否正在上报中 orderNo
    String CASINO_REPORT_ING_STATE = "casino:report:state:%s";
}
