package com.uponly.casino.mapper;

import com.uponly.casino.admin.dto.*;
import com.uponly.casino.admin.vo.EntryFrontVO;
import com.uponly.casino.admin.vo.EntryVO;
import com.uponly.casino.admin.vo.FavoriteCountVO;

import java.util.List;
import java.util.Map;

public interface EntranceMapper {
    EntryVO getEntryByEid(Long entryId);
    EntryFrontVO getEntryByEid2(Map<String, Object> map);
    EntryFrontVO getEntryByEid3(Map<String, Object> map);

    List<EntryVO> searchGameEntrance(SearchGameEntranceDTO searchGameEntranceDTO);

    void addGameEntrance(AddGameEntranceDTO addGameEntranceDTO);

    Integer searchAddition(String addition);
    Integer searchEnameProvider(SearchEnameDTO searchEnameDTO);
    Integer searchEname(String ename);
    Integer getRecommendByEid(Long eid);

    int editGameEntrance(EditGameEntranceDTO editGameEntranceDTO);

    long addGameRegion(AddRegionDTO addRegionDTO);
    List<Long> searchAllGameEid(String mainEntry);

    int deleteGameEntrance(DeleteGameEntranceDTO deleteGameEntranceDTO);

    int deleteGameRegion(DeleteRegionDTO deleteRegionDTO);

    Long getPidByEid(Long eid);

    List<EntryFrontVO> listFavoriteGamesByRegion(Map<String, Object> map);

    List<EntryFrontVO> listEntryGamesByGameType(Map<String, Object> map);

    List<EntryFrontVO> listEntryGamesByAll(Map<String, Object> map);

    List<EntryFrontVO> listEntryGamesByPromotion(Map<String, Object> map);

    List<EntryFrontVO> listEntryGamesByRecommend(Map<String, Object> map);

    void batchSort(BatchSortDTO batchSortDTO);

    List<EntryVO> selectAllEntrance();
    List<EntryVO> selectAllEntranceByPid(Long pid);

    FavoriteCountVO getFavoriteCount(FavoriteCountVO favoriteCountVO);



}
