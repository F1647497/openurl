package com.uponly.casino.admin.vo;

import lombok.Data;

import java.util.Date;

@Data
public class GameSearch {
    private int id;
    private String providerName;
    private String tableId;
    private String tableName;
    private String tableNameEdit;
    private String tableIcon;
    private String tableIconEdit;

    private String betLimits;
    private String gameType;
    private int players;
    private String dealer;
    private String operationHours;

    private boolean open;
    private String descriptions;
    private Date operationStart;
    private Date operationEnd;
}
