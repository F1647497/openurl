package com.uponly.casino.admin.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Data
public class AddProviderDTO extends ProviderDTO {
    @Schema(description = "供应商ID", hidden = true)
    private Long pid;

    @Schema(title="创建人")
    private String creator;
}
