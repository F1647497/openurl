package com.uponly.casino.provider.dto.ae.resp;

import com.alibaba.fastjson2.JSONObject;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class CancelBetResp {
    protected String status;
    protected String desc;
    protected BigDecimal balance;
    protected String balanceTs;

    public CancelBetResp(String status, String desc, BigDecimal balance, String balanceTs) {
        this.status = status;
        this.desc = desc;
        this.balance = balance;
        this.balanceTs = balanceTs;
    }
    public CancelBetResp(String status, String desc, boolean success) {
        this.status = status;
        this.desc = desc;
    }

    public CancelBetResp(){
        super();
    }

    public JSONObject toReturnFail(String status,String desc) {
        this.status = status;
        this.desc = desc;
        JSONObject jsonObject =JSONObject.from(this);
        jsonObject.put("status", getStatus());
        jsonObject.put("desc", getDesc());
        return jsonObject;
    }

    public JSONObject toReturnSuccess(String status,BigDecimal balance,String balanceTs) {
        this.status = status;
        this.balance = balance;
        this.balanceTs = balanceTs;
        JSONObject jsonObject =JSONObject.from(this);
        jsonObject.put("status", getStatus());
        jsonObject.put("balance", getBalance());
        jsonObject.put("balanceTs", getBalanceTs());
        return jsonObject;
    }

}
