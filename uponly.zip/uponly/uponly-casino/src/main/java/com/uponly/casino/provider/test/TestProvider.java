package com.uponly.casino.provider.test;

import com.alibaba.fastjson.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class TestProvider {

    static JSONObject getGamesFiltered() {
        try {
            // 设置请求 URL
            URL url = new URL("https://tm2up.uat1.evo-test.com/api/lobby/v1/tm2up00000000001/state?gameVertical=live&gameProvider=evolution");
            // 创建 HttpURLConnection 对象
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();

            // 设置请求头
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Authorization", "Basic dG0ydXAwMDAwMDAwMDAwMTp0ZXN0MTIz");

            // 发送请求并获取响应码
            int responseCode = conn.getResponseCode();
            System.out.println("Response Code: " + responseCode);

            // 读取响应内容
            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            JSONObject jsonObject = JSONObject.parseObject(response.toString());


            JSONObject tables = jsonObject.getJSONObject("tables");

            // 定义一个Map来存储所有的tableId和对应的详细信息
            Map<String, JSONObject> tableIdMap = new HashMap<>();
            // 获取tables中的所有键值对
            Set<Map.Entry<String, Object>> entrySet = tables.entrySet();

            Map<String,String> gameTypeList = new HashMap<>();

            // 遍历entrySet并获取所有tableId的键和值
            for (Map.Entry<String, Object> entry : entrySet) {
                String tableId = entry.getKey(); // 获取tableId
                JSONObject tableData = (JSONObject) entry.getValue();
                //获取tableData的所有数据

                //对下面字段进行判空处理
                String gameType = tableData.getString("gameType");
                String gameSubType = tableData.getString("gameSubType");

                gameTypeList.put(gameType,gameSubType);

                String name = tableData.getString("name");
                //获取sitesAssigned，players，gameProvider，display，language，descriptions，videoSnapshot的值
                com.alibaba.fastjson.JSONArray sitesAssigned = tableData.getJSONArray("sitesAssigned");
                com.alibaba.fastjson.JSONArray luckyNumbers = tableData.getJSONArray("luckyNumbers");
                com.alibaba.fastjson.JSONArray history = tableData.getJSONArray("history");

                // 获取players字段
                int players = tableData.getIntValue("players");
                String gameProvider = tableData.getString("gameProvider");
                String display = tableData.getString("display");
                String language = tableData.getString("language");
                JSONObject descriptions = tableData.getJSONObject("descriptions");
                JSONObject dealer = tableData.getJSONObject("dealer");
                String videoSnapshot = tableData.getString("videoSnapshot");
                String virtualTableId = tableData.getString("virtualTableId");

                JSONObject betLimitObj  = tableData.getJSONObject("betLimits");
                JSONObject limitOfTHB  = betLimitObj.getJSONObject("THB");
                JSONObject limitOfVND  = betLimitObj.getJSONObject("VND");
                JSONObject limitOfIDR  = betLimitObj.getJSONObject("IDR");
                JSONObject limitOfMYR  = betLimitObj.getJSONObject("MYR");
                JSONObject limitOfUSD  = betLimitObj.getJSONObject("USD");

                JSONObject myBetLimitObj  = new JSONObject();
                myBetLimitObj.put("THB",limitOfTHB);
                myBetLimitObj.put("VND",limitOfVND);
                myBetLimitObj.put("IDR",limitOfIDR);
                myBetLimitObj.put("MYR",limitOfMYR);
                myBetLimitObj.put("USD",limitOfUSD);

                JSONObject myTableData = new JSONObject();
                myTableData.put("gameType", gameType);
                myTableData.put("gameSubType", gameSubType);
                myTableData.put("luckyNumbers", luckyNumbers);
                myTableData.put("history", history);
                myTableData.put("name", name);
                myTableData.put("sitesAssigned", sitesAssigned);
                myTableData.put("players", players);
                myTableData.put("gameProvider", gameProvider);
                myTableData.put("display", display);
                myTableData.put("language", language);
                myTableData.put("descriptions", descriptions);
                myTableData.put("videoSnapshot", videoSnapshot);
                myTableData.put("virtualTableId", virtualTableId);
                myTableData.put("dealer", dealer);

                myTableData.put("betLimits", myBetLimitObj);
                // 获取对应的详细信息
                tableIdMap.put(tableId, myTableData); // 将tableId和详细信息存入map中

            }

            System.out.println("gameTypeList:---- " + gameTypeList);


            //将tableIdMap转换为json字符串
            String tableIdMapJson = JSONObject.toJSONString(tableIdMap);

            // 创建一个新的 JSONObject
            JSONObject res = new JSONObject();

            // 遍历 tableIdMap，并将每个键值对放入 JSONObject
            for (Map.Entry<String, JSONObject> entry : tableIdMap.entrySet()) {
                res.put(entry.getKey(), entry.getValue());
            }

            //打印myTableData的所有数据
            System.out.println("res:---- " + res);
            System.out.println("jsonObject:---- " + jsonObject);

            return res;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    static JSONObject getEntry(){
        try {
            // 创建 URL 对象
            URL url = new URL("https://tm2up.uat1.evo-test.com/ua/v1/tm2up00000000001/test123");

            // 创建 HttpURLConnection 对象
            HttpURLConnection con = (HttpURLConnection) url.openConnection();

            // 设置请求方法为 POST
            con.setRequestMethod("POST");

            // 设置请求头
            con.setRequestProperty("Content-Type", "application/json");

            // 启用输出流，并设置请求体数据
            con.setDoOutput(true);

            String requestData = "{" +
                    "\"uuid\":\"123\"," +
                    "\"player\":{" +
                    "\"id\":\"a1a2a3a4\"," +
                    "\"update\":true," +
                    "\"nickname\":\"nickname\"," +
                    "\"language\":\"en-GB\"," +
                    "\"currency\":\"EUR\"," +
                    "\"session\":{" +
                    "\"id\":\"111ssss3333rrrrr45555\"," +
                    "\"ip\":\"192.168.0.1\"" +
                    "}," +
                    "\"maxBet\":5.0" +
                    "}," +
                    "\"config\":{" +
                    "\"brand\":{" +
                    "\"id\":\"1\"," +
                    "\"skin\":\"1\"" +
                    "}," +
                    "\"game\":{" +
                    "\"category\":\"roulette\"," +
                    "\"interface\":\"view1\"," +
                    "\"table\":{" +
                    "\"id\":\"vip-roulette-123\"" +
                    "}" +
                    "}," +
                    "\"channel\":{" +
                    "\"wrapped\":false," +
                    "\"mobile\":false" +
                    "}," +
                    "\"urls\":{" +
                    "\"cashier\":\"http://www.chs.ee\"," +
                    "\"responsibleGaming\":\"http://www.RGam.ee\"," +
                    "\"lobby\":\"http://www.lobb.ee\"," +
                    "\"sessionTimeout\":\"http://www.sesstm.ee\"" +
                    "}" +
                    "}";

            try (DataOutputStream wr = new DataOutputStream(con.getOutputStream())) {
                wr.writeBytes(requestData);
                wr.flush();
            }

            // 获取响应状态码
            int responseCode = con.getResponseCode();

            // 读取响应内容
            try (BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()))) {
                String inputLine;
                StringBuffer response = new StringBuffer();
                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                // 打印响应内容
                System.out.println(response.toString());
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    static JSONObject getCheck() {
        try {
            // 创建 URL 对象
            URL url = new URL("https://tm2up.uat1.evo-test.com/api/check?authToken=53FB7C65719DF37B");

            // 创建 HttpURLConnection 对象
            HttpURLConnection con = (HttpURLConnection) url.openConnection();

            // 设置请求方法为 POST
            con.setRequestMethod("POST");

            // 设置请求头
            con.setRequestProperty("Content-Type", "application/json");

            // 启用输出流，并设置请求体数据
            con.setDoOutput(true);

            String requestData = "{" +
                    "\"sid\":\"sid-parameter-from-UserAuthentication-call\"," +
                    "\"userId\":\"2906\"," +
                    "\"channel\":{" +
                    "\"type\":\"P\"" +
                    "}," +
                    "\"uuid\":\"ce186440-ed92-11e3-ac10-0800200c9a66\"" +
                    "}";

            try (DataOutputStream wr = new DataOutputStream(con.getOutputStream())) {
                wr.writeBytes(requestData);
                wr.flush();
            }

            // 获取响应状态码
            int responseCode = con.getResponseCode();

            // 读取响应内容
            try (BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()))) {
                String inputLine;
                StringBuffer response = new StringBuffer();
                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                // 打印响应内容
                System.out.println(response.toString());
            }



        } catch (ProtocolException e) {
            throw new RuntimeException(e);
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return null;
    }
        public static void main(String[] args) {
        getGamesFiltered();
        //getEntry();
      //      getCheck();

    }
}

