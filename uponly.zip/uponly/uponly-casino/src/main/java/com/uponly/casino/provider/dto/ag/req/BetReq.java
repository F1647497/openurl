package com.uponly.casino.provider.dto.ag.req;

import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Map;


@Data
public class BetReq {
    private String sessionToken;      // 服务器的验证编码。与Create Game Session的值相同。
    private String currency;   // dm 代表返回的网站域名 *如无须跳转，请设置为dm=NO_RETURN
    private BigDecimal value; // 金额，数值准确至小数后4个位。
    private String playname;  // 游戏账号，為product ID+username 組合，並区分大小写。
    private String agentCode;     // 代理编码
    private String transactionID;     // 同一局里下注同一位置(playtype)兩次會產生兩組交易編號transactionID
    private String platformType;     // 平台类型
    private String round;     // 平台游戏厅别类型，请参考附录：视讯游戏round平台内的大厅类型
    private String gametype;     // 游戏类型
    private String gameCode;     // 游戏局号
    private String tableCode;     // 台号
    private String transactionType;     //交易类型 BET：下注 WIN：贏 LOSE：输 REFUND：额度回滚
    private String transactionCode;     //真人下注产生的交易，请参考附录：视讯游戏transactionCode交易代码
    private String deviceType;     //DESKTOP – 代表电脑 MOBILE – 代表手机
    private String playtype;     //下注玩法

    public BetReq() {

    }
}
