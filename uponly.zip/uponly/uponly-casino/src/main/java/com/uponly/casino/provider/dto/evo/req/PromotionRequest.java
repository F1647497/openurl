package com.uponly.casino.provider.dto.evo.req;

import lombok.Data;

import java.util.Map;
import java.util.Objects;

@Data
public class PromotionRequest {
    private String sid;                // Player's session ID
    private String userId;             // Player's ID, assigned by Licensee
    private String currency;           // Currency code (ISO 4217 3-letter code)
    private Game game;                 // Game details, may be null
    private PromoTransaction promoTransaction; // Promotional transaction details
    private String uuid;

    public PromotionRequest(Map<String, Object> body) {
        this.sid = (String) body.get("sid");
        this.userId = (String) body.get("userId");
        this.currency = (String) body.get("currency");
        this.game = Objects.isNull(body.get("game"))?null:new Game((Map<String, Object>) body.get("game"));
        this.promoTransaction = new PromoTransaction((Map<String, Object>) body.get("promoTransaction"));
        this.uuid = (String) body.get("uuid");
    }
}
