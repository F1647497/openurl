package com.uponly.casino.admin.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.uponly.casino.admin.dto.BannerBatchSortDTO;
import com.uponly.casino.admin.dto.BannerDTO;
import com.uponly.casino.admin.service.CasinoBannerService;
import com.uponly.casino.admin.vo.CasinoBanner;
import com.uponly.casino.common.constant.CasinoRedisKeyPrefix;
import com.uponly.casino.common.constant.exception.BusinessException;
import com.uponly.casino.mapper.CasinoBannerMapper;
import com.uponly.casino.util.RedissonUtil;
import com.uponly.casino.util.RegionIntegerUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@Slf4j
public class CasinoBannerServiceImpl implements CasinoBannerService {

    @Autowired
    private CasinoBannerMapper casinoBannerMapper;
    /*@Autowired
    private LiveWinsRecordMapper liveWinsRecordMapper;*/
    @Autowired
    private RedissonUtil redissonUtil;

    @Override
    public List<CasinoBanner> casinoBannerListFe(String region) {
        return redissonUtil.getList(CasinoRedisKeyPrefix.casino_banner_cache+region);
    }

    @Override
    public PageInfo<CasinoBanner> casinoBannerList(BannerDTO dto) {
        return PageHelper.startPage(dto.getPage(), dto.getPageSize())
                .setOrderBy("sort asc")
                .doSelectPageInfo(() -> casinoBannerMapper.queryBanner(dto));
    }

    @Override
    public void insert(CasinoBanner casinoBanner) throws BusinessException {

        List<Integer> sort = new ArrayList<>();
        sort.add(casinoBanner.getSort());
        if (casinoBannerMapper.querySort(sort).size() > 0) {
            throw new BusinessException("序号重复：" + sort);
        }

        casinoBannerMapper.insertSelective(casinoBanner);
        this.updateCache();
    }

    @Override
    public void update(CasinoBanner casinoBanner) throws BusinessException {


        if (casinoBanner.getSort() != null) {
            List<Integer> sort = new ArrayList<>();
            sort.add(casinoBanner.getSort());
            if (casinoBannerMapper.querySort(sort).size() > 0) {
                throw new BusinessException("序号重复：" + sort);
            }
        }

        casinoBannerMapper.updateByPrimaryKeySelective(casinoBanner);
        this.updateCache();
    }

    @Override
    public void delete(Long id) {

        casinoBannerMapper.deleteById(id);
        this.updateCache();
    }

    @Override
    public void batchSort(List<BannerBatchSortDTO> batch) throws BusinessException {
        List<Integer> sortList = batch.stream().map(BannerBatchSortDTO::getSort).collect(Collectors.toList());
        if (casinoBannerMapper.querySort(sortList).size() > 0) {
            throw new BusinessException("序号重复：" + sortList);
        }
        for (BannerBatchSortDTO dto : batch) {
            CasinoBanner casinoBanner = new CasinoBanner();
            casinoBanner.setSort(dto.getSort());
            casinoBanner.setId(dto.getId());
            casinoBannerMapper.updateSort(casinoBanner);
        }
        this.updateCache();
    }


    /**
     * 刷新缓存
     */
    @Override
    public void updateCache() {
        log.info("CasinoBannerServiceImpl updateCache");
        List<CasinoBanner> casinoBannerList = casinoBannerMapper.refreshCache();
        Map<String, List<CasinoBanner>> groupedBanners = casinoBannerList.stream()
                .collect(Collectors.groupingBy(banner -> banner.getLocation() + "-" + banner.getLocale()));
        log.info("CasinoBannerServiceImpl updateCache groupedBanners={}", groupedBanners);
        for (Map.Entry<String, List<CasinoBanner>> entry : groupedBanners.entrySet()) {
            String key = entry.getKey(); // 获取键
            List<CasinoBanner> banners = entry.getValue(); // 获取值
            List<Object> objectList = banners.stream()
                    .map(obj -> (Object) obj)  // 使用映射将每个 MyObj 转换为 Object
                    .toList();
            log.info("CasinoBannerServiceImpl updateCache objectList={}", objectList);
            redissonUtil.setList(CasinoRedisKeyPrefix.casino_banner_cache + key, objectList, 1);
        }
    }

    @Override
    public Integer maxSort() {
        return RegionIntegerUtil.roundUpToHundreds(casinoBannerMapper.getMaxSort());
    }


}
