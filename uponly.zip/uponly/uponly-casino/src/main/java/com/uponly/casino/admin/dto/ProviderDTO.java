package com.uponly.casino.admin.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class ProviderDTO implements java.io.Serializable {
    @Schema(description = "地区", requiredMode = Schema.RequiredMode.REQUIRED)
    private String region;

    @Schema(title="供应商图标", requiredMode = Schema.RequiredMode.REQUIRED)
    private String providerIcon;

    @Schema(title="供应商名称", requiredMode = Schema.RequiredMode.REQUIRED)
    private String providerName;

    @Schema(title="供应商名称", requiredMode = Schema.RequiredMode.REQUIRED)
    private String portalDisplayName;

    @Schema(title="状态", requiredMode = Schema.RequiredMode.REQUIRED)
    private int status;

    @Schema(title="排序", requiredMode = Schema.RequiredMode.REQUIRED)
    private int sort;

    @Schema(title="是否上线", requiredMode = Schema.RequiredMode.REQUIRED)
    private int isComming;
    
}
