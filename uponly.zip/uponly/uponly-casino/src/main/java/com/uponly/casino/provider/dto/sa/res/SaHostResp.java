package com.uponly.casino.provider.dto.sa.res;

import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class SaHostResp {

    /**
     * 桌台id
     */
    private String HostID;
    /**
     * 游戏类型
     */
    private String GameType;
    /**
     * 桌台名称
     */
    private String HostName;
    /**
     * true – 营运商已在后台启用
     * false – 营运商已在后台停用
     */
    private String Enabled;
    /**
     * 0:桌台已开
     * 1:桌台已关
     */
    private String GameStatus;


    public SaHostResp() {

    }
}
