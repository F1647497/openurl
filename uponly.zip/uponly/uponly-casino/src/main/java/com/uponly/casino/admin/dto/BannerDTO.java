package com.uponly.casino.admin.dto;


import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.Date;

@Data
public class BannerDTO extends MyPageParams{

    @Schema(title = "id")
    private Long id;

    @Schema(title = "排序")
    private Integer sort;

    @Schema(title = "广告名称")
    private String bannerName;

    @Schema(title = "all app h5(逗号隔开)")
    private String platformType;

    @Schema(title = "厂商")
    private String provider;

    @Schema(title = "图片地址")
    private String pictureUrl;

    @Schema(title = "开始时间")
    private Date startTime;

    @Schema(title = "结束时间")
    private Date endTime;

    @Schema(title = "跳转url")
    private String redirectUrl;

    @Schema(title = "创建人")
    private String founder;

    @Schema(title = "备注")
    private String remark;

    @Schema(title = "0关闭 1开启")
    private Integer status;

    @Schema(title = "创建时间")
    private Date createTime;

    @Schema(title = "修改时间")
    private Date updateTime;

    @Schema(title = "修改人")
    private String updateBy;

    @Schema(title = "语言 en,zh,id,vi,th,ms")
    private String locale;

    @Schema(title = "地区  1 3 4 5 7")
    private Integer location;



}
