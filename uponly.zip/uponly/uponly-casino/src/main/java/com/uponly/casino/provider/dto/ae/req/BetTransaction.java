package com.uponly.casino.provider.dto.ae.req;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

import java.math.BigDecimal;
@Data
public class BetTransaction {
    public String platformTxId;
    public String userId;
    public String currency;
    public String platform;
    public String gameType;
    public String gameCode;
    public String gameName;
    public String betType;
    public BigDecimal betAmount;
    public BigDecimal jackpotBetAmount;
    public String betTime;
    public String roundId;
    @JsonIgnore
    public String gameInfo;
}
