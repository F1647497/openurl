package com.uponly.casino.provider.service.impl;

import cn.hutool.core.util.IdUtil;
import cn.hutool.http.HttpResponse;
import cn.hutool.http.HttpUtil;
import com.alibaba.fastjson2.JSON;
import com.alibaba.fastjson2.JSONArray;
import com.alibaba.fastjson2.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.uponly.casino.admin.service.GameService;
import com.uponly.casino.admin.vo.*;
import com.uponly.casino.common.api.Result;
import com.uponly.casino.common.api.ResultCode;
import com.uponly.casino.common.constant.CommonConstant;
import com.uponly.casino.common.exception.BusinessException;
import com.uponly.casino.mapper.GameOriginalMapper;
import com.uponly.casino.mapper.OrderItemMapper;
import com.uponly.casino.provider.dto.GameInfoDTO;
import com.uponly.casino.provider.dto.RequestDTO;
import com.uponly.casino.provider.dto.ae.AEConfig;
import com.uponly.casino.provider.dto.ae.req.*;
import com.uponly.casino.provider.dto.ae.resp.*;
import com.uponly.casino.provider.dto.evo.Config;
import com.uponly.casino.provider.dto.evo.req.CreditRequest;
import com.uponly.casino.provider.dto.evo.req.PromotionRequest;
import com.uponly.casino.provider.dto.evo.req.SidRequest;
import com.uponly.casino.provider.dto.evo.res.AuthenticationResponse;
import com.uponly.casino.provider.dto.evo.res.CreditResponse;
import com.uponly.casino.provider.dto.evo.res.PromotionResponse;
import com.uponly.casino.provider.dto.evo.res.SidResponse;
import com.uponly.casino.provider.dto.toup.BalanceDTO;
import com.uponly.casino.provider.dto.toup.ChangeBalanceResponse;
import com.uponly.casino.provider.dto.toup.GetBalanceResponse;
import com.uponly.casino.provider.enums.EVOGameType;
import com.uponly.casino.provider.enums.EVOStatusType;
import com.uponly.casino.provider.enums.EnumBodyType;
import com.uponly.casino.provider.enums.EnumWalletOperatorType;
import com.uponly.casino.provider.service.ProviderManager;
import com.uponly.casino.provider.vo.UserInfoVO;
import com.uponly.casino.util.UidUtil;
import lombok.extern.slf4j.Slf4j;
import org.redisson.api.RBucket;
import org.redisson.api.RList;
import org.redisson.api.RMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import java.math.BigDecimal;
import java.net.URLDecoder;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

import static com.uponly.casino.common.constant.CommonConstant.CASINO_ORDER_RESULT_LIST;


@Slf4j
@Service
public class AeProviderImpl extends BaseProviderImpl {
    protected Map<String,AEConfig> aeConfigMap;
    public static Config config ;
    @Autowired
    private GameService gameService;
    @Autowired
    private GameOriginalMapper gameOriginalMapper;
    @Autowired
    private ProviderManager providerManager;

    @Autowired
    private OrderItemMapper orderItemMapper;

    public static final String CASINO_SESSION_KEY = "casino:user:session:";

    @Override
    public boolean initialize(ProviderVO providerVo) {
        super.initialize(providerVo);
        List<AEConfig> aeConfigList = JSON.parseArray(providerVo.getConfig(), AEConfig.class);

        aeConfigMap = aeConfigList.stream()
                .collect(Collectors.toMap(AEConfig::getCurrency, aeConfig -> aeConfig));

        if (aeConfigMap.isEmpty()) {
            log.error("AE config is null");
            return false;
        }

        return true;
    }
    public boolean checkUserId(String uid) {
        // 驗證 uid 是否為純數字
        try {
            Long.parseLong(uid);
        } catch (NumberFormatException e) {
            log.error("AE userId is not a numeric value");
            return false;
        }
        return true;
    }

    public boolean checkCert(AEConfig config,String cert) {
        if(!config.getCert().equals(cert)){
            return false;
        }
        return true;
    }

    public EnumBodyType getBodyType() {
        return EnumBodyType.URL_ENCODE;
    }

    public boolean validate(String uid, String sid) {
        if (uid == null || sid == null) {
            log.error("ae userId or sid is null");
            return false;
        }
        var sessionKey = CASINO_SESSION_KEY + uid;
        RMap<String, String> map = redissonClient.getMap(sessionKey);
        String jsonValue = map.get("sessionids");
        try {
            JSONObject nested = JSONObject.parseObject(jsonValue);
            if (Objects.isNull(nested) || !nested.containsKey(sid)) {
                log.error("ae {} sid is invalid", sid);
                return false;
            }
        } catch (Exception e) {
            log.error("ae validate error: {}", e.getMessage());
            return false;
        }
        return true;
    }

    public JSONObject getBalance(RequestDTO param) throws Exception {
        log.info("ae balance api call {}", JSON.toJSONString(param.getBody()));
        // 把 param的body转换成JSONObject
        Object message  = param.getBody().get("message");
        JSONObject jsonObject = JSONObject.parseObject(URLDecoder.decode(String.valueOf(message), "UTF-8"));
        var req = new BalanceReq(jsonObject);
        var res = new BalanceResp();
        var userId = req.getUserId();

        if(!checkUserId(userId)){
            log.error("ae userId is invalid {}", userId);
            return res.toReturnFail("1000","Invalid userId!");
        }
        Long uid = Long.valueOf(userId);
        Optional<UserInfoVO> user = userInfoService.getUser(uid);
        if (user.isEmpty()) {
            log.error("ae userId is invalid {}", uid);
            return res.toReturnFail("1000","Invalid userId!");
        }
        if(aeConfigMap.get(user.get().getCurrency()) == null){
            log.error("ae AeConfig is null currency {}",user.get().getCurrency());
            return res.toReturnFail("9999","Fail");
        }
        if(!checkCert(aeConfigMap.get(user.get().getCurrency()),String.valueOf(param.getBody().get("key")))) {
            log.error("ae Certificate is invalid");
            return res.toReturnFail("1027","Invalid Certificate!");
        }

        var balanceResponse = getBalance(uid);
        // 把 balanceResponse转换成JSONObject
        if (balanceResponse.isEmpty()) {
            log.error("ae balanceResponse is null");
            return res.toReturnFail("9999","Fail");
        }
        var balance = balanceResponse.get().getBalance();
        ZonedDateTime now = ZonedDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
        return res.toReturnSuccess("0000",balance.setScale(2,BigDecimal.ROUND_HALF_UP),now.format(formatter),userId);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public JSONObject credit(RequestDTO param) {
        log.info("ae 【credit】api call {}", JSON.toJSONString(param.getBody()));
        var ret = new CreditRequest(param.getBody());
        var res = new CreditResponse();
        res.setUuid(ret.getUuid());
        var userId = ret.getUserId();
        if(!checkUserId(ret.getUserId())){
            res.setStatus(EVOStatusType.INVALID_PARAMETER.name());
            return res.toJSONObject();
        }
        var check = validate(userId, ret.getSid());
        if (!check) {
            res.setStatus(EVOStatusType.INVALID_SID.name());
            log.error("ae 【credit】  check is false");
            return res.toJSONObject();
        }
        var changeBalance = new BalanceDTO();
        var transaction = ret.getTransaction();
        var game = ret.getGame();
        changeBalance.setTransactionId(transaction.getId());
        changeBalance.setSessionId(transaction.getRefId());
        changeBalance.setGameId(game.getId());
        changeBalance.setGameName(game.getType());
        changeBalance.setAmount(transaction.getAmount());
        changeBalance.setUserId(Long.valueOf(userId));
        // 从redis中获取存入的Order
        String orderKey = ORDER_KEY_REF + transaction.getRefId();
        RBucket<String> bucket = redissonClient.getBucket(orderKey);
        OrderVO order;
        OrderHistoryVO orderHistory;
        var orderData = (String)bucket.get();
        if (orderData == null) {
            // 根据orderKey没有找到对应的order, 从数据库中查找
            order = orderMapper.selectByUserIdAndRoundId(changeBalance.getUserId(), game.getId());
            if (order == null) {
                //多注合併後 還需去歷史紀錄找
                orderHistory = orderMapper.selectHistoryByUserIdAndSessionId(changeBalance.getUserId(), transaction.getId(),EnumWalletOperatorType.CasinoBetFreeze.getValue());
                if (orderHistory == null) {
                    log.error("ae 【credit】 order is null, cannot find order by userId={}, pid={}, roundId={}", userId, game.getId(), transaction.getRefId());
                    res.setStatus(EVOStatusType.BET_DOES_NOT_EXIST.name());
                    return res.toJSONObject();
                }else {
                    if(!orderHistory.getSessionId().equals(transaction.getRefId())){
                        res.setStatus(EVOStatusType.BET_DOES_NOT_EXIST.name());
                        return res.toJSONObject();
                    }
                    var user = userInfoService.getUser(changeBalance.getUserId());
                    if (user.isEmpty()) {
                        log.error("【newOrder】获取用户信息失败,userId={},betOrderNumber={}", param.getBody().get("userId"), changeBalance.getOrderNo());
                        res.setStatus(EVOStatusType.INVALID_SID.name());
                        return res.toJSONObject();
                    }
                    order= new OrderVO();
                    order.setThirdOrderNo(transaction.getId());
                    order.setOrderNo(orderHistory.getOrderNo());
                    order.setStatus(OrderVO.EnumOrderStatus.BET.getCode());
                    order.setAmount(orderHistory.getAmount());

                    order.setUserId(changeBalance.getUserId());
                    order.setUserName(user.get().getUserName());
                    order.setCurrency(user.get().getCurrency());
                    order.setRegion(user.get().getLocation());
                    order.setPid(changeBalance.getProviderId());

                    order.setMsgState(OrderVO.EnumMsgState.NONE.getCode());
                    order.setSessionId(changeBalance.getSessionId());
                    order.setRoundId(changeBalance.getGameId());
                    order.setGameName(changeBalance.getGameName());
                    order.setBody(new JSONObject(param.getBody()).toJSONString());
                }
            }
        } else {
            log.info("ae 【credit】 redis orderData={}", orderData);
            order = JSON.parseObject(orderData, OrderVO.class);
            bucket.expire(expiration);
        }

        //確認狀態是否已經派彩過
        if(order.getStatus().equals(OrderVO.EnumOrderStatus.PAYOUT.getCode()) || order.getStatus().equals(OrderVO.EnumOrderStatus.CANCEL.getCode()) ){
            res.setStatus(EVOStatusType.BET_ALREADY_SETTLED.name());
            return res.toJSONObject();
        }

        //檢查注單refId是否對的上
        if(!order.getSessionId().equals(transaction.getRefId())){
            res.setStatus(EVOStatusType.BET_DOES_NOT_EXIST.name());
            return res.toJSONObject();
        }

        changeBalance.setOrderNo(order.getOrderNo());

        changeBalance.setOperatorType(EnumWalletOperatorType.CasinoPayout.getValue());
        changeBalance.setRemark(game.getDetails().toString());
        newHistory(changeBalance, param);
        var changeResponse = changeBalance(changeBalance);
        if (changeResponse.isEmpty()) {
            res.setStatus(EVOStatusType.INSUFFICIENT_FUNDS.name());
            log.error("ae 【credit】  changeResponse is empty");
            return res.toJSONObject();
        }

        if(changeResponse.get().getMgs()!=null){
            if(changeResponse.get().getMgs().equals(170) || changeResponse.get().getMgs().equals(100)){//重複訂單
                res.setStatus(EVOStatusType.BET_ALREADY_SETTLED.name());
                return res.toJSONObject();
            }
            res.setStatus(EVOStatusType.INSUFFICIENT_FUNDS.name());
            return res.toJSONObject();
        }

        // 更新credit状态
        order.setPayout(transaction.getAmount());
        // add by danny 2024-05-09
        if (transaction.getAmount().compareTo(BigDecimal.ZERO) > 0) {
            var usdAmount = rollingRankingService.getRate(order.getCurrency());
            BigDecimal bigDecimal = usdAmount.get();
            order.setUsdPayout(bigDecimal.multiply(transaction.getAmount()));
        }

        order.setStatus(OrderVO.EnumOrderStatus.PAYOUT.getCode());
        order.setSettleAt(new Date());
        order.setPid(providerVO.getPid());
        order.setGameType(game.getType());
        if (orderMapper.updatePayout(order) == 0) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            log.error("ae 【credit】 updatePayout failed");
            res.setStatus(EVOStatusType.UNKNOWN_ERROR.name());
            return res.toJSONObject();
        }
        order.setBody(null);

        if(EVOGameType.getEnumByName(game.getType()) == null){
            savePayoutRedis(order);
        }else {
            RList<OrderVO> resultList = redissonClient.getList(CASINO_ORDER_RESULT_LIST);
            resultList.add(order);
        }


        // 更新排行榜
        order.setBody(new JSONObject(param.getBody()).toJSONString());
        rollingRankingService.processBettingData(order);

        String orderJson = JSONObject.toJSONString(order);
        bucket.set(orderJson, expiration);

        var balance = changeResponse.get().getBalance();
        res.setBalance(balance);
        res.setBonus(BigDecimal.ZERO);
        return res.toJSONObject();
    }

    public void savePayoutRedis(OrderVO order) {
        RList<String> amountList = redissonClient.getList(CommonConstant.CASINO_ORDER_AMOUNT_LIST + "_" + DateTimeFormatter.ofPattern("yyyyMMdd").format(LocalDate.now()));
        amountList.add(JSONObject.toJSONString(order));
        RList<String> rebateList = redissonClient.getList(CommonConstant.CASINO_ORDER_REBATE_LIST + "_" + DateTimeFormatter.ofPattern("yyyyMMdd").format(LocalDate.now()));
        rebateList.add(JSONObject.toJSONString(order));
    }

    @Transactional(rollbackFor = Exception.class)
    public JSONObject bet(RequestDTO param) {
        log.info("ae 【bet】bet api call {} ", JSON.toJSONString(param.getBody()));
        Object message = param.getBody().get("message");
        ObjectMapper objectMapper = new ObjectMapper();

        BetReq betReq;
        BetResp betResp = new BetResp();
        try {
            betReq = objectMapper.readValue(URLDecoder.decode(String.valueOf(message)), BetReq.class);
        } catch (JsonProcessingException e) {
            log.error("ae 【bet】bet json parse error {}", e.getMessage());
            return betResp.toReturnFail("1036","Invalid parameters");
        }

        String userId = betReq.getTxns().get(0).getUserId();
        String gameCode = betReq.getTxns().get(0).getGameCode();
        String roundId = betReq.getTxns().get(0).getRoundId();
        String thirdPartyOrderNo = roundId  +"-"+ userId;

        BigDecimal sumAmount = betReq.getTxns().stream().map(BetTransaction::getBetAmount).reduce(BigDecimal::add).orElse(BigDecimal.ZERO);
        Optional<GetBalanceResponse> balanceRes = getBalance(Long.parseLong(userId));

        if (!checkUserId(userId)) {
            return betResp.toReturnFail("1000","Invalid user Id");
        }

        if(sumAmount.compareTo(balanceRes.get().getBalance())>0){
            return betResp.toReturnFail("1018","Not Enough Balance");
        }

        OrderVO order;
        order = orderMapper.selectByPidAndThirdOrderNo(String.valueOf(providerVO.getPid()), thirdPartyOrderNo);
        if (order != null  && order.getThirdOrderNo().equals(thirdPartyOrderNo)){
            return betResp.toReturnFail("1016","TxCode already operation!");
        }
        BalanceDTO changeBalance = new BalanceDTO();
        changeBalance.setSessionId(roundId);
        changeBalance.setProviderId(providerVO.getPid());
        changeBalance.setGameId(gameCode);

        if(gameCode != null) {
            String gameName = getGameName(gameCode);
            changeBalance.setGameName(gameName);
        }
        changeBalance.setAmount(sumAmount);
        changeBalance.setUserId(Long.valueOf(userId));
        changeBalance.setOperatorType(EnumWalletOperatorType.CasinoBetFreeze.getValue());

        changeBalance.setTransactionId(thirdPartyOrderNo);
        changeBalance.setOrderNo(UidUtil.getOrderNo(userId));

        Optional<ChangeBalanceResponse> changeResponse = createOrder(changeBalance, param, betReq.getTxns());
        if (changeResponse.isEmpty()) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            log.error("ae 【debit】changeResponse is null");
            return betResp.toReturnFail("1018","Not Enough Balance");
        }
        ZonedDateTime now = ZonedDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
        betResp.setBalance(changeResponse.get().getBalance());
        betResp.setBalanceTs(now.format(formatter));

        return betResp.toReturnSuccess("0000",changeResponse.get().getBalance(),now.format(formatter));

    }

    @Transactional(rollbackFor = Exception.class)
    public Optional<ChangeBalanceResponse> createOrder(BalanceDTO balanceDTO, RequestDTO param,List<BetTransaction> transactionList) {
        //保存到数据库
        var user = userInfoService.getUser(balanceDTO.getUserId());
        if (user.isEmpty()) {
            log.error("【newOrder】获取用户信息失败,userId={},betOrderNumber={}", param.getBody().get("userId"), balanceDTO.getOrderNo());
            return Optional.empty();
        }
        var order = new OrderVO();
        order.setOrderNo(balanceDTO.getOrderNo());
        order.setThirdOrderNo(balanceDTO.getTransactionId());
        order.setStatus(OrderVO.EnumOrderStatus.INIT.getCode());
        order.setUserId(balanceDTO.getUserId());
        order.setUserName(user.get().getUserName());
        order.setCurrency(user.get().getCurrency());
        order.setRegion(user.get().getLocation());
        order.setPid(balanceDTO.getProviderId());
        order.setAmount(balanceDTO.getAmount());
        order.setBetType(0);
        order.setMsgState(OrderVO.EnumMsgState.NONE.getCode());
        order.setSessionId(balanceDTO.getSessionId());
        order.setRoundId(balanceDTO.getSessionId());
        order.setGameName(balanceDTO.getGameName());
        order.setCreatedAt(new Date());
        order.setGameResult(JSONArray.toJSONString(transactionList));
        order.setBody(new JSONObject(param.getBody()).toJSONString());

        try {
            var size = orderMapper.add(order);
            if (size == 0) {
                log.error("【newOrder】保存到数据库失败,userId={},betOrderNumber={}", param.getBody().get("userId"), balanceDTO.getOrderNo());
                return Optional.empty();
            }
            List<OrderItemVO> orderItemList = new ArrayList<>();
            transactionList.forEach(item -> {
                OrderItemVO orderItemVO = new OrderItemVO();
                orderItemVO.setCasinoOrderId(order.getId());
                orderItemVO.setOrderNo(order.getOrderNo());
                orderItemVO.setTransactionId(item.getPlatformTxId());
                orderItemVO.setUserId(balanceDTO.getUserId());
                orderItemVO.setRoundId(item.getRoundId());
                orderItemVO.setUserId(balanceDTO.getUserId());
                orderItemVO.setAmount(item.getBetAmount());
                orderItemVO.setResult(order.getStatus());
                orderItemVO.setBetType(item.getBetType());
                orderItemVO.setItemPayload("{}");
                orderItemList.add(orderItemVO);

            });
            orderItemMapper.addBatch(orderItemList);

        } catch (Exception e) {
            log.error("【newOrder】保存到数据库失败", e);
            return Optional.empty();
        }
        log.info("【newOrder】保存到数据库成功,userId={},betOrderNumber={}", param.getBody().get("userId"), balanceDTO.getOrderNo());
        var changeBalanceResponse = changeBalance(balanceDTO);
        if (changeBalanceResponse.isEmpty()) {
            log.error("【newOrder】调用钱包服务失败,userId={},betOrderNumber={}", param.getBody().get("userId"), balanceDTO.getOrderNo());
            return Optional.empty();
        }
        // 存Order到redis
//        try {
//
//            String orderJson = JSONObject.toJSONString(order);
//            String orderKey = ORDER_KEY_REF + balanceDTO.getSessionId();
//            String mappingOrderKey = ORDER_KEY_GAME_ID + balanceDTO.getGameId();
//            log.info("【newOrder】存Order到redis, key={}, value={}", orderKey, orderJson);
//            RBucket<String> bucket = redissonClient.getBucket(orderKey);
//            RBucket<String> mappingOrderBucket = redissonClient.getBucket(mappingOrderKey);
//            bucket.set(orderJson, expiration);
//            mappingOrderBucket.set(orderJson, expiration);
//        } catch (Exception e) {
//            log.error("【newOrder】存Order到redis失败 ", e);
//        }

        //更新数据库
        var updates = orderMapper.updateStatus(OrderVO.EnumOrderStatus.BET.getCode(), order.getOrderNo());
        if (updates == 0) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            log.error("【bet】更新数据库失败,userId={},betOrderNumber={}", param.getBody().get("userId"), balanceDTO.getOrderNo());
        }
//        var proxy = (BaseProviderImpl)AopContext.currentProxy();
        newHistory(balanceDTO, param);

        return changeBalanceResponse;
    }

    @Transactional(rollbackFor = Exception.class)
    public JSONObject settle(RequestDTO param) {
        log.info("ae 【settle】settle api call {} ", JSON.toJSONString(param.getBody()));
        Object message = param.getBody().get("message");
        ObjectMapper objectMapper = new ObjectMapper();

        SettleReq settleReq;
        SettleResp settleResp = new SettleResp();
        try {
            settleReq = objectMapper.readValue(URLDecoder.decode(String.valueOf(message)), SettleReq.class);
            log.info("ae 【settle】settle req {}", JSON.toJSONString(settleReq));
        } catch (JsonProcessingException e) {
            log.error("ae 【settle】settle json parse error {}", e.getMessage());
            return settleResp.toReturnFail("1036","Invalid parameters");
        }

        return settleResp.toReturnSuccess("00000");

    }
    @Transactional(rollbackFor = Exception.class)
    public JSONObject cancelBet(RequestDTO param) {
        log.info("ae cancelbet api call {} ", JSON.toJSONString(param.getBody()));
        Object message = param.getBody().get("message");
        ObjectMapper objectMapper = new ObjectMapper();

        CancelBetReq cancelBetReq;
        CancelBetResp cancelBetResp = new CancelBetResp();
        try {
            cancelBetReq = objectMapper.readValue(URLDecoder.decode(String.valueOf(message)), CancelBetReq.class);
            log.info("ae cancelbet req {}", JSON.toJSONString(cancelBetReq));
        } catch (JsonProcessingException e) {
            log.error("ae cancelbet json parse error {}", e.getMessage());
            return cancelBetResp.toReturnFail("1036","Invalid parameters");
        }

        ZonedDateTime now = ZonedDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");

        return cancelBetResp.toReturnSuccess("0000",BigDecimal.valueOf(10000925.03),now.format(formatter));

    }

    public String getGameName(String tableId) {
        var gameInfo = gameInfoService.getGameInfoByTableId(tableId);
        if (gameInfo.isEmpty()) {
            log.error("ae getGameName gameInfo is null");
            return "";
        }
        return gameInfo.get().getName();
    }
//    @Transactional(rollbackFor = Exception.class)
//    public JSONObject cancel(RequestDTO param) {
//        log.info("ae 【cancel】cancel api call {} ", JSON.toJSONString(param.getBody()));
//        Object message = param.getBody().get("message");
//        ObjectMapper objectMapper = new ObjectMapper();
//
//        CancelReq cancelReq;
//        CancelResp cancelResp = new CancelResp();
//
//        try {
//            cancelReq = objectMapper.readValue(URLDecoder.decode(String.valueOf(message)), CancelReq.class);
//        } catch (JsonProcessingException e) {
//            cancelResp.setStatus("1036");
//            cancelResp.setDesc("Invalid parameters");
//            cancelResp.setSuccess(false);
//            return cancelResp.toReturn();
//        }
//
//        var changeBalance = new BalanceDTO();
//        var transaction = ret.getTransaction();
//        var game = ret.getGame();
//        changeBalance.setUserId(Long.valueOf(userId));
//        changeBalance.setTransactionId(transaction.getId());
//        changeBalance.setSessionId(transaction.getRefId());
//        changeBalance.setGameId(game.getId());
//        changeBalance.setGameName(game.getType());
//        // 从redis中获取存入的Order
//        String orderKey = ORDER_KEY_REF + transaction.getRefId();
//        RBucket<String> bucket = redissonClient.getBucket(orderKey);
//        OrderVO order;
//        OrderHistoryVO orderHistoryVO ;
//        var orderData = (String)bucket.get();
//        if (orderData == null) {
//            // 根据orderKey没有找到对应的order, 从数据库中查找
//            order = orderMapper.selectByUserIdAndSessionId(Long.valueOf(userId), transaction.getRefId());
//            if (order == null) {// 都找不到還要再去 歷史紀錄裡找
//                orderHistoryVO = orderMapper.selectHistoryByUserIdAndSessionId(Long.valueOf(userId), transaction.getRefId(),EnumWalletOperatorType.CasinoBetFreeze.getValue());
//                if(orderHistoryVO==null){
//                    log.error("ae 【cancel】order is null, cannot find order by userId={}, pid={}, roundId={}", userId, game.getId(), transaction.getRefId());
//                    res.setStatus(EVOStatusType.BET_DOES_NOT_EXIST.name());
//                    log.info("ae 【cancel】 特殊情境 : key {}",ORDER_KEY_CANCEL + game.getId());
//                    RBucket<String> cancelBucket = redissonClient.getBucket(ORDER_KEY_CANCEL + game.getId());
//                    cancelBucket.set(game.getId(),expiration);
//                    return res.toJSONObject();
//                }else {
//                    order=new OrderVO();
//                    order.setOrderNo(orderHistoryVO.getOrderNo());
//                    order.setStatus(OrderVO.EnumOrderStatus.BET.getCode());
//                }
//            }
//        } else {
//            order = JSON.parseObject(orderData, OrderVO.class);
//            bucket.expire(expiration);
//        }
//        //確認狀態是否已經取消過
//        if(order.getStatus().equals(OrderVO.EnumOrderStatus.CANCEL.getCode()) || order.getStatus().equals(OrderVO.EnumOrderStatus.PAYOUT.getCode())) {
//            res.setStatus(EVOStatusType.BET_ALREADY_SETTLED.name());
//            return res.toJSONObject();
//        }
//
//        changeBalance.setOrderNo(order.getOrderNo());
//        // 金額從注單拿(多注的原因 不然取消會址取消一半) 拿不到再從req拿
//       OrderVO balanceOrder = orderMapper.selectByUserIdAndRoundId(Long.valueOf(userId), game.getId());
//        BigDecimal amount = transaction.getAmount();
//
//        if(balanceOrder!=null){
//            amount=balanceOrder.getAmount();
//        }
//
//        changeBalance.setAmount(amount);
//        changeBalance.setOperatorType(EnumWalletOperatorType.CasinoBetRefund.getValue());
//        changeBalance.setRemark(game.getDetails().toString());
//        newHistory(changeBalance, param);
//        var changeResponse = changeBalance(changeBalance);
//        if (changeResponse.isEmpty()) {
//            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
//            log.error("evo 【cancel】cancel changeResponse is null");
//            res.setStatus(EVOStatusType.INSUFFICIENT_FUNDS.name());
//            return res.toJSONObject();
//        }
//
//        if(changeResponse.get().getMgs()!=null){
//            if(changeResponse.get().getMgs().equals(170) || changeResponse.get().getMgs().equals(100)){//重複訂單
//                res.setStatus(EVOStatusType.BET_ALREADY_SETTLED.name());
//                return res.toJSONObject();
//            }
//            res.setStatus(EVOStatusType.INSUFFICIENT_FUNDS.name());
//            return res.toJSONObject();
//        }
//        order.setAmount(amount);
//        order.setThirdOrderNo(changeBalance.getTransactionId());
//        order.setUserId(changeBalance.getUserId());
//        order.setPid(providerVO.getPid());
//        order.setSessionId(changeBalance.getSessionId());
//        order.setRoundId(changeBalance.getGameId());
//        order.setGameName(changeBalance.getGameName());
////        // 更新cancel状态
//        order.setPayout(BigDecimal.ZERO);
//        order.setStatus(OrderVO.EnumOrderStatus.CANCEL.getCode());
//        order.setSettleAt(new Date());
//        if (orderMapper.updatePayout(order) == 0) {
//            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
//            log.error("evo 【cancel】cancel updatePayout failed");
//            res.setStatus(EVOStatusType.UNKNOWN_ERROR.name());
//            return res.toJSONObject();
//        }
//
//        String orderJson = JSONObject.toJSONString(order);
//        bucket.set(orderJson, expiration);
//
//        BigDecimal balance = changeResponse.get().getBalance();
//        res.setBalance(balance);
//        res.setBonus(BigDecimal.ZERO);
//        return res.toJSONObject();
//    }

    @Transactional(rollbackFor = Exception.class)
    public JSONObject promo_payout(RequestDTO param) {
        log.info("ae promotion api call {}", JSON.toJSONString(param.getBody()));
        var ret = new PromotionRequest(param.getBody());
        var res = new PromotionResponse();
        res.setUuid(ret.getUuid());
        var userId = ret.getUserId();
        if(!checkUserId(ret.getUserId())){
            res.setStatus(EVOStatusType.INVALID_PARAMETER.name());
            return res.toJSONObject();
        }
        var check = validate(userId, ret.getSid());
        if (!check) {
            res.setStatus(EVOStatusType.INVALID_SID.name());
            log.error("evo promotion check is false");
            return res.toJSONObject();
        }


        var changeBalance = new BalanceDTO();
        var promoTransaction = ret.getPromoTransaction();
        var game = ret.getGame();

        OrderHistoryVO orderHistoryVO = orderMapper.selectHistoryByUserIdAndSessionId(Long.valueOf(userId), promoTransaction.getId(),EnumWalletOperatorType.CasinoPromotion.getValue());
        if(Objects.nonNull(orderHistoryVO)){
            res.setStatus(EVOStatusType.BET_ALREADY_SETTLED.name());
            return res.toJSONObject();
        }

        changeBalance.setOrderNo(UidUtil.getOrderNo(ret.getUserId()));
        changeBalance.setTransactionId(promoTransaction.getId());
        var amount = BigDecimal.valueOf(promoTransaction.getAmount());
        changeBalance.setAmount(amount);
        changeBalance.setUserId(Long.valueOf(userId));
        changeBalance.setProviderId(providerVO.getPid());
        changeBalance.setSessionId(promoTransaction.getId());
        changeBalance.setOperatorType(EnumWalletOperatorType.CasinoPromotion.getValue());
        if (game != null) {
            changeBalance.setSessionId(game.getId());
            changeBalance.setRemark(game.getDetails().toString());
        } else {
            changeBalance.setRemark(promoTransaction.toString());
        }
        var changeResponse = changeBalance(changeBalance);
        if (changeResponse.isEmpty()) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            res.setStatus(EVOStatusType.INSUFFICIENT_FUNDS.name());
            return res.toJSONObject();
        }

        if(changeResponse.get().getMgs()!=null){
            if(changeResponse.get().getMgs().equals(170) || changeResponse.get().getMgs().equals(100)){//重複訂單
                res.setStatus(EVOStatusType.BET_ALREADY_EXIST.name());
                return res.toJSONObject();
            }
            res.setStatus(EVOStatusType.INSUFFICIENT_FUNDS.name());
            return res.toJSONObject();
        }

        newHistory(changeBalance, param);
        BigDecimal balance = changeResponse.get().getBalance();
        res.setBalance(balance);
        res.setBonus(BigDecimal.ZERO);
        return res.toJSONObject();
    }

    public Result<?> getGameList() {
        return Result.success();
    }

    @Override
    public void history(String orderStr, Integer status) {
    }

    @Override
    public void history(String orderStr) {

    }

    public Result<?> getLaunchURI(Map<String, Object> body) {
        // 游戏ID, 桌子ID, 用户ID, 语言, 用户ID
        String userId = (String)body.get("uid");
        String language = (String)body.get("language");
        GameInfoDTO gameInfo = (GameInfoDTO)body.get("gameInfo");
        String playMode = (String)body.get("playMode");
        String backUrl = (String)body.get("backUrl");

        Long uid = Long.valueOf(userId);
        Optional<UserInfoVO> user = userInfoService.getUser(uid);
        if (user.isEmpty()) {
            return Result.fail(1201, "user is null");
        }
        String currency = user.get().getCurrency();
        if(currency.equals("IDR")) {
            currency = "PTI";
        }else if(currency.equals("VND")) {
            currency = "PTV";
        } else if(currency.equals("USDT")) {
            currency = "USD";
        }
        String Lang = switch (language) {
            case "th" -> "th";
            case "vi" -> "vn";
            case "zh" -> "cn";
            default -> "en";
        };
        String agentId = aeConfigMap.get(currency).getAgentId();
        String cert = aeConfigMap.get(currency).getCert();
        String baseUrl = aeConfigMap.get(currency).getBaseUrl();

        //進遊戲前要先確認是否創建帳號
        JSONObject resp=checkOrCreateGameAccount(new CreateMemberReq(cert,agentId,userId,currency,"",Lang,userId));

        if (resp == null) {
            throw new BusinessException(1201, "AE创建帐号失败");
        }
        AeCreateMemberResp checkResp = JSON.parseObject(JSON.toJSONString(resp), AeCreateMemberResp.class);
        if(!checkResp.getStatus().equals("0000") && !checkResp.getStatus().equals("1001")){
            throw new BusinessException(1021, checkResp.getDesc());
        }
        // 设置Redis的session
        String sid = IdUtil.randomUUID();
        String sessionKey = "casino_user_session_" + userId;
        RMap<String, String> map = redissonClient.getMap(sessionKey);
        String jsonValue = map.get("sessionids");
        var objectMapper = new ObjectMapper();
        try {
            jsonValue = jsonValue == null ? "{}" : jsonValue;
            Map<String, Object> nestedMap = objectMapper.readValue(jsonValue, Map.class);
            nestedMap.put(sid, new Date());
            map.put("sessionids", objectMapper.writeValueAsString(nestedMap));
            log.info("ae getGameURI call, add new sid={}", sid);
        } catch (Exception e) {
            log.error("ae getGameURI call error: {}", e.getMessage());
        }

        String isLaunchGameTable = (gameInfo.getMainEntrance().equalsIgnoreCase(EntryVO.EnumMainEntry.GAME_LOBBY.getValue())? "false" : "true");

        try {
            JSONObject launchGame = doLoginAndLaunchGame(new LoginAndLaunchGameReq(cert,
                    agentId,
                    userId,
                    "true",
                    baseUrl,
                    gameInfo.getName(),
                    Lang,
                    isLaunchGameTable,
                    gameInfo.getTableId(),
                    currency));

            AeLoginAndLaunchGameResp launchGameResp =JSON.parseObject(JSON.toJSONString(launchGame), AeLoginAndLaunchGameResp.class);
            if(!launchGameResp.getStatus().equals("0000")){
                throw new BusinessException(1201, "AE登入游戏失败");
            }
            var resData = new AuthenticationResponse(launchGameResp.getUrl());
            return Result.success(resData);
        } catch (Exception e) {
            throw new BusinessException(ResultCode.GAME_CLOSE.getCode(), e.getMessage());
        }
    }

    public JSONObject sid(RequestDTO param) {
        var ret = new SidRequest(param.getBody());
        var res = new SidResponse();
        res.setUuid(ret.getUuid());
        if(!checkUserId(ret.getUserId())){
            res.setStatus(EVOStatusType.INVALID_PARAMETER.name());
            return res.toJSONObject();
        }
        var check = validate(ret.getUserId(), ret.getSid());
        if (check) {
            log.error("evo sid api check is OK, sid={}", ret.getSid());
            return res.toJSONObject();
        }
        var sid = IdUtil.randomUUID();
        // 设置Redis的session
        var sessionKey = CASINO_SESSION_KEY + ret.getUserId();

        RMap<String, String> map = redissonClient.getMap(sessionKey);
        String jsonValue = map.get("sessionids");
        var objectMapper = new ObjectMapper();
        try {
            jsonValue = jsonValue == null ? "{}" : jsonValue;
            Map<String, Object> nestedMap = objectMapper.readValue(jsonValue, Map.class);
            nestedMap.put(sid, new Date());
            map.put("sessionids", objectMapper.writeValueAsString(nestedMap));
            log.info("evo sid call, add new sid={}", sid);
        } catch (Exception e) {
            log.error("evo sid error: {}", e.getMessage());
            res.setStatus(EVOStatusType.UNKNOWN_ERROR.name());
            return res.toJSONObject();
        }
        res.setSid(sid);
        return res.toJSONObject();
    }

    public JSONObject doLoginAndLaunchGame(LoginAndLaunchGameReq req) {

        Map<String, Object> params = new HashMap<>();
        params.put("cert", req.getCert());
        params.put("agentId", req.getAgentId());
        params.put("userId", req.getUserId());
        params.put("isMobileLogin", req.getIsMobileLogin());
        params.put("externalURL", req.getExternalURL());
        params.put("platform", req.getPlatform());
        params.put("gameType", req.getGameType());
        params.put("language", req.getLanguage());
        params.put("autoBetMode", req.getAutoBetMode());


        String baseUrl = aeConfigMap.get(req.getCurrency()).getBaseUrl();
        HashMap<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "application/x-www-form-urlencoded");

        String aeGameUrl = String.format("%s/wallet/login", baseUrl);
        log.info("ae 请求的url：{}", aeGameUrl);
        HttpResponse response = HttpUtil.createPost(aeGameUrl).addHeaders(headers).form(params).execute();
        log.info("ae 请求的结果：{}", response.body());
        int httpStatus = response.getStatus();
        if (httpStatus != 200) {
            log.error("ae 请求失败！httpStatus={},body={}", httpStatus, response.body());
            throw new BusinessException("Failed to get ae game URL, HTTP status: " + httpStatus);
        }
        return JSONObject.parseObject(response.body());

    }

    public JSONObject login(LoginReq req) {

        Map<String, Object> params = new HashMap<>();
        params.put("cert", req.getCert());
        params.put("agentId", req.getAgentId());
        params.put("userId", req.getUserId());
        params.put("isMobileLogin", req.getIsMobileLogin());
        params.put("externalURL", req.getExternalURL());
        params.put("platform", req.getPlatform());
        params.put("gameType", req.getGameType());
        params.put("gameForbidden", req.getGameForbidden());
        params.put("language", req.getLanguage());
        params.put("autoBetMode", req.getAutoBetMode());


        String baseUrl = aeConfigMap.get(req.getCurrency()).getBaseUrl();
        HashMap<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "application/x-www-form-urlencoded");

        String aeGameUrl = String.format("%s/wallet/login", baseUrl);
        log.info("ae 请求的url：{}, param={}", aeGameUrl,params.toString());
        HttpResponse response = HttpUtil.createPost(aeGameUrl).addHeaders(headers).form(params).execute();
        log.info("ae 请求的结果：{}", response.body());
        int httpStatus = response.getStatus();
        if (httpStatus != 200) {
            log.error("ae 请求失败！httpStatus={},body={}", httpStatus, response.body());
            throw new BusinessException("Failed to get ae game URL, HTTP status: " + httpStatus);
        }
        return JSONObject.parseObject(response.body());

    }
    public JSONObject checkOrCreateGameAccount(CreateMemberReq req) {

        AEConfig config = aeConfigMap.get(req.getCurrency());
        log.info("ae config={}", config);
        Map<String, Object> params = new HashMap<>();
        params.put("cert", req.getCert());
        params.put("agentId", req.getAgentId());
        params.put("userId", req.getUserId());
        params.put("currency", req.getCurrency());
        params.put("betLimit",  String.format("{\"SEXYBCRT\":{\"LIVE\":{\"limitId\":[%d]}}}",Integer.valueOf(config.getBetLimit())));
        params.put("language", req.getLanguage());
        params.put("userName", req.getUserId());

        String baseUrl = config.getBaseUrl();
        HashMap<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "application/x-www-form-urlencoded");

        String aeGameUrl = String.format("%s/wallet/createMember", baseUrl);
        log.info("ae 请求的url：{}, param={}", aeGameUrl,params.toString());
        HttpResponse response = HttpUtil.createPost(aeGameUrl).addHeaders(headers).form(params).execute();
        log.info("ae 请求的结果：{}", response.body());
        int httpStatus = response.getStatus();
        if (httpStatus != 200) {
            log.error("ae 请求失败！httpStatus={},body={}", httpStatus, response.body());
            throw new BusinessException("Failed to register member, HTTP status: " + httpStatus);
        }
        return JSONObject.parseObject(response.body());
    }
}
