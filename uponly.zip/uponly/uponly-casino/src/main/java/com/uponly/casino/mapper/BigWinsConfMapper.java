package com.uponly.casino.mapper;

import com.uponly.casino.admin.dto.BigWinsConfDTO;
import com.uponly.casino.admin.vo.BigWinsConfVO;


import java.util.List;

public interface BigWinsConfMapper {

    List<BigWinsConfVO> list(BigWinsConfDTO dto);

    BigWinsConfVO queryById(Long id);

    BigWinsConfVO getOneByCurrency(String currency);

    long count(BigWinsConfVO bigWinsConf);

    int save(BigWinsConfVO bigWinsConf);

    int edit(BigWinsConfVO bigWinsConf);

    int delete(Long id);

    List<BigWinsConfVO> selectAll();
}

