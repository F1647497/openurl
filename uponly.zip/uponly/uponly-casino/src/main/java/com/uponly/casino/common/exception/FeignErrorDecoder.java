package com.uponly.casino.common.exception;

import com.uponly.casino.common.api.ResultCode;
import feign.RetryableException;
import feign.Util;
import feign.codec.ErrorDecoder;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;

import java.io.IOException;
import java.util.Collection;

@Slf4j
@RequiredArgsConstructor
public class FeignErrorDecoder extends ErrorDecoder.Default {

    /**
     * 封装feign异常为自定义的统一格式
     */
    @SneakyThrows
    @Override
    public Exception decode(String methodKey, feign.Response response) {
        log.error("feign client error,response is {}:", response);
        Exception exception = super.decode(methodKey, response);

        // 如果是RetryableException，则返回继续重试
        if (exception instanceof RetryableException) {
            return exception;
        }

        try {
            if (response == null || response.body() == null) {
                return new BusinessException(ResultCode.INTERNAL_SERVER_ERROR.getCode(), "【feign】decode response is null");
            }

            // 如果是FeignException，则对其进行处理，并抛出BusinessException
//            if (exception instanceof FeignException && ((FeignException) exception).responseBody().isPresent()) {
//                ByteBuffer responseBody = ((FeignException) exception).responseBody().get();
//                String body = Util.toString(response.body().asReader(Charset.defaultCharset()));
//            }

            int status = response.status();
            Collection<String> contentTypes = response.headers().get("Content-Type");
            if (contentTypes != null && !contentTypes.isEmpty()) {
                String contentType = contentTypes.iterator().next();
                if (contentType.contains("text/html")) {
                    // 返回的内容是网页格式的
                    throw new BusinessException(response.status(), response.reason());
                }
            }
            if (status == 403) { //特别处理历史原因造成的外部403异常
                throw new BusinessException(response.status(), response.reason());
            }


            String body = Util.toString(response.body().asReader(Util.UTF_8));
            log.info("【feign】 decode body:{}", body);
            if (StringUtils.isBlank(body)) {
                return null;
            }
            if (status != HttpStatus.OK.value()) {
//                Collection<String> contentTypes = response.headers().get("Content-Type");
//                if (contentTypes != null && !contentTypes.isEmpty()) {
//                    String contentType = contentTypes.iterator().next();
//                    if (contentType.contains("text/html")) {
//                        // 返回的内容是网页格式的
//                        log.error("【feign】decode error, contentType:{} status:{}，body:{}", contentType, status, body);
//                    }
//                }

                if (status >= 400 && status <= 499) {
                    log.error("【feign】 client decode error occurred with status:{}，body:{}", status, body);
                } else if (status >= 500 && status <= 599) {
                    log.error("【feign】 Server decode error occurred with status:{}，body:{}", status, body);
                }
                throw new BusinessException(status, response.reason());
            }
        } catch (IOException e) {
            log.error("Response 转换异常: ", e);
            exception = new BusinessException(ResultCode.INTERNAL_SERVER_ERROR.getCode(), e.getMessage());
        }
        return exception;
    }
}
