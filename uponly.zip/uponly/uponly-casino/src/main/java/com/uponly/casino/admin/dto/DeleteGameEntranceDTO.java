package com.uponly.casino.admin.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(title = "删除入口DTO")
public class DeleteGameEntranceDTO implements java.io.Serializable {

    @Schema(title = "入口id")
    private Long eid;


}