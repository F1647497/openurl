package com.uponly.casino.admin.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.github.pagehelper.PageInfo;
import com.uponly.casino.admin.dto.*;
import com.uponly.casino.admin.vo.EntryVO;

import java.util.List;
import java.util.Optional;

public interface EntranceService {
    Optional<EntryVO> getEntry(Long entryId);

    PageInfo<EntryVO> searchGameEntrance(SearchGameEntranceDTO searchGameEntranceDTO);

    Long newGameEntrance(AddGameEntranceDTO addGameEntranceDTO) throws JsonProcessingException;

    int deleteGameEntrance(DeleteGameEntranceDTO deleteGameEntranceDTO);

    int editGameEntrance(EditGameEntranceDTO editGameEntranceDTO);

    void setGameEntrance(BatchSortDTO batchSortDTO);

    Integer searchAddition(String addition);
    Integer searchEname(SearchEnameDTO searchEnameDTO);
    List<Long> searchAllGameEid(String mainEntry);
}
