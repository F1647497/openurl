package com.uponly.casino.portal.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Data
@Schema(title = "用户对应游戏收藏")
public class FavoriteVO {



    /**
     * 排序
     */
    @Schema(title = "用户id")
    private Long userId;


    /**
     * 地区
     */
    @Schema(title = "入口id")
    private Long eid;


    /**
     * 创建时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Schema(title = "创建时间")
    private Date createAt;




}