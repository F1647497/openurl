//package com.uponly.casino.handler;
//
//
//import com.alibaba.fastjson.JSONArray;
//import com.alibaba.fastjson.JSONObject;
//import com.uponly.casino.admin.dto.UpdateEffectiveAmountDTO;
//import com.uponly.casino.admin.dto.UpdateMsgDTO;
//import com.uponly.casino.admin.vo.AmountMsgVO;
//import com.uponly.casino.common.utils.RegionIntegerUtil;
//import com.uponly.casino.admin.service.GetRedisDataService;
//import com.uponly.casino.mapper.OrderMapper;
//import com.uponly.casino.provider.service.UserInfoService;
//import com.uponly.casino.provider.vo.UserInfoVO;
//import lombok.extern.slf4j.Slf4j;
//import org.redisson.api.RLock;
//import org.redisson.api.RedissonClient;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.kafka.core.KafkaTemplate;
//import org.springframework.kafka.support.SendResult;
//import org.springframework.stereotype.Service;
//
//import java.math.BigDecimal;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Optional;
//import java.util.UUID;
//import java.util.concurrent.CompletableFuture;
//
//
//@Service
//@Slf4j
//public class AmountJob extends AbstractReportJob {
//    @Autowired
//    private KafkaTemplate<String, String> kafkaTemplate;
//
//    @Autowired
//    RedissonClient redissonClient;
//
//    @Autowired
//    UserInfoService userInfoService;
//
//    @Autowired
//    GetRedisDataService getRedisDataService;
//
//    @Autowired
//    OrderMapper ordermapper;
//
//
//    public void sendAmountMsg(List<String> orderListRedis) {
//        RLock lock = redissonClient.getLock("sendAmountMsg");
//        try {
//            // 从redis中获取casino注单列表，然后一次性发送订单数组到kafka
//            lock.lock();
//            List<AmountMsgVO> amountMsgVOList = this.generateMsg(orderListRedis);
//            for (AmountMsgVO amountMsgVO : amountMsgVOList) {
//                CompletableFuture<SendResult<String, String>> future = this.sendAmountMsgJob(amountMsgVO);
//                log.info("【sendAmountMsgJob】的发送结果={}", future);
//            }
//        } catch (Exception e) {
//            log.error("sendAmountMsg异常 ", e);
//        } finally {
//            lock.unlock();
//        }
//    }
//
//    public List<AmountMsgVO> generateMsg(List<String> orderListRedis) {
//        try {
//            List<AmountMsgVO> amountMsgVOList = new ArrayList<>();
//            for (String orderJsonString : orderListRedis) {
//                JSONObject jsonObject = JSONObject.parseObject(orderJsonString);
//
//                Long userId = jsonObject.getLong("userId");
//                Optional<UserInfoVO> userInfoVO = userInfoService.getUser(userId);
//                UserInfoVO userInfo = userInfoVO.get(); // 获取内部对象
//
//                String region = RegionIntegerUtil.lcationIdToRegion(userInfo.getLocation());
//                int level = userInfo.getVip();
//                int star = userInfo.getStar();
//                String agentId = userInfo.getAgentId();
//
//                BigDecimal amount = jsonObject.getBigDecimal("amount");
//                BigDecimal payout = jsonObject.getBigDecimal("payout");
//                BigDecimal difference = payout.subtract(amount); // 使用 subtract() 方法进行减法操作
//                String stakeResult = difference.compareTo(BigDecimal.ZERO) > 0 ? "win" : difference.compareTo(BigDecimal.ZERO) < 0 ? "lose" : "draw";
//                String currency = jsonObject.getString("currency");
//                String betId = jsonObject.getString("orderNo");
//                String tagFromUserInfo = jsonObject.getString("tag");
//                String settleAt = jsonObject.getString("settleAt");
//                String tag = tagFromUserInfo == null ? "real" : "test";
//                String gameResult = jsonObject.getString("gameResult");
//                AmountMsgVO amountMsgVO = new AmountMsgVO();
//                //获取游戏流水
//                BigDecimal effectiveAmount = super.getEffectiveAmount(amount, gameResult);
//                amountMsgVO.setEffectiveAmount(effectiveAmount);
//                Boolean isTurnover = amountMsgVO.getEffectiveAmount() == BigDecimal.ZERO ? false : true;
//                amountMsgVO.setUserId(userId);
//                amountMsgVO.setAgentId(agentId);
//                amountMsgVO.setRegion(region);
//                amountMsgVO.setLevel(level);
//                amountMsgVO.setStar(star);
//                amountMsgVO.setStakeResult(stakeResult);
//                amountMsgVO.setIsTurnover(isTurnover);
//                amountMsgVO.setCurrency(currency);
//                amountMsgVO.setAmount(amount);
//                amountMsgVO.setBetId(betId);
//                amountMsgVO.setTag(tag);
//                amountMsgVO.setSettleAt(settleAt);
//
//                amountMsgVOList.add(amountMsgVO);
//            }
//
//            return amountMsgVOList;
//        } catch (Exception e) {
//            log.error("generateMsg 异常{} ", e.getMessage());
//        }
//        return List.of();
//    }
//
//    public CompletableFuture<SendResult<String, String>> sendAmountMsgJob(AmountMsgVO amountMsgVO) {
//        try {
//            var body = new JSONObject();
//
//            body.put("agentId", amountMsgVO.getAgentId());
//            body.put("userId", amountMsgVO.getUserId());
//            body.put("region", amountMsgVO.getRegion());
//            body.put("currency", amountMsgVO.getCurrency());
//            body.put("gameType", "EVO Casino");
//            body.put("amount", amountMsgVO.getAmount());
//            //放入有效流水，要扣和局
//            body.put("effectiveAmount", amountMsgVO.getEffectiveAmount());
//            body.put("stakeType", "cash");
//            body.put("isTurnover", amountMsgVO.getIsTurnover());
//
//            body.put("stakeResult", amountMsgVO.getStakeResult());
//            body.put("betId", amountMsgVO.getBetId());
//            body.put("copiedBetId", "");
//            body.put("tag", amountMsgVO.getTag());
//            body.put("level", amountMsgVO.getLevel());
//            body.put("star", amountMsgVO.getStar());
//
//            var msgJson = new JSONObject();
//            msgJson.put("messageType", "amount");
//            msgJson.put("messageBody", body);
//            msgJson.put("partion", 0);
//            msgJson.put("messageId", UUID.randomUUID());
//            String settleAt = amountMsgVO.getSettleAt();
//            log.info("【amount注单上报】settleAt={}", settleAt);
//            long timestamp = getTimestamp(amountMsgVO.getSettleAt());
//            log.info("【amount注单上报】timestamp={}", timestamp);
//            msgJson.put("ts", timestamp);
//            String msgOfBettingForKafka = msgJson.toJSONString();
//
//            log.info("【amount注单上报】sendAmountMsg.msg={}", msgOfBettingForKafka);
//            CompletableFuture<SendResult<String, String>> future = super.execute(amountMsgVO.getUserId(), msgOfBettingForKafka);
//            //用5个位置 表示发送消息的状态，1表示已发送，0 未发送，
//            // 消息所在位置：AmountMsg：第1位；GgrMsg：第2位；ActiveMsg：第3位；GgrMsg：第4位；BetMsg：第5位；RebateMsg
//            UpdateMsgDTO updateMsgDTO = new UpdateMsgDTO();
//            updateMsgDTO.setOrderNo(amountMsgVO.getBetId());
//            updateMsgDTO.setMsgNumber(0b10000);
//
//            if (future != null) {
//                Integer count = ordermapper.updateMsgState(updateMsgDTO);
//                log.info("amount更新消息状态数量 = {}", count);
//            }
//            //     CompletableFuture<SendResult<String, String>> future = kafkaTemplate.send(CommonConstant.CASINO_BETTING_JOB_TOPIC, msgOfBettingForKafka);
//            return future;
//        } catch (Exception e) {
//            log.error("sendAmountMsgJob 异常{} ", e.getMessage());
//        }
//        return null;
//    }
//
//
//}
