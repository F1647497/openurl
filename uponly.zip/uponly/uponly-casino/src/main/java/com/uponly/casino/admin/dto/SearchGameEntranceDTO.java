package com.uponly.casino.admin.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class SearchGameEntranceDTO extends PageInfoDTO {
    @Schema(description = "供应商名称", nullable = true)
    private String providerName;

    @Schema(title="是否推广")
    private Integer promotion;

    @Schema(title="状态")
    private Integer status;

    @Schema(title="游戏类型")
    private String gameType;

    @Schema(title="主入口")
    private String mainEntry;

    @Schema(title="次入口")
    private String addition;

    @Schema(title="入口id")
    private Long eid;

    @Schema(title="入口名称")
    private String ename;

    @Schema(description = "地区id", nullable = true)
    private Integer region;



}
