//package com.uponly.casino.handler;
//
//import cn.hutool.core.thread.ExecutorBuilder;
//import cn.hutool.core.thread.ThreadFactoryBuilder;
//import com.alibaba.fastjson.JSONArray;
//
//import com.alibaba.fastjson.JSONObject;
//import com.uponly.casino.common.constant.CommonConstant;
//import lombok.extern.slf4j.Slf4j;
//import org.apache.commons.lang3.StringUtils;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.kafka.core.KafkaTemplate;
//import org.springframework.kafka.support.SendResult;
//import org.springframework.stereotype.Service;
//import org.springframework.util.CollectionUtils;
//
//import java.math.BigDecimal;
//import java.text.ParseException;
//import java.text.SimpleDateFormat;
//import java.util.Date;
//import java.util.List;
//import java.util.UUID;
//import java.util.concurrent.ArrayBlockingQueue;
//import java.util.concurrent.CompletableFuture;
//import java.util.concurrent.ExecutorService;
//
//@Service
//@Slf4j
//public abstract class AbstractReportJob {
//    @Autowired
//    protected KafkaTemplate<String, String> kafkaTemplate;
//
//    private static final ExecutorService executor = ExecutorBuilder.create()
//            .setCorePoolSize(10)
//            .setMaxPoolSize(20)
//            .setWorkQueue(new ArrayBlockingQueue<>(100))
//            .setThreadFactory(ThreadFactoryBuilder.create().setNamePrefix("kfk-future-").build())
//            .build();
//
//    public CompletableFuture<SendResult<String, String>> execute(Long userId, String kfkData) {
//        try {
//            if (kfkData == null) {
//                log.info("没有kfkData");
//                return null;
//            }
//            CompletableFuture<SendResult<String, String>> future = kafkaTemplate.send(CommonConstant.CASINO_BETTING_JOB_TOPIC, String.valueOf(userId), kfkData);
//            future.whenCompleteAsync((n, ex) -> {
//                if (ex != null) {
//                    log.error("【注单上报】上报失败，data={},exception={}", kfkData, ex.getMessage(), ex);
//                }
//            }, executor);
//            return future;
//        } catch (Exception e) {
//            log.error("【注单上报】Job发生异常：exception={} ", e.getMessage(), e);
//        }
//        return null;
//    }
//    public CompletableFuture<SendResult<String, String>> executeRebate(Long userId, String kfkData) {
//        try {
//            if (kfkData == null) {
//                log.info("没有kfkData");
//                return null;
//            }
//            CompletableFuture<SendResult<String, String>> future = kafkaTemplate.send(CommonConstant.CASINO_ACTIVITY_TOPIC, String.valueOf(userId), kfkData);
//            future.whenCompleteAsync((n, ex) -> {
//                if (ex != null) {
//                    log.error("【注单上报】上报失败，data={},exception={}", kfkData, ex.getMessage(), ex);
//                }
//            }, executor);
//            return future;
//        } catch (Exception e) {
//            log.error("【注单上报】Job发生异常：exception={} ", e.getMessage(), e);
//        }
//        return null;
//    }
//
//
//    public BigDecimal getEffectiveAmount(BigDecimal amount,String gameResult) {
//        if (gameResult != null && !"".equals(gameResult)) {
//            JSONArray jsonArray = JSONArray.parseArray(gameResult);
//            // 遍历 JSON 数组，处理每个游戏结果
//            BigDecimal effectiveAmount = amount;
//            for (int i = 0; i < jsonArray.size(); i++) {
//                JSONObject resultJs = jsonArray.getJSONObject(i);
//                String result = resultJs.getString("result");
//                BigDecimal payout = resultJs.getBigDecimal("payout");
//                if (result.toLowerCase().contains("tie") || "Push".equals(result)) {
//                    effectiveAmount = effectiveAmount.subtract(payout);
//                }
//            }
//            return effectiveAmount;
//        }
//        return amount;
//    }
//
//    public static long getTimestamp(String time){
//        try {
//            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//            // 解析日期时间字符串为 Date 对象
//            Date date = dateFormat.parse(time);
//            // 获取 Date 对象的时间戳（毫秒）
//            long timestamp = date.getTime();
//            // 打印时间戳
//            System.out.println("Timestamp: " + timestamp);
//            return timestamp;
//        } catch (ParseException e) {
//            System.err.println("日期时间字符串解析失败：" + e.getMessage());
//        }
//
//        return 0;
//    }
//}
