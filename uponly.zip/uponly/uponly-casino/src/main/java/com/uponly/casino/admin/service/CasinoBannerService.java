package com.uponly.casino.admin.service;

import com.github.pagehelper.PageInfo;
import com.uponly.casino.admin.dto.BannerBatchSortDTO;
import com.uponly.casino.admin.dto.BannerDTO;
import com.uponly.casino.admin.vo.CasinoBanner;
import com.uponly.casino.common.exception.BusinessException;

import java.util.List;

public interface CasinoBannerService {


    PageInfo<CasinoBanner> casinoBannerList(BannerDTO dto);

    List<CasinoBanner> casinoBannerListFe(String region);

    void insert(CasinoBanner slotBanner) throws BusinessException;

    void update(CasinoBanner slotBanner) throws BusinessException;

    void delete(Long id);


    void batchSort(List<BannerBatchSortDTO> batch) throws BusinessException;

    /**
     * 刷新缓存
     */
    void updateCache();

    Integer maxSort();

}
