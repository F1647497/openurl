package com.uponly.casino.provider.dto.sa.res;

import lombok.Data;

import java.util.List;

@Data
public class SaHostListResp {
    private Integer ErrorMsgId;
    private String ErrorMsg;
    private List<SaHostResp> HostList;


    public SaHostListResp() {

    }
}
