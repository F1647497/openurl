package com.uponly.casino.provider.dto.evo.req;

import lombok.Data;

import java.util.Map;

@Data
public class CheckUserRequest {
    private String userId;   // Player's ID
    private String sid;      // Player's session ID
    private Channel channel; // Object containing channel details
    private String uuid;     // Unique request ID

    @Data
    public static class Channel {
        private String type;
    }

    public CheckUserRequest(String userId, String sid, Channel channel, String uuid) {
        this.userId = userId;
        this.sid = sid;
        this.channel = channel;
        this.uuid = uuid;
    }

    public CheckUserRequest(Map<String, Object> body) {
        this.userId = (String) body.get("userId");
        this.sid = (String) body.get("sid");
        var channelMap = (Map<String, Object>) body.get("channel");
        if (channelMap != null) {
            this.channel = new CheckUserRequest.Channel();
            this.channel.type = (String) channelMap.get("type");
        }
        this.uuid = (String) body.get("uuid");
    }
}
