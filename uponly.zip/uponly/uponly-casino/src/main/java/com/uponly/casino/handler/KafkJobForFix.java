//package com.uponly.casino.handler;
//
//
//import com.uponly.casino.admin.service.GetRedisDataService;
//import com.uponly.casino.common.constant.CommonConstant;
//import lombok.extern.slf4j.Slf4j;
//import org.redisson.api.RLock;
//import org.redisson.api.RedissonClient;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.scheduling.annotation.Scheduled;
//import org.springframework.stereotype.Service;
//
//import java.time.LocalDate;
//import java.util.List;
//import java.util.concurrent.TimeUnit;
//
//
//@Service
//@Slf4j
//public class KafkJobForFix {
//
//    @Autowired
//    RedissonClient redissonClient;
//
//    @Autowired
//    ActivetJob activetJob;
//
//    @Autowired
//    AmountJob amountJob;
//
//    @Autowired
//    BetMsgJob betMsgJob;
//
//    @Autowired
//    GgrJob ggrJob;
//
//    @Autowired
//    RebateJob rebateJob;
//
//    @Autowired
//    GetRedisDataService getRedisDataService;
//
//    @Autowired
//    UpdateEffectiveAmountJob updateEffectiveAmountJob;
//
//
// //   @Scheduled(cron = "0 47 12 8 * ?") // 每天的 20:00 分执行
//    public void sendAmountMsg() {
//        //测试
//        RLock lock = redissonClient.getLock("sendAllAmountMsgLock");
//        try {
//            if (lock.tryLock(500, TimeUnit.MILLISECONDS)) { // 尝试获取锁，等待 500 毫秒
//                List<String> orderListRedis = getRedisDataService.getEvoRedisDataForFix();
//                System.out.println("orderListRedis: " + orderListRedis);
//                if (orderListRedis.size() == 0) {
//                    log.info("casino Amount 报表 本次发送没有数据");
//                } else {
//                    log.info("casino Amount 报表 本次发送数据量为: {}", orderListRedis.size());
//
//                    try {
//                        amountJob.sendAmountMsg(orderListRedis);
//                    } catch (Exception e) {
//                        log.error("发送 amount 消息失败", e);
//                    }
//
//                }
//            } else {
//                log.info("任务已经被其他 Pod 执行，当前 Pod 不执行任务");
//            }
//        } catch (InterruptedException e) {
//            Thread.currentThread().interrupt();
//            log.error("获取分布式锁时被中断", e);
//        } finally {
//            lock.unlock(); // 释放锁
//        }
//    }
//
//
//}
