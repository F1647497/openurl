package com.uponly.casino.provider.dto.sa.req;

import cn.hutool.core.date.DateTime;
import lombok.Data;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;

/**
 * sa第三方下注请求对象
 */
@Data
public class PlaceBetCancelReq {

    /**
     * 用户名
     */
    private String username;
    /**
     * 币种
     */
    private String currency;
    /**
     * 投注金额
     */
    private BigDecimal amount;
    /**
     * 交易单号
     */
    private String txnid;
    /**
     * 时间
     */
    private DateTime timestamp;
    /**
     * 游戏类型
     */
    private String gametype;
    /**
     * 桌台编号
     */
    private Integer hostid;
    /**
     * 游戏局号
     */
    private String gameid;

    /**
     * 对应之前PlaceBet请求时的 txnid。第三方系统需要检查这个txn_reverse_id是否有处理过，而正确地返回点数给会员
     */
    private String txn_reverse_id;

    /**
     * 首次发送︰retry=0
     * 第二次发送︰retry=1
     */
    private Integer retry;
    /**
     * 取消原因简述
     * 1 - 因荷官操作问题需要取消
     * 0 - 其他原因 (例如：下注回覆超时或返回错误码)
     */
    private Byte gamecancel;


}
