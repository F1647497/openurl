//package com.uponly.casino.handler;
//
//
//import com.uponly.casino.common.constant.CommonConstant;
//import com.uponly.casino.admin.service.GetRedisDataService;
//import lombok.extern.slf4j.Slf4j;
//import org.redisson.api.RLock;
//import org.redisson.api.RedissonClient;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.scheduling.annotation.Scheduled;
//import org.springframework.stereotype.Service;
//
//import java.time.LocalDate;
//import java.util.List;
//import java.util.concurrent.TimeUnit;
//
//
//@Service
//@Slf4j
//public class KafkJob {
//
//    @Autowired
//    RedissonClient redissonClient;
//
//    @Autowired
//    ActivetJob activetJob;
//
//    @Autowired
//    AmountJob amountJob;
//
//    @Autowired
//    BetMsgJob betMsgJob;
//
//    @Autowired
//    GgrJob ggrJob;
//
//    @Autowired
//    RebateJob rebateJob;
//
//    @Autowired
//    GetRedisDataService getRedisDataService;
//
//    @Autowired
//    UpdateEffectiveAmountJob updateEffectiveAmountJob;
//
//
////    @Scheduled(cron = "0 */5 * * * ?") // 每5分钟执行一次
//    public void sendAmountMsg() {
//        //测试
//        RLock lock = redissonClient.getLock("sendAllAmountMsgLock");
//        try {
//            if (lock.tryLock(500, TimeUnit.MILLISECONDS)) { // 尝试获取锁，等待 500 毫秒
//                List<String> orderListRedis = getRedisDataService.getEvoRedisDataForAmount();
//                if (orderListRedis.size() == 0) {
//                    log.info("casino Amount 报表 本次发送没有数据");
//                } else {
//                    log.info("casino Amount 报表 本次发送数据量为: {}", orderListRedis.size());
//                    LocalDate currentDate = LocalDate.now();
//                    long deletedKeys = this.deleteRedisData(currentDate, CommonConstant.CASINO_ORDER_AMOUNT_LIST);
//                    log.info("Amount 删除 {} 条的redis数据成功", deletedKeys);
//                    try {
//                        updateEffectiveAmountJob.updateEffectiveAmount(orderListRedis);
//                    } catch (Exception e) {
//                        log.error("updateEffectiveAmountJob 任务失败", e);
//                    }
//                    try {
//                        amountJob.sendAmountMsg(orderListRedis);
//                    } catch (Exception e) {
//                        log.error("发送 amount 消息失败", e);
//                    }
//                    try {
//                        ggrJob.sendGgrMsg(orderListRedis);
//                    } catch (Exception e) {
//                        log.error("发送 Ggr 消息失败", e);
//                    }
//                }
//            } else {
//                log.info("任务已经被其他 Pod 执行，当前 Pod 不执行任务");
//            }
//        } catch (InterruptedException e) {
//            Thread.currentThread().interrupt();
//            log.error("获取分布式锁时被中断", e);
//        } finally {
//            lock.unlock(); // 释放锁
//        }
//    }
//
////    @Scheduled(cron = "0 */5 * * * ?") // 每5分钟执行一次
//    public void sendABGMsg() {
//        RLock lock = redissonClient.getLock("sendAllDataMsgLock");
//        try {
//            if (lock.tryLock(500, TimeUnit.MILLISECONDS)) { // 尝试获取锁，等待 500 毫秒
//                List<String> orderListRedis = getRedisDataService.getEvoRedisDataForABG();
//                if (orderListRedis.size() == 0) {
//                    log.info("casino ABG 报表 本次发送没有数据");
//                } else {
//                    log.info("casino ABG 报表 本次发送数据量为: {}", orderListRedis.size());
//
//                    // 投注后立刻发送的消息
//                    try {
//                        activetJob.sendActiveMsg(orderListRedis);
//                    } catch (Exception e) {
//                        log.error("发送 Active 消息失败", e);
//                    }
//                    try {
//                        betMsgJob.sendBetMsg(orderListRedis);
//                    } catch (Exception e) {
//                        log.error("发送 BetMsg 消息失败", e);
//                    }
//                    LocalDate currentDate = LocalDate.now();
//                    long deletedKeys = this.deleteRedisData(currentDate, CommonConstant.CASINO_ORDER_ABG_LIST);
//                    log.info("ABG 删除 {} 条的redis数据成功", deletedKeys);
//                }
//            } else {
//                log.info("任务已经被其他 Pod 执行，当前 Pod 不执行任务");
//            }
//        } catch (InterruptedException e) {
//            Thread.currentThread().interrupt();
//            log.error("获取分布式锁时被中断", e);
//        } finally {
//            lock.unlock(); // 释放锁
//        }
//    }
//
////    @Scheduled(cron = "0 30 0 * * *") // 每日10点07分钟执行一次
//    public void sendRebateMsg() {
//        RLock lock = redissonClient.getLock("sendRebateMsgLock");
//        try {
//            if (lock.tryLock(500, TimeUnit.MILLISECONDS)) { // 尝试获取锁，等待 500 毫秒
//                List<String> orderListRedis = getRedisDataService.getEvoRedisDataForRebate();
//                if (orderListRedis.size() == 0) {
//                    log.info("casino rebate 本次发送没有数据");
//                } else {
//                    log.info("casino rebate 本次发送数据量为: {}", orderListRedis.size());
//
//                    try {
//                        rebateJob.sendRebateMsg(orderListRedis);
//                    } catch (Exception e) {
//                        log.error("发送 rebate 消息失败", e);
//                    }
//                    //生成15天前的日期
//                    LocalDate previousDate = LocalDate.now().minusDays(15);
//                    //暂时取消删除redis数据
//                    long deletedKeys = this.deleteRedisData(previousDate, CommonConstant.CASINO_ORDER_REBATE_LIST);
//                    log.info("rebate 删除 {} 条的redis数据成功", deletedKeys);
//                }
//            } else {
//                log.info("任务已经被其他 Pod 执行，当前 Pod 不执行任务");
//            }
//        } catch (InterruptedException e) {
//            Thread.currentThread().interrupt();
//            log.error("获取分布式锁时被中断", e);
//        } finally {
//            lock.unlock(); // 释放锁
//        }
//    }
//
//    //删除redis数据
//    private long deleteRedisData(LocalDate date, String redisKey) {
//        //去掉dateStr 的横线
//        String dateStr = date.toString().replace("-", "");
//        String key = redisKey + "_" + dateStr;
//        long deletedKeys = redissonClient.getKeys().delete(key);
//        return deletedKeys;
//    }
//}
