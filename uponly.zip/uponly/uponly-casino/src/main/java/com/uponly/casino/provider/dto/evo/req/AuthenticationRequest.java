package com.uponly.casino.provider.dto.evo.req;

import com.alibaba.fastjson2.JSONObject;
import lombok.Data;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Data
public class AuthenticationRequest {
    private String uuid;
    private Player player;
    private Config config;

    public AuthenticationRequest() {
        this.uuid = UUID.randomUUID().toString();
        this.player = new Player();
        this.config = new Config();
    }

    public JSONObject toJSONObject() {
        return JSONObject.from(this);
    }

    public Map<String, Object> toMap() {
        Map<String, Object> map = new HashMap<>();
        map.put("uuid", this.uuid);
        map.put("player", this.player);
        map.put("config", this.config);
        return map;
    }

    @Data
    public static class Player {
        private String id;
        private boolean update;
        private String nickname;
        private String language;
        private String currency;
        private Session session;
        private double maxBet;

        public Player() {
            this.session = new Session();
        }
    }

    @Data
    public static class Config {
        private Brand brand;
        private Game game;
        private Channel channel;
        private Urls urls;

        public Config() {
            this.brand = new Brand();
            this.game = new Game();
            this.channel = new Channel();
            this.urls = new Urls();
        }
    }

    @Data
    public static class Channel {
        private boolean wrapped;
        private boolean mobile;
    }

    @Data
    public static class Session {
        private String id;
        private String ip;
    }

    @Data
    public static class Game {
        private String category;
        private String interfaceType;
        private Table table;
        private String playMode;
    }

    @Data
    public static class Urls {
        private String cashier;
        private String responsibleGaming;
        private String lobby;
        private String sessionTimeout;
    }

    @Data
    public static class Brand {
        private String id;
        private String skin;
    }

    public static enum EnumGamePlayMode {
        REAL_MONEY("real_money"),
        PLAY_FOR_FUN("play_for_fun"),
        REWORD_GAMES("reward_games"),
        DEMO("demo");
        private final String value;

        EnumGamePlayMode(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }
    }

    public static enum EnumGameInterface {
        VIEW1("view1"), // launch game in 3D view;
        VIEW2("view2"), // launch game in classic view;
        MLR("MLR"), // launch game in mini live roulette view;
        SLINGSHOT("Slingshot"), // launch game in slingshot view (for auto-roulette only);
        HD1("hd1"), // roulette immersive view and used in CSP.
        HD2("hd2"); // roulette immersive view and used in CSP.

        private final String value;

        EnumGameInterface(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }
    }

    public enum GameCategory {
        GAME_SHOWS("game_shows"),
        BACCARAT_SICBO("baccarat_sicbo"),
        POKER("poker"),
        TOP_GAMES("top_games"),
        ROULETTE("roulette"),
        BLACKJACK("blackjack"),
        REWARD_GAMES("reward_games"),
        SLOTS("slots", "no respective category in Evolution lobby");

        private final String value;
        private final String description;

        // Constructor for categories without a specific description
        GameCategory(String value) {
            this.value = value;
            this.description = "";
        }

        // Constructor for categories with a specific description
        GameCategory(String value, String description) {
            this.value = value;
            this.description = description;
        }

        public String getValue() {
            return value;
        }

        public String getDescription() {
            return description;
        }
    }
}
