package com.uponly.casino.provider.enums.ag;

import lombok.Getter;


@Getter
public enum AgCallbackCode {
    BET("BET"),
    WIN("WIN"),
    LOSE("LOSE"),
    DRAW("DRAW"),
    REFUND("REFUND"),

    ;

    private final String code;


    AgCallbackCode(String code) {
        this.code = code;

    }

    public static AgCallbackCode getEnum(String code) {
        for (AgCallbackCode enumToupAction : AgCallbackCode.values()) {
            if (enumToupAction.getCode().equals(code)) {
                return enumToupAction;
            }
        }
        return null;
    }

}
