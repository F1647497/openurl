package com.uponly.casino.provider.dto.evo.res;

import java.math.BigDecimal;

public class CreditResponse extends BalanceResponse{
    public CreditResponse(String uuid, String status, BigDecimal balance, BigDecimal bonus) {
        super(uuid, status, balance, bonus);
    }

    public CreditResponse() {
        super();
    }
}
