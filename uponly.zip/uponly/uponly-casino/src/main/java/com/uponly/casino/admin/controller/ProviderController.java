package com.uponly.casino.admin.controller;

import com.github.pagehelper.PageInfo;
import com.uponly.casino.admin.dto.AddProviderDTO;
import com.uponly.casino.admin.dto.DeleteProviderDTO;
import com.uponly.casino.admin.dto.SearchProviderDTO;
import com.uponly.casino.admin.dto.UpdateProviderDTO;
import com.uponly.casino.admin.service.ProviderService;
import com.uponly.casino.admin.vo.BaseProviderVO;
import com.uponly.casino.admin.vo.ProviderVO;
import com.uponly.casino.common.api.Result;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@Slf4j
@RestController
@RequestMapping("/provider")
@Tag(name = "ProviderController", description = "供应商管理")
public class ProviderController {
    @Autowired
    private ProviderService providerService;

    @ResponseBody
    @Operation(summary = "添加供应商")
    @PostMapping("/add")
    public Result<String> add(@RequestBody AddProviderDTO addProviderDTO) {
        try {
            Long pid = providerService.add(addProviderDTO);
         //   System.out.println("pid--: " + pid);
            if (pid > 0) {
                return Result.success("添加供应商成功");
            }
            return Result.fail("添加供应商失败");

        } catch (Exception e) {
            return Result.fail("添加供应商失败", e.getMessage());
        }
    }

    // 更新供应商
    @ResponseBody
    @Operation(summary = "更新供应商")
    @PostMapping("/update")
    public Result<String> update(@RequestBody UpdateProviderDTO updateProviderDTO) {
        try {
            int count = providerService.update(updateProviderDTO);
            if (count > 0) {
                return Result.success("更新供应商成功");
            }
            return Result.fail("更新供应商失败, 未找到对应供应商");
        } catch (Exception e) {
            return Result.fail("更新供应商失败", e.getMessage());
        }
    }

    // 删除供应商
    @ResponseBody
    @Operation(summary = "删除供应商")
    @RequestMapping(value = "/delete/{pid}", method = RequestMethod.GET)
    public Result<String> delete(@PathVariable Long pid) {
        try {
            DeleteProviderDTO deleteProviderDTO = new DeleteProviderDTO();
            deleteProviderDTO.setPid(pid);
            System.out.println(deleteProviderDTO);
            int count = providerService.delete(deleteProviderDTO);
            if (count > 0) {
                return Result.success("删除供应商成功");
            }
            return Result.fail("删除供应商失败, 未找到对应供应商");
        } catch (Exception e) {
            return Result.fail("删除供应商失败", e.getMessage());
        }
    }

    //根据页码 和 每页要展示的数据来生成所有数据页面
    @ResponseBody
    @Operation(summary = "查询供应商")
    @PostMapping("/search")
    public Result<PageInfo<ProviderVO>> search(@RequestBody SearchProviderDTO searchProviderDTO) {
        try {
            PageInfo<ProviderVO> pageInfo = providerService.search(searchProviderDTO);
            return Result.success(pageInfo);
        } catch (Exception e) {
            log.error("查询供应商 异常{} ", e.getMessage());

        }
        return null;
    }

    // 获取全部供应商
    @ResponseBody
    @Operation(summary = "获取全部供应商")
    @GetMapping("/list")
    public Result<PageInfo<BaseProviderVO>> list() {
        try {
            // 获取所有供应商
            var providers = providerService.providers();
            // 转换成BaseProviderVO的列表
            var pageInfo = new PageInfo<BaseProviderVO>(providers);
            return Result.success(pageInfo);
        } catch (Exception e) {
            log.error("获取供应商列表失败", e);
            return Result.fail(1001, "无法获取供应商列表，请稍后再试");
        }
    }

    // 获取最大排序值的后续100可以整除的值
    @ResponseBody
    @Operation(summary = "获取最大排序值")
    @GetMapping("/maxSort")
    public Result<Integer> maxSort() {
        try {
            Optional<Integer> maxSort = providerService.maxSort();
            return Result.success(maxSort.orElse(0));
        } catch (Exception e) {
            log.error("获取最大排序值 异常{} ", e.getMessage());
        }
        return null;
    }
}

