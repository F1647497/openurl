package com.uponly.casino.admin.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class TotalAmountVO {

    //投注总额
    @Schema(title = "货币")
    private String currency;

    @Schema(title = "总投注额")
    private BigDecimal totalBetAmount;

    @Schema(title = "总赔付额")
    private BigDecimal totalPayout;





}
