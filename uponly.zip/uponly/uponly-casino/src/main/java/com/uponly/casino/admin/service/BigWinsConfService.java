package com.uponly.casino.admin.service;


import com.github.pagehelper.PageInfo;
import com.uponly.casino.admin.dto.BigWinsConfDTO;
import com.uponly.casino.admin.vo.BigWinsConfVO;


import java.util.List;


public interface BigWinsConfService {


    PageInfo<BigWinsConfVO> page(BigWinsConfDTO dto);

    List<BigWinsConfVO> list(BigWinsConfDTO dto);

    int save(BigWinsConfVO entity);

    int edit(BigWinsConfVO entity);

    void batchEdit(List<BigWinsConfVO> list);

    int delete(Long id);


}
