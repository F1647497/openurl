package com.uponly.casino.provider.dto.sa;
import lombok.Data;

@Data
public class SaConfig {
    /**
     * 回调地址
     */
    private String backUrl;
    /**
     * api域名
     */
    private String baseUrl;
    /**
     * H5域名
     */
    private String openUrl;
    /**
     * md5 key
     */
    private String MD5;
    /**
     * 加密密钥
     */
    private String DES;

    private String getUrl;
    /**
     * 密钥
     */
    private String secretKey;
    /**
     * 第三方代码
     */
    private String lobby;

    public SaConfig() {

    }
}
