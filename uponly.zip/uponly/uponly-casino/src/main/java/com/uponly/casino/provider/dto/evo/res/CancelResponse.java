package com.uponly.casino.provider.dto.evo.res;

public class CancelResponse extends BalanceResponse{
    public CancelResponse() {
        super();
    }
}
