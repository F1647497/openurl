package com.uponly.casino.admin.controller;

import com.github.pagehelper.PageInfo;
import com.uponly.casino.admin.dto.RecommendDTO;
import com.uponly.casino.admin.dto.SearchRecommendDTO;
import com.uponly.casino.admin.service.RecommendService;
import com.uponly.casino.admin.vo.RecommendGameVO;
import com.uponly.casino.common.api.Result;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@Slf4j
@RestController
@RequestMapping("/recommend")
@Tag(name = "RecommendController", description = "推荐入口管理")
public class RecommendController {
    @Autowired
    private RecommendService recommendService;

    @ResponseBody
    @Operation(summary = "添加推荐入口")
    @PostMapping("/add")
    public Result<String> add(@RequestBody RecommendDTO recommendDTO) {
        try {

            var id = recommendService.add(recommendDTO);
            if (id > 0) {
                return Result.success("添加入口成功");
            }
            return Result.fail("添加入口失败");
        } catch (Exception e) {
            return Result.fail("添加入口失败", e.getMessage());
        }
    }

    // 更新推荐游戏
    @ResponseBody
    @Operation(summary = "更新推荐入口")
    @PostMapping("/update")
    public Result<String> update(@RequestBody RecommendDTO recommendDTO) {
        try {
            var count = recommendService.update(recommendDTO);
            if (count > 0) {
                return Result.success("更新推荐游戏成功");
            }
            return Result.fail("更新推荐游戏失败, 未找到对应推荐游戏");
        } catch (Exception e) {
            return Result.fail("更新推荐游戏失败", e.getMessage());
        }
    }

    // 删除推荐游戏
    @ResponseBody
    @Operation(summary = "删除推荐入口")
    @PostMapping("/delete")
    public Result<String> delete(@RequestBody RecommendDTO recommendDTO) {
        try {
            var count = recommendService.delete(recommendDTO);
            if (count > 0) {
                return Result.success("删除推荐游戏成功");
            }
            return Result.fail("删除推荐入口失败, 未找到对应推荐游戏");
        } catch (Exception e) {
            return Result.fail("删除推荐入口失败", e.getMessage());
        }
    }

    //根据页码 和 每页要展示的数据来生成所有数据页面
    @ResponseBody
    @Operation(summary = "查询推荐入口")
    @PostMapping("/search")
    public Result<PageInfo<RecommendGameVO>> search(@RequestBody SearchRecommendDTO searchRecommendDTO) {
        try {
            PageInfo<RecommendGameVO> pageInfo = recommendService.searchRecommendGame(searchRecommendDTO);
            return Result.success(pageInfo);
        } catch (Exception e) {
            log.error("查询推荐入口 异常{} ", e.getMessage());

        }
        return null;
    }

    // 获取sort最大值
    @ResponseBody
    @Operation(summary = "获取sort最大值")
    @GetMapping("/maxSort")
    public Result<Integer> maxSort() {
        try {
            Optional<Integer> maxOrder = recommendService.maxSort();
            return Result.success(maxOrder.orElse(0));
        } catch (Exception e) {
            log.error("获取最大的排序值 异常{} ", e.getMessage());

        }
        return null;
    }
}

