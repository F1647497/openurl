package com.uponly.casino.provider.enums.ag;

import lombok.Getter;


public enum AgLanguageCode {
    EN("en","3"),
    TH("th","6"),
    VI("vi","8"),
    ID("id","11"),
    MS("ms","3"),
    ZH("zh","1"),

    ;
    //1   简体中文 Simplified Chinese
    //2   䌓体中文 Traditional Chinese
    //3   英语 English
    //4   日语 Japanese
    //5   韩语 Korean
    //6   泰文 Thai
    //8   越南文 Vietnamese
    //9   柬埔寨语 Cambodian
    //11  印尼语 Indonesian
    //23  葡萄牙语 Portuguese
    @Getter
    private final String code;
    @Getter
    private final String agCode;

    AgLanguageCode(String code, String agCode) {
        this.code = code;
        this.agCode = agCode;
    }

    public static AgLanguageCode getEnum(String code) {
        for (AgLanguageCode enumToupAction : AgLanguageCode.values()) {
            if (enumToupAction.getCode().equals(code)) {
                return enumToupAction;
            }
        }
        return EN;
    }

}
