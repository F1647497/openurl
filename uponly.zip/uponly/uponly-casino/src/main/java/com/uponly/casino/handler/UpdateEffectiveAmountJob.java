//package com.uponly.casino.handler;
//
//
//import com.alibaba.fastjson.JSONObject;
//import com.uponly.casino.admin.dto.UpdateEffectiveAmountDTO;
//import com.uponly.casino.admin.service.GetRedisDataService;
//import com.uponly.casino.admin.vo.AmountMsgVO;
//import com.uponly.casino.common.utils.RegionIntegerUtil;
//import com.uponly.casino.job.AbstractReportJob;
//import com.uponly.casino.mapper.OrderMapper;
//import com.uponly.casino.provider.service.UserInfoService;
//import com.uponly.casino.provider.vo.UserInfoVO;
//import lombok.extern.slf4j.Slf4j;
//import org.redisson.api.RLock;
//import org.redisson.api.RedissonClient;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.kafka.core.KafkaTemplate;
//import org.springframework.kafka.support.SendResult;
//import org.springframework.stereotype.Service;
//
//import java.math.BigDecimal;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Optional;
//import java.util.UUID;
//import java.util.concurrent.CompletableFuture;
//
//
//@Service
//@Slf4j
//public class UpdateEffectiveAmountJob extends AbstractReportJob {
//    @Autowired
//    private KafkaTemplate<String, String> kafkaTemplate;
//
//    @Autowired
//    RedissonClient redissonClient;
//
//    @Autowired
//    UserInfoService userInfoService;
//
//    @Autowired
//    GetRedisDataService getRedisDataService;
//
//    @Autowired
//    private OrderMapper orderMapper;
//
//
//    public void updateEffectiveAmount(List<String> orderListRedis) {
//        RLock lock = redissonClient.getLock("updateEffectiveAmount");
//        try {
//            // 从redis中获取casino注单列表，然后一次性发送订单数组到kafka
//            lock.lock();
//            Integer totalCount = this.UpdateEffectiveAmountDTO(orderListRedis);
//            log.info("【总的UpdateEffectiveAmountDTO】的结果={}", totalCount);
//        } catch (Exception e) {
//            log.error("UpdateEffectiveAmountDTO ", e);
//        } finally {
//            lock.unlock();
//        }
//    }
//
//    public Integer UpdateEffectiveAmountDTO(List<String> orderListRedis) {
//        try {
//            Integer totalCount = 0;
//            for (String orderJsonString : orderListRedis) {
//                JSONObject jsonObject = JSONObject.parseObject(orderJsonString);
//
//                BigDecimal amount = jsonObject.getBigDecimal("amount");
//                String gameResult = jsonObject.getString("gameResult");
//
//                String betId = jsonObject.getString("orderNo");
//                BigDecimal effectiveAmount = super.getEffectiveAmount(amount, gameResult);
//                //更新有效流水
//                UpdateEffectiveAmountDTO updateEffectiveAmountDTO = new UpdateEffectiveAmountDTO();
//                updateEffectiveAmountDTO.setEffectiveAmount(effectiveAmount);
//                updateEffectiveAmountDTO.setOrderNo(betId);
//                Integer count = orderMapper.updateEffectiveAmount(updateEffectiveAmountDTO);
//                totalCount += count;
//                log.info("更新有效流水结果：{}", count + "，金额为：" + updateEffectiveAmountDTO);
//            }
//
//            return totalCount;
//        } catch (Exception e) {
//            log.error("更新有效流水结果 异常{} ", e.getMessage());
//        }
//        return 0;
//    }
//
//
//}
