package com.uponly.casino.admin.vo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.io.Serializable;

@Data
@TableName("casino_game_entrance")
public class EntryVO implements Serializable {
    @TableId(type = IdType.AUTO)
    @Schema(title = "eid")
    private Long eid;

    @Schema(title = "pid")
    private Long pid;

    @Schema(title = "providerName")
    private String providerName;

    @Schema(title = "gameId")
    private Long gameId;

    @Schema(title = "ename")
    private String ename;

    @Schema(title = "gameType")
    private String gameType;

    @Schema(title = "status")
    private Integer status;

    @Schema(title = "icon")
    private String icon;

    @Schema(title = "mainEntry")
    private String mainEntry;

    @Schema(title = "addtion")
    private String addition;

    @Schema(title = "promotion")
    private Integer promotion;

    @Schema(title = "sort")
    private Integer sort;

    @Schema(title = "favorite_count")
    private Integer favoriteCount;

    @Schema(title = "regions")
    private String regions;

    @Schema(title="版本号")
    private Integer version;

    public enum EnumMainEntry {
        LOBBY("lobby"),
        GAME_LOBBY("game_lobby"),
        GAME("game"),
        ORIGIN("origin");

        private String value;

        EnumMainEntry(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }
    }

    public enum EnumGameType {
        BACCARAT("baccarat"),
        BLACK_JACK("blackjack"),
        POKER("poker"),
        ROULETTE("roulette"),
        DRAGON_TIGER("dragon_tiger"),
        DICE("dice"),
        GAME_SHOW("game_show");

        private String value;

        EnumGameType(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }
    }
}
