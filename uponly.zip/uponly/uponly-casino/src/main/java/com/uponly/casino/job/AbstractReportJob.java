package com.uponly.casino.job;

import cn.hutool.core.thread.ExecutorBuilder;
import cn.hutool.core.thread.ThreadFactoryBuilder;
import com.alibaba.fastjson2.JSON;
import com.alibaba.fastjson2.JSONObject;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.uponly.casino.admin.vo.OrderVO;
import com.uponly.casino.common.constant.CommonConstant;
import com.uponly.casino.common.constant.RedisKeyPrefixConst;
import com.uponly.casino.common.enums.ReportType;
import com.uponly.casino.mapper.OrderMapper;
import com.uponly.casino.provider.service.UserInfoService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.redisson.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StopWatch;

import java.math.BigDecimal;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * 上报任务
 * 鉴于上报为异步任务，需要保证任务的幂等性，
 * 所以在上报任务开始时，设置任务状态为上报中，上报结束后(无论成功还是失败)再更新状态
 * TODO 等待加锁
 */

@Slf4j
public abstract class AbstractReportJob {

    @Autowired
    protected RedissonClient redissonClient;
    @Autowired
    protected UserInfoService userInfoService;
    @Autowired
    protected OrderMapper orderMapper;
    @Autowired
    protected KafkaTemplate<String, String> kafkaTemplate;

    private static final ExecutorService executor = ExecutorBuilder.create()
            .setCorePoolSize(10)
            .setMaxPoolSize(20)
            .setWorkQueue(new ArrayBlockingQueue<>(100))
            .setThreadFactory(ThreadFactoryBuilder.create().setNamePrefix("kfk-future-").build())
            .build();


    public void execute() {
        StopWatch stopWatch = new StopWatch();
        stopWatch.start("fetchDataSafely");

        List<Object> dataList = fetchDataSafely();
        stopWatch.stop();
        log.info("【注单上报】获取数据完成并标记上报状态到redis，dataList.size={}，耗时={}ms", dataList.size(), stopWatch.getLastTaskTimeMillis());

        stopWatch.start("processReport");
        if (!CollectionUtils.isEmpty(dataList)) {
            dataList.forEach(this::processReport);
        }
        stopWatch.stop();
        log.info("【注单上报】单次上报Job执行完成，耗时={}ms", stopWatch.getTotalTimeMillis());
    }


    /**
     * 安全获取数据
     * 防止多个任务同时获取相同数据，数据获取到时，保存其“正在上报”状态到redis
     *
     * @return 原始数据列表
     */
    private List<Object> fetchDataSafely() {
        ReportType reportType = getReportType();
        RLock lock = redissonClient.getLock("report-job-lock-" + reportType.getType());
        List<Object> dataList = Lists.newArrayList();
        boolean lockAcquired = false;
        try {
            lockAcquired = lock.tryLock(10, 30, TimeUnit.SECONDS);
            if (lockAcquired) {
                log.info("【注单上报】reportType={}，获取锁:{}成功", reportType.getType(), lock.getName());
                return fetchData();
            } else {
                log.warn("【注单上报】reportType={}，获取锁:{}失败", reportType.getType(), lock.getName());
            }
        } catch (Exception e) {
            log.error("【注单上报】】reportType={}，获取数据失败：exception={} ", reportType.getType(), e.getMessage(), e);
        } finally {
            if (lockAcquired && lock.isHeldByCurrentThread()) {
                log.info("【注单上报】reportType={}，释放锁:{}成功", reportType.getType(), lock.getName());
                lock.unlock();
            }
        }
        return dataList;
    }

    /**
     * 处理上报
     *
     * @param data 原始数据
     */
    private void processReport(Object data) {
        ReportType reportType = null;
        try {
            reportType = getReportType();
            String topic = kafkaTopic();
            String key = kafkaKey(data); //分区key，send(topic, key, kfkData)
            String kfkData = kafkaData(data);

            if (StringUtils.isBlank(kfkData)) {
                log.error("【注单上报】reportType={},上报失败，kafkaData为空，data={}", reportType, data);
                return;
            }
            sendKafkaMessage(topic, kfkData, data, reportType);
        } catch (Exception e) {
            log.error("【注单上报】reportType={},Job发生异常：data={},exception={}", reportType, data, e.getMessage(), e);
            finishReporting(data);
        }
    }

    /**
     * 发送kafka消息
     *
     * @param topic   主题
     * @param kfkData kafka数据
     * @param data    原始数据
     */
    private void sendKafkaMessage(String topic, String kfkData, Object data, ReportType reportType) {
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();

        CompletableFuture<SendResult<String, String>> future = kafkaTemplate.send(topic, kfkData);
        future.whenCompleteAsync((result, ex) -> {
            stopWatch.stop();
            handleKafkaResult(result, ex, kfkData, data, reportType, stopWatch);
        }, executor);
    }


    /**
     * 异步处理kafka发送结果
     *
     * @param result  发送结果
     * @param ex      异常
     * @param kfkData kafka数据
     * @param data    原始数据
     */
    private void handleKafkaResult(SendResult<String, String> result, Throwable ex,
                                   String kfkData, Object data, ReportType reportType,
                                   StopWatch stopWatch) {
        long elapsedTime = stopWatch.getTotalTimeMillis();
        if (ex != null) { //上报失败
            log.error("【注单上报】reportType={}，上报失败，data={},exception={}", reportType, kfkData, ex.getMessage(), ex);
            finishReporting(data);
        } else {
            log.info("【注单上报】reportType={}，上报成功，data={},topic={}, partition={}, offset={}, ts={}, 耗时={}ms",
                    reportType,
                    data.toString(),
                    result.getRecordMetadata().topic(),
                    result.getRecordMetadata().partition(),
                    result.getRecordMetadata().offset(),
                    result.getRecordMetadata().timestamp(),
                    elapsedTime);
            try {
                updateData(data);
            } catch (Exception e) {
                log.error("【注单上报】】reportType={}，更新数据状态失败，data={},exception={}", reportType, kfkData, e.getMessage(), e);
            } finally {
                finishReporting(data);
            }
        }
    }


    protected abstract String kafkaTopic();

    protected abstract String kafkaKey(Object data);

    protected abstract String kafkaData(Object data);

    protected abstract ReportType getReportType();

    //获取需上报的源数据
    protected abstract List<Object> fetchData();

    //上报成功更新数据库状态
    protected abstract void updateData(Object data);

    protected abstract void finishReporting(Object data);


    //组装kafka消息体
    protected String buildKafkaMessage(String messageType, JSONObject body, long ts) {
        JSONObject msgJson = new JSONObject();
        msgJson.put("messageType", messageType);
        msgJson.put("messageBody", body);
        msgJson.put("partion", 0);
        msgJson.put("messageId", UUID.randomUUID());
        msgJson.put("ts", ts);
        return msgJson.toJSONString();
    }


    /**
     * 获取单笔注单的有效流水
     * game_result有值时判断其中的tie和push注单，计算有效流水
     * game_result为空时，返回原始投注金额
     *
     * @param betAmount  投注金额
     * @param gameResult 游戏结果
     * @return 有效流水
     */
    public BigDecimal getEffectiveAmount(BigDecimal betAmount, String gameResult) {
        if (StringUtils.isBlank(gameResult) || "{}".equals(gameResult)) {
            return Optional.ofNullable(betAmount).orElse(BigDecimal.ZERO);
        }
        List<JSONObject> gameResultList = JSON.parseArray(gameResult).toList(JSONObject.class);

        return gameResultList.stream()
                .filter(order -> order != null && order.getString("result") != null)
                .filter(order -> {
                    String result = order.getString("result").toLowerCase();
                    return result.contains("tie") || "push".equals(result);
                })
                .peek(order -> {
                    BigDecimal effectiveAmount = betAmount.subtract(Optional.ofNullable(order.getBigDecimal("payout")).orElse(BigDecimal.ZERO));
                    log.info("【注单上报】发现tie或push注单，order={},其流水effectiveAmount={}", order, effectiveAmount);
                })
                .map(order -> Optional.ofNullable(order.getBigDecimal("payout")).orElse(BigDecimal.ZERO))
                .reduce(betAmount, BigDecimal::subtract);
    }

    /**
     * 判断注单的settleAt是否超过指定的时长
     *
     * @return true: 超时 false: 未超时
     */
    public static boolean isSettleAtTimeout(OrderVO order) {
        Date settleAt = order.getSettleAt();
        return System.currentTimeMillis() - settleAt.getTime() > CommonConstant.CASINO_ORDER_HISTORY_TIMEOUT;
    }


    //=================================================================================================

    private static String redisReportKey(String orderNo) {
        return String.format(RedisKeyPrefixConst.CASINO_REPORT_ING_STATE, orderNo);
    }

    /**
     * 设置任务状态为正在上报
     *
     * @param orderNo    任务id："report_" + orderNo
     * @param reportType 任务状态 即每个任务的唯一标识 reportType的state 为位数
     */
    public void startReporting(String orderNo, ReportType reportType) {
        RBitSet bitSet = redissonClient.getBitSet(redisReportKey(orderNo));
        bitSet.set(reportType.getState(), true);
        log.info("【注单上报】reportType={}，设置注单为‘上报中’，orderNo={}", reportType, orderNo);
    }

    /**
     * 批量设置任务状态为正在上报 同时设置该注单的超时时间
     */
    public void batchStartReporting(Set<String> orderNos, ReportType reportType) {
        if (orderNos.isEmpty()) {
            return;
        }
        RBatch batch = redissonClient.createBatch();
        for (String orderNo : orderNos) {
            RBitSetAsync bitSet = batch.getBitSet(redisReportKey(orderNo));
            bitSet.setAsync(reportType.getState(), true);
            bitSet.expireAsync(Duration.ofMinutes(CommonConstant.CASINO_REPORT_EXPIRE_MIN));
        }
        batch.execute();
        log.info("【注单上报】reportType={}，批量设置注单状态为‘上报中’：orderNos={}", reportType, orderNos);
    }

    /**
     * 设置任务状态为上报完成
     *
     * @param orderNo    任务id："report_" + orderNo
     * @param reportType 任务状态 即每个任务的唯一标识 reportType的state 为位数
     */
    public void finishReporting(String orderNo, ReportType reportType) {
        RBitSet bitSet = redissonClient.getBitSet(redisReportKey(orderNo));
        bitSet.set(reportType.getState(), false);
        log.info("【注单上报】reportType={}，设置注单状态为‘上报结束’(false)，orderNo={}", reportType, orderNo);
    }

    /**
     * 批量设置任务状态为上报完成
     */
    public void batchFinishReporting(Set<String> orderNos, ReportType reportType) {
        RBatch batch = redissonClient.createBatch();
        for (String orderNo : orderNos) {
            RBitSetAsync bitSet = batch.getBitSet(redisReportKey(orderNo));
            bitSet.setAsync(reportType.getState(), false);
        }
        BatchResult<?> batchResult = batch.execute();
        List<?> results = batchResult.getResponses();
        log.info("【注单上报】reportType={}，results={}", reportType, results);
        log.info("【注单上报】reportType={}，批量设置注单为上报完成(false)，orderNos={}", reportType, orderNos);
    }

    /**
     * 检查任务是否正在上报
     *
     * @param orderNo    任务id "report_" + orderNo
     * @param reportType 任务状态 即每个任务的唯一标识 reportType的state 为位数
     * @return 是否正在上报
     */
    public boolean isReporting(String orderNo, int reportType) {
        RBitSet bitSet = redissonClient.getBitSet(redisReportKey(orderNo));
        boolean isReporting = bitSet.get(reportType);
        log.info("【注单上报】检查注单是否正在上报，orderNo={},reportType={}，isReporting={}", orderNo, reportType, isReporting);
        return isReporting;
    }

    /**
     * 批量获取可以上报的注单（没有在上报中）
     * 如果处理中出现异常，则放弃记录正上报的状态，直接返回所有记录
     *
     * @param originOrderIds 原始注单id列表
     * @param reportType     任务状态 即每个任务的唯一标识 reportType的state 为位数
     * @return 没有在上报中的注单id列表
     */
    public Set<String> batchAndMarkUnReportingOrders(List<String> originOrderIds, ReportType reportType) {
        Set<String> results = Sets.newHashSet();
        try {
            RBatch batch = redissonClient.createBatch();
            // 创建批处理命令
            for (String orderNo : originOrderIds) {
                batch.getBitSet(redisReportKey(orderNo)).getAsync(reportType.getState());
            }
            // 执行批处理并获取结果
            List<?> responses = batch.execute().getResponses();
            for (int i = 0; i < originOrderIds.size(); i++) {
                Object response = responses.get(i);
                if (response == null) {
                    log.error("【注单上报】Response at orderId= {} is null.", originOrderIds.get(i));
                    continue;
                }
                if (response instanceof Boolean status) {
                    if (!status) {
                        results.add(originOrderIds.get(i));
                    }
                } else {
                    log.error("【注单上报】Response at orderId= {} is not a Boolean:{} ", originOrderIds.get(i), response);
                }
            }
            log.info("【注单上报】ReportType={}，当前可上报注单orderNos={} ", reportType, results);
            // 设置任务状态为正在上报
            batchStartReporting(results, reportType);
            return results;
        } catch (Exception e) {
            if (!results.isEmpty()) {
                // 异常则回滚设置任务状态为上报完成
                batchFinishReporting(results, reportType);
            }
            log.error("【注单上报】批量获取可以上报的注单失败，返回原始数据。：exception={} ", e.getMessage(), e);
            return Sets.newHashSet(originOrderIds);
        }
    }


}
