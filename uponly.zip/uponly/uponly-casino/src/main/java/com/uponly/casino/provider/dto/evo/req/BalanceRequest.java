package com.uponly.casino.provider.dto.evo.req;

import lombok.Data;

import java.util.Map;

@Data
public class BalanceRequest {
    private String sid;      // Player's session ID
    private String userId;   // Player's ID, assigned by Licensee
    private String currency; // Currency code (ISO 4217 3-letter code)
    private Game game;       // May be null or empty if non-game related
    private String uuid;     // Unique request ID

    public BalanceRequest(Map<String, Object> body) {
        this.sid = (String) body.get("sid");
        this.userId = (String) body.get("userId");
        this.currency = (String) body.get("currency");
        var gameObj = body.get("game");
        if (gameObj == null) {
            this.game = null;
        } else {
            this.game = new Game((Map<String, Object>)gameObj);
        }
        this.uuid = (String) body.get("uuid");
    }
}
