package com.uponly.casino.common.utils;


import com.alibaba.fastjson2.JSON;
import com.alibaba.fastjson2.JSONArray;
import com.alibaba.fastjson2.JSONException;
import com.alibaba.fastjson2.JSONObject;
import com.uponly.casino.common.enums.LanguageEnum;
import lombok.extern.slf4j.Slf4j;

import java.util.Objects;

@Slf4j
public class LanguageUtil {

    public static String getName(String jsonObjectStr, String language) {
        try {
            JSONObject jsonObject = JSON.parseObject(jsonObjectStr);
            if (!jsonObject.containsKey("nameI18n")) {
                log.error("jsonObject.containsKey(\"nameI18n\")={} jsonObjectStr={} ", jsonObject.containsKey("nameI18n"), jsonObjectStr);
                return null;
            }
            JSONArray jsonArray = jsonObject.getJSONArray("nameI18n");
            return jsonArray.stream()
                    .map(Object::toString)
                    .map(JSON::parseObject)
                    .filter(object -> Objects.equals(object.getString("id"), language))
                    .map(object -> object.getString("name"))
                    .findFirst()
                    .orElse(null);
        } catch (JSONException e) {
            log.error("Failed to parse JSON string: " + e.getMessage());
            return null;
        }
    }

    public static String initNameEdit() {
        //根据LanguageEnum的id初始化name，要求生成的格式如下：{\"nameId\": \"id\", \"nameI18n\": [{\"id\": \"en\", \"name\": \"英文\", \"label\": \"英文\"}, {\"id\": \"zh\", \"name\": \"中文\", \"label\": \"中文\"}, {\"id\": \"th\", \"name\": \"泰文\", \"label\": \"泰文\"}, {\"id\": \"vi\", \"name\": \"越南文\", \"label\": \"越南文\"}, {\"id\": \"ms\", \"name\": \"马来文\", \"label\": \"马来文\"}, {\"id\": \"id\", \"name\": \"印尼文\", \"label\": \"印尼文\"}]}
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("nameId", "id");
        JSONArray jsonArray = new JSONArray();
        for (LanguageEnum languageEnum : LanguageEnum.values()) {
            JSONObject object = new JSONObject();
            object.put("id", languageEnum.getId());
            object.put("name", "");
            object.put("label", "");
            jsonArray.add(object);
        }
        jsonObject.put("nameI18n", jsonArray);
        return jsonObject.toJSONString();
    }

    //{"nameId": "id", "nameI18n": [{"id": "en", "name": "英文", "label": "英文"}, {"id": "zh", "name": "中文", "label": "中文"}, {"id": "th", "name": "泰文", "label": "泰文"}, {"id": "vi", "name": "越南文", "label": "越南文"}, {"id": "ms", "name": "马来文", "label": "马来文"}, {"id": "id", "name": "印尼文", "label": "印尼文"}]}

    public static String initAdEdit() {
        //根据LanguageEnum的id初始化name，要求生成的格式如下：{\"nameId\": \"id\", \"nameI18n\": [{\"id\": \"en\", \"name\": \"英文\", \"label\": \"英文\"}, {\"id\": \"zh\", \"name\": \"中文\", \"label\": \"中文\"}, {\"id\": \"th\", \"name\": \"泰文\", \"label\": \"泰文\"}, {\"id\": \"vi\", \"name\": \"越南文\", \"label\": \"越南文\"}, {\"id\": \"ms\", \"name\": \"马来文\", \"label\": \"马来文\"}, {\"id\": \"id\", \"name\": \"印尼文\", \"label\": \"印尼文\"}]}
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("nameId", "id");
        JSONArray jsonArray = new JSONArray();
        for (LanguageEnum languageEnum : LanguageEnum.values()) {
            JSONObject object = new JSONObject();
            object.put("id", languageEnum.getId());
            object.put("name", "");
            object.put("label", "");
            jsonArray.add(object);
        }
        jsonObject.put("nameI18n", jsonArray);
        return jsonObject.toJSONString();
    }



    public static void main(String[] args) {
        String str = "{\"nameId\": \"id\", \"nameI18n\": [{\"id\": \"en\", \"name\": \"英文\", \"label\": \"英文\"}, {\"id\": \"zh\", \"name\": \"中文\", \"label\": \"中文\"}, {\"id\": \"th\", \"name\": \"泰文\", \"label\": \"泰文\"}, {\"id\": \"vi\", \"name\": \"越南文\", \"label\": \"越南文\"}, {\"id\": \"ms\", \"name\": \"马来文\", \"label\": \"马来文\"}, {\"id\": \"id\", \"name\": \"印尼文\", \"label\": \"印尼文\"}]}";
        System.out.println(getName(str, "zh"));
        System.out.println(str);
        System.out.println(initNameEdit());
        System.out.println(initAdEdit());
    }


}
