package com.uponly.casino.admin.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.uponly.casino.admin.dto.*;
import com.uponly.casino.admin.service.EntranceService;
import com.uponly.casino.admin.vo.EntryVO;
import com.uponly.casino.admin.vo.FavoriteCountVO;
import com.uponly.casino.mapper.EntranceMapper;
import com.uponly.casino.mapper.RecommendMapper;
import com.uponly.casino.provider.dto.GameInfoDTO;
import com.uponly.casino.provider.service.GameInfoService;
import org.apache.commons.lang3.SerializationUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.SQLOutput;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class EntranceServiceImpl implements EntranceService {

    private static final Logger log = LoggerFactory.getLogger(EntranceServiceImpl.class);
    @Autowired
    private EntranceMapper entranceMapper;

    @Autowired
    private RecommendMapper recommendGameMapper;

    @Autowired
    GameInfoService gameInfoService;


    public Optional<EntryVO> getEntry(Long entryId) {
        var entry = entranceMapper.getEntryByEid(entryId);
        return Optional.ofNullable(entry);
    }

    @Override
    public PageInfo<EntryVO> searchGameEntrance(SearchGameEntranceDTO searchGameEntranceDTO) {
        Integer page = searchGameEntranceDTO.getPage();
        Integer pageSize = searchGameEntranceDTO.getPageSize();

        // 开始分页
        PageHelper.startPage(page, pageSize);

        // 查询数据
        List<EntryVO> entryList = entranceMapper.searchGameEntrance(searchGameEntranceDTO);

        // 获取所有游戏入口的收藏计数
        Set<Long> eids = new HashSet<>();
        for (EntryVO entryVO : entryList) {
            eids.add(entryVO.getEid());
        }

        // 存储收藏计数
        Map<Long, Integer> favoriteCounts = new HashMap<>();
        for (Long eid : eids) {
            FavoriteCountVO favoriteCountVO = new FavoriteCountVO();
            favoriteCountVO.setEid(eid);
            FavoriteCountVO favoriteCountResult = entranceMapper.getFavoriteCount(favoriteCountVO);
            int favoriteCount = favoriteCountResult == null ? 0 : favoriteCountResult.getFavoriteCount();
            favoriteCounts.put(eid, favoriteCount);
        }

        // 克隆并设置收藏计数
        List<EntryVO> newEntryList = new ArrayList<>();
        for (EntryVO entryVO : entryList) {
            EntryVO clonedEntryVO = SerializationUtils.clone(entryVO);  // 深度克隆
            int favoriteCount = favoriteCounts.getOrDefault(entryVO.getEid(), 0);
            clonedEntryVO.setFavoriteCount(favoriteCount);  // 设置收藏计数
            newEntryList.add(clonedEntryVO);
        }

        // 构建 PageInfo 对象
        PageInfo<EntryVO> pageInfo = new PageInfo<>(entryList);  // 使用分页查询结果
        pageInfo.setList(newEntryList);  // 替换为处理后的列表

        return pageInfo;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Long newGameEntrance(AddGameEntranceDTO addGameEntranceDTO) throws JsonProcessingException {
        String addition = addGameEntranceDTO.getAddition();
        String ename = addGameEntranceDTO.getEname();

        Integer countOfTableId = entranceMapper.searchAddition(addition);
        Integer countOfEname = entranceMapper.searchEname(ename);
        if (countOfTableId > 0 && countOfEname > 0) {
            throw new IllegalArgumentException("Table ID or ename already exists.");
        } else {
            entranceMapper.addGameEntrance(addGameEntranceDTO);
            //将地区信息添加到地区表
            Long eid = addGameEntranceDTO.getEid();
            System.out.println("eid: " + eid);

            AddRegionDTO addRegionDTO = new AddRegionDTO();
            String jsonRegions = addGameEntranceDTO.getRegions();

            // 正则表达式提取方括号内的数字
            Pattern pattern = Pattern.compile("\\d+");
            Matcher matcher = pattern.matcher(jsonRegions);

            // 存储提取的整数
            List<Integer> regionsNumber = new ArrayList<>();

            // 将匹配到的数字添加到列表
            while (matcher.find()) {
                int region = Integer.parseInt(matcher.group());
                regionsNumber.add(region);
            }
            // 打印提取到的数字
            for (int region : regionsNumber) {
                addRegionDTO.setEid(eid);
                addRegionDTO.setRegion(region);
                entranceMapper.addGameRegion(addRegionDTO);
            }
            //获取pid并通知游戏更新
            Long id = addRegionDTO.getId();

            gameInfoService.notifyGameUpdate(addGameEntranceDTO.getPid());

            return id;
        }

    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int editGameEntrance(EditGameEntranceDTO editGameEntranceDTO) {
        // 编辑游戏入口
        int rowsAffected = entranceMapper.editGameEntrance(editGameEntranceDTO);
        if (rowsAffected == 0) {
            return 0;
        }
        // 提取 jsonRegions 字符串中的数字
        String jsonRegions = editGameEntranceDTO.getRegions();

        if (jsonRegions != null && !jsonRegions.trim().isEmpty()) {
            // 删除相关的区域信息
            Long eid = editGameEntranceDTO.getEid();
            DeleteRegionDTO deleteRegionDTO = new DeleteRegionDTO();
            deleteRegionDTO.setEid(eid);
            int rowsAffectedOfGameRegion = entranceMapper.deleteGameRegion(deleteRegionDTO);
            if (rowsAffectedOfGameRegion == 0) {
                return 0;
            } else {
                // 正则表达式提取方括号内的数字
                Pattern pattern = Pattern.compile("\\d+");
                Matcher matcher = pattern.matcher(jsonRegions);
                // 存储提取的整数
                List<Integer> regionsNumber = new ArrayList<>();
                // 将匹配到的数字添加到列表
                while (matcher.find()) {
                    int region = Integer.parseInt(matcher.group());
                    regionsNumber.add(region);
                }
                // 重新添加区域
                AddRegionDTO addRegionDTO = new AddRegionDTO();
                addRegionDTO.setEid(eid);
                for (int region : regionsNumber) {
                    addRegionDTO.setRegion(region);
                    entranceMapper.addGameRegion(addRegionDTO);
                }
            }
        }
        //获取pid并通知游戏更新
        gameInfoService.notifyGameUpdate(editGameEntranceDTO.getPid());

        return rowsAffected;
    }

    @Override
    public void setGameEntrance(BatchSortDTO batchSortDTO) {
        List<Integer> sorts = batchSortDTO.getSorts();
        List<Long> eids = batchSortDTO.getEids();
        // 确保两个列表的大小相同
        if (sorts.size() != eids.size()) {
            throw new IllegalArgumentException("The size of 'sorts' and 'eids' must be the same.");
        }
        for (int i = 0; i < sorts.size(); i++) {
            int sort = sorts.get(i);
            long eid = eids.get(i);
            BatchSortDTO dto = new BatchSortDTO();  // 确保不会多次修改原始对象
            dto.setEid(eid);
            dto.setSort(sort);
            entranceMapper.batchSort(dto);
        }
    }

    @Override
    public Integer searchAddition(String addition) {
        return entranceMapper.searchAddition(addition);
    }

   /* @Override
    public Integer searchEname(String providerName,String ename) {

        String enameDash = ename.replace(" ", "-");
        String providerNameDash = providerName.replace(" ", "-");

        // 拼接请求数据并直接调用服务
        Optional<GameInfoDTO> gameInfoDTO = gameInfoService.getGameInfo(providerNameDash + "-" + enameDash);


        System.out.println("gameInfoDTO"+gameInfoDTO);
        // 如果存在游戏信息，则返回1；否则返回0
        return gameInfoDTO.isPresent() ? 1 : 0;
    }*/

    @Override
    public Integer searchEname(SearchEnameDTO searchEnameDTO) {

        try {
            Integer count = entranceMapper.searchEnameProvider(searchEnameDTO);
            // 如果存在游戏信息，则返回1；否则返回0
            return count;
        } catch (Exception e) {
            log.error(e.getMessage());
        }
        return 0;
    }


    @Override
    public List<Long> searchAllGameEid(String mainEntry) {

        List<Long> list = entranceMapper.searchAllGameEid(mainEntry);
        return list;
    }


    @Override
    @Transactional(rollbackFor = Exception.class)
    public int deleteGameEntrance(DeleteGameEntranceDTO deleteGameEntranceDTO) {
        if (deleteGameEntranceDTO == null || deleteGameEntranceDTO.getEid() == null) {
            throw new IllegalArgumentException("Game Entrance ID is required for deletion.");
        }

        Long eid = deleteGameEntranceDTO.getEid();
        Long pid = entranceMapper.getPidByEid(eid);

        int rowsAffectedOfGameEntrance = entranceMapper.deleteGameEntrance(deleteGameEntranceDTO);
        // 删除相关的区域信息
        DeleteRegionDTO deleteRegionDTO = new DeleteRegionDTO();
        deleteRegionDTO.setEid(eid);

        int rowsAffectedOfGameRegion = entranceMapper.deleteGameRegion(deleteRegionDTO);
        Integer count = entranceMapper.getRecommendByEid(eid);

        if (rowsAffectedOfGameEntrance > 0 && rowsAffectedOfGameRegion > 0) {
            if (count == null || count <= 0) {
                // 如果没有相关的推荐入口，直接返回
                gameInfoService.notifyGameUpdate(pid);
                return 1;
            } else {
                // 删除相关的推荐入口
                RecommendDTO recommendDTO = new RecommendDTO();
                recommendDTO.setEid(eid);
                int rowsAffectedOfRecommend = recommendGameMapper.deleteRecommend(recommendDTO);
                if (rowsAffectedOfRecommend > 0) {
                    gameInfoService.notifyGameUpdate(pid);
                    return 1;
                }
            }
        }
        return 0;
    }


}
