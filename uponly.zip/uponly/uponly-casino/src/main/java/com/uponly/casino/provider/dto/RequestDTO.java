package com.uponly.casino.provider.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.Map;

@Data
public class RequestDTO implements java.io.Serializable {
    public RequestDTO(String method, Map<String, Object> params, Map<String, Object> headers) {
        this.method = method;
        this.params = params;
        this.headers = headers;
    }

    @Schema(description = "method")
    String method;

    @Schema(description = "Post的body")
    Map<String, Object> body;

    @Schema(description = "Get的参数")
    Map<String, Object> params;

    @Schema(description = "header参数")
    Map<String, Object> headers;

}
