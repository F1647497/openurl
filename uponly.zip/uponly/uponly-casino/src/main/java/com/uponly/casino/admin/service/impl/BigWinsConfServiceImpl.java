package com.uponly.casino.admin.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import com.uponly.casino.admin.dto.BigWinsConfDTO;
import com.uponly.casino.admin.service.BigWinsConfService;
import com.uponly.casino.admin.vo.BigWinsConfVO;
import com.uponly.casino.common.constant.CommonConstant;
import com.uponly.casino.common.constant.TopicConstant;
import com.uponly.casino.common.enums.RegionCurrencyEnum;
import com.uponly.casino.interceptor.kafka.KafkaMessageHelper;
import com.uponly.casino.mapper.BigWinsConfMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Optional;


@Slf4j
@Service
public class BigWinsConfServiceImpl implements BigWinsConfService {

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    @Autowired
    private BigWinsConfMapper bigWinsConfMapper;


    @Override
    public PageInfo<BigWinsConfVO> page(BigWinsConfDTO dto) {
        return PageHelper.startPage(Optional.ofNullable(dto.getPage()).orElse(1), Optional.ofNullable(dto.getPageSize()).orElse(10))
                .setOrderBy("id asc")
                .doSelectPageInfo(() -> bigWinsConfMapper.list(dto));
    }

    @Override
    public int save(BigWinsConfVO entity) {
        entity.setCreator(entity.getCreator());
        entity.setUpdater(entity.getCreator());
        return bigWinsConfMapper.save(entity);
    }

    @Override
    public int edit(BigWinsConfVO entity) {
        entity.setUpdater(entity.getUpdater());
        entity.setUpdateTime(new Date());
        return bigWinsConfMapper.edit(entity);
    }

    @Override
    public void batchEdit(List<BigWinsConfVO> list) {
        list.forEach(entity -> {
            entity.setUpdater(entity.getUpdater());
            entity.setUpdateTime(new Date());
            bigWinsConfMapper.edit(entity);
        });
        for (RegionCurrencyEnum regionCurrencyEnum : RegionCurrencyEnum.getAllRecord()) {
            String channel = CommonConstant.CASINO_LIVE_WIN_REGION_FORMAT.formatted(regionCurrencyEnum.getLocationId());
            String msg = KafkaMessageHelper.toJsonString(CommonConstant.GAME_STATUS_NOTIFY, list, channel);
            kafkaTemplate.send(TopicConstant.CASINO_WS_TOPIC, msg);
        }
    }

    @Override
    public List<BigWinsConfVO> list(BigWinsConfDTO dto) {
        return bigWinsConfMapper.list(dto);
    }

    @Override
    public int delete(Long id) {
        return bigWinsConfMapper.delete(id);
    }


}




