package com.uponly.casino.admin.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class SearchGameDTO extends PageInfoDTO {
    @Schema(description = "供应商ID", nullable = true)
    private Long pid;

    @Schema(description = "游戏ID", nullable = true)
    private Long gameId;

    @Schema(description = "状态", nullable = true)
    private int status;

    @Schema(description = "标签", nullable = true)
    private String tag;

    @Schema(description = "推广", nullable = true)
    private Boolean promotion;

    @Schema(description = "游戏类型", nullable = true)
    private String gameType;

    @Schema(description = "三方游戏ID", nullable = true)
    private String pgameId;

    @Schema(description = "游戏名称", nullable = true)
    private String pgameName;

    @Schema(description = "地区", nullable = true)
    private int region;
}
