package com.uponly.casino.provider.service.impl;

import cn.hutool.db.AbstractDb;
import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpResponse;
import cn.hutool.json.JSONUtil;
import cn.hutool.json.XML;
import com.alibaba.fastjson2.JSON;
import com.alibaba.fastjson2.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.uponly.casino.admin.service.GameService;
import com.uponly.casino.admin.vo.*;
import com.uponly.casino.common.api.Result;
import com.uponly.casino.common.exception.BusinessException;
import com.uponly.casino.mapper.GameOriginalMapper;
import com.uponly.casino.mapper.OrderItemMapper;
import com.uponly.casino.provider.dto.GameInfoDTO;
import com.uponly.casino.provider.dto.RequestDTO;
import com.uponly.casino.provider.dto.sa.SaConfig;
import com.uponly.casino.provider.dto.sa.req.*;
import com.uponly.casino.provider.dto.sa.res.SaHostListResp;
import com.uponly.casino.provider.dto.sa.res.SaHostResp;
import com.uponly.casino.provider.dto.sa.res.SaResp;
import com.uponly.casino.provider.dto.toup.BalanceDTO;
import com.uponly.casino.provider.dto.toup.ChangeBalanceResponse;
import com.uponly.casino.provider.dto.toup.GetBalanceDTO;
import com.uponly.casino.provider.dto.toup.GetBalanceResponse;
import com.uponly.casino.provider.enums.EnumBodyType;
import com.uponly.casino.provider.enums.EnumToupAction;
import com.uponly.casino.provider.enums.EnumWalletOperatorType;
import com.uponly.casino.provider.enums.sa.SaGameType;
import com.uponly.casino.provider.service.ProviderManager;
import com.uponly.casino.provider.vo.UserInfoVO;
import com.uponly.casino.util.MyJSONUtil;
import com.uponly.casino.util.UidUtil;
import lombok.extern.slf4j.Slf4j;
import org.redisson.api.RBucket;
import org.redisson.api.RMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;
import org.springframework.util.CollectionUtils;

import javax.crypto.*;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
public class SaProviderImpl extends BaseProviderImpl {

    protected SaConfig saConfig;

    @Autowired
    ObjectMapper objectMapper;

    @Autowired
    OrderItemMapper orderItemMapper;

    @Autowired
    GameOriginalMapper gameOriginalMapper;

    //代表真钱账号
    public static final String ACTYPE_1 = "1";
    //代表试玩账号
    public static final String ACTYPE_0 = "0";

    public static final String param = "param";

    @Override
    public boolean initialize(ProviderVO providerVo) {
        super.initialize(providerVo);
        SaConfig saConfig = JSON.parseObject(providerVo.getConfig(), SaConfig.class);

        if (saConfig == null) {
            log.error("sa config is null");
            return false;
        }
        this.saConfig = saConfig;

        return true;
    }


    public EnumBodyType getBodyType() {
        return EnumBodyType.TEXT;
    }

    public boolean validate(String uid, String sid) {
        if (uid == null || sid == null) {
            log.error("ag userId or sid is null");
            return false;
        }
        var sessionKey = "casino_user_session_" + uid;
        RMap<String, String> map = redissonClient.getMap(sessionKey);
        String jsonValue = map.get("sessionids");
        try {
            JSONObject nested = JSONObject.parseObject(jsonValue);
            if (Objects.isNull(nested) || !nested.containsKey(sid)) {
                log.error("ag {} sid is invalid", sid);
                return false;
            }
        } catch (Exception e) {
            log.error("ag validate error: {}", e.getMessage());
            return false;
        }
        return true;
    }

    @Override
    public JSONObject check(RequestDTO param) {
        return null;
    }

    @Override
    public Result<?> getGameList() {
        return null;
    }

    @Override
    public void history(String orderStr, Integer status) {

    }

    @Override
    public void history(String orderStr) {

    }

    @Override
    public JSONObject balance(RequestDTO param) {
        return null;
    }

    public String getXMLStr(HashMap<String, Object> resMap) {
        // 构建 XML 字符串
        StringBuilder xmlBuilder = new StringBuilder();
        xmlBuilder.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
        xmlBuilder.append("<RequestResponse>");
        for (Map.Entry<String, Object> entry : resMap.entrySet()) {
            //动态拼接xml返回参数
            xmlBuilder.append(String.format("<%s>%s</%s>", entry.getKey(), entry.getValue(), entry.getKey()));
        }
        xmlBuilder.append("</RequestResponse>");

        // 输出 XML 字符串
        return xmlBuilder.toString();
    }

    /**
     * 获取SA供应商的桌台数据
     */
    public void GetActiveHostList() {
        //请求SA桌台接口名
        String method = "GetActiveHostList";
        //请求SA接口的当前时间
        String nowTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
        //密钥key
        String baseUrl = saConfig.getBaseUrl();
        String secretKey = saConfig.getSecretKey();
        String des = saConfig.getDES();
        String md5 = saConfig.getMD5();

        String param = String.format("method=%s&Key=%s&Time=%s",
                method,
                secretKey,
                nowTime);

        //加密后的密文 和 md5
        String q = DESencrypt(param, des);
        String s = buildMD5(param, md5, nowTime, secretKey);
        log.info("sa 请求url:{},请求参数:{},加密参数:q={},s={}", baseUrl, param, q, s);
        HttpResponse execute = HttpRequest.post(baseUrl).form("q", q).form("s", s).execute();

        log.info("sa 请求的结果：{}", execute.body());
        int httpStatus = execute.getStatus();
        if (httpStatus != 200) {
            log.error("sa 请求失败！httpStatus={},body={}", httpStatus, execute.body());
            throw new BusinessException("Failed to get ag game URL, HTTP status: " + httpStatus);
        }
        //将SA返回的xml文件转换成Json
        cn.hutool.json.JSONObject xmlJson = XML.toJSONObject(execute.body());

        cn.hutool.json.JSONObject resJson = xmlJson.getJSONObject("GetActiveHostListResponse");
        if (resJson == null) {
            log.error("sa 获取桌台数据失败！httpStatus={},body={}", httpStatus, execute.body());
            throw new BusinessException("Failed to get ag game URL, HTTP status: " + httpStatus);
        }

        String respStr = JSON.toJSONString(resJson);
        log.info("调用SA登录接口，返回数据:{}", respStr);
        SaHostListResp saHostListResp = JSON.parseObject(respStr, SaHostListResp.class);
        log.info("SA返回数据转换对象：{}", saHostListResp.toString());
        if (saHostListResp.getErrorMsgId() != 0) {
            log.error("sa 桌台接口状态码异常！info={}", saHostListResp);
            throw new BusinessException(1201, saHostListResp.getErrorMsg());
        }

        List<SaHostResp> hostList = saHostListResp.getHostList();

        List<String> hostIdList = hostList.stream().map(SaHostResp::getHostID).collect(Collectors.toList());
        //将Sa的桌台集合转换成map
        Map<String, SaHostResp> hostMap = hostList.stream().collect(Collectors.toMap(SaHostResp::getHostID, item -> item, (value1, value2) -> value1));

        //通过桌台编号查询桌台
        List<GameOriginalVO> tableList = gameOriginalMapper.selectListByTableId(hostIdList);

        if (CollectionUtils.isEmpty(tableList)) {
            //如果查询桌台为空，那就需要插入桌台数据
            tableList = new ArrayList<>();
            for (SaHostResp host : hostList) {
                GameOriginalVO originalVO = new GameOriginalVO();
                originalVO.setTableId(host.getHostID());
                originalVO.setGameName(host.getGameType());
                originalVO.setTableName(host.getHostName());
                //当桌台在后台关闭，或者桌台已关的话，都要关闭当前桌台
                originalVO.setOpen(
                        Boolean.FALSE.equals(Boolean.parseBoolean(host.getEnabled()))
                                || Integer.parseInt(host.getGameStatus()) == 1 ? 0 : 1
                );
                tableList.add(originalVO);
            }
            gameOriginalMapper.addGameList(tableList);
        } else {
            //如果桌台集合不为null，则通过sa桌台比对，更新桌台状态
            for (GameOriginalVO vo : tableList) {
                SaHostResp host = hostMap.get(vo.getTableId());
                if (!Objects.isNull(host)) {
                    //当桌台在后台关闭，或者桌台已关的话，都要关闭当前桌台
                    vo.setOpen(Boolean.FALSE.equals(Boolean.parseBoolean(host.getEnabled()))
                            || Integer.parseInt(host.getGameStatus()) == 1 ? 0 : 1);
                }
            }
            gameOriginalMapper.updateGameBatch(tableList);
        }
    }

    /**
     * 下注扣款
     *
     * @param placeBetParam 密文str
     */
    @Transactional(rollbackFor = Exception.class)
    public Object PlaceBet(RequestDTO placeBetParam) throws JsonProcessingException {
        //封装返回xml对象
        HashMap<String, Object> resMap = new HashMap<>();
        //将密文解密成明文，并且转换成json
        String desCbc;
        String ciphertext = String.valueOf(placeBetParam.getBody().get(param));
        try {
            desCbc = desCbc(ciphertext, saConfig.getDES());
        } catch (Exception e) {
            log.error("【placeBet】密文解密失败,密文={}", ciphertext);
            resMap.put("error", 1006);
            return getXMLStr(resMap);
        }
        JSONObject placeBetJson = paramToJson(desCbc);
        PlaceBetReq placeBetReq = JSONUtil.toBean(placeBetJson.toJSONString(), PlaceBetReq.class);

        //打印请求参数
        log.info("sa placeBet param={}", placeBetJson.toJSONString());

        var userInfo = userInfoService.getUserByName(placeBetReq.getUsername());
        if (userInfo.isEmpty()) {
            log.error("【placeBet】获取用户信息失败,userName={}", placeBetReq.getUsername());
            resMap.put("error", 1000);
            return getXMLStr(resMap);
        }
        Long userId = userInfo.get().getUserId();
        BigDecimal balance = getBalance(userId).get().getBalance();

        Optional<GetBalanceResponse> balanceRes = getBalance(userId);

        if (placeBetReq.getAmount().compareTo(balanceRes.get().getBalance()) > 0) {
            resMap.put("amount", balance.setScale(2, RoundingMode.HALF_UP));
            resMap.put("error", 1004);
            return getXMLStr(resMap);
        }

        //封装钱包对象
        BalanceDTO changeBalance = new BalanceDTO();
        changeBalance.setSessionId(placeBetReq.getTxnid());
        changeBalance.setProviderId(providerVO.getPid());
        changeBalance.setGameId(placeBetReq.getGameid());

        String gameType = placeBetReq.getGametype();
        if (gameType != null) {
            String gameName;
            SaGameType saGameType = SaGameType.getEnum(gameType);
            if (saGameType == null) {
                log.error("【placeBet】 getGameName gameType is null param={}", gameType);
                resMap.put("error", 1005);
                return getXMLStr(resMap);
            } else {
                gameName = saGameType.getDes();
            }
            changeBalance.setGameName(gameName);
        }
        changeBalance.setTransactionId(placeBetReq.getTxnid());
        BigDecimal amount = placeBetReq.getAmount();
        // 把 amount转换成负数
        changeBalance.setAmount(amount.abs());
        changeBalance.setUserId(userId);
        changeBalance.setOperatorType(EnumWalletOperatorType.CasinoBetFreeze.getValue());
        changeBalance.setRemark(placeBetReq.getBetdetails());

        //正常下注行為 新增注單
        changeBalance.setOrderNo(UidUtil.getOrderNo(userId.toString()));

        //创建bodyJson
        placeBetParam.setBody(
                objectMapper.readValue(setBodyJson(
                        changeBalance.getTransactionId(), placeBetReq.getAmount(),
                        userId.toString(), placeBetReq.getCurrency(),
                        placeBetReq.getGameid(), placeBetReq.getGametype(), placeBetReq.getHostid().toString()), Map.class)
        );

        Optional<ChangeBalanceResponse> changeResponse = newOrder(changeBalance, placeBetParam);
        if (changeResponse.isEmpty()) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            log.error("sa 【placeBet】changeResponse is null");
            resMap.put("error", 9999);
            return getXMLStr(resMap);
        }
        resMap.put("username", userInfo.get().getUserName());
        resMap.put("currency", placeBetReq.getCurrency());
        //保留两位小数
        resMap.put("amount", changeResponse.get().getBalance().setScale(2, RoundingMode.HALF_UP));
        resMap.put("error", 0);
        return getXMLStr(resMap);
    }

    /**
     * 投注完结并赢取金额，进行派彩
     *
     * @param playWinParam 注单赢取请求
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public Object PlayerWin(RequestDTO playWinParam) throws JsonProcessingException {
        //封装返回xml对象
        HashMap<String, Object> resMap = new HashMap<>();
        //将密文解密成明文，并且转换成json
        String desCbc;
        String ciphertext = String.valueOf(playWinParam.getBody().get(param));
        try {
            desCbc = desCbc(ciphertext, saConfig.getDES());
        } catch (Exception e) {
            log.error("【playerWin】密文解密失败,密文={}", ciphertext);
            resMap.put("error", 1006);
            return getXMLStr(resMap);
        }
        JSONObject paramJson = paramToJson(desCbc);
        PlaceWinReq placeWinReq = JSONUtil.toBean(paramJson.toJSONString(), PlaceWinReq.class);
        //打印请求参数
        log.info("sa playerWin param={}", paramJson.toJSONString());

        //将注单输赢详情通过jsonArray转换出来
        List<PayoutDetails> payoutDetails = paramJson
                .getJSONObject("payoutdetails")
                .getJSONArray("betlist")
                .toJavaList(PayoutDetails.class);

        //根据详情里的流水号分组
        Map<String, List<PayoutDetails>> orderGroupMap = payoutDetails.stream().collect(Collectors.groupingBy(PayoutDetails::getTxnid));

        //通过用户名获取用户信息
        var userInfo = userInfoService.getUserByName(placeWinReq.getUsername());
        if (userInfo.isEmpty()) {
            log.error("【playerWin】获取用户信息失败,userName={}", placeWinReq.getUsername());
            resMap.put("error", 1000);
            return getXMLStr(resMap);
        }
        Long userId = userInfo.get().getUserId();

        String gameName = null;
        //通过枚举获取游戏名
        if (placeWinReq.getGametype() != null) {
            SaGameType saGameType = SaGameType.getEnum(placeWinReq.getGametype());
            if (saGameType == null) {
                log.error("【placeBet】 getGameName gameType is null param={}", placeWinReq.getGametype());
                resMap.put("error", 1005);
                return getXMLStr(resMap);
            } else {
                gameName = saGameType.getDes();
            }
        }

        //计数器
        int lastIndex = orderGroupMap.size() - 1;
        int index = 0;
        boolean flag = Boolean.FALSE;

        var changeResponse = Optional.of(new ChangeBalanceResponse());
        for (Map.Entry<String, List<PayoutDetails>> entry : orderGroupMap.entrySet()) {
            if (index == lastIndex) {
                flag = true;
            }
            //第三方唯一流水号
            String txnid = entry.getKey();
            List<PayoutDetails> orderList = entry.getValue();

            //派彩金额
            BigDecimal payoutAmount = orderList.stream()
                    .map(item -> item.getBetamount().add(item.getResultamount()))
                    .reduce(BigDecimal.ZERO, BigDecimal::add);

            //下注本金
            BigDecimal betAmount = orderList.stream().map(PayoutDetails::getBetamount).reduce(BigDecimal.ZERO, BigDecimal::add);
            //有效流水
            BigDecimal rollingSum = orderList.stream().map(PayoutDetails::getRolling).reduce(BigDecimal.ZERO, BigDecimal::add);

            //封装钱包对象
            BalanceDTO changeBalance = new BalanceDTO();
            changeBalance.setTransactionId(placeWinReq.getTxnid());
            changeBalance.setSessionId(placeWinReq.getTxnid());
            changeBalance.setGameId(placeWinReq.getGametype());
            changeBalance.setProviderId(providerVO.getPid());
            changeBalance.setGameName(gameName);
            changeBalance.setAmount(payoutAmount);
            changeBalance.setUserId(userId);

            // 从redis中获取存入的Order
            String orderKey = ORDER_KEY_REF + txnid;
            RBucket<String> bucket = redissonClient.getBucket(orderKey);
            OrderVO order;
            OrderHistoryVO orderHistory;
            var orderData = (String) bucket.get();
            if (orderData == null) {
                // 根据orderKey没有找到对应的order, 从数据库中查找
                order = orderMapper.selectByUserIdAndRoundIdAndThirdOrderNo(
                        userId, placeWinReq.getGameid(), txnid
                );
                if (order == null) {
                    //多注合併後 還需去歷史紀錄找
                    orderHistory = orderMapper.selectHistoryByUserIdAndSessionId(changeBalance.getUserId(), txnid, EnumWalletOperatorType.CasinoBetFreeze.getValue());
                    if (orderHistory == null) {
                        log.error("sa 【placeWin】 order is null, cannot find order by userId={}, pid={}, roundId={} txnid={}", userId, placeWinReq.getGametype(), placeWinReq.getGameid(), txnid);
                        resMap.put("error", 1005);
                        return getXMLStr(resMap);
                    } else {
                        if (!orderHistory.getSessionId().equals(txnid)) {
                            resMap.put("error", 1005);
                            return getXMLStr(resMap);
                        }

                        order = new OrderVO();
                        order.setThirdOrderNo(placeWinReq.getTxnid());
                        order.setOrderNo(orderHistory.getOrderNo());
                        order.setStatus(OrderVO.EnumOrderStatus.BET.getCode());
                        order.setAmount(orderHistory.getAmount());

                        order.setUserId(changeBalance.getUserId());
                        order.setUserName(userInfo.get().getUserName());
                        order.setCurrency(placeWinReq.getCurrency());
                        order.setRegion(userInfo.get().getLocation());
                        order.setPid(changeBalance.getProviderId());

                        order.setMsgState(OrderVO.EnumMsgState.NONE.getCode());
                        order.setSessionId(changeBalance.getSessionId());
                        order.setRoundId(changeBalance.getGameId());
                        order.setGameName(changeBalance.getGameName());
                        order.setCreatedAt(new Date());
                        order.setBody(setBodyJson(
                                order.getThirdOrderNo(), order.getAmount(),
                                order.getUserId().toString(), order.getCurrency(),
                                placeWinReq.getGameid(), placeWinReq.getGametype(),
                                placeWinReq.getHostid().toString())
                        );
                    }
                }
            } else {
                log.info("SA 【placeWin】 redis orderData={}", orderData);
                order = JSON.parseObject(orderData, OrderVO.class);
                bucket.expire(expiration);
            }

            //确认状态是否派彩过 or 取消过
            if (order.getStatus().equals(OrderVO.EnumOrderStatus.PAYOUT.getCode()) || order.getStatus().equals(OrderVO.EnumOrderStatus.CANCEL.getCode())) {
                log.info("SA 【placeWin】 order payout repeat orderId={}", order.getId());
                resMap.put("error", 1005);
                return getXMLStr(resMap);
            }

            //检查注单gameId和流水号是否一致
            if (!order.getRoundId().equals(placeWinReq.getGameid()) && !order.getThirdOrderNo().equals(txnid)) {
                log.info("SA 【placeWin】 The bet does not exist orderId={}", order.getId());
                resMap.put("error", 1005);
                return getXMLStr(resMap);
            }

            changeBalance.setOrderNo(order.getOrderNo());
            changeBalance.setOperatorType(EnumWalletOperatorType.CasinoPayout.getValue());
            changeBalance.setRemark(JSONUtil.toJsonStr(orderList));
            playWinParam.setBody(objectMapper.readValue(order.getBody(), Map.class));
            //新增注单历史记录
            newHistory(changeBalance, playWinParam);
            //判断是否为最后一次派彩
            if (!flag) {
                changeBalance.setIsFinish(Boolean.FALSE);
            }
            //调用钱包派彩
            changeResponse = changeBalance(changeBalance);
            if (changeResponse.isEmpty()) {
                log.error("sa 【playerWin】  changeResponse is empty");
                resMap.put("error", 1005);
                return getXMLStr(resMap);
            }

            if (changeResponse.get().getMgs() != null) {
                //重複訂單
                if (changeResponse.get().getMgs().equals(170) || changeResponse.get().getMgs().equals(100)) {
                    resMap.put("error", 0);
                    return getXMLStr(resMap);
                }
                resMap.put("error", 1004);
                return getXMLStr(resMap);
            }


            // 更新order状态
            order.setPayout(payoutAmount);
            if (payoutAmount.compareTo(BigDecimal.ZERO) > 0) {
                var usdAmount = rollingRankingService.getRate(order.getCurrency());
                BigDecimal bigDecimal = usdAmount.get();
                order.setUsdPayout(bigDecimal.multiply(payoutAmount));
            }

            order.setStatus(OrderVO.EnumOrderStatus.PAYOUT.getCode());
            order.setSettleAt(new Date());
            order.setPid(providerVO.getPid());
            order.setGameType(placeWinReq.getGametype());
            if (payoutAmount.compareTo(BigDecimal.ZERO) > 0) {
                //赔率保留两位小数
                RoundingMode halfUp = RoundingMode.HALF_UP;
                order.setMultiplier(payoutAmount.divide(betAmount, halfUp));
            } else {
                order.setMultiplier(BigDecimal.ZERO);
            }
            //有效流水
            order.setEffectiveAmount(rollingSum);
            //换算成usd后的派彩金额
            if (placeWinReq.getAmount().compareTo(BigDecimal.ZERO) > 0) {
                var usdAmount = rollingRankingService.getRate(order.getCurrency());
                BigDecimal bigDecimal = usdAmount.get();
                order.setUsdPayout(bigDecimal.multiply(placeWinReq.getAmount()));
            }
            //将详情数据插入到order子表中
            saveOrderItem(changeBalance, orderList, order.getCurrency(), order.getId());
            if (orderMapper.updatePayout(order) == 0) {
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                log.error("sa 【playerWin】 updatePayout failed");
                resMap.put("error", 9999);
                return getXMLStr(resMap);
            }
            order.setBody(null);

            savePayoutRedis(order);
            saveAmountRedis(order);

            // 更新排行榜
            rollingRankingService.processBettingData(order);

            String orderJson = JSONObject.toJSONString(order);
            bucket.set(orderJson, expiration);
            index++;
        }

        resMap.put("username", userInfo.get().getUserName());
        resMap.put("currency", placeWinReq.getCurrency());
        //保留两位小数
        resMap.put("amount", changeResponse.get().getBalance().setScale(2, RoundingMode.HALF_UP));
        resMap.put("error", 0);
        return getXMLStr(resMap);
    }

    /**
     * 投注完结及派彩，
     *
     * @param playerLostParam 结算完成的参数请求
     * @return 响应结果
     */
    public Object PlayerLost(RequestDTO playerLostParam) throws JsonProcessingException {
        //封装返回xml对象
        HashMap<String, Object> resMap = new HashMap<>();
        //将密文解密成明文，并且转换成json
        String desCbc;
        Map<String, Object> body = playerLostParam.getBody();
        String ciphertext = String.valueOf(body.get(param));
        try {
            desCbc = desCbc(ciphertext, saConfig.getDES());
        } catch (Exception e) {
            log.error("【playerLostParam】密文解密失败,密文={}", ciphertext);
            resMap.put("error", 1006);
            return getXMLStr(resMap);
        }
        JSONObject paramJson = paramToJson(desCbc);
        PlaceLostReq placeLostReq = JSONUtil.toBean(paramJson.toJSONString(), PlaceLostReq.class);

        //打印请求参数
        log.info("sa playerLost param={}", paramJson.toJSONString());

        //将注单输赢详情通过jsonArray转换出来
        List<PayoutDetails> payoutDetails = paramJson
                .getJSONObject("payoutdetails")
                .getJSONArray("betlist")
                .toJavaList(PayoutDetails.class);

        String gameName = null;
        //通过枚举获取游戏名
        if (placeLostReq.getGametype() != null) {
            SaGameType saGameType = SaGameType.getEnum(placeLostReq.getGametype());
            if (saGameType == null) {
                log.error("【placeBet】 getGameName gameType is null param={}", placeLostReq.getGametype());
                resMap.put("error", 1005);
                return getXMLStr(resMap);
            } else {
                gameName = saGameType.getDes();
            }
        }

        var userInfo = userInfoService.getUserByName(placeLostReq.getUsername());
        if (userInfo.isEmpty()) {
            log.error("【playerLostParam】获取用户信息失败,userName={}", placeLostReq.getUsername());
            resMap.put("error", 1000);
            return getXMLStr(resMap);
        }
        Long userId = userInfo.get().getUserId();

        //根据详情里的流水号分组
        Map<String, List<PayoutDetails>> orderGroupMap = payoutDetails.stream().collect(Collectors.groupingBy(PayoutDetails::getTxnid));
        var changeResponse = Optional.of(new ChangeBalanceResponse());
        //计数器
        int lastIndex = orderGroupMap.size() - 1;
        int index = 0;
        boolean flag = Boolean.FALSE;

        for (Map.Entry<String, List<PayoutDetails>> entry : orderGroupMap.entrySet()) {
            if (index == lastIndex) {
                flag = true;
            }

            //第三方唯一流水号
            String txnid = entry.getKey();
            List<PayoutDetails> orderList = entry.getValue();

            //派彩金额
            BigDecimal payoutAmount = orderList.stream()
                    .map(item -> item.getBetamount().add(item.getResultamount()))
                    .reduce(BigDecimal.ZERO, BigDecimal::add);

            //下注金额
            BigDecimal betAmount = orderList.stream().map(PayoutDetails::getBetamount).reduce(BigDecimal.ZERO, BigDecimal::add);

            //有效流水
            BigDecimal rollingSum = orderList.stream().map(PayoutDetails::getRolling).reduce(BigDecimal.ZERO, BigDecimal::add);

            // 从redis中获取存入的Order
            String orderKey = ORDER_KEY_REF + txnid;
            RBucket<String> bucket = redissonClient.getBucket(orderKey);
            OrderVO order;
            OrderHistoryVO orderHistory;
            var orderData = (String) bucket.get();
            if (orderData == null) {
                // 根据orderKey没有找到对应的order, 从数据库中查找
                order = orderMapper.selectByUserIdAndRoundIdAndThirdOrderNo(
                        userId, placeLostReq.getGameid(), txnid
                );
                if (order == null) {
                    //多注合併後 還需去歷史紀錄找
                    orderHistory = orderMapper.selectHistoryByUserIdAndSessionId(userId, txnid, EnumWalletOperatorType.CasinoBetFreeze.getValue());
                    if (orderHistory == null) {
                        log.error("sa 【playerLostParam】 order is null, cannot find order by userId={}, pid={}, roundId={}", userId, providerVO.getPid(), placeLostReq.getGameid());
                        resMap.put("error", 1005);
                        return getXMLStr(resMap);
                    } else {
                        if (!orderHistory.getSessionId().equals(txnid)) {
                            resMap.put("error", 1005);
                            return getXMLStr(resMap);
                        }

                        order = new OrderVO();
                        order.setThirdOrderNo(txnid);
                        order.setOrderNo(orderHistory.getOrderNo());
                        order.setStatus(OrderVO.EnumOrderStatus.BET.getCode());
                        order.setAmount(orderHistory.getAmount());

                        order.setUserId(userId);
                        order.setUserName(userInfo.get().getUserName());
                        order.setCurrency(userInfo.get().getCurrency());
                        order.setRegion(userInfo.get().getLocation());
                        order.setPid(providerVO.getPid());

                        order.setMsgState(OrderVO.EnumMsgState.NONE.getCode());
                        order.setSessionId(placeLostReq.getTxnid());
                        order.setRoundId(placeLostReq.getGameid());
                        order.setGameName(gameName);
                        order.setCreatedAt(new Date());
                        order.setBody(setBodyJson(
                                order.getThirdOrderNo(), order.getAmount(),
                                order.getUserId().toString(), order.getCurrency(),
                                placeLostReq.getGameid(), placeLostReq.getGametype(),
                                placeLostReq.getHostid().toString())
                        );
                    }
                }
            } else {
                log.info("SA 【placeLost】 redis orderData={}", orderData);
                order = JSON.parseObject(orderData, OrderVO.class);
                bucket.expire(expiration);
            }

            //确认状态是否已派彩or 取消
            if (order.getStatus().equals(OrderVO.EnumOrderStatus.PAYOUT.getCode()) || order.getStatus().equals(OrderVO.EnumOrderStatus.CANCEL.getCode())) {
                log.info("SA 【placeLost】 order payout repeat orderId={}", order.getId());
                resMap.put("error", 1005);
                return getXMLStr(resMap);
            }

            //檢查注單refId是否對的上
            if (!order.getRoundId().equals(placeLostReq.getGameid()) && !order.getThirdOrderNo().equals(txnid)) {
                log.info("SA 【placeLost】 The bet does not exist orderId={}", order.getId());
                resMap.put("error", 1005);
                return getXMLStr(resMap);
            }

            playerLostParam.setBody(objectMapper.readValue(order.getBody(), Map.class));

            //创建对象,保存注单历史记录
            var changeBalance = new BalanceDTO();
            changeBalance.setUserId(userId);
            changeBalance.setTransactionId(placeLostReq.getTxnid());
            changeBalance.setGameId(placeLostReq.getGameid());
            changeBalance.setGameName(gameName);
            changeBalance.setOrderNo(order.getOrderNo());
            changeBalance.setAmount(BigDecimal.ZERO);
            changeBalance.setOperatorType(EnumWalletOperatorType.CasinoPayout.getValue());
            changeBalance.setRemark(JSONUtil.toJsonStr(orderList));

            //新增注单记录记录
            newHistory(changeBalance, playerLostParam);

            //判断是否为最后一次派彩
            if (!flag) {
                changeBalance.setIsFinish(Boolean.FALSE);
            }

            changeResponse = changeBalance(changeBalance);
            if (changeResponse.isEmpty()) {
                log.error("sa 【playerWin】  changeResponse is empty");
                resMap.put("error", 1005);
                return getXMLStr(resMap);
            }

            if (changeResponse.get().getMgs() != null) {
                //重複訂單
                if (changeResponse.get().getMgs().equals(170) || changeResponse.get().getMgs().equals(100)) {
                    resMap.put("error", 0);
                    return getXMLStr(resMap);
                }
                resMap.put("error", 1004);
                return getXMLStr(resMap);
            }

            order.setStatus(OrderVO.EnumOrderStatus.PAYOUT.getCode());
            order.setSettleAt(new Date());
            order.setPid(providerVO.getPid());
            order.setGameType(placeLostReq.getGametype());
            //将详情数据添加到注单子表中
            saveOrderItem(changeBalance, orderList, order.getCurrency(), order.getId());
            if (payoutAmount.compareTo(BigDecimal.ZERO) > 0) {
                //赔率保留两位小数
                RoundingMode halfUp = RoundingMode.HALF_UP;
                order.setMultiplier(payoutAmount.divide(betAmount, halfUp));
            } else {
                order.setMultiplier(BigDecimal.ZERO);
            }
            //有效流水
            order.setEffectiveAmount(rollingSum);
            //用户输了的话，就是0
            order.setUsdPayout(payoutAmount);
            if (orderMapper.updatePayout(order) == 0) {
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                log.error("sa 【playerLost】 param updatePayout failed");
                resMap.put("error", 1005);
                return getXMLStr(resMap);
            }

            // 更新排行榜
            rollingRankingService.processBettingData(order);

            String orderJson = JSONObject.toJSONString(order);
            bucket.set(orderJson, expiration);
            index++;
        }

        resMap.put("username", userInfo.get().getUserName());
        resMap.put("currency", placeLostReq.getCurrency());
        resMap.put("amount", getBalance(userId).get().getBalance().setScale(2, RoundingMode.HALF_UP));
        resMap.put("error", 0);
        return getXMLStr(resMap);

    }

    /**
     * 根据用户名和币种，查询用户最新余额
     *
     * @param balanceReqParam 查询用户余额的密文参数
     * @return 用户最新余额
     */
    public String GetUserBalance(RequestDTO balanceReqParam) {
        //封装返回xml对象
        HashMap<String, Object> resMap = new HashMap<>();
        //将密文解密成明文，并且转换成json
        String ciphertext = String.valueOf(balanceReqParam.getBody().get(param));
        String desCbc;
        try {
            desCbc = desCbc(ciphertext, saConfig.getDES());
        } catch (Exception e) {
            log.error("【getUserBalance】密文解密失败,密文={}", ciphertext);
            resMap.put("error", 1006);
            return getXMLStr(resMap);
        }

        JSONObject paramJson = paramToJson(desCbc);
        GetUserBalanceReq balanceReq = JSONUtil.toBean(paramJson.toJSONString(), GetUserBalanceReq.class);

        //打印请求参数
        log.info("sa getUserBalance param={}", paramJson.toJSONString());

        //通过用户名获取用户信息
        String userName = balanceReq.getUsername();
        var userInfo = userInfoService.getUserByName(userName);
        if (userInfo.isEmpty()) {
            log.error("【getUserBalance】获取用户信息失败,userName={}", userName);
            resMap.put("error", 1000);
            return getXMLStr(resMap);
        }
        //获取当前用户余额
        try {
            var getBalanceDTO = new GetBalanceDTO(userInfo.get());
            var request = MyJSONUtil.packageJson(getBalanceDTO.toJSONObject(), EnumToupAction.GET_BALANCE.getAction());
            var jsonStr = walletService.send(request);
            var jonResponse = MyJSONUtil.analysis2Data(jsonStr);
            log.info("【balance】获取当前用户余额={}", jonResponse);
            if (jonResponse == null) {
                log.error("【balance】获取当前用户余额失败,参数={}", getBalanceDTO);
                resMap.put("error", 1002);
                return getXMLStr(resMap);
            }


            resMap.put("username", userName);
            resMap.put("currency", balanceReq.getCurrency());
            //保留两位小数
            resMap.put("amount", new BigDecimal(jonResponse.getString("balance"))
                    .setScale(2, RoundingMode.HALF_UP));
            resMap.put("error", 0);
            return getXMLStr(resMap);
        } catch (Exception e) {
            log.error("【balance】获取当前用户余额失败,userName={},异常={}", userName, e.getMessage(), e);
        }
        resMap.put("error", 9999);
        return getXMLStr(resMap);
    }


    /**
     * 注单取消并退还注单金额
     * 当发出了placeBet请求，但需要取消注单时,调用取消注单请求
     *
     * @param cancelParam 取消注单密文
     * @return 取消响应xml
     */
    @Transactional(rollbackFor = Exception.class)
    public Object PlaceBetCancel(RequestDTO cancelParam) throws JsonProcessingException {
        //封装返回xml对象
        HashMap<String, Object> resMap = new HashMap<>();
        //将密文解密成明文，并且转换成json
        String desCbc;
        String ciphertext = String.valueOf(cancelParam.getBody().get(param));
        try {
            desCbc = desCbc(ciphertext, saConfig.getDES());
        } catch (Exception e) {
            log.error("【placeBetCancel】密文解密失败,密文={}", ciphertext);
            resMap.put("error", 1006);
            return getXMLStr(resMap);
        }
        String paramJson = paramToJson(desCbc).toJSONString();
        PlaceBetCancelReq req = JSONUtil.toBean(paramJson, PlaceBetCancelReq.class);

        //打印请求参数
        log.info("sa PlaceBetCancel param={}", paramJson);

        var userInfo = userInfoService.getUserByName(req.getUsername());
        if (userInfo.isEmpty()) {
            log.error("【placeBetCancel】获取用户信息失败,userName={}", req.getUsername());
            resMap.put("error", 1000);
            return getXMLStr(resMap);
        }
        var changeBalance = new BalanceDTO();
        Long userId = userInfo.get().getUserId();
        changeBalance.setUserId(userId);
        changeBalance.setTransactionId(req.getTxnid());
        changeBalance.setGameId(req.getGameid());
        //判断gameType是否存在
        if (req.getGametype() != null) {
            String gameName;
            SaGameType saGameType = SaGameType.getEnum(req.getGametype());
            if (saGameType == null) {
                log.error("【placeBetCancel】 getGameName gameType is null param={}", req.getGametype());
                resMap.put("error", 1005);
                return getXMLStr(resMap);
            } else {
                gameName = saGameType.getDes();
            }
            changeBalance.setGameName(gameName);
        }
        // 从redis中获取存入的Order
        String orderKey = ORDER_KEY_REF + req.getTxnid();
        RBucket<String> bucket = redissonClient.getBucket(orderKey);
        OrderVO order;
        OrderHistoryVO orderHistoryVO;
        var orderData = (String) bucket.get();
        if (orderData == null) {
            // 根据orderKey没有找到对应的order, 从数据库中查找
            order = orderMapper.selectByUserIdAndSessionId(userId, req.getTxnid());
            if (order == null) {
                // 都找不到還要再去 歷史紀錄裡找
                orderHistoryVO = orderMapper.selectHistoryByUserIdAndSessionId(userId, req.getTxnid(), EnumWalletOperatorType.CasinoBetFreeze.getValue());
                if (orderHistoryVO == null) {
                    log.error("sa 【placeBetCancel】order is null, cannot find order by userId={}, roundId={}", userId, req.getTxnid());
                    resMap.put("error", 1005);
                    log.info("sa 【placeBetCancel】 特殊情境 : key {}", ORDER_KEY_CANCEL + req.getGameid());
                    RBucket<String> cancelBucket = redissonClient.getBucket(ORDER_KEY_CANCEL + req.getGameid());
                    cancelBucket.set(req.getGameid(), expiration);
                    return getXMLStr(resMap);
                } else {
                    order = new OrderVO();
                    order.setOrderNo(orderHistoryVO.getOrderNo());
                    order.setStatus(OrderVO.EnumOrderStatus.BET.getCode());
                }
            }
        } else {
            order = JSON.parseObject(orderData, OrderVO.class);
            bucket.expire(expiration);
        }
        //確認狀態是否已經取消過
        if (order.getStatus().equals(OrderVO.EnumOrderStatus.CANCEL.getCode()) || order.getStatus().equals(OrderVO.EnumOrderStatus.PAYOUT.getCode())) {
            log.info("SA 【placeBetCancel】 order cancel repeat orderId={}", order.getId());
            resMap.put("error", 1005);
            return getXMLStr(resMap);
        }

        changeBalance.setOrderNo(order.getOrderNo());
        BigDecimal amount = req.getAmount();
        changeBalance.setAmount(amount);
        changeBalance.setOperatorType(EnumWalletOperatorType.CasinoBetRefund.getValue());
        changeBalance.setRemark(req.getGamecancel() == 0 ? "因荷官操作问题需要取消" : "其他原因");

        cancelParam.setBody(objectMapper.readValue(order.getBody(), Map.class));
        //新增注单历史记录
        newHistory(changeBalance, cancelParam);

        var changeResponse = changeBalance(changeBalance);
        if (changeResponse.isEmpty()) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            log.error("sa 【placeBetCancel】cancel changeResponse is null");
            resMap.put("error", 1005);
            return getXMLStr(resMap);
        }

        if (changeResponse.get().getMgs() != null) {
            //重複訂單
            if (changeResponse.get().getMgs().equals(170)) {
                resMap.put("error", 0);
                return getXMLStr(resMap);
            }
            resMap.put("error", 1005);
            return getXMLStr(resMap);
        }

        order.setThirdOrderNo(changeBalance.getTransactionId());
        order.setUserId(userId);
        order.setPid(providerVO.getPid());
        order.setSessionId(changeBalance.getSessionId());
        order.setRoundId(changeBalance.getGameId());
        order.setGameName(changeBalance.getGameName());
        // 更新cancel状态
        order.setPayout(BigDecimal.ZERO);
        order.setStatus(OrderVO.EnumOrderStatus.CANCEL.getCode());
        order.setSettleAt(new Date());
        if (orderMapper.updatePayout(order) == 0) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            log.error("SA 【placeBetCancel】cancel updatePayout failed");
            resMap.put("error", 9999);
            return getXMLStr(resMap);
        }
        //将json存储到redis中
        String orderJson = JSONObject.toJSONString(order);
        bucket.set(orderJson, expiration);

        BigDecimal balance = changeResponse.get().getBalance();
        resMap.put("username", userId);
        resMap.put("currency", order.getCurrency());
        //保留两位小数
        resMap.put("amount", balance.setScale(2, RoundingMode.HALF_UP));
        resMap.put("error", 0);
        return getXMLStr(resMap);
    }

    /**
     * 游戏入口
     *
     * @param body
     * @return
     */
    public Result<?> getLaunchURI(Map<String, Object> body) {
        // 游戏ID, 桌子ID, 用户ID, 语言, 用户ID
        String userId = (String) body.get("uid");
        String language = (String) body.get("language");
        GameInfoDTO gameInfo = (GameInfoDTO) body.get("gameInfo");
        String playMode = (String) body.get("playMode");
        String backUrl = (String) body.get("backUrl");

        Long uid = Long.valueOf(userId);
        Optional<UserInfoVO> user = userInfoService.getUser(uid);
        if (user.isEmpty()) {
            return Result.fail(1201, "user is null");
        }
        UserInfoVO userInfoVO = user.get();

        //调用sa登录接口
        cn.hutool.json.JSONObject resp = loginRequest(playMode, userInfoVO.getCurrency(), userInfoVO.getUserName());
        if (resp == null) {
            throw new BusinessException(1201, "SA登录帐号失败");
        }

        String respJson = JSON.toJSONString(resp);
        log.info("调用SA登录接口，返回数据:{}", respJson);
        SaResp saResp = JSON.parseObject(respJson, SaResp.class);
        log.info("SA返回数据转换对象：{}", saResp.toString());
        if (saResp.getErrorMsgId() != 0) {
            throw new BusinessException(1201, saResp.getErrorMsg());
        }

        String url = String.format("%s?username=%s&token=%s&lobby=%s&lang=%s&returnurl=%s&options=%s",
                saConfig.getOpenUrl(),
                Objects.isNull(playMode) || ACTYPE_1.equals(playMode) ? userInfoVO.getUserName() : saResp.getDisplayName(),
                saResp.getToken(),
                saConfig.getLobby(),
                language,
                backUrl,
                "defaulttable=" + gameInfo.getTableId()
        );
        //包装对象返回
        Map<String, String> resultMap = new HashMap<>();
        resultMap.put("url", url);

        return Result.success(resultMap);
    }

    /**
     * 用户登录
     *
     * @param playMode     游玩类型
     * @param currencyType 币种
     * @param userName     用户名
     * @return sa返回响应
     */
    public cn.hutool.json.JSONObject loginRequest(String playMode, String currencyType, String userName) {
        LoginSaAccountReq accountReq = new LoginSaAccountReq();
        accountReq.setMethod(LoginSaAccountReq.MethodEnum.loginRequest.getValue());
        accountReq.setKey(saConfig.getSecretKey());
        String timeFormat = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
        accountReq.setTime(timeFormat);
        accountReq.setUserName(userName);
        accountReq.setCurrencyType(currencyType);

        String baseUrl = saConfig.getBaseUrl();
        String des = saConfig.getDES();
        String md5 = saConfig.getMD5();

        String param;
        String respXmlName;
        //判断是真钱登录还是试玩登录
        if (Objects.isNull(playMode) || ACTYPE_1.equals(playMode)) {
            respXmlName = "LoginRequestResponse";
            param = String.format("method=%s&Key=%s&Time=%s&Username=%s&CurrencyType=%s",
                    LoginSaAccountReq.MethodEnum.loginRequest.getValue(),
                    accountReq.getKey(),
                    accountReq.getTime(),
                    accountReq.getUserName(),
                    accountReq.getCurrencyType()
            );
        } else {
            respXmlName = "LoginRequestTryToPlayResponse";
            param = String.format("method=%s&Key=%s&Time=%s&amount=%s&CurrencyType=%s",
                    LoginSaAccountReq.MethodEnum.loginRequestForFun.getValue(),
                    accountReq.getKey(),
                    accountReq.getTime(),
                    BigDecimal.ZERO,
                    accountReq.getCurrencyType()
            );
        }

        //加密后的密文 和 md5
        String q = DESencrypt(param, des);
        String key = buildMD5(param, md5, timeFormat, accountReq.getKey());
        log.info("sa 请求url:{},请求参数:{},加密参数:q={},s={}", baseUrl, param, q, key);
        HttpResponse execute = HttpRequest.post(baseUrl).form("q", q).form("s", key).execute();

        log.info("sa 请求的结果：{}", execute.body());
        int httpStatus = execute.getStatus();
        if (httpStatus != 200) {
            log.error("sa 请求失败！httpStatus={},body={}", httpStatus, execute.body());
            throw new BusinessException("Failed to get ag game URL, HTTP status: " + httpStatus);
        }
        cn.hutool.json.JSONObject xmlJson = XML.toJSONObject(execute.body());
        return xmlJson.getJSONObject(respXmlName);
    }


    /**
     * des加密
     *
     * @param qs  加密语句
     * @param des 加密密钥
     * @return 加密后的密文
     */
    public static String DESencrypt(String qs, String des) {
        try {

            // encryptKey
            byte[] encryptKey = des.getBytes();
            KeySpec keySpec = new DESKeySpec(encryptKey);
            SecretKey myDesKey = SecretKeyFactory.getInstance("DES").generateSecret(keySpec);
            IvParameterSpec iv = new IvParameterSpec(encryptKey);

            Cipher desCipher;
            // Create the cipher
            desCipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
            // Initialize the cipher for encryption
            desCipher.init(Cipher.ENCRYPT_MODE, myDesKey, iv);

            //sensitive information
            byte[] text = qs.getBytes();

            // Encrypt the text
            byte[] textEncrypted = desCipher.doFinal(text);
            return Base64.getEncoder().encodeToString(textEncrypted);

        } catch (NoSuchAlgorithmException | NoSuchPaddingException |
                InvalidKeyException | InvalidKeySpecException |
                IllegalBlockSizeException | InvalidAlgorithmParameterException |
                BadPaddingException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 构建md5 密文
     *
     * @param qs        查询语句
     * @param md5Key    密文key
     * @param time      时间
     * @param secretKey 私钥
     * @return md5密文
     */
    public static String buildMD5(String qs, String md5Key, String time, String secretKey) {
        try {
            String input = qs + md5Key + time + secretKey;
            // Static getInstance method is called with hashing MD5
            MessageDigest md = MessageDigest.getInstance("MD5");
            // digest() method is called to calculate message digest
            //  of an input digest() return array of byte
            byte[] messageDigest = md.digest(input.getBytes());
            // Convert byte array into signum representation
            BigInteger no = new BigInteger(1, messageDigest);
            // Convert message digest into hex value
            StringBuilder hashtext = new StringBuilder(no.toString(16));
            while (hashtext.length() < 32) {
                hashtext.insert(0, "0");
            }
            return hashtext.toString();
        }

        // For specifying wrong message digest algorithms
        catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }

    //插入注单子表
    private void saveOrderItem(BalanceDTO changeBalance, List<PayoutDetails> details, String currency, Integer
            orderId) {
        List<OrderItemVO> itemList = new ArrayList<>();
        //注单详情
        for (PayoutDetails detail : details) {
            OrderItemVO itemVO = new OrderItemVO();
            itemVO.setCasinoOrderId(orderId);
            itemVO.setOrderNo(detail.getBetid().toString());
            itemVO.setTransactionId(detail.getTxnid() + "_" + itemVO.getOrderNo());
            itemVO.setUserId(changeBalance.getUserId());
            itemVO.setAmount(detail.getBetamount());
            itemVO.setEffectiveAmount(detail.getRolling());
            itemVO.setPayout(detail.getResultamount());
            //计算usd币种的金额
            if (detail.getBetamount().compareTo(BigDecimal.ZERO) > 0) {
                var usdAmount = rollingRankingService.getRate(currency);
                BigDecimal bigDecimal = usdAmount.get();
                itemVO.setUsdPayout(bigDecimal.multiply(detail.getBetamount()));
            }
            itemVO.setBetType(detail.getBettype().toString());
            itemList.add(itemVO);
        }
        orderItemMapper.addAll(itemList);
    }

    /**
     * 存储body的格式处理
     *
     * @param transactionId 交易id
     * @param amount        金额
     * @param userId        用户id
     * @param currency      币种
     * @param gameId        游戏id
     * @param gameType      游戏类型
     * @param tableId       桌台
     * @return bodyJsonStr
     */
    private String setBodyJson(String transactionId, BigDecimal amount, String userId, String currency, String
            gameId, String gameType, String tableId) {
        //为了保持一致,存储body的格式要根据evo格式处理
        JSONObject bodyJson = new JSONObject();
        JSONObject transactionJson = new JSONObject();
        JSONObject gameJson = new JSONObject();
        JSONObject detailsJson = new JSONObject();
        JSONObject tableJson = new JSONObject();

        transactionJson.put("id", transactionId);
        transactionJson.put("refId", transactionId);
        transactionJson.put("amount", amount);

        tableJson.put("id", tableId);
        detailsJson.put("table", tableJson);
        gameJson.put("details", detailsJson);
        gameJson.put("type", gameType);
        gameJson.put("id", gameId);

        bodyJson.put("userId", userId);
        bodyJson.put("currency", currency);
        bodyJson.put("transaction", transactionJson);
        bodyJson.put("game", gameJson);
        return bodyJson.toJSONString();
    }

    /**
     * 解密第三方的密文
     *
     * @param ciphertext 密文
     * @param des        解密私钥
     * @return 返回解密后的明文
     */
    public String desCbc(String ciphertext, String des) {
        String deCodedStr = java.net.URLDecoder.decode(ciphertext, StandardCharsets.UTF_8);
        String decoded = null;
        try {
            // encryptKey
            byte[] encryptKey = des.getBytes();
            KeySpec keySpec = new DESKeySpec(encryptKey);
            SecretKey myDesKey = SecretKeyFactory.getInstance("DES").generateSecret(keySpec);
            IvParameterSpec iv = new IvParameterSpec(encryptKey);

            Cipher desCipher;

            // Create the cipher
            desCipher = Cipher.getInstance("DES/CBC/PKCS5Padding");

            byte[] text = Base64.getDecoder().decode(deCodedStr.replaceAll(" ", "+").getBytes());
            // Initialize the same cipher for decryption
            desCipher.init(Cipher.DECRYPT_MODE, myDesKey, iv);

            //Decrypt the text
            byte[] textDecrypted = desCipher.doFinal(text);

            decoded = new String(textDecrypted);

        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (NoSuchPaddingException e) {
            e.printStackTrace();
        } catch (InvalidKeyException e) {
            e.printStackTrace();
        } catch (InvalidKeySpecException e) {
            e.printStackTrace();
        } catch (InvalidAlgorithmParameterException | IllegalBlockSizeException | BadPaddingException e) {
            e.printStackTrace();
        }
        return decoded;
    }

    public static JSONObject paramToJson(String paramStr) {
        JSONObject paramJson = new JSONObject();
        String[] paramArray = paramStr.split("&");
        for (String param : paramArray) {
            String[] split = param.split("=");
            paramJson.put(split[0], split[1]);
        }
        return paramJson;
    }

//    public static void main(String[] args) throws IllegalBlockSizeException, BadPaddingException, IllegalAccessException {
//        LoginSaAccountReq req = new LoginSaAccountReq();
//        req.setMethod("LoginRequestForFun");
//        req.setKey("A0E34D9A4E814B4AA5588D9FFFFFA844");
//        req.setTime("20240603152959");
//        req.setUserName("chris1");
//        req.setCurrencyType("USDT");
//        String qs = String.format("method=%s&Key=%s&Time=%s&Amount=%s&CurrencyType=%s", req.getMethod(), req.getKey(), req.getTime(), BigDecimal.ZERO, req.getCurrencyType());
//        String deSencrypt = DESencrypt(qs, "g9G16nTs");
//        String md5 = buildMD5(qs, "GgaIMaiNNtg", "20240603152959", "A0E34D9A4E814B4AA5588D9FFFFFA844");
//        System.out.println(qs);
//        System.out.println(deSencrypt);
//        System.out.println(md5);
//        JSONObject jsonObject = new JSONObject();
//        jsonObject.put("username","1");
//        jsonObject.put("currency","1");
//        GetUserBalanceReq balanceReq = JSONUtil.toBean(jsonObject.toJSONString(), GetUserBalanceReq.class);
//        System.out.println(balanceReq);
//    }

    public static void main(String[] args) {
        //加密main方法
        try {
            byte[] encryptKey = "g9G16nTs".getBytes(); // encryptKey
            KeySpec keySpec = new DESKeySpec(encryptKey);
            SecretKey myDesKey = SecretKeyFactory.getInstance("DES").generateSecret(keySpec);
            IvParameterSpec iv = new IvParameterSpec(encryptKey);
            KeyGenerator keygenerator = KeyGenerator.getInstance("DES");
            Cipher desCipher;
            // Create the cipher
            desCipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
            // Initialize the cipher for encryption
            desCipher.init(Cipher.ENCRYPT_MODE, myDesKey, iv);

            //sensitive information
            String source = "username=chris01&currency=USDT&amount=18.45&txnid=1833724&gametype=bac&Payouttime=2024-06-25 23:48:39&timestamp=2024-06-25 23:50:00.947&rolling=4.05&gameid=27695898996736&hostid=907&retry=0&payoutdetails={\"betlist\":[{\"betid\":31151467,\"bettype\":2,\"betamount\":1,\"resultamount\":0.95,\"txnid\":1833723,\"betsource\":2640,\"rolling\":0.05},{\"betid\":31151468,\"bettype\":4,\"betamount\":1,\"resultamount\":11,\"txnid\":1833723,\"betsource\":2640,\"rolling\":1},{\"betid\":31151469,\"bettype\":37,\"betamount\":1,\"resultamount\":3.5,\"txnid\":1833723,\"betsource\":2640,\"rolling\":1},{\"betid\":31151464,\"bettype\":1,\"betamount\":1,\"resultamount\":-1,\"txnid\":1833722,\"betsource\":2640,\"rolling\":0},{\"betid\":31151465,\"bettype\":3,\"betamount\":1,\"resultamount\":-1,\"txnid\":1833722,\"betsource\":2640,\"rolling\":1},{\"betid\":31151466,\"bettype\":36,\"betamount\":1,\"resultamount\":-1,\"txnid\":1833722,\"betsource\":2640,\"rolling\":1}]}";
            byte[] text = source.getBytes();

            System.out.println("Text [Byte Format] : " + text);
            System.out.println("Text : " + new String(text));

            // Encrypt the text
            byte[] textEncrypted = desCipher.doFinal(text);
            String t = Base64.getEncoder().encodeToString(textEncrypted);

            System.out.println("Text Encryted [Byte Format] : " + textEncrypted);
            System.out.println("Text Encryted : " + t);

            // Initialize the same cipher for decryption
            desCipher.init(Cipher.DECRYPT_MODE, myDesKey, iv);

            // Decrypt the text
            byte[] textDecrypted = desCipher.doFinal(textEncrypted);

            System.out.println("Text Decryted : " + new String(textDecrypted));

        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (NoSuchPaddingException e) {
            e.printStackTrace();
        } catch (InvalidKeyException e) {
            e.printStackTrace();
        } catch (InvalidKeySpecException e) {
            e.printStackTrace();
        } catch (IllegalBlockSizeException e) {
            e.printStackTrace();
        } catch (InvalidAlgorithmParameterException e) {
            e.printStackTrace();
        } catch (BadPaddingException e) {
            e.printStackTrace();
        }

    }

// public static void main(String[] args) {
//         解密main方法
//        String deCodedStr = java.net.URLDecoder.decode("MDQGx7yYdmYWrS+Y0WeG0sYGt+t+4kLi3AeUWMSq9I8=", StandardCharsets.UTF_8);
//        String decoded = null;
//        try {
//            // encryptKey
//            byte[] encryptKey = "g9G16nTs".getBytes();
//            KeySpec keySpec = new DESKeySpec(encryptKey);
//            SecretKey myDesKey = SecretKeyFactory.getInstance("DES").generateSecret(keySpec);
//            IvParameterSpec iv = new IvParameterSpec(encryptKey);
//
//            Cipher desCipher;
//
//            // Create the cipher
//            desCipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
//
//            byte[] text = Base64.getDecoder().decode(deCodedStr.replaceAll(" ","+").getBytes());
//            // Initialize the same cipher for decryption
//            desCipher.init(Cipher.DECRYPT_MODE, myDesKey, iv);
//
//            //Decrypt the text
//            byte[] textDecrypted = desCipher.doFinal(text);
//
//            decoded = new String(textDecrypted);
//
//        } catch (NoSuchAlgorithmException e) {
//            e.printStackTrace();
//        } catch (NoSuchPaddingException e) {
//            e.printStackTrace();
//        } catch (InvalidKeyException e) {
//            e.printStackTrace();
//        } catch (InvalidKeySpecException e) {
//            e.printStackTrace();
//        } catch (InvalidAlgorithmParameterException | IllegalBlockSizeException | BadPaddingException e) {
//            e.printStackTrace();
//        }
//        System.out.println(decoded);
//    }

}
