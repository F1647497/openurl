package com.uponly.casino.common.api;


/**
 * 枚举了一些常用API操作码
 */

public enum ResultCode implements IErrorCode {

    SUCCESS(0, "success"),

    GAME_CLOSE(201, "游戏维护中，请稍后再试"),

    BAD_REQUEST(400, "请求失败"),
    NOT_FOUND(404, "未找到请求的资源"),
    METHOD_NOT_ALLOWED(405, "请求方式不支持"),
    PROVIDER_NOT_FOUND(407, "can't find provider"),

    UNAUTHORIZED(401, "暂未登录或token已经过期"),
    FORBIDDEN(403, "没有相关权限"),
    VALIDATE_USER_NOT_FOUND(406, "用户不存在"),
    VALIDATE_FAILED(408, "参数检验失败"),
    VALIDATE_REGION_NOT_SUPPORT(409, "该游戏不支持您账号的地区"),
    TOMANY_REQUEST_ERROR(429, "后端服务触发流控"),

    INTERNAL_SERVER_ERROR(500, "操作失败"),
    BAD_GATEWAY(502, "网关服务异常"),

    AUTHORIZATION_HEADER_IS_EMPTY(600, "请求头中的token为空"),
    GET_TOKEN_KEY_ERROR(601, "远程获取TokenKey异常"),
    GEN_PUBLIC_KEY_ERROR(602, "生成公钥异常"),
    JWT_TOKEN_EXPIRE(603, "token校验异常"),
    BACKGROUND_DEGRADE_ERROR(604, "后端服务触发降级"),

    WALLET_REFUSE(700, "钱包拒绝加钱"),


    ;

    private final int code;
    private final String message;

    ResultCode(int code, String message) {
        this.code = code;
        this.message = message;
    }

    @Override
    public int getCode() {
        return code;
    }

    @Override
    public String getMessage() {
        return message;
    }

}
