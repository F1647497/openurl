package com.uponly.casino.interceptor.kafka;

import com.alibaba.fastjson2.JSON;

public class KafkaMessageHelper {
    public static final String CASINO_MESSAGE_TYPE = "tochannel";

    /**
     * @param type    消息类型
     * @param data    消息数据
     * @param channel casino_channel_%s region
     * @return json string
     */
    public static String toJsonString(String type, Object data, String channel) {
        return JSON.toJSONString(KafkaDataMessage.builder()
                .messageType(CASINO_MESSAGE_TYPE)
                .messageBody(KafkaDataMessage.MessageBody.builder()
                        .channel(channel)
                        .data(KafkaDataMessage.Body.builder().type(type).data(data).build())
                        .build())
                .build());
    }

    /**
     * @param body 上报的活动消息数据
     * @return json string
     */
    public static String toActivityString(String messageType, KafkaDataMessage.ActivityMessage body) {
        var message = KafkaDataMessage.ActivityMessage.builder()
                .messageType(messageType)
                .messageBody(body)
                .build();
        System.out.println("message: " + message);
        return JSON.toJSONString(message);
    }

    public enum TopicEnum {
        MSG_ACTIVITY_TOPIC("msg.activity"),
        EVENT_ADMIN_TOPIC("event.admin"),
        EVENT_WS_TOPIC("event.ws");

        private String topic;

        private TopicEnum(String topic) {
            this.topic = topic;
        }

        public String getTopic() {
            return this.topic;
        }

        public static TopicEnum fromString(String topic) {
            for (TopicEnum topicEnum : TopicEnum.values()) {
                if (topicEnum.getTopic().equals(topic)) {
                    return topicEnum;
                }
            }
            return null;
        }
    }
}
