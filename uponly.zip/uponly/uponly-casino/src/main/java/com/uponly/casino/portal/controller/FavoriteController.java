package com.uponly.casino.portal.controller;


import com.uponly.casino.admin.service.EntranceService;
import com.uponly.casino.mapper.GameMapper;
import com.uponly.casino.portal.dto.FavoriteDTO;
import com.uponly.casino.portal.service.FavoriteService;
import com.uponly.casino.common.api.Result;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@Tag(name = "FavoriteController", description = "收藏游戏")
@RequestMapping("/portal/favorite")
@Slf4j
public class FavoriteController {
    @Autowired
    private FavoriteService favoriteService;

    @Autowired
    GameMapper gameMapper;

    @Autowired
    EntranceService entranceService;

    @Operation(summary = "收藏游戏入口")
    @RequestMapping(value = "/add", method = RequestMethod.POST)
    @ResponseBody
    public Result<String> add(@RequestBody FavoriteDTO favoriteDTO,
                              @RequestHeader("uid") Long uid) {
        if (uid.equals(0L)) {
            return Result.fail("用户未登入");
        }
        try {
            List<Long> list = entranceService.searchAllGameEid("lobby");
            //   System.out.println("list = " + list);
            favoriteDTO.setUserId(uid);
            int totalAddCount = 0;
            // 判断是否已存在
            boolean isExist = favoriteService.exists(favoriteDTO);
            if (list.contains(favoriteDTO.getEid())) {
                if (isExist) {
                    return Result.fail("游戏入口已收藏");
                }
                for (Long eid : list) {
                        FavoriteDTO favoriteDTONew = new FavoriteDTO();
                        favoriteDTONew.setEid(eid);
                        favoriteDTONew.setUserId(uid);
                        favoriteService.add(favoriteDTONew);
                        if (favoriteDTONew.getId() > 0){
                            totalAddCount++;
                        }
                    }

                return Result.success("共收藏"+totalAddCount+"条入口成功");
            } else {
                if (isExist) {
                    return Result.fail("游戏入口已收藏");
                }
                favoriteService.add(favoriteDTO);
                if (favoriteDTO.getId() > 0) {
                    return Result.success("游戏入口收藏成功");
                }
            }
        } catch (Exception e) {
            log.error("游戏入口收藏游戏失败", e);
            return Result.fail("游戏入口收藏游戏失败", e.getMessage());
        }
        return null;
    }

    @Operation(summary = "取消收藏游戏入口")
    @RequestMapping(value = "/delete", method = RequestMethod.POST)
    @ResponseBody
    public Result<String> delete(@RequestBody FavoriteDTO favoriteDTO,
                                 @RequestHeader("uid") Long uid) {
        if (uid.equals(0L)) {
            return Result.fail("用户未登入");
        }
        try {
            List<Long> list = entranceService.searchAllGameEid("lobby");
            favoriteDTO.setUserId(uid);
            int totalDeleteCount = 0;
            if (list.contains(favoriteDTO.getEid())) {
                for (Long eid : list) {
                    FavoriteDTO favoriteDTONew = new FavoriteDTO();
                    favoriteDTONew.setEid(eid);
                    favoriteDTONew.setUserId(uid);
                    int deleteCount = favoriteService.delete(favoriteDTONew);
                    totalDeleteCount += deleteCount;
                }
                return Result.success("共取消"+totalDeleteCount+"条入口成功");
            } else {
                int deleteCount = favoriteService.delete(favoriteDTO);
                if (deleteCount > 0) {
                    return Result.success("取消收藏游戏入口成功");
                }
                return Result.fail("没有收藏这个游戏入口");
            }
        } catch (Exception e) {
            log.error("取消游戏入口收藏失败", e);
            return Result.fail("取消游戏入口收藏失败", e.getMessage());
        }
    }
}
