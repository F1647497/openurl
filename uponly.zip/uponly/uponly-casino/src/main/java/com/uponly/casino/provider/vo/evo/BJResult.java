package com.uponly.casino.provider.vo.evo;

import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

@Data
public class BJResult {
    private Game data;


    @lombok.Data
    public static class Game {
        private String id;
        private String gameProvider;
        private String startedAt;
        private String settledAt;
        private String status;
        private String gameType;
        private Table table;
        private Dealer dealer;
        private String currency;
        private List<Participant> participants;
        private Result result;
        private BigDecimal wager;
        private BigDecimal payout;

    }

    @lombok.Data
    public static class Table {
        private String id;
        private String name;

    }

    @lombok.Data
    public static class Dealer {
        private String uid;
        private String name;

    }

    @lombok.Data
    public static class Participant {
        private String casinoId;
        private String playerId;
        private String screenName;
        private String playerGameId;
        private String sessionId;
        private String casinoSessionId;
        private String currency;
        private List<Bet> bets;
        private String playMode;
        private String channel;
        private String os;
        private String device;
        private String currencyRateVersion;

    }

    @lombok.Data
    public static class Bet {
        private String code;
        private BigDecimal stake;
        private BigDecimal payout;
        private String placedOn;
        private String transactionId;
        private String description;


    }

    @lombok.Data
    public static class Result {
        private Dealer dealer;
        private Seats seats;
        private List<String> burnedCards;

    }

    @lombok.Data
    public static class Seats {
        private Seat Seat4;
        private Seat Seat3;
        private Seat Seat2;
        private Seat Seat5;
        private Seat Seat6;
        private Seat Seat1;
        private Seat Seat7;
        private Seat Seat8;
        private Seat Seat9;

        private Seat Seat1Split;
        private Seat Seat2Split;
        private Seat Seat3Split;
        private Seat Seat4Split;
        private Seat Seat5Split;
        private Seat Seat6Split;
        private Seat Seat7Split;
        private Seat Seat8Split;
        private Seat Seat9Split;

    }

    @lombok.Data
    public static class Seat {
        private List<Decision> decisions;
        private int score;
        private String outcome;
        private List<String> cards;
        private List<String> bonusCards;

    }

    @lombok.Data
    public static class Decision {
        private String recordedAt;
        private String type;

    }
}