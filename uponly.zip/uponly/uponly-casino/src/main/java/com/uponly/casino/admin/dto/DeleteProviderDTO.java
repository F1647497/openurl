package com.uponly.casino.admin.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(title = "删除供应商DTO")
public class DeleteProviderDTO implements java.io.Serializable {

    @Schema(title = "入口id")
    private Long pid;


}