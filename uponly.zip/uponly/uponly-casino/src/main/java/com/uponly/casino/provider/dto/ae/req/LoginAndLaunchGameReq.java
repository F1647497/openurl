package com.uponly.casino.provider.dto.ae.req;

import lombok.Data;
import lombok.experimental.SuperBuilder;

@SuperBuilder
@Data
public class LoginAndLaunchGameReq {
    private String cert;
    private String agentId;
    private String userId;
    private String isMobileLogin;
    private String externalURL;
    private String platform ="SEXYBCRT";
    private String gameType="LIVE";
    private String gameCode;
    private String hall="SEXY";
    private String language;
    private String betLimit="";
    private String autoBetMode="1";
    private String isLaunchGameTable;
    private String gameTableId;
    private String currency;


    public LoginAndLaunchGameReq() {

    }

    public LoginAndLaunchGameReq(String cert,
                                 String agentId,
                                 String userId,
                                 String isMobileLogin,
                                 String externalURL,
                                 String gameCode,
                                 String language,
                                 String isLaunchGameTable,
                                 String gameTableId,
                                 String currency) {
        this.cert = cert;
        this.agentId = agentId;
        this.userId = userId;
        this.isMobileLogin = isMobileLogin;
        this.externalURL = externalURL;
        this.gameCode = gameCode;
        this.language = language;
        this.isLaunchGameTable = isLaunchGameTable;
        this.gameTableId = gameTableId;
        this.currency = currency;
    }
}
