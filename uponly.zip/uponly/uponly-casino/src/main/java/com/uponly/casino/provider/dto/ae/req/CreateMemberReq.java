package com.uponly.casino.provider.dto.ae.req;

import lombok.Data;
import lombok.experimental.SuperBuilder;

@SuperBuilder
@Data
public class CreateMemberReq {
    private String cert;
    private String agentId;
    private String userId;
    private String currency;
    private String betLimit = "";
    private String language;
    private String userName;


    public CreateMemberReq() {

    }

    public CreateMemberReq(String cert, String agentId, String userId, String currency, String betLimit, String language, String userName) {
        this.cert = cert;
        this.agentId = agentId;
        this.userId = userId;
        this.currency = currency;
        this.betLimit = betLimit;
        this.language = language;
        this.userName = userName;
    }

}
