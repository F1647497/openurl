CREATE TABLE `user_favorite` (
                                 `id` int NOT NULL AUTO_INCREMENT COMMENT 'id',
                                 `user_id` int NOT NULL COMMENT '用户id',
                                 `game_id` int NOT NULL COMMENT '收藏的游戏id,对应slot的id',
                                 `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
                                 PRIMARY KEY (`id`) USING BTREE,
                                 KEY `idx_userId` (`user_id`) USING BTREE COMMENT '使用userId获取所有游戏'
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='用户收藏游戏表';

-- 从users_collections表中迁移数据到user_favorite表
INSERT INTO user_favorite (user_id, game_id,create_time)
SELECT uc.user_id, sm.id,uc.create_time
FROM users_collections uc
         JOIN slot_management sm ON uc.game_id = sm.game_id
