alter table provider_conf
    add portal_display_name varchar(255) null comment '前台(客户端) 显示名称';
