-- slots_bet_order表增加一个`父注单id`字段
ALTER TABLE slots_bet_order
    ADD COLUMN parent_bet_id VARCHAR(100) COMMENT '三方父注单id';

UPDATE provider_conf
SET portal_display_name = provider_name;
